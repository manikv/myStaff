export * from '../actions/template-details.actions';
export * from '../reducers/template-details.reducer';
export * from '../selectors/template-details.selectors';