import { Associate } from './associate';

describe('Associate', () => {
  it('should create an instance', () => {
    expect(new Associate()).toBeTruthy();
  });
});
