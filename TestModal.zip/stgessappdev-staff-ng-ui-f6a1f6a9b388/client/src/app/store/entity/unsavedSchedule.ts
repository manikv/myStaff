import { Task } from './task'
import { Associate } from './associate'

export class UnsavedSchedule extends Object{
	task: Task;
	public associates: Associate[] = []; 
	rowIndex: number;
	constructor(associates, task, rowIndex){
		super();
		this.associates = associates;
		this.task = task;
		this.rowIndex = rowIndex;
	}
}
