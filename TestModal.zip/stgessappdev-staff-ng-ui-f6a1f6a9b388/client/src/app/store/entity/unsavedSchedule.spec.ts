import { UnsavedSchedule } from './unsavedSchedule';

describe('UnsavedSchedule', () => {
  it('should create an instance', () => {
    expect(new UnsavedSchedule([],'','')).toBeTruthy();
  });
});
