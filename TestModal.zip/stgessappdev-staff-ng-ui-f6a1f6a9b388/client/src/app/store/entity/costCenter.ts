export class CostCenter {
	team_name: string;
	team_description: string;
}
