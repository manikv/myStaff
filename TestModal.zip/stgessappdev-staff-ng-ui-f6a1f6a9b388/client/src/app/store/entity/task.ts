
import { Associate } from './associate';
export class Task {
	cost_center_name: string;
	location_name: string;
	task_name: string;
	coverage: number;
	start_time: string;
	break_start: string;
	break_end: string;
	end_time: string;
	associates: Associate[];
	taskbg: string;
	location_id: number
}
