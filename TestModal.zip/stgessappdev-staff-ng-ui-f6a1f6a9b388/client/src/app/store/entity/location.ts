export class Location {
	location_id: string;
	location_name: string;
}
