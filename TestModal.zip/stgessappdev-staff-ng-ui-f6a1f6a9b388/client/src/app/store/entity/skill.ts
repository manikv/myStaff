
export class Skill {
	name: string;
	description: string;
}
