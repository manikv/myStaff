import { Task } from './task'
export class Assignment {
	created_by: string;
	created_date: string;
	employee_id: number
	errors: null
	id: number;
	personnel_number: null
	processed_indicator: string;
	scheduled_date: string;
	shifts: Task[];
	updated_by: string;
	updated_date: string;
	wbt_id: number;
}
