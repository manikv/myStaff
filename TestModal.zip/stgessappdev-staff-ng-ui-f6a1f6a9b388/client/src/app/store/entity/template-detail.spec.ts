import { TemplateDetail } from './template-detail';

describe('TemplateDetail', () => {
  it('should create an instance', () => {
    expect(new TemplateDetail()).toBeTruthy();
  });
});
