export class TemplateDetail {
	cost_center_name: string;
	location_name: string;
	task_name: string;
	coverage: number;
	start_time: string;
	break_start: string;
	break_end: string;
	end_time: string;
	template_name: string;
	location_id: string;
	task_id: string;
	id: string;
	shifts: shifts[];
	updated?: boolean;
	department_name?: string;
}

export interface shifts{
	name: string;
	id: number;
}
