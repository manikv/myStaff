import { Template } from './template';

describe('Template', () => {
  it('should create an instance', () => {
    expect(new Template()).toBeTruthy();
  });
});
