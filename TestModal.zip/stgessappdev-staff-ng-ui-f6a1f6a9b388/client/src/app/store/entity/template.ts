export class Template {
	template_id: string;
	template_name: string;
	location_id: number;
}
