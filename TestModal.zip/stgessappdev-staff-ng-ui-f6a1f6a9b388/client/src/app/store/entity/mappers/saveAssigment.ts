import { Task } from '../task'
export class SaveAssigment extends Object{
	employee_id: number
	errors: null
	id: number;
	personnel_number: null
	processed_indicator: string;
	scheduled_date: string;
	shifts: Task[] = [];
	updated_by: string;
	updated_date: string;
	wbt_id: number;

	constructor(emp_id, emp_name, team_name, shift){
		super();
		this.employee_id = emp_id;
		this.personnel_number = emp_name;
		this.wbt_id = team_name;
		this.shifts.push(shift);
	}
}
