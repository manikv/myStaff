export class Events {
	selectedComplex: string;
	selectedWeekend: string;
	allDay: boolean;
	cls: string;
	desc: string;
	name: string;
	totAmt: number;
	totHrs: number;
	total: number;
}
