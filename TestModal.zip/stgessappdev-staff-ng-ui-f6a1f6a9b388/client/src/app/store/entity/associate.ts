export class Associate {
	complex: string;
	emp_first_name: string;
	emp_full_name: string;
	emp_id: number
	emp_last_name: string;
	emp_name: string;
	emp_status: string;
	errors: [] | null;
	home_team: string;
	job_desc: string;
	job_id: string;
	job_name: string;
	team_name: string;
	team_id: string;
}
