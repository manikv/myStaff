import { Assignment } from './Assignment';

describe('Assignment', () => {
  it('should create an instance', () => {
    expect(new Assignment()).toBeTruthy();
  });
});
