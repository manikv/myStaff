import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable, of } from 'rxjs';
import { EBSTeamService } from '@staff/shared/common/services/ebs/team.service';
import { Action } from '@ngrx/store';
import * as fromTeam from '../stores/team.state';
import { catchError, map, mergeMap } from 'rxjs/operators';
import { Globals } from '@staff/shared/common/global/global.provider';
import { CostCenter } from '@staff/store/entity/costCenter';
import { Skill } from '@staff/store/entity/skill';
@Injectable()
export class TeamEffects {

  constructor(private actions$: Actions,
    private eventBaseScheduleService: EBSTeamService,
    private globals: Globals
    ) {
  }

  @Effect()
  getCostCenters$: Observable<Action> = this.actions$.pipe(
  ofType(fromTeam.TeamActionTypes.GetTeamCostCentersLoad),
  mergeMap((action:{payload: {selectedTeam: string}}) =>
  this.eventBaseScheduleService.getTeamCostCenters(action.payload.selectedTeam).pipe(
      map((res:CostCenter[]) => {
        return new fromTeam.GetTeamCostCentersSuccess(res);
      }),
      catchError((error) =>
        of(new fromTeam.GetTeamCostCentersFail(error)))
    )
  ));

  @Effect()
  createCostCenters$: Observable<Action> = this.actions$.pipe(
  ofType(fromTeam.TeamActionTypes.CreateTeamLocation),
  mergeMap((action:{payload: {selectedTeam: string, data: {}}}) =>
  this.eventBaseScheduleService.createTeamLocation(action.payload.selectedTeam, this.globals.user_name, action.payload.data).pipe(
      map((res:CostCenter[]) => {
        return new fromTeam.CreateTeamLocationSuccess(res);
      }),
      catchError((error) =>
        of(new fromTeam.CreateTeamLocationFail(error)))
    )
  ));

  @Effect()
  getTeamSkills$: Observable<Action> = this.actions$.pipe(
  ofType(fromTeam.TeamActionTypes.GetTeamSkillsLoad),
  mergeMap((action:{payload: {selectedTeam: string}}) =>
  this.eventBaseScheduleService.getTeamSkills(action.payload.selectedTeam).pipe(
      map((res:Skill[]) => {
        return new fromTeam.GetTeamSkillsSuccess(res);
      }),
      catchError((error) =>
        of(new fromTeam.CreateTeamLocationFail(error)))
    )
  ));
}