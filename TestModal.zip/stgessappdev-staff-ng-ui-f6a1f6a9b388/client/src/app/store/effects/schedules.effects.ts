import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable, of } from 'rxjs';
import { EventBaseScheduleService } from '@staff/shared/common/services/ebs.service';
import { Action } from '@ngrx/store';
import * as fromScheduling from '../stores/scheduling.state';
import { catchError, map, mergeMap } from 'rxjs/operators';
import { Assignment } from '@staff/store/entity/assignment';

@Injectable()
export class SchedulesEffects {

  constructor(private actions$: Actions,
    private eventBaseScheduleService: EventBaseScheduleService) {
  }

  @Effect()
  getSchedules$: Observable<Action> = this.actions$.pipe(
  ofType(fromScheduling.SchedulingActionTypes.GetComplexSchedulesLoad),
  mergeMap((action:{payload: {selected_team: string, user_name: string, event_id: number, week_start: string, week_end: string}}) =>
  this.eventBaseScheduleService.getTeamScheduleAssociates(action.payload.selected_team, action.payload.user_name, action.payload.event_id, action.payload.week_start, action.payload.week_end).pipe(
      map((schedules: Assignment[]) => {
        return new fromScheduling.GetComplexSchedulesSuccess(schedules);
      }),
      catchError((error) =>
        of(new fromScheduling.GetComplexSchedulesFail(error)))
    )
  ));
}