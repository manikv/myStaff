import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable, of } from 'rxjs';
import { EBSTemplateService } from '@staff/shared/common/services/ebs/template.service';
import { Action } from '@ngrx/store';
import * as fromTemplates from '../stores/template-details.state';
import { catchError, map, mergeMap } from 'rxjs/operators';
import { Location } from '@staff/store/entity/location';
import { Template } from '@staff/store/entity/template';

@Injectable()
export class TemplateLocationsEffects {

  constructor(private actions$: Actions,
    private eventBaseScheduleService: EBSTemplateService) {
  }

  @Effect()
  getTemplates$: Observable<Action> = this.actions$.pipe(
  ofType(fromTemplates.TemplateDetailsActionTypes.GetTemplateLocationsLoad),
  mergeMap((action:{payload: {selectedTeam: string}}) =>{
    // return this.eventBaseScheduleService.getTemplateLocations(action.payload.selectedTeam).pipe(
    return this.eventBaseScheduleService.getTemplateLocations(action.payload.selectedTeam).pipe(
      map((res: [{locations: Location[],templates: Template[]}]) => {
        return new fromTemplates.GetTemplateLocationsSuccess(res);
      }),
      catchError((error) =>
        of(new fromTemplates.GetTemplateLocationsFail(error)))
    )
  }
  ));
}