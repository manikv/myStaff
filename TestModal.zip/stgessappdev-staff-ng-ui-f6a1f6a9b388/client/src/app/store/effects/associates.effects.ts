import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable, of } from 'rxjs';
import { EventBaseScheduleService } from '@staff/shared/common/services/ebs.service';
import { Action } from '@ngrx/store';
import * as fromScheduling from '../stores/scheduling.state';
import { catchError, map, mergeMap } from 'rxjs/operators';
import { Associate } from '@staff/store/entity/associate';

@Injectable()
export class AssociatesEffects {

  constructor(private actions$: Actions,
    private eventBaseScheduleService: EventBaseScheduleService) {
  }

  @Effect()
  getAssociates$: Observable<Action> = this.actions$.pipe(
  ofType(fromScheduling.SchedulingActionTypes.GetComplexAssociatesLoad),
  mergeMap((action:{payload: string}) =>
    this.eventBaseScheduleService.getTeamAssociates(action.payload).pipe(
      map((associates: Associate[]) => {
        return new fromScheduling.GetComplexAssociatesSuccess(associates);
      }),
      catchError((error) =>
        of(new fromScheduling.GetComplexAssociatesFail(error)))
    )
  ));
}