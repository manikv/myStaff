import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable, of } from 'rxjs';
import { EventBaseScheduleService } from '@staff/shared/common/services/ebs.service';
import { Action } from '@ngrx/store';
import * as fromScheduling from '../stores/scheduling.state';
import { catchError, map, mergeMap } from 'rxjs/operators';
import { Task } from '@staff/store/entity/task';
import { Globals } from '@staff/shared/common/global/global.provider';
@Injectable()
export class TasksEffects {

  constructor(private actions$: Actions,
    private eventBaseScheduleService: EventBaseScheduleService,
    public globals: Globals) {
  }

  @Effect()
  getTasks$: Observable<Action> = this.actions$.pipe(
  ofType(fromScheduling.SchedulingActionTypes.GetComplexTasksLoad),
  mergeMap((action:{payload: {selected_team: string, event_id: string}}) =>
    this.eventBaseScheduleService.getTeamTemplateHistory(action.payload.selected_team, action.payload.event_id).pipe(
      map((res: any) => {
        let _this = this;
        res.data[0].tasks = res.data[0].tasks.filter((t) => {
          t.associates = new Array();
          t.taskbg = _this.globals.random_bg_color();
          return t.task_id !== 10006;
        });
        return new fromScheduling.GetComplexTasksSuccess(res.data[0].tasks);
      }),
      catchError((error) =>
        of(new fromScheduling.GetComplexTasksFail(error)))
    )
  ));

  @Effect()
  CreateScheduleForAssociates$: Observable<Action> = this.actions$.pipe(
    ofType(fromScheduling.SchedulingActionTypes.CreateScheduleForAssociates),
    mergeMap((action: { payload: { selectedTeam: string, userName: string, data: {} } }) =>
      this.eventBaseScheduleService.createScheduleForAssociates(action.payload.selectedTeam, action.payload.userName, action.payload.data).pipe(
        map((res: any) => {
          return new fromScheduling.CreateScheduleForAssociatesSuccess(res);
        }),
        catchError((error) =>
          of(new fromScheduling.CreateScheduleForAssociatesFail(error)))
      )
    ));
}