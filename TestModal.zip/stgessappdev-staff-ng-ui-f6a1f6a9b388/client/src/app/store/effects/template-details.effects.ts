import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Observable, of } from 'rxjs';
import { EBSTemplateService } from '@staff/shared/common/services/ebs/template.service';
import { Action } from '@ngrx/store';
import * as fromTemplates from '../stores/template-details.state';
import { catchError, map, mergeMap } from 'rxjs/operators';
import { TemplateDetail } from '@staff/store/entity/template-detail';
import { Template } from '@staff/store/entity/template';

@Injectable()
export class TemplatesEffects {

  constructor(private actions$: Actions,
    private eventBaseScheduleService: EBSTemplateService) {
  }

  @Effect()
  getTemplates$: Observable<Action> = this.actions$.pipe(
  ofType(fromTemplates.TemplateDetailsActionTypes.GetTemplateDetailsLoad),
  mergeMap((action:{payload: {selectedTeam: string, selectedTemplateId:string}}) =>{
    return this.eventBaseScheduleService.getTemplateDetailsData(action.payload.selectedTeam, action.payload.selectedTemplateId).pipe(
      map((templateDetails: [{tasks: TemplateDetail[]}]) => {
        return new fromTemplates.GetTemplateDetailSuccess(templateDetails);
      }),
      catchError((error) =>
        of(new fromTemplates.GetTemplateDetailFail(error)))
    )
  }
  ));

  @Effect()
  getTaskCoverage$: Observable<Action> = this.actions$.pipe(
  ofType(fromTemplates.TemplateDetailsActionTypes.GetTaskCoverage),
  mergeMap((action:{payload: {selectedTask: string, selectedTaskTeam: string}}) =>{
    return this.eventBaseScheduleService.getTemplateCoverage(action.payload.selectedTaskTeam, action.payload.selectedTask).pipe(
      map((templateDetails: Template[]) => {
        return new fromTemplates.GetTaskCoverageSuccess(templateDetails);
      }),
      catchError((error) =>
        of(new fromTemplates.GetTaskCoverageFail(error)))
    )
  }
  ));
}