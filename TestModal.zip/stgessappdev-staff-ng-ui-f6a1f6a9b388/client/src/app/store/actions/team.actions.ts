import { Action } from '@ngrx/store';
import { HttpErrorResponse } from '@angular/common/http';
import { CostCenter } from '@staff/store/entity/costCenter';
import { Skill } from '@staff/store/entity/skill';

export enum TeamActionTypes {
  GetTeamCostCentersLoad = '[EBS] Get Team CostCenters',
  GetTeamCostCentersSuccess = '[EBS] Get Team CostCenters Success',
  GetTeamCostCentersFail = '[EBS] Get Team CostCenters Fail',
  CreateTeamLocation = '[EBS] Create Team Location',
  CreateTeamLocationSuccess = '[EBS] Create Team Location Success',
  CreateTeamLocationFail = '[EBS] Create Team Location Fail',
  GetTeamSkillsLoad = '[EBS] Get Team Skills',
  GetTeamSkillsSuccess = '[EBS] Get Team Skills Success',
  GetTeamSkillsFail = '[EBS] Get Team Skills Fail',
}

export class GetTeamCostCentersLoad implements Action {
  public readonly type = TeamActionTypes.GetTeamCostCentersLoad;
  constructor(public payload: {selectedTeam: string}){ }
}

export class GetTeamCostCentersSuccess implements Action {
  public readonly type = TeamActionTypes.GetTeamCostCentersSuccess;

  constructor(public payload: CostCenter[]) { }
}

export class GetTeamCostCentersFail implements Action {
  public readonly type = TeamActionTypes.GetTeamCostCentersFail;

  constructor(public error: HttpErrorResponse) { }
}

export class CreateTeamLocation implements Action {
  public readonly type = TeamActionTypes.CreateTeamLocation;
  constructor(public payload: {selectedTeam: string, data: {}}){ }
}

export class CreateTeamLocationSuccess implements Action {
  public readonly type = TeamActionTypes.CreateTeamLocationSuccess;

  constructor(public payload: CostCenter[]) { }
}

export class CreateTeamLocationFail implements Action {
  public readonly type = TeamActionTypes.CreateTeamLocationFail;

  constructor(public error: HttpErrorResponse) { }
}

export class GetTeamSkillsLoad implements Action {
  public readonly type = TeamActionTypes.GetTeamSkillsLoad;
  constructor(public payload: {selectedTeam: string}){ }
}

export class GetTeamSkillsSuccess implements Action {
  public readonly type = TeamActionTypes.GetTeamSkillsSuccess;

  constructor(public payload: Skill[]) { }
}

export class GetTeamSkillsFail implements Action {
  public readonly type = TeamActionTypes.GetTeamSkillsFail;

  constructor(public error: HttpErrorResponse) { }
}

export type TeamActions = GetTeamCostCentersLoad | GetTeamCostCentersSuccess | GetTeamCostCentersFail | CreateTeamLocation | CreateTeamLocationSuccess | CreateTeamLocationFail | GetTeamSkillsLoad | GetTeamSkillsSuccess | GetTeamSkillsFail;