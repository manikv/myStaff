import { createAction, props } from '@ngrx/store';
import { Events } from '@staff/store/entity/events';

export const loadEventss = createAction(
  '[Events] Load Events'
);

export const loadEventssSuccess = createAction(
  '[Events] Load Events Success',
  props<{ data: Events }>()
);

export const loadEventssFailure = createAction(
  '[Events] Load Events Failure',
  props<{ error: Events }>()
);
