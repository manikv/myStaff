import { Action } from '@ngrx/store';
import { TemplateDetail } from '@staff/store/entity/template-detail';
import { HttpErrorResponse } from '@angular/common/http';
import { Location } from '@staff/store/entity/location';
import { Template } from '@staff/store/entity/template';

export enum TemplateDetailsActionTypes {
  GetTemplateDetailsLoad = '[EBS] Get TemplateDetails',
  GetTemplateDetailsSuccess = '[EBS] Get TemplateDetails Success',
  GetTemplateDetailsFail = '[EBS] Get TemplateDetails Fail',
  GetTemplateLocationsLoad = '[EBS] Get TemplateLocations',
  GetTemplateLocationsSuccess = '[EBS] Get TemplateLocations Success',
  GetTemplateLocationsFail = '[EBS] Get TemplateLocations Fail',
  GetTaskCoverage = '[EBS] Get TaskCoverage',
  GetTaskCoverageSuccess = '[EBS] Get TaskCoverage Success',
  GetTaskCoverageFail = '[EBS] Get TaskCoverage Fail',
  ResetSelectedTask = '[EBS] Reset Selected Task ',
}

export class GetTemplateDetailsLoad implements Action {
  public readonly type = TemplateDetailsActionTypes.GetTemplateDetailsLoad;
  constructor(public payload: {selectedTeam: string; selectedTemplateId: string}){ }
}

export class GetTemplateDetailSuccess implements Action {
  public readonly type = TemplateDetailsActionTypes.GetTemplateDetailsSuccess;

  constructor(public payload: [{tasks: TemplateDetail[]}]) { }
}

export class GetTemplateDetailFail implements Action {
  public readonly type = TemplateDetailsActionTypes.GetTemplateDetailsFail;

  constructor(public error: HttpErrorResponse) { }
}

export class GetTemplateLocationsLoad implements Action {
  public readonly type = TemplateDetailsActionTypes.GetTemplateLocationsLoad;
  constructor(public payload: {selectedTeam: string}){ }
}

export class GetTemplateLocationsSuccess implements Action {
  public readonly type = TemplateDetailsActionTypes.GetTemplateLocationsSuccess;

  constructor(public payload: [{locations: Location[], templates: Template[]}]) { }
}

export class GetTemplateLocationsFail implements Action {
  public readonly type = TemplateDetailsActionTypes.GetTemplateLocationsFail;

  constructor(public error: HttpErrorResponse) { }
}

export class GetTaskCoverage implements Action {
  public readonly type = TemplateDetailsActionTypes.GetTaskCoverage;
  constructor(public payload: {selectedTask: string, selectedTaskTeam: string}){ }
}

export class GetTaskCoverageSuccess implements Action {
  public readonly type = TemplateDetailsActionTypes.GetTaskCoverageSuccess;

  constructor(public payload: Template[]) { }
}

export class GetTaskCoverageFail implements Action {
  public readonly type = TemplateDetailsActionTypes.GetTaskCoverageFail;

  constructor(public error: HttpErrorResponse) { }
}

export class ResetSelectedTask implements Action {
  public readonly type = TemplateDetailsActionTypes.ResetSelectedTask;
  constructor(){ }
}

export type TemplateDetailsActions = GetTemplateDetailsLoad | GetTemplateDetailSuccess | GetTemplateDetailFail | GetTemplateLocationsLoad | GetTemplateLocationsSuccess | GetTemplateLocationsFail | GetTaskCoverage | GetTaskCoverageSuccess | GetTaskCoverageFail | ResetSelectedTask;