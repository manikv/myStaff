import { Action } from '@ngrx/store';
import { Task } from '@staff/store/entity/task';
import { Assignment } from '@staff/store/entity/assignment';
import { Associate } from '@staff/store/entity/associate';
import { UnsavedSchedule } from '@staff/store/entity/unsavedSchedule';
import { HttpErrorResponse } from '@angular/common/http';

export enum SchedulingActionTypes {
  GetComplexAssociatesLoad = '[EBS] Get ComplexAssociates',
  GetComplexAssociatesSuccess = '[EBS] Get ComplexAssociates Success',
  GetComplexAssociatesFail = '[EBS] Get ComplexAssociates Fail',
  SetComplexAssociates = '[EBS] Set ComplexAssociates',
  GetComplexAssociatesLoaded = '[EBS] Get ComplexAssociates Loaded',
  GetComplexSchedulesLoad = '[EBS] Get ComplexSchedules',
  GetComplexSchedulesSuccess = '[EBS] Get ComplexSchedules Success',
  GetComplexSchedulesFail = '[EBS] Get ComplexSchedules Fail',
  SetComplexSchedules = '[EBS] Set ComplexSchedules',
  GetComplexSchedulesLoaded = '[EBS] Get ComplexSchedules Loaded',
  GetComplexTasksLoad = '[EBS] Get ComplexTasks',
  GetComplexTasksSuccess = '[EBS] Get ComplexTasks Success',
  GetComplexTasksFail = '[EBS] Get ComplexTasks Fail',
  SetComplexTasks = '[EBS] Set ComplexTasks',
  GetComplexTasksLoaded = '[EBS] Get ComplexTasks Loaded',
  SetComplexUnsavedAssignments = '[EBS] Set ComplexUnsavedAssignments',
  GetComplexUnsavedAssignments = '[EBS] Get ComplexUnsavedAssignments Loaded',
  PopComplexUnsavedAssignments = '[EBS] Pop ComplexUnsavedAssignments',
  CreateScheduleForAssociates = '[EBS] Create/Save Schedule',
  CreateScheduleForAssociatesSuccess = '[EBS] Create/Save Schedule',
  CreateScheduleForAssociatesFail = '[EBS] Create/Save Schedule',
  ResetScheduleTaskAssociate = '[EBS] Reset Schedule Task and Associate'
}

/* Associates Actions */
export class GetComplexAssociatesLoad implements Action {
  public readonly type = SchedulingActionTypes.GetComplexAssociatesLoad;
  constructor(public payload: string) { }
}

export class GetComplexAssociatesSuccess implements Action {
  public readonly type = SchedulingActionTypes.GetComplexAssociatesSuccess;

  constructor(public payload: Associate[]) { }
}

export class GetComplexAssociatesFail implements Action {
  public readonly type = SchedulingActionTypes.GetComplexAssociatesFail;

  constructor(public error: HttpErrorResponse) { }
}

export class GetComplexAssociatesLoaded implements Action {
  public readonly type = SchedulingActionTypes.GetComplexAssociatesLoaded;
}

export class SetComplexAssociates implements Action {
  public readonly type = SchedulingActionTypes.SetComplexAssociates;

  constructor(public payload: Associate[]) { }
}

/* Schedules Actions */

export class GetComplexSchedulesLoad implements Action {
  public readonly type = SchedulingActionTypes.GetComplexSchedulesLoad;
  constructor(public payload: { selected_team: string, user_name: string, event_id: number, week_start: string, week_end: string }) { }
}

export class GetComplexSchedulesSuccess implements Action {
  public readonly type = SchedulingActionTypes.GetComplexSchedulesSuccess;

  constructor(public payload: Assignment[]) { }
}

export class GetComplexSchedulesFail implements Action {
  public readonly type = SchedulingActionTypes.GetComplexSchedulesFail;

  constructor(public error: HttpErrorResponse) { }
}

export class GetComplexSchedulesLoaded implements Action {
  public readonly type = SchedulingActionTypes.GetComplexSchedulesLoaded;
}

export class SetComplexSchedules implements Action {
  public readonly type = SchedulingActionTypes.SetComplexSchedules;

  constructor(public payload: Assignment[]) { }
}

/* Task Actions */

export class GetComplexTasksLoad implements Action {
  public readonly type = SchedulingActionTypes.GetComplexTasksLoad;
  constructor(public payload: { selected_team: string, event_id: string }) { }
}

export class GetComplexTasksSuccess implements Action {
  public readonly type = SchedulingActionTypes.GetComplexTasksSuccess;

  constructor(public payload: Task[]) { }
}

export class GetComplexTasksFail implements Action {
  public readonly type = SchedulingActionTypes.GetComplexTasksFail;

  constructor(public error: HttpErrorResponse) { }
}

export class GetComplexTasksLoaded implements Action {
  public readonly type = SchedulingActionTypes.GetComplexTasksLoaded;
}

export class SetComplexTasks implements Action {
  public readonly type = SchedulingActionTypes.SetComplexTasks;

  constructor(public payload: Task[]) { }
}

/* UnsavedAssignments Actions */

export class GetComplexUnsavedAssignments implements Action {
  public readonly type = SchedulingActionTypes.GetComplexUnsavedAssignments;
}

export class SetComplexUnsavedAssignments implements Action {
  public readonly type = SchedulingActionTypes.SetComplexUnsavedAssignments;

  constructor(public payload: UnsavedSchedule) { }
}

export class PopComplexUnsavedAssignments implements Action {
  public readonly type = SchedulingActionTypes.PopComplexUnsavedAssignments;
}

/* save/create schedules Actions */

export class CreateScheduleForAssociates implements Action {
  public readonly type = SchedulingActionTypes.CreateScheduleForAssociates;
  constructor(public payload: { selectedTeam: string, userName: string, data: {} }) { }
}

export class CreateScheduleForAssociatesSuccess implements Action {
  public readonly type = SchedulingActionTypes.CreateScheduleForAssociatesSuccess;

  constructor(public payload: Assignment[]) { }
}

export class CreateScheduleForAssociatesFail implements Action {
  public readonly type = SchedulingActionTypes.CreateScheduleForAssociatesFail;

  constructor(public error: HttpErrorResponse) { }
}

export class ResetScheduleTaskAssociate implements Action {
  public readonly type = SchedulingActionTypes.ResetScheduleTaskAssociate;
}


export type SchedulingActions =
  GetComplexAssociatesLoad |
  GetComplexAssociatesSuccess |
  GetComplexAssociatesFail |
  SetComplexAssociates |
  GetComplexAssociatesLoaded |
  GetComplexSchedulesLoad |
  GetComplexSchedulesSuccess |
  GetComplexSchedulesFail |
  GetComplexSchedulesLoaded |
  SetComplexSchedules |
  GetComplexTasksLoad |
  GetComplexTasksSuccess |
  GetComplexTasksFail |
  GetComplexTasksLoaded |
  SetComplexTasks |
  GetComplexUnsavedAssignments |
  SetComplexUnsavedAssignments |
  PopComplexUnsavedAssignments |
  CreateScheduleForAssociates |
  CreateScheduleForAssociatesSuccess |
  CreateScheduleForAssociatesFail |
  ResetScheduleTaskAssociate;