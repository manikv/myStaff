import * as fromEvents from './events.actions';

describe('loadEventss', () => {
  it('should return an action', () => {
    expect(fromEvents.loadEventss().type).toBe('[Events] Load Eventss');
  });
});
