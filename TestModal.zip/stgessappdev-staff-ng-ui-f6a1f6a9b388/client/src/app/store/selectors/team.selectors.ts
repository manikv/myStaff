import { createFeatureSelector, createSelector } from "@ngrx/store";
import { ITeamState } from "../stores/team.state";
 
const getTeamState = createFeatureSelector<ITeamState>('team');
 
export const allTeam = createSelector(getTeamState, (state: ITeamState) => {
  return state;
});
