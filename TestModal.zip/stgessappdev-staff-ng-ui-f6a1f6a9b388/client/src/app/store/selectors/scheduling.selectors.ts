import { createFeatureSelector, createSelector } from "@ngrx/store";
import { ISchedulingState } from "../stores/scheduling.state";
 
const getSchedulingState = createFeatureSelector<ISchedulingState>('scheduling');
 
export const allScheduling = createSelector(getSchedulingState, (state: ISchedulingState) => {
  return state;
});
