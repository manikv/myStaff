import { createFeatureSelector, createSelector } from "@ngrx/store";
import { ITemplateDetailsState } from "../stores/template-details.state";
 
const getTemplateDetailsState = createFeatureSelector<ITemplateDetailsState>('templateDetails');
 
export const allTemplateDetails = createSelector(getTemplateDetailsState, (state: ITemplateDetailsState) => {
  return state;
});
