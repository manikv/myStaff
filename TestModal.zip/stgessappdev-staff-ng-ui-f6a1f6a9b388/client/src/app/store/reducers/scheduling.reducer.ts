import { Task } from '@staff/store/entity/task';
import { Assignment } from '@staff/store/entity/assignment';
import { Associate } from '@staff/store/entity/associate';
import { UnsavedSchedule } from '@staff/store/entity/unsavedSchedule';
import { SaveAssigment } from '@staff/store/entity/mappers/saveAssigment';
import { SchedulingActionTypes, SchedulingActions } from '@staff/store/actions/scheduling.actions';
import { cloneDeep } from 'lodash';
import * as moment from 'moment';
import { act } from '@ngrx/effects';

export interface ISchedulingState {
  tasks?: Task[];
  associates?: Associate[],
  schedules?: Assignment[],
  associateInitialLoad?: boolean;
  schedulesInitialLoad?: boolean;
  tasksInitialLoad?: boolean;
  unsavedAssignments?: SaveAssigment[],
  unsavedSchedules?: UnsavedSchedule,
  unsavedAssignmentsCount?: number,
  message: string;
  conflictMessage?: string;
  createScheduleComplete?: boolean;
}

const initialState: ISchedulingState = {
  tasks: [],
  associates: [],
  associateInitialLoad: false,
  schedulesInitialLoad: false,
  schedules: [],
  tasksInitialLoad: false,
  unsavedAssignments: [],
  unsavedAssignmentsCount: 0,
  message: '',
};

export function reducer(state = initialState, action: SchedulingActions): ISchedulingState {

  switch (action.type) {
    case SchedulingActionTypes.GetComplexAssociatesLoad: {
      return {
        ...state,
        associateInitialLoad: false
      }
    }

    case SchedulingActionTypes.GetComplexAssociatesSuccess: {
      return {
        ...state,
        associates: action.payload,
        associateInitialLoad: true,
        message: 'Data fetch Successfully!'
      }
    }

    case SchedulingActionTypes.GetComplexAssociatesFail: {
      return {
        associates: [],
        associateInitialLoad: false,
        message: 'Something went wrong!'
      }
    }

    case SchedulingActionTypes.SetComplexAssociates: {
      return {
        ...state,
        associates: action.payload,
        associateInitialLoad: false,
        message: 'Data fetch Successfully!'
      }
    }

    case SchedulingActionTypes.GetComplexSchedulesLoad: {
      return {
        ...state,
        schedulesInitialLoad: false
      }
    }

    case SchedulingActionTypes.GetComplexSchedulesLoad: {
      return {
        ...state,
        schedulesInitialLoad: false
      }
    }

    case SchedulingActionTypes.GetComplexSchedulesSuccess: {
      return {
        ...state,
        schedules: action.payload,
        schedulesInitialLoad: true,
        message: 'Data fetch Successfully!'
      }
    }

    case SchedulingActionTypes.GetComplexSchedulesFail: {
      return {
        schedules: [],
        schedulesInitialLoad: false,
        message: 'Something went wrong!'
      }
    }

    case SchedulingActionTypes.SetComplexSchedules: {
      return {
        ...state,
        schedules: action.payload,
        schedulesInitialLoad: false,
        message: 'Data fetch Successfully!'
      }
    }

    case SchedulingActionTypes.GetComplexSchedulesLoaded: {
      return {
        ...state,
        schedulesInitialLoad: true
      }
    }

    case SchedulingActionTypes.GetComplexTasksLoad: {
      return {
        ...state,
        tasksInitialLoad: false
      }
    }

    case SchedulingActionTypes.GetComplexTasksSuccess: {
      return {
        ...state,
        tasks: action.payload,
        tasksInitialLoad: true,
        message: 'Data fetch Successfully!'
      }
    }

    case SchedulingActionTypes.GetComplexTasksFail: {
      return {
        tasks: [],
        tasksInitialLoad: false,
        message: 'Something went wrong!'
      }
    }

    case SchedulingActionTypes.SetComplexTasks: {
      return {
        ...state,
        tasks: action.payload,
        tasksInitialLoad: false,
        message: 'Data fetch Successfully!'
      }
    }

    case SchedulingActionTypes.GetComplexTasksLoaded: {
      return {
        ...state,
        tasksInitialLoad: true
      }
    }

    case SchedulingActionTypes.SetComplexUnsavedAssignments: {
      let unsavedAssigments = cloneDeep(state.unsavedAssignments);
      let associates_with_conflicts = [];
      const format = 'hh:mm:ss';
      let selectedAssociates = cloneDeep(action.payload.associates);
      action.payload.associates.map((a, associateIndex)=>{
        const index = unsavedAssigments.findIndex(v=>v.employee_id === a.emp_id)
        if(index == -1){
          unsavedAssigments.push(new SaveAssigment(a.emp_id,a.emp_name,a.team_id, action.payload.task));
        }else {
          let check_shift_conflict = [];
          unsavedAssigments[index].shifts.map(a=>{
            let check_shift_conflict_flag = true;
            if (moment(a.start_time, format).isBefore(moment(action.payload.task.start_time, format)) && moment(a.end_time, format).isBefore(moment(action.payload.task.end_time, format))) {
              check_shift_conflict_flag = false;
            } else if (moment(a.start_time, format).isAfter(moment(action.payload.task.start_time, format)) && moment(a.end_time, format).isAfter(moment(action.payload.task.end_time, format))) {
              check_shift_conflict_flag = false;
            }
            check_shift_conflict.push(check_shift_conflict_flag);
          });
          if(check_shift_conflict.indexOf(true) === -1){
            let task = cloneDeep(action.payload.task);
            delete task.associates;
            unsavedAssigments[index].shifts.push(task);
          }else {
            associates_with_conflicts.push(a.emp_id);
          }
        }
      });
      let conflict_users = [], conflictMessage = '';
      associates_with_conflicts.map(value=>{
        let ind = selectedAssociates.findIndex(v=> v.emp_id === value);
        conflict_users.push(selectedAssociates[ind]);
        selectedAssociates.splice(ind, 1);
      });
      if(conflict_users.length > 0){
        conflictMessage = conflict_users[0].emp_full_name + '(' + conflict_users[0].emp_name +')';
        for(let i=1;i<conflict_users.length;i++){
          if(i===(conflict_users.length-1)){
            conflictMessage = conflictMessage +' and ' + conflict_users[i].emp_full_name + '(' + conflict_users[i].emp_name +')'
          }else{
            conflictMessage = conflictMessage + ', ' + conflict_users[i].emp_full_name + '(' + conflict_users[i].emp_name +')'
          }
        }
        conflictMessage = conflictMessage + ' has a conflicts!'
      }
      return {
        ...state,
        tasksInitialLoad: false,
        associateInitialLoad: false,
        schedulesInitialLoad: false,
        unsavedSchedules: new UnsavedSchedule(selectedAssociates, action.payload.task, action.payload.rowIndex),
        unsavedAssignmentsCount: state.unsavedAssignmentsCount + selectedAssociates.length,
        unsavedAssignments: unsavedAssigments,
        conflictMessage: conflictMessage
      }
    }

    case SchedulingActionTypes.GetComplexUnsavedAssignments: {
      return {
        ...state,
        tasksInitialLoad: false,
        associateInitialLoad: false,
        schedulesInitialLoad: false,
      }
    }

    case SchedulingActionTypes.PopComplexUnsavedAssignments: {
      console.log(state);
      return {
        ...state
      }
    }

    case SchedulingActionTypes.CreateScheduleForAssociates: {
      return {
        ...state
      }
    }

    case SchedulingActionTypes.CreateScheduleForAssociatesSuccess: {
      return {
        ...state,
        createScheduleComplete: true
      }
    }

    case SchedulingActionTypes.CreateScheduleForAssociatesFail: {
      return {
        ...state,
        createScheduleComplete: false,

      }
    }

    case SchedulingActionTypes.ResetScheduleTaskAssociate: {
      return {
        tasks: [],
        associates: [],
        associateInitialLoad: false,
        schedulesInitialLoad: false,
        schedules: [],
        tasksInitialLoad: false,
        unsavedAssignments: [],
        unsavedAssignmentsCount: 0,
        message: '',
      }
    }

    default:
      return state;
  }
}