import { TeamActionTypes, TeamActions } from '@staff/store/actions/team.actions';
import { CostCenter } from '@staff/store/entity/costCenter';
import { Skill } from '@staff/store/entity/skill';

export interface ITeamState {
  selectedTeam?: string;
  selectedTemplateId?: string;
  costCenters?: CostCenter[];
  isLoading: boolean;
  teamLocationCreated?: boolean;
  teamLocationAddedError?: string;
  teamSkills?: Skill[];
}

const initialState: ITeamState = {
  costCenters: [],
  isLoading: false,
};

export function reducer(state = initialState, action: TeamActions): ITeamState {

  switch (action.type) {
    case TeamActionTypes.GetTeamCostCentersLoad: {
      return {
        ...state,
        isLoading: true,
        selectedTeam: action.payload.selectedTeam,
        teamLocationCreated: undefined,
        teamLocationAddedError: undefined
      }
    }

    case TeamActionTypes.GetTeamCostCentersSuccess: {
      return {
        ...state,
        costCenters: action.payload,
        isLoading: false
      }
    }

    case TeamActionTypes.GetTeamCostCentersFail: {
      return {
        costCenters: [],
        isLoading: false,
      }
    }

    case TeamActionTypes.CreateTeamLocation: {
      return {
        ...state
      }
    }

    case TeamActionTypes.CreateTeamLocationSuccess: {
      return {
        ...state,
        teamLocationCreated: true,
      }
    }

    case TeamActionTypes.CreateTeamLocationFail: {
      return {
        ...state,
        teamLocationCreated: false,
        teamLocationAddedError: 'Failed!'
      }
    }

    case TeamActionTypes.GetTeamSkillsLoad: {
      return {
        ...state
      }
    }

    case TeamActionTypes.GetTeamSkillsSuccess: {
      return {
        ...state,
        teamSkills: action.payload
      }
    }

    case TeamActionTypes.GetTeamSkillsFail: {
      return {
        ...state,
      }
    }

    default:
      return state;
  }
}