import { TemplateDetail } from '@staff/store/entity/template-detail';
import { TemplateDetailsActionTypes, TemplateDetailsActions } from '@staff/store/actions/template-details.actions';
import { Location } from '@staff/store/entity/location';
import { Template } from '@staff/store/entity/template';
export interface ITemplateDetailsState {
  selectedTeam?: string;
  selectedTemplateId?: string;
  data: TemplateDetail[];
  isLoading: boolean;
  message: string;
  templateLocationsLoaded?: boolean;
  templateLocations?: Location[];
  complexTemplates?: Template[];
  taskCoverage?: Template[];
  selectedTask?: string;
  selectedTaskTeam?: string;
}

const initialState: ITemplateDetailsState = {
  data: [],
  isLoading: false,
  message: ''
};

export function reducer(state = initialState, action: TemplateDetailsActions): ITemplateDetailsState {

  switch (action.type) {
    case TemplateDetailsActionTypes.GetTemplateDetailsLoad: {
      return {
        ...state,
        isLoading: true,
        selectedTeam: action.payload.selectedTeam,
        selectedTemplateId: action.payload.selectedTemplateId,
      }
    }

    case TemplateDetailsActionTypes.GetTemplateDetailsSuccess: {
      return {
        ...state,
        data: action.payload && action.payload[0] && action.payload[0].tasks ? action.payload[0].tasks : [] ,
        isLoading: false,
        message: 'Data fetch Successfully!'
      }
    }

    case TemplateDetailsActionTypes.GetTemplateDetailsFail: {
      return {
        data: [],
        isLoading: false,
        message: 'Something went wrong!'
      }
    }

    case TemplateDetailsActionTypes.GetTemplateLocationsLoad: {
      return {
        ...state,
        templateLocationsLoaded: false,
      }
    }

    case TemplateDetailsActionTypes.GetTemplateLocationsSuccess: {
      return {
        ...state,
        templateLocations: action.payload[0].locations,
        complexTemplates: action.payload[0].templates,
        templateLocationsLoaded: true,
        message: 'Data fetch Successfully!'
      }
    }

    case TemplateDetailsActionTypes.GetTemplateLocationsFail: {
      return {
        ...state,
        templateLocations: [],
        templateLocationsLoaded: false,
        message: 'Something went wrong!'
      }
    }

    case TemplateDetailsActionTypes.GetTaskCoverage: {
      return {
        ...state,
        selectedTask: action.payload.selectedTask,
        selectedTaskTeam: action.payload.selectedTaskTeam,
      }
    }

    case TemplateDetailsActionTypes.GetTaskCoverageSuccess: {
      return {
        ...state,
        taskCoverage: action.payload
      }
    }

    case TemplateDetailsActionTypes.GetTaskCoverageFail: {
      return {
        ...state,
      }
    }

    case TemplateDetailsActionTypes.ResetSelectedTask: {
      return {
        ...state,
        selectedTask: '',
        selectedTaskTeam: '',
      }
    }

    default:
      return state;
  }
}