import { Component, OnInit } from '@angular/core';
import { DropdownModel } from '../../shared/common/components/dropdown/dropdown.component';
import { DatePipe } from '@angular/common';
import { AssociateTimeConfirmationService } from './associate-time-confirmation.service';
import { NgForm } from '@angular/forms';
import { CommonService } from '../../shared/common/services/common.service';
import { DatePickerModel } from '../../shared/common/components/datepicker/datepicker.component';
import { Globals } from '../../shared//common/global/global.provider';

@Component({
  selector: 'app-associate-time-confirmation',
  templateUrl: './associate-time-confirmation.component.html'
})
export class AssociateTimeConfirmationComponent implements OnInit {

  dropdownModel = new DropdownModel();
  startDateModel = new DatePickerModel();
  endDateModel = new DatePickerModel();
  errorDataEmpty: any = '';
  startDate: any;
  endDate: any;

  constructor(
    private associateTimeConfirmationService: AssociateTimeConfirmationService,
    private commonService: CommonService,
    private globals: Globals
  ) { }

  flagToReplace = ':urlFlag';
  datePipe = new DatePipe('en-US');

  prmSubTeam;
  prmEmployeeCategory;
  prmWorkedCostSite;
  dataSelection;
  orderBy;
  format;
  prmView;
  selectedAssociates = [];
  selectedTeams = [];

  prmViewOptions = {
    label: 'View options',
    default: 'A',
    data: [
      {
        text: 'Associate Time Confirmation Report',
        value: 'A'
      },
      {
        text: 'Associate Time Confirmation Report - One Per Page',
        value: 'P'
      }
    ]
  };

  prmSubTeamOptions = {
    label: 'Sub Team',
    default: '1',
    data: [
      {
        text: 'YES',
        value: '1'
      },
      {
        text: 'NO',
        value: '0'
      }
    ]
  };
  prmEmployeeCategoryOptions = {
    label: 'Employee Category',
    default: 'ALL',
    data: this.commonService.getEmployeeCatInfo()
  };

  dataSelectionOptions = {
    label: 'Data Selection',
    data: [
      {
        text: 'Manual',
        value: '1'
      },
      {
        text: 'Today',
        value: '2'
      },
      {
        text: 'This week',
        value: '3'
      },
      {
        text: 'Yesterday',
        value: '4'
      },
      {
        text: 'Previous week',
        value: '5'
      },
    ],
    default: '1',
  };
  orderByOptions = {
    label: 'Order By',
    default: '0',
    data: [
      {
        text: 'Personnel Number',
        value: '0'
      },
      {
        text: 'First Name',
        value: '1'
      },
      {
        text: 'Last Name',
        value: '2'
      }
    ]
  };
  formatOptions = {
    label: 'Format',
    default: 'html',
    data: [
      {
        text: 'HTML',
        value: 'html'
      },
      {
        text: 'PDF',
        value: 'pdf'
      },
      {
        text: 'EXCEL',
        value: 'xlsx'
      }
    ]
  };

  ngOnInit() {
    this.associateTimeConfirmationService.getSecuredObjects('associate-wage-report').subscribe(res=>{
      const currentDate =  new Date();
      this.dropdownModel = res[0].attributes;
      this.startDateModel.required = true;
      this.startDateModel.id = 'ATC-start-date';
      this.startDateModel.validFormat = true;
      this.startDateModel.value = { year: currentDate.getFullYear(), month: currentDate.getMonth() +1, day: currentDate.getDate() };
      this.endDateModel.required = true;
      this.endDateModel.id = 'ATC-end-date';
      this.endDateModel.validFormat = true;
      this.endDateModel.value = { year: currentDate.getFullYear(), month: currentDate.getMonth() +1, day: currentDate.getDate() };
    });
    console.log('globals', this.globals);
  }

  changeDataSelection(value) {
    const currDate = new Date();
    let dateObj;

    switch (value) {
      case '2': // today selection
        dateObj = {day:currDate.getDate(), month: currDate.getMonth() + 1, year: currDate.getFullYear()};
        this.startDateModel.value = dateObj;
        this.endDateModel.value = dateObj;
        break;
      case '5': // pevius week selection
        const start = new Date();
        const end = new Date();
        const fistDay = (currDate.getDay() - 12) < 0 ? (currDate.getDay() - 11) * -1 : (currDate.getDay() - 12);
        const lastDay = (currDate.getDay() - 6) < 0 ? (currDate.getDay() - 6) * -1 : (currDate.getDay() - 6);
        const firstForPreWeek = new Date(start.setDate(currDate.getDate() - fistDay));
        const lastForPreWeek = new Date(end.setDate(currDate.getDate() - lastDay));
        this.startDateModel.value = {day:firstForPreWeek.getDate(), month: firstForPreWeek.getMonth() + 1, year: firstForPreWeek.getFullYear()};
        this.endDateModel.value = {day:lastForPreWeek.getDate(), month: lastForPreWeek.getMonth() + 1, year: lastForPreWeek.getFullYear()};
        break;
      case '3': // current week selection
        const first = currDate.getDate() - currDate.getDay() + 1;
        const last = currDate.getDate() - currDate.getDay() + 7;
        const startWeek:any = new Date(new Date().setDate(first));
        const endWeek :any= new Date(new Date().setDate(last));
        this.startDateModel.value = {day:startWeek.getDate(), month: startWeek.getMonth() + 1, year: startWeek.getFullYear()};
        this.endDateModel.value = {day:endWeek.getDate(), month: endWeek.getMonth() + 1, year: endWeek.getFullYear()};
        break;
      case '4': // previus day selection
        const yesterday = new Date(new Date().setDate(new Date().getDate() - 1));
        dateObj = {day:yesterday.getDate(), month: yesterday.getMonth() + 1, year: yesterday.getFullYear()};
        this.startDateModel.value = dateObj;
        this.endDateModel.value = dateObj;
        break;
      default: // manual date seletion
        this.startDateModel.value = '';
        this.endDateModel.value = '';
        break;
    }
  }

  openReport(reportForm: NgForm) {
    this.errorDataEmpty = false;
    if (!this.selectedAssociates.length && !this.selectedTeams.length) {
      this.errorDataEmpty = true;
      return;
    }

    delete  reportForm.value.__format;
    delete  reportForm.value.__asattachment;
    delete  reportForm.value['__ExcelEmitter.SingleSheet'];
    const index = this.format === 'html' ? 'stgviewer' : 'frameset';
    const url = this.globals.base_urls.report +
                `/reports/${this.flagToReplace}?__report=sso/MySTAFF/Associate_Time_Confirmation_365Days.rptdesign`
                .replace(this.flagToReplace, index);
    reportForm.value.prmStartdate = this.commonService.setDateFormat(this.startDateModel.value);
    reportForm.value.prmEndDate = this.commonService.setDateFormat(this.endDateModel.value);
    reportForm.value.prmSubTeam = this.prmSubTeam;
    reportForm.value.prmWorkedCostSite = this.commonService.objArrayToString(this.prmWorkedCostSite, 'team_name');
    reportForm.value.prmEmployeeCategory = this.prmEmployeeCategory;
    reportForm.value.prmOrderBy = this.orderBy;
    reportForm.value.prmPersonnelNumber = this.commonService.objArrayToString(this.selectedAssociates, 'emp_id');
    reportForm.value.prmTeamName = this.commonService.objArrayToString(this.selectedTeams, 'team_name');
    reportForm.value.prmView = this.prmView;
    reportForm.value.UserName = this.globals.user_name;

    if (this.format !== 'html') {
      reportForm.value.__format = this.format;
      reportForm.value.__asattachment = true;
      if(this.format == 'xlsx' && this.prmView == 'A') {
        reportForm.value['__ExcelEmitter.SingleSheet'] = true;
      }
    }

    console.log('form', reportForm.value);
    window.open(url + '&' + this.commonService.generateParameterString(reportForm.value), '_blank');
  }

  selectAssociates(assoc: any) {
    this.selectedAssociates = assoc;
    this.selectedTeams = [];
  }

  selectTeams(team: any) {
    this.selectedTeams = team;
    this.selectedAssociates = [];
  }

  cancelReport(){
    parent.history.back();
  }
}
