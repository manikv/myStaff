import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { Observer } from 'rxjs/internal/types';
import { SecurityService } from '../../shared/common/services/security.service';

@Injectable({
  providedIn: 'root'
})
export class AssociateTimeConfirmationService {

  constructor(private securityService: SecurityService) { }

  getSecuredObjects(pageName: string): Observable<any>{
    return Observable.create((observer: Observer<any>) => {
        this.securityService.getSecuredObjects(pageName).subscribe(
        res=> {
            observer.next(res);
            observer.complete();
        });
    });
  }
}
