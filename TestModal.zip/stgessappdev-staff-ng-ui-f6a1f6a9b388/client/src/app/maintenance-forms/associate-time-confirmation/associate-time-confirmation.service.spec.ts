import { TestBed } from '@angular/core/testing';

import { AssociateTimeConfirmationService } from './associate-time-confirmation.service';

describe('AssociateTimeConfirmationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AssociateTimeConfirmationService = TestBed.get(AssociateTimeConfirmationService);
    expect(service).toBeTruthy();
  });
});
