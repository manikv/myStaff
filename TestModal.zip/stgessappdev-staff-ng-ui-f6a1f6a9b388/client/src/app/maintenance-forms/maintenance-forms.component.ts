import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-maintenance-forms',
  templateUrl: './maintenance-forms.component.html',
})
export class MaintenanceFormsComponent implements OnInit {
  ngOnInit() {
  }
}
