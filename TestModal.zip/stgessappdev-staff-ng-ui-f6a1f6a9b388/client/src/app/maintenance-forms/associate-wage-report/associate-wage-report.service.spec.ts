import { TestBed } from '@angular/core/testing';

import { AssociateWageReportService } from './associate-wage-report.service';

describe('AssociateWageReportService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AssociateWageReportService = TestBed.get(AssociateWageReportService);
    expect(service).toBeTruthy();
  });
});
