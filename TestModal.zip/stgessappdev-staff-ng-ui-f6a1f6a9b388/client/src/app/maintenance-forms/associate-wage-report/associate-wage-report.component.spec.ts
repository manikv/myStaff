import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssociateWageReportComponent } from './associate-wage-report.component';

describe('AssociateWageReportComponent', () => {
  let component: AssociateWageReportComponent;
  let fixture: ComponentFixture<AssociateWageReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssociateWageReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssociateWageReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
