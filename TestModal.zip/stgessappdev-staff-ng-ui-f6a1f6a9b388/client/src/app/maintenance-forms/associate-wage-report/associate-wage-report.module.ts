// import { NgModule } from '@angular/core';
// import { CommonModule } from '@angular/common';

// import { AssociateWageReportRoutingModule } from './associate-wage-report-routing.module';
// import { AssociateWageReportComponent } from './associate-wage-report.component';
// import { DropdownModule } from '../../../../projects/dropdown/src/public-api';
// import { AssociateWageReportService } from './associate-wage-report.service';
// import { DatepickerModule } from '../../../../projects/datepicker/src/public-api';
// import { FormsModule } from '@angular/forms';

// @NgModule({
//   declarations: [
//     AssociateWageReportComponent
//   ],
//   imports: [
//     CommonModule,
//     AssociateWageReportRoutingModule,
//     DropdownModule,
//     DatepickerModule,
//     FormsModule
//   ],
//   providers: [
//     AssociateWageReportService
//   ]
// })
// export class AssociateWageReportModule { }