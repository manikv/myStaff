// import { NgModule } from '@angular/core';
// import { Routes, RouterModule } from '@angular/router';
// import { AssociateWageReportComponent } from './associate-wage-report.component';

// const routes: Routes = [
//   {
//     path: 'associate-wage-report',
//     component: AssociateWageReportComponent
//   }
// ];

// @NgModule({
//   imports: [RouterModule.forChild(routes)],
//   exports: [RouterModule]
// })
// export class AssociateWageReportRoutingModule { }
