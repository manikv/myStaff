import { Component, OnInit } from '@angular/core';
import { AssociateWageReportService } from './associate-wage-report.service';
import { DropdownModel } from '../../shared/common/components/dropdown/dropdown.component';
import { NgForm } from '@angular/forms';
import { CommonService } from '../../shared/common/services/common.service';
import { Globals } from '../../shared//common/global/global.provider';
import { DatePickerModel } from '../../shared/common/components/datepicker/datepicker.component';

@Component({
  selector: 'app-associate-wage-report',
  templateUrl: './associate-wage-report.component.html'
})
export class AssociateWageReportComponent implements OnInit {

  dropdownModel = new DropdownModel();
  startDateModel = new DatePickerModel();
  endDateModel = new DatePickerModel();
  errorDataEmpty: any = false;

  constructor(
    private associateWageReportService: AssociateWageReportService,
    private commonService: CommonService,
    private globals: Globals
  ) { }
  flagToReplace = ':urlFlag';

  startDate;
  endDate;
  prmSubTeam;
  prmEmployeeCategory;
  showParameters;
  format;
  prmView: any = 'A';
  inputValue;
  selectedAssociates = [];
  selectedTeams = [];

  prmViewOptions = {
    label: 'View options',
    default: 'A',
    data: [
      {
        text: 'Associate Wage Report',
        value: 'A'
      },
      {
        text: 'Alt CC Only 365 Days report',
        value: 'C'
      }
    ]
  }
  prmSubTeamOptions = {
    label: 'Sub Team',
    default: '1',
    data: [
      {
        text: 'YES',
        value: '1'
      },
      {
        text: 'NO',
        value: '0'
      }
    ]
  };

  prmEmployeeCategoryOptions = {
    label: 'Employee Category',
    default: 'ALL',
    data: this.commonService.getEmployeeCatInfo()
  };

  showParametersOptions = {
    label: 'Show parameters',
    default: '1',
    data: [
      {
        text: 'YES',
        value: '1'
      },
      {
        text: 'NO',
        value: '0'
      }
    ]
  };
  formatOptions = {
    label: 'Format',
    default: 'html',
    data: [
      {
        text: 'HTML',
        value: 'html'
      },
      {
        text: 'PDF',
        value: 'pdf'
      },
      {
        text: 'EXCEL',
        value: 'xlsx'
      }
    ]
  };

  ngOnInit() {
    this.associateWageReportService.getSecuredObjects('associate-wage-report').subscribe(res=>{
      const currentDate =  new Date();
      this.dropdownModel = res[0].attributes;
      this.startDateModel.id = 'AWR-start-date';
      this.startDateModel.value = { year: currentDate.getFullYear(), month: currentDate.getMonth() +1, day: currentDate.getDate() };
      this.startDateModel.required = true;
      this.startDateModel.validFormat = true;
      this.endDateModel.id = 'AWR-end-date';
      this.endDateModel.value = { year: currentDate.getFullYear(), month: currentDate.getMonth() +1, day: currentDate.getDate() };
      this.endDateModel.required = true;
      this.endDateModel.validFormat = true;
    });
   }

  openReport(reportForm: NgForm) {
    this.errorDataEmpty = false;
    if (!this.selectedAssociates.length && !this.selectedTeams.length) {
      this.errorDataEmpty = true;
      return;
    }

    delete  reportForm.value.__format;
    delete  reportForm.value.__asattachment;
    delete  reportForm.value['__ExcelEmitter.SingleSheet'];
    const url = this.globals.base_urls.report + `/reports/${this.flagToReplace}?__report=sso/MySTAFF/AssociateWageReport_365.rptdesign`;
    const viewType = this.format === 'html' ? 'stgviewer' : 'frameset';
    const finalUrl = url.replace(this.flagToReplace, viewType);
    reportForm.value.parmStartdate = this.commonService.setDateFormat(this.startDateModel.value);
    reportForm.value.parmsEndDate = this.commonService.setDateFormat(this.endDateModel.value);
    reportForm.value.paramSubTeam = this.prmSubTeam;
    reportForm.value.EmployeeCategory = this.prmEmployeeCategory;
    reportForm.value.ShowParameters = this.showParameters;
    reportForm.value.PersonnelNumber = this.commonService.objArrayToString(this.selectedAssociates,'emp_name');   // 'emp_id');
    reportForm.value.TeamName =  this.commonService.objArrayToString(this.selectedTeams, 'team_name');
    reportForm.value.prmView = this.prmView;
    reportForm.value.UserName = this.globals.user_name;

    if (this.format !== 'html') {
      reportForm.value.__format = this.format;
      reportForm.value.__asattachment = true;
      if(this.format == 'xlsx') {
        reportForm.value['__ExcelEmitter.SingleSheet'] = true;
      }
    }

    console.log('form', reportForm.value);
    window.open(finalUrl + '&' + this.commonService.generateParameterString(reportForm.value), '_blank');
  }

  selectAssociates(assoc: any){
    this.selectedAssociates = assoc;
    this.selectedTeams = [];

  }

  selectTeams(team: any){
    this.selectedTeams = team;
    this.selectedAssociates = [];
  }

  cancelReport(){
    parent.history.back();
  }
}
