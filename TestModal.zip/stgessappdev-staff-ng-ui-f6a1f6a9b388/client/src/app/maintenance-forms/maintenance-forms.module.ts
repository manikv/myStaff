import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DropdownModule } from '../shared/common/components/dropdown/dropdown.module';
import { DatepickerModule } from '../shared/common/components/datepicker/datepicker.module';
import { MaintenanceFormsRoutingModule } from './maintenance-forms.routing';
import { MaintenanceFormsComponent } from './maintenance-forms.component';
import { AssociateWageReportComponent } from './associate-wage-report/associate-wage-report.component';
import { AssociateTimeConfirmationComponent } from './associate-time-confirmation/associate-time-confirmation.component';
import { AssociateMultiTypeheadModule, TeamMultiTypeaheadModule } from '@staff/sharedModules/index'

@NgModule({
  declarations: [
    MaintenanceFormsComponent,
    AssociateWageReportComponent,
    AssociateTimeConfirmationComponent

  ],
  imports: [
    CommonModule,
    MaintenanceFormsRoutingModule,
    FormsModule,
    DropdownModule,
    DatepickerModule,
    AssociateMultiTypeheadModule,
    TeamMultiTypeaheadModule
  ]
})
export class MaintenanceFormsModule { }