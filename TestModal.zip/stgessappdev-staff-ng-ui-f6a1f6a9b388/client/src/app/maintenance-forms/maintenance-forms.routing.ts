import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MaintenanceFormsComponent } from './maintenance-forms.component';
import { AssociateWageReportComponent } from './associate-wage-report/associate-wage-report.component';
import { AssociateTimeConfirmationComponent } from './associate-time-confirmation/associate-time-confirmation.component';

const routes: Routes = [
  {
    path: '',
    component: MaintenanceFormsComponent,
    children: [
      {
        path: 'associate-wage-report',
        component: AssociateWageReportComponent
      },
      {
        path: 'associate-time-confirmation-report',
        component: AssociateTimeConfirmationComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MaintenanceFormsRoutingModule { }
