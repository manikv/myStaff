import { of } from 'rxjs'

export class MockBurstService {

  getBurstApprovals(username, month_end_date){
    return of([
        {
            burstTaskEmpId: 35532,
            burstId: 13483,
            name: "BURGER, CHEESE2",
            teamName: "6335",
            empName: "999898",
            empId: 349714,
            burstStatus: "Published",
            jobId: 10100,
            taskId: 152169,
            taskName: "Cook Evening",
            projectId: 47608,
            scheduleDate: "2020-01-29",
            startTime: "1970-01-01 14:00",
            endTime: "1970-01-01 21:00",
            brkStartTime: "1970-01-01 15:00",
            brkEndTime: "1970-01-01 15:30",
            rate: null,
            positionId: null,
            employeeResponse: "Accepted",
            employeeResponseDate: "2020-01-28 16:09",
            managerResponse: "Published",
            notificationStatus: null,
            managerResponseDate: "2020-01-27 17:54",
            comments: "",
            associateComments: null,
            readOnly: false,
            empEmail: "NOREPLY@COMPASS-USA.COM",
            empPhone: "7043285359",
            dayOneCount: 0,
            dayTwoCount: 0,
            dayThreeCount: 0,
            dayFourCount: 0,
            dayFiveCount: 0,
            daySixCount: 1,
            daySevenCount: 1
        },
        {
            burstTaskEmpId: 35532,
            burstId: 13483,
            name: "BURGER, CHEESE2",
            teamName: "6335",
            empName: "999898",
            empId: 349714,
            burstStatus: "Published",
            jobId: 10100,
            taskId: 152169,
            taskName: "Cook Evening",
            projectId: 47608,
            scheduleDate: "2020-01-29",
            startTime: "1970-01-01 14:00",
            endTime: "1970-01-01 21:00",
            brkStartTime: "1970-01-01 15:00",
            brkEndTime: "1970-01-01 15:30",
            rate: null,
            positionId: null,
            employeeResponse: "Accepted",
            employeeResponseDate: "2020-01-28 16:09",
            managerResponse: "Published",
            notificationStatus: null,
            managerResponseDate: "2020-01-27 17:54",
            comments: "",
            associateComments: null,
            readOnly: false,
            empEmail: "NOREPLY@COMPASS-USA.COM",
            empPhone: "7043285359",
            dayOneCount: 0,
            dayTwoCount: 0,
            dayThreeCount: 0,
            dayFourCount: 0,
            dayFiveCount: 0,
            daySixCount: 1,
            daySevenCount: 1
        },
        {
            burstTaskEmpId: 35533,
            burstId: 13483,
            name: "BURGER, CHEESE2",
            teamName: "6335",
            empName: "999898",
            empId: 349714,
            burstStatus: "Published",
            jobId: 10100,
            taskId: 152169,
            taskName: "Cook Evening",
            projectId: 47608,
            scheduleDate: "2020-01-30",
            startTime: "1970-01-01 14:00",
            endTime: "1970-01-01 21:00",
            brkStartTime: "1970-01-01 15:00",
            brkEndTime: "1970-01-01 15:30",
            rate: null,
            positionId: null,
            employeeResponse: "Accepted",
            employeeResponseDate: "2020-01-28 16:09",
            managerResponse: "Published",
            notificationStatus: null,
            managerResponseDate: "2020-01-27 17:54",
            comments: "",
            associateComments: null,
            readOnly: false,
            empEmail: "NOREPLY@COMPASS-USA.COM",
            empPhone: "7043285359",
            dayOneCount: 0,
            dayTwoCount: 0,
            dayThreeCount: 0,
            dayFourCount: 0,
            dayFiveCount: 0,
            daySixCount: 1,
            daySevenCount: 1
        }
    ])
  }

  updateBurstAssignments(data) {
    return of()
  }

  creatBurst( data: any){
    return  of()
  }

  createBurstTasks( data: any){
    return  of()
  }

  createBurstAssigments( data: any){
    return  of()
  }

  updateManagerShiftBurst(burst_id: any, burst_status:any){
    return  of()
  }
}