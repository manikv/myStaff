import { of } from 'rxjs';

export class MockScheduleService {
    getDailySchedules(team, string_format){
        return of({
            shifts: []
        })
    }
}