import { of } from 'rxjs';

export class MockHomepageService {
  getDashboard(user_name: string) {
    return of({
      data: [
        {
          id: 57800,
          wbu_id: 80687,
          wbu_name: "TESTO06",
          approaching_ot: 7,
          missed_meal: 48,
          assoc_needing_setup: 714,
          punch_compliance: 2,
          unauth_timesheets: null,
          offline_clocks: 3511
        }
      ]
    });
  }

  getDashboardUnauth(user_name: string) {
    return of({
      data: [{
        id: null,
        wbu_id: null,
        wbu_name: null,
        approaching_ot: null,
        missed_meal: null,
        assoc_needing_setup: null,
        punch_compliance: null,
        unauth_timesheets: 78108,
        offline_clocks: null
      }]
    });
  }

  getAccordion(user_name: string) {
    return of([
      {
        items: [
          {
            link_id: 1,
            link_name: "Check Daily Attendance",
            link_url: "/cgReports/cg_reportAttendance.jsp?ATT_DATE=",
            link_info: "This report allows you to monitor your associate's attendance punches, so you know when they clocked in/out to work and punched in/out for meals and breaks.  You will also be able to easily correct punch errors for previous days in the current pay period, directly on the associate's timesheet.",
            avail_days_of_week: "Mo,Tu,We,Th,Fr,Sa,Su",
            avail_for_num_of_weeks_future: 5,
            avail_for_num_of_weeks_past: 100,
            link_start_date: "1900-01-01",
            link_end_date: "3000-01-01",
            show_help: "Y",
            emp_name: 10087,
            wbu_name: "TESTO06",
            wbu_id: 80687
          }
        ],
        day_of_week: 0,
        week_day: "Mo",
        activity_date: null
      },
      {
        items: [
          {
            link_id: 10299,
            link_name: "Correct Unauthorized Timesheets",
            link_url: "/reports/cognos/reportParams.jsp?mfrm_id=1011995&report_name=UNAUTHORIZED TIMESHEET LISTING IN EXCEL",
            link_info: null,
            avail_days_of_week: "Mo,Tu,We,Th,Sa,Su",
            avail_for_num_of_weeks_future: 5,
            avail_for_num_of_weeks_past: 100,
            link_start_date: "1900-02-09",
            link_end_date: "3000-02-18",
            show_help: null,
            emp_name: 10087,
            wbu_name: "TESTO06",
            wbu_id: 80687
          }
        ],
        day_of_week: 1,
        week_day: "Tu",
        activity_date: null
      },
      {
        items: [
          {
            link_id: 10363,
            link_name: "Demand Based Scheduler",
            link_url: "/cgSRA/cgSchedSra.jsp",
            link_info: "This link will take you to the Demand Based Scheduler where you can enter associate Schedules.",
            avail_days_of_week: "Mo,Tu,We,Th,Fr,Sa,Su",
            avail_for_num_of_weeks_future: 5,
            avail_for_num_of_weeks_past: 100,
            link_start_date: "2015-10-01",
            link_end_date: "2016-08-19",
            show_help: "Y",
            emp_name: 10087,
            wbu_name: "TESTO06",
            wbu_id: 80687
          }
        ],
        day_of_week: 2,
        week_day: "We",
        activity_date: null
      }
    ]);
  }

  getDashboardAnnouncement(user_name: string) {
    return of();
  }

  getWidgetGridData(type: string, user_name: string, page: string, limit: string) {
    return of();
  }

  getWidgetGridUnauthTimesheetData(user_name: string, user_id: string) {
    return of();
  }
}