import { Injectable } from '@angular/core';

@Injectable()
export class MockGlobals {
    paygroups: [
        {
            id: 10005
            name: "FRI-THURS HOURLY",
            description: "Fri-Thurs Hourly",
            start_date: "01/10/2020",
            end_date: "01/16/2020"
        },
        {
            id: 10164,
            name: "SUN-SAT HOURLY",
            description: "Sun-Sat Hourly",
            start_date: "02/24/2019",
            end_date: "03/02/2019"
        },
        {
            id: 10170,
            name: "SAT-FRI HOURLY",
            description: "Sat - Fri Hourly",
            start_date: "05/04/2019",
            end_date: "05/10/2019"
        },
        {
            id: 10172,
            name: "MON-SUN HOURLY",
            description: "Mon - Sun Hourly",
            start_date: "02/11/2019",
            end_date: "02/17/2019"
        }
    ];
    getIconType(balance_description) {
        return 'default';
    };
    staffProfile: {
        user_id: 80687,
        emp_id: 349712,
        paygroup_id: 10005,
        home_team: "6335",
        emp_name: "999894",
        first_name: "Oms",
        last_name: "Test06"
    };
}