import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AssociateViewComponent } from './associate-view/associate-view.component';

const routes: Routes = [
  {
    path: 'associate-view',
    component: AssociateViewComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SchedulingRoutingModule { }
