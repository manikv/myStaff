import { Component, ViewChild, AfterViewInit, Input } from '@angular/core';
import { SchedulerComponent } from 'bryntum-angular-shared';
import { Globals } from '../../shared/common/global/global.provider';
import { ScheduleService } from '../../shared/common/services/schedule.service';
import { DatePickerModel } from '../../shared/common/components/datepicker/datepicker.component';
import * as moment from 'moment';
import { DatepickerComponent } from '../../shared/common/components/datepicker/datepicker.component';
import { DateHelper } from 'bryntum-scheduler/scheduler.umd.js';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-associate-view',
  templateUrl: './associate-view.component.html',
  styleUrls: ['./associate-view.component.scss']
})
export class AssociateViewComponent implements AfterViewInit {
    @Input() home_team:any = false;
    @ViewChild("datepicker") datepickercomponent: DatepickerComponent;
    constructor(
        public globals: Globals,
        public scheduleService: ScheduleService,
        public activeModal: NgbActiveModal,
    ){
        let startDate = new Date(),
            endDate = new Date();
            startDate.setHours(0,0,0,0);
            endDate.setHours(24,0,0,0);
        this.schedulerConfig = {
            minHeight        : '20em',
            startDate        : startDate,
            endDate          : endDate,
            viewPreset       : 'hourAndDay',
            rowHeight        : 50,
            barMargin        : 5,
            multiEventSelect : true,
            mode : 'horizontal',
            columns : [
                { text : 'Name', field : 'name', width : 130 }
            ],
            resourceTimeRangesFeature : true,
            eventRenderer : ({eventRecord}) => {
                return `
                    <div class:"info">
                        <div class:"name">${eventRecord.name}</div>
                        <div class:"desc">${eventRecord.desc}</div>
                    </div>
                `;
            }
        };
    }
    teamComponent = [];
    barMargin: number = 10;
    schedulerConfig: any;
    currentTeamSelected: any;
    resources = [];
    events = [];

    @ViewChild(SchedulerComponent) scheduler: SchedulerComponent;
    currentDate = new Date();
    datePickerModel: DatePickerModel = { id: 'SCHC-start-date', value: { year: this.currentDate.getFullYear(), month: this.currentDate.getMonth() +1, day: this.currentDate.getDate() } }

    ngAfterViewInit() {
       //this.scheduler.schedulerEngine.setTimeSpan(DateHelper.add(this.currentDate, 0, 'hour'), DateHelper.add(this.currentDate, 23, 'hour'));
        if(this.home_team){
            this.initData(this.home_team.team_name);
        }
    }

    initData(team_name, date = moment().format('MM/DD/YYYY')){
        // this.scheduleService.getDailySchedules(team_name, date).subscribe((resp: any) => {
        // this.events = [];
        // this.resources = [];
        // resp.map(schedule => {
        //     this.resources.push({
        //         id: schedule.employee_id,
        //         name: schedule.last_name+', '+schedule.first_name
        //     });
        //     this.schedulerConfig.resources = this.resources;
        //     for (const assignment of schedule.shifts) {
        //         this.events.push({
        //             id : schedule.employee_id+'-'+assignment.task_id,
        //             resourceId : schedule.employee_id,
        //             startDate  : assignment.start,
        //             endDate    : assignment.end,
        //             name       : assignment.task_name,
        //             desc      : assignment.task_name,
        //             eventColor: "blue",
        //             iconCls    : 'b-fa b-fa-calendar'
        //         })
        //     }
        //     this.schedulerConfig.events = this.events;
        //     });
        // });
    }

    // change scheduler start/end dates
    parameterSelected(value: any, parameterKey) {
        switch (parameterKey) {
            case 'date':
                let dateSelect = new Date(value.year, value.month - 1, value.day);
                this.scheduler.schedulerEngine.setTimeSpan(DateHelper.add(dateSelect, 0, 'hour'), DateHelper.add(dateSelect, 23, 'hour'));
                if(this.currentTeamSelected){
                    this.initData(this.currentTeamSelected, moment(dateSelect).format('MM/DD/YYYY'))
                }
                break;
            default:
                break;
        }
    }

    // add event button click handled here
    onAddEventClick() {
        this.scheduler.addEvent();
    }

    // remove event button click handled here
    onRemoveEventClick() {
        this.scheduler.removeEvent();
    }

    // Uncomment the code in this method to start "logging" events
    onSchedulerEvents(event: any) {
        // // catch scheduler events here, for example when dropping an event:
        // if (event.type === 'eventdrop') {
        //     console.log('Drop: ', event);
        // }

        // // or when editing one:
        // if (event.type === 'eventschange') {
        //     console.log('EventStore: ', event);
        // }

        // // or when editing a resource:
        // if (event.type === 'resourceschange') {
        //     console.log('ResourceStore: ', event);
        // }
    }

    select(eve: any){
        if(eve){
            this.currentTeamSelected = eve.team_name;
            this.initData(eve.team_name);
        }
    }

    passBack() {
        this.activeModal.close(0);
      }

}
