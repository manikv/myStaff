import {Component, ViewChild, OnInit, Input, ElementRef} from '@angular/core';
import { SchedulerComponent } from 'bryntum-angular-shared';
import { Globals } from '../../shared/common/global/global.provider';
import { ScheduleService } from '../../shared/common/services/schedule.service';
import * as moment from 'moment';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
// import { BlockUI, NgBlockUI  } from 'ng-block-ui';

import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-daily-view',
  templateUrl: './daily-view.component.html',
  styleUrls: ['./daily-view.component.scss']
})
export class DailyViewComponent implements OnInit {
  @Input() schedule:any = false;
  @Input() punches:any = false;
  @Input() selected_team_name: any = '';
  @Input() attendanceNumbers: any = [];
  // @BlockUI('thisDV-section') blockUI: NgBlockUI;

  toastrMsg: string = '';
  refreshInterval: number = 30000;  //10000(10secs)=>refreshes for 5min; 30000(30secs)=>refreshes for 15min;
  refreshTimerId :any;


  // currDateTime = moment('6/29/2020 13:00').format("YYYY-MM-DD HH:mm")
  // currDateTime = moment().format();

  eventNames = [{"id":'A',"name":"ALL EVENTS"},
    {"id":'S',"name":"SCHEDULE"},
    {"id":'W',"name":"WORK"},
    {"id":'M',"name":"MEAL"},
    {"id":'V',"name":"OFF"}];

  constructor(
    public globals: Globals,
    public scheduleService: ScheduleService,
    public activeModal: NgbActiveModal,
    private toastr: ToastrService,
  ){
    let startDate =  new Date(),
      endDate = new Date();
    startDate.setHours(0,0,0,0);
    endDate.setHours(24,0,0,0);
    this.schedulerConfig = {
      minHeight        : '50em',
      startDate        : startDate,
      endDate          : endDate,
      viewPreset       : {
        base            : 'hourAndDay',
        tickWidth       : 25,
        columnLinesFor  : 1,
        mainHeaderLevel : 1,
        headers         : [
          {
            unit       : 'd',
            align      : 'center',
            dateFormat : 'ddd - MM/DD',
            renderer (startDate, endDate, headerConfig, cellIdx) {
              headerConfig.headerCellCls = "b-header-config-1";
              return `<div>${headerConfig.value}</div>`;
            }
          },
          {
            unit       : 'h',
            align      : 'center',
            dateFormat : 'h A',
            renderer (startDate, endDate, headerConfig, cellIdx) {
              headerConfig.headerCellCls = "b-header-config-2 ";
              return `<div>${headerConfig.value}</div>`;
            }
          }
        ]
      },
      rowHeight        : 47,
      barMargin        : 13,
      multiEventSelect : false,
      mode : 'horizontal',
      columns : [
        { text : 'Name', field : 'name', width : 150, htmlEncode : false,
          renderer ({ record }) {
            return `<div>${record.data.name}<br /><span class="emp-no">(${record.data.per_no})</span></div>`;
          }
        },
        { text : 'Status', field : 'status', width : 80, htmlEncode : false,
          renderer({ record, value, size }) {
            if (value === 'Absent'){
              return `<div class="absent">${value}</div>`;
            } else {
              return `<div>${value}</div>`;
            }
          }
        },
        { text : 'Job', field : 'job', width : 110 },
      ],
      eventRenderer : ({ eventRecord, resourceRecord, tplData }) => {
        // tplData.event.draggable = false;
        eventRecord.draggable = false;
        if (eventRecord.data.eventOverNight) {
          tplData.style = '';  //cust-b-style
          tplData.iconCls =  'fa fa-moon-o';
        }
        if (eventRecord.data.schdStartTime && !eventRecord.data.schdEndTime) {
          return `<div>${eventRecord.data.schdStartTime}</div>`
        } else if (eventRecord.data.schdEndTime && !eventRecord.data.schdStartTime) {
          return `<div>${eventRecord.data.schdEndTime}</div>`
        } else if (eventRecord.data.schdStartTime && eventRecord.data.schdEndTime ) {
          return `<div>${eventRecord.data.schdStartTime}</div>
                  <div>${eventRecord.data.schdEndTime}</div>`
        }
        // if (eventRecord.data.eventClass === 'absent' || eventRecord.data.eventClass === 'scheduled') {
        //   tplData.cls.add(eventRecord.data.eventClass);
        //eventRecord.data.cls = eventRecord.data.eventClass;
        // } //else {
        //   eventRecord.data.cls = 'at-work';
        // }
      },
      event : [],
      resourceTimeRangesFeature : true,
      filterBarFeature          : true,
      eventContextMenuFeature   : false,
      eventDragFeature          : false,
      readOnly                  : true,
      zoomOnTimeAxisDoubleClick : false,
      headerContextMenuFeature  : false,
      eventFilterFeature        : false,
      features : {
        timeRanges : {
          showCurrentTimeLine : true
        },
        eventTooltip :  ({ eventRecord}) =>{
          return eventRecord.data.eventHoverMsg
        }
      },
      horizontalEventSorterFn : function (a, b) {
        var startA = a.data.sortOrder, endA = a.data.sortOrder;
        var startB = b.data.sortOrder, endB = b.data.sortOrder;
        var sameStart = (startA - startB === 0);
        if (sameStart) {
          return endA > endB ? -1 : 1;
        } else {
          return (startA < startB) ? -1 : 1;
        }
      }

    };

    this.refreshTimerId =  this.globals.setIntervalX(()=> { this.refreshHP() }, this.refreshInterval, 30);

  }
  teamComponent = [];
  barMargin: number = 5;
  schedulerConfig: any;
  events = [];
  resources = [];
  attendance = [];

  ifRefreshed: boolean = false;

  @ViewChild(SchedulerComponent) scheduler: SchedulerComponent;
  @ViewChild("filterElement") filterEle: ElementRef;
  @ViewChild("sch1") schElement: ElementRef;

  // currentDate = new Date();

  ngOnInit() {
    if(this.schedule){
      // this.blockUI.start('Loading...');
      this.initData(this.schedule, this.punches);
      // this.blockUI.stop();
    }
  }

  ngAfterViewInit() {
    this.schElement.nativeElement.focus();
    this.scheduler.schedulerEngine.resourceStore.sort('name');
 }

  initData(schedules, punches){
    this.events = []; this.resources = [];
    schedules.map(schedule => {
      const punchIndex = punches.map(o => o.emp_name).indexOf(schedule.personnel_number);
      let lastPunch: any = null, at_work_indicator = false, punched_out = false;
      if(punchIndex!=-1){
        at_work_indicator = punches[punchIndex].at_work;
        punches[punchIndex].punches.sort((a, b) => (this.getPunchDateformat(a.punch_string) > this.getPunchDateformat(b.punch_string)) ? 1 : -1);
        punched_out = punches[punchIndex].punches[punches[punchIndex].punches.length-1].punch_type==='OUT';
        lastPunch = punches[punchIndex].punches[punches[punchIndex].punches.length-1];
      }
      //get work status
      let status ='Off';
      if (schedule.shifts.length==0 && punchIndex == -1) {
        status = 'Off'
      } else if (schedule.shifts.length==0 && punchIndex != -1) {
        //not scheduled but has punches
        status = (lastPunch.punch_type=='IN'||lastPunch.punch_type=='MEAL_OUT')?'Clocked In'
          :lastPunch.punch_type=='MEAL_IN'?'Meal Break'
            :lastPunch.punch_type=='OUT'?'Clocked Out'
              : 'Scheduled'
      } else {
        //get first shift time to check if Absent
        if (moment(schedule.shifts[0].start).isBefore(moment().format("YYYY-MM-DD HH:mm"))) {
          if (lastPunch !==null) {
            //he's at work; hence not absent
            status = (lastPunch.punch_type=='IN'||lastPunch.punch_type=='MEAL_OUT')?'Clocked In'
              :lastPunch.punch_type=='MEAL_IN'?'Meal Break'
                :lastPunch.punch_type=='OUT'?'Clocked Out'
                  : 'Scheduled'
          } else if (!at_work_indicator && punched_out) {
            //he finished the schedule and punched out;  hence not absent
            //may be early or on time punch out
            status = 'AOff';
          } else if (!at_work_indicator && !punched_out) {
            status = 'Absent';
          }
        } else {
          status = 'Scheduled'
        }
      }

      this.resources.push({
        id: schedule.employee_id,
        name: schedule.last_name + ', ' + schedule.first_name,
        per_no: schedule.personnel_number,
        status: status,
        job: schedule.job_desc,
        icon: "people"
      });
      this.schedulerConfig.resources = this.resources;

      for (const assignment of schedule.shifts) {
        var schEvents = this.getScheduleBreaks(assignment, schedule.employee_id, status);
        for (const schEvent of schEvents) { this.events.push(schEvent); }
      }

      if(punchIndex!= -1){
        let punchEvents = this.getPunchEvents(punches[punchIndex].punches);
        for (const punchEvent of punchEvents) {
          this.events.push({
            id            : schedule.employee_id+'-punch-'+punchEvent.start+punchEvent.pType,
            resourceId    : schedule.employee_id,
            startDate     : punchEvent.start,
            endDate       : punchEvent.end,
            name          : this.eventNames.find(x => x.id === punchEvent.type).name,
            eventType     : punchEvent.type,
            eventColor    : "green",
            //iconCls     : 'meal-break',
            eventStyle    : punchEvent.type=='W' ? "line":"dashed",
            cls           : 'meal-break',
            editable      : false,
            eventOverNight: this.overNight(punchEvent.start, punchEvent.end),
            sortOrder     : 2,
            eventHoverMsg : punchEvent.eventHoverStartMsg + punchEvent.eventHoverEndMsg
          });
        }

      }
    });
    this.schedulerConfig.events = this.events;
  }

  getPunchEvents(punches){
    let events=[];
    punches.map((punch,i)=>{
      if (punch.punch_type === 'IN') {
        let endT = punches.length==1 ? moment().format('h:mm a') : this.getPunchDateformat_sm(punches[punches.length-1].punch_string);
        events.push({
          type  : 'W', pType: "IN",
          start : this.getPunchDateformat(punch.punch_string),
          end   : moment().format('YYYY-MM-DD HH:mm'),
          eventHoverStartMsg :
            "<div>WORK<br/> " +
            this.getPunchDateformat_sm(punch.punch_string) + " - ",
          eventHoverEndMsg  : endT + "</div>"
        });
      } else {
        if (punch.punch_type === 'MEAL_IN') {
          if (events.length > 0) {
            events[events.length-1].end = this.getPunchDateformat(punch.punch_string)
            // events[events.length-1].eventHoverEndMsg = moment(punch.punch_string).format("h:mm a") + "</div>"
          }
          events.push({
            type  : 'M', pType: "MEAL",
            start : this.getPunchDateformat(punch.punch_string),
            end   : moment().format('YYYY-MM-DD HH:mm'),
            eventHoverStartMsg :
              "<div>MEAL<br/> " +
              this.getPunchDateformat_sm(punch.punch_string) + " - ",
            eventHoverEndMsg  : moment().format("h:mm a") + "</div>"
          });
        }
        if (punch.punch_type === 'MEAL_OUT') {
          if (events.length > 0) {
            events[events.length-1].end = this.getPunchDateformat(punch.punch_string),
              events[events.length-1].eventHoverEndMsg = this.getPunchDateformat_sm(punch.punch_string) + "</div>"
          }
          if (i==punches.length-1) {
            //MEAL_OUT is the last punch, add Back to Work event
            events.push({
              type  : 'W', pType: "OUT",
              start : this.getPunchDateformat(punch.punch_string),
              end   : moment().format('YYYY-MM-DD HH:mm'),
              eventHoverStartMsg :
                "<div>WORK<br/> " +
                this.getPunchDateformat_sm(punches[0].punch_string) + " - ",
              eventHoverEndMsg  : moment().format("h:mm a")  + "</div>"
            });
            //since still At Work, modify the IN hover msg
            if (events[0].pType == ' IN') {
              // events[0].end = moment(this.currDateTime).format('YYYY-MM-DD HH:mm');
              events[0].eventHoverEndMsg = moment().format("h:mm a") + "</div>";
            }
          }
        }
        if (punch.punch_type === 'OUT') {
          //no meal break punches - has just IN & OUT
          if (punches.length == 2 && events[0].pType == 'IN') {
            events[0].end = this.getPunchDateformat(punch.punch_string);
            events[0].eventHoverEndMsg = ".HI." + this.getPunchDateformat_sm(punch.punch_string) + "</div>"
          } else {
            events.push({
              type: 'W', pType: "OUT",
              start: this.getPunchDateformat(events[events.length - 1].end),
              end: this.getPunchDateformat(punch.punch_string),
              eventHoverStartMsg:   //alter first punch end time
                "<div>WORK<br/> " +
                this.getPunchDateformat_sm(punches[0].punch_string) + " - ",
              eventHoverEndMsg: this.getPunchDateformat_sm(punch.punch_string) + "</div>"
            });
          }
        }
      }
    });
    return events;
  }

  getEventClass(status, position){
    let retClass = status=='Absent'?"absent":"scheduled";
    if (position ==='start') {
      retClass += " sch-start-time"
    } else  if (position ==='end') {
      retClass += " sch-end-time"
    } else if (position === 'both') {
      retClass += " sch-both-ends-time"
    }
    return retClass;
  }

  getScheduleBreaks(assignment, empId, status) {
    let schEvents = [];
    var brk_st_time = moment(assignment.break_start).format("HH:mm");
    var brk_end_time = moment(assignment.break_end).format("HH:mm");
    if (brk_st_time === "00:00" && brk_end_time === "00:00") {
      schEvents.push({
        id            : empId + '-sched-' + assignment.start+"-NOBRK",
        resourceId    : empId,
        name          : this.eventNames.find(x => x.id === 'S').name,
        startDate     : assignment.start,
        endDate       : assignment.end,
        eventStyle    : 'line',
        editable      : false,
        eventOverNight: this.overNight(assignment.start, assignment.end),
        cls           : this.getEventClass(status,"both"),
        sortOrder     : 1,
        schdStartTime : moment(assignment.start).format("h:mm a"),
        schdEndTime   : moment(assignment.end).format("h:mm a"),
        eventHoverMsg : this.overNight(assignment.start, assignment.end) ?
          "<div> SCHEDULED <br/> " +
          moment(assignment.start).format("MMM DD, hh:mm a") + " - "+
          moment(assignment.end).format("MMM DD, hh:mm a") + "</div>":
          "<div> SCHEDULED <br/> " +
          moment(assignment.start).format("hh:mm a") + " - "+
          moment(assignment.end).format("hh:mm a") + "</div>"
      })
    } else {   //has meal break
      schEvents.push({
        id            : empId + '-sched-' + assignment.start+"-IN",
        resourceId    : empId,
        name          : this.eventNames.find(x => x.id === 'S').name,
        startDate     : assignment.start,
        endDate       : assignment.break_start,
        eventStyle    : 'line',
        editable      : false,
        eventOverNight: this.overNight(assignment.start, assignment.break_start),
        cls           : this.getEventClass(status, "start"),
        sortOrder     : 1,
        schdStartTime : moment(assignment.start).format("h:mm a"),
        eventHoverMsg : this.overNight(assignment.start, assignment.break_start) ?
          "<div> SCHEDULED <br/> " +
          moment(assignment.start).format("MMM DD, hh:mm a") + " - "+
          moment(assignment.end).format("MMM DD, hh:mm a") + "</div>":
          "<div> SCHEDULED <br/> " +
          moment(assignment.start).format("hh:mm a") + " - "+
          moment(assignment.end).format("hh:mm a") + "</div>"
      });
      schEvents.push({
        id            : empId + '-sched-' + assignment.end+"-OUT",
        resourceId    : empId,
        name          : this.eventNames.find(x => x.id === 'S').name,
        startDate     : assignment.break_end,
        endDate       : assignment.end,
        eventStyle    : 'line',
        editable      : false,
        eventOverNight: this.overNight(assignment.break_end, assignment.end),
        cls           : this.getEventClass(status, "end"),
        sortOrder     : 1,
        schdEndTime   : moment(assignment.end).format("h:mm a"),
        eventHoverMsg : this.overNight(assignment.start, assignment.break_start) ?
          "<div> SCHEDULED <br/> " +
          moment(assignment.start).format("MMM DD, h:mm a") + " - "+
          moment(assignment.end).format("MMM DD, h:mm a") + "</div>" :
          "<div> SCHEDULED <br/> " +
          moment(assignment.start).format("h:mm a") + " - "+
          moment(assignment.end).format("h:mm a") + "</div>"
      });
      schEvents.push({
        id            : empId + '-sched-' + assignment.break_end+"-BRK",
        resourceId    : empId,
        name          : this.eventNames.find(x => x.id === 'S').name,
        startDate     : assignment.break_start,
        endDate       : assignment.break_end,
        eventStyle    : 'dashed',
        editable      : false,
        eventOverNight: this.overNight(assignment.break_start, assignment.break_end),
        cls           : this.getEventClass(status,null),
        sortOrder     : 1,
        eventHoverMsg : this.overNight(assignment.start, assignment.break_start) ?
          "<div>MEAL<br/> " +
          moment(assignment.break_start).format("MMM DD, h:mm a") + " - "+
          moment(assignment.break_end).format("MMM DD, h:mm a") + "</div>" :
          "<div>MEAL<br/> " +
          moment(assignment.break_start).format("h:mm a") + " - "+
          moment(assignment.break_end).format("h:mm a") + "</div>"
      })
    }

    return schEvents;
  }

  filterEvents(value) {
    // if (value.toUpperCase() === 'ALL EVENTS') {
    //   this.scheduler.schedulerEngine.eventStore.clearFilters();
    // } else {
    //   value = value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    //   this.scheduler.schedulerEngine.eventStore.filter({
    //     filters: event => event.name.match(new RegExp(value, 'i')),
    //     replace: true
    //   });
    // }

    let filterval = '';
    if(value === 'WORK'){
       filterval = 'Clocked In';
    }else if(value === 'SCHEDULE'){
       filterval = 'Scheduled';
     }
    if (value.toUpperCase() === 'ALL EVENTS') {
      this.scheduler.schedulerEngine.eventStore.clearFilters();
      this.scheduler.schedulerEngine.resourceStore.clearFilters();
    } else {
            this.scheduler.schedulerEngine.eventStore.clearFilters();
            this.scheduler.schedulerEngine.resourceStore.clearFilters();
            this.scheduler.schedulerEngine.resourceStore.filterBy(function(resource) {
                  return resource.data.status === filterval ? true : false;
             });
    }



  }

  // add event button click handled here
  onAddEventClick() {
    this.scheduler.addEvent();
  }

  // remove event button click handled here
  onRemoveEventClick() {
    this.scheduler.removeEvent();
  }

  // Uncomment the code in this method to start "logging" events
  onSchedulerEvents(event: any) {
    // // catch scheduler events here, for example when dropping an event:
    // if (event.type === 'eventdrop') {
    //     console.log('Drop: ', event);
    // }

    // // or when editing one:
    // if (event.type === 'eventschange') {
    //     console.log('EventStore: ', event);
    // }

    // // or when editing a resource:
    // if (event.type === 'resourceschange') {
    //     console.log('ResourceStore: ', event);
    // }
  }

  passBack() {
    this.globals.clearIntervalX(this.refreshTimerId);
    if (!this.ifRefreshed)
      this.activeModal.close(0);
    else
      this.activeModal.close(this.attendance);
  }

  overNight(stDate, endDate) {
    return !(moment(stDate).format("MM/DD/YYYY") === moment(endDate).format("MM/DD/YYYY"));
  }

  refreshHP() {
     console.log("Refresh start (DV)....id:"+ this.refreshTimerId)
    // this.blockUI.start("Refreshing Data ...");

    let strDt = moment().format("M/D/YYYY");
    this.scheduleService.getDailyPunches(this.selected_team_name, strDt).subscribe((p: any) => {
        p.map(emp=> {
          const punchIndex = this.punches.map(o => o.emp_name).indexOf(emp.emp_name);
          if (punchIndex == -1) {
            this.processPunchChange(emp);
          } else {
            if (emp.punches.length != this.punches[punchIndex].punches.length) {
              this.processPunchChange(emp);
            }
          }
        });
        this.attendance = this.scheduleService.setAttendance(this.selected_team_name, moment().format("YYYY-MM-DD HH:mm"), this.attendanceNumbers, this.schedule, p);
        this.schedule = this.attendance[0].scheduleList;
        this.punches = this.attendance[0].punchList;
        this.schedule.sort((a, b) => (a.name > b.name) ? 1 : -1);
        this.punches.sort((a, b) => (a.name > b.name) ? 1 : -1);

        if (this.toastrMsg!='') {
          this.toastr.success(this.toastrMsg,
            'Attendance Status', {
              enableHtml: true,
              closeButton: true
            });
        }
        this.toastrMsg = '';
        this.initData(this.schedule, this.punches);
    });


  }

  processPunchChange(data){
    data.punches.sort((a, b) => (this.getPunchDateformat(a.punch_string) > this.getPunchDateformat(b.punch_string)) ? 1 : -1);
    const lastPunch = data.punches[data.punches.length - 1];
    const punchMsg = lastPunch.punch_type=='IN'?'just Clocked In.'
      :lastPunch.punch_type=='OUT'?'just Clocked Out.'
        :lastPunch.punch_type=='MEAL_IN'?'just went for a Meal.'
          :'is back to work.' ;
    this.toastrMsg += data.emp_lastname+', '+data.emp_firstname+' '+punchMsg + "<br/>";
    this.ifRefreshed = true;
  }

  getPunchDateformat(dtString: string) {
      return moment(dtString.replace(" ",''), 'YYYYMMDDHHmm').format("YYYY-MM-DD HH:mm");
  }

  getPunchDateformat_sm(dtString: string) {
    return moment(dtString.replace(" ",''), 'YYYYMMDDHHmm').format("h:mm A");
  }





}
