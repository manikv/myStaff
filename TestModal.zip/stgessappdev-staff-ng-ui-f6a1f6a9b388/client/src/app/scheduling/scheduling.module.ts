import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DatepickerModule } from '../shared/common/components/datepicker/datepicker.module';
import { DropdownModule } from '../shared/common/components/dropdown/dropdown.module';
import { ToastrService } from 'ngx-toastr';
import { BlockUIModule } from 'ng-block-ui';
import { SchedulingRoutingModule } from './scheduling-routing.module';
//import { EventSummaryComponent } from './event-summary/event-summary.component';
import { BryntumAngularSharedModule } from 'bryntum-angular-shared';
import { AssociateViewComponent } from './associate-view/associate-view.component';
import { DailyViewComponent } from './daily-view/daily-view.component';
import { ScheduleService } from '../shared/common/services/schedule.service';
import { TeamMultiTypeaheadModule } from '@staff/sharedModules/index';
// import { EventsService } from '../shared/common/services/events.service';
//import { TasksTemplatesComponent } from './tasks-templates/tasks-templates.component';
//import { EventBaseScheduleService } from '../shared/common/services/event-base-schedule.service';
//import { AddEventComponent } from '../event-base-scheduler/add-event/add-event.component'
//import { AddEventRoutingModule } from '../event-base-scheduler/add-event-routing.module';
import { GooglePlaceModule } from "ngx-google-places-autocomplete";
// import { TimepickerModalComponent } from "../shared/timepicker-modal/timepicker-modal.component";
import { TimepickerModule } from '../shared/timepicker/timepicker.module';



@NgModule({
  declarations: [
    //EventSummaryComponent,
    AssociateViewComponent,
    DailyViewComponent,
    //TasksTemplatesComponent,
    //AddEventComponent,
    // TimepickerModalComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    NgbModule,
    DatepickerModule,
    DropdownModule,
    TeamMultiTypeaheadModule,
    BlockUIModule.forRoot(),
    SchedulingRoutingModule,
    BryntumAngularSharedModule,
    // AddEventRoutingModule,
    GooglePlaceModule,
    TimepickerModule,
  ],
  providers: [
    ToastrService,
    ScheduleService,
    // EventBaseScheduleService
  ],
  entryComponents: [
    // TimepickerModalComponent
  ]
})
export class SchedulingModule { };
