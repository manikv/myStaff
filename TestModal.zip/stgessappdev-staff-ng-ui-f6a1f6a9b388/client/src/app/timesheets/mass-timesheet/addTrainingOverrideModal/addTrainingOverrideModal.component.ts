import { Component, Input } from '@angular/core';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import * as moment from "moment";
import * as _ from "lodash";

@Component({
	templateUrl: './addTrainingOverrideModal.component.html',
	styles: [
		'.error { font-size: .5rem; color: red; }'
	]
})
export class AddTrainingOverrideComponent {
	@Input() public showRate;
	@Input() maxRate;
	starttime: any = { hour: 8, minute: 0 };
	endtime: any = { hour: 17, minute: 0 };
	mealStartTime: any = { hour: 0, minute: 0 };
	mealEndTime: any = { hour: 0, minute: 0 };
	rate: any = '';
	meridian = true;
	constructor(public activeModal: NgbActiveModal) { }

	isAddDisabled() {
		return ((this.rate >= 0 && this.rate > this.maxRate) || this.validateEndTime() || this.validateMealEndTime() || !this.validateMealTimes('mealStartTime'));

	}

	//Endtime should be after start time
	validateEndTime() {
		let startTime = moment(this.starttime.hour + ':' + this.starttime.minute, 'HH:mm');
		let endTime = moment(this.endtime.hour + ':' + this.endtime.minute, 'HH:mm');
		if (startTime.format('HH:mm') === endTime.format('HH:mm')) {
			return true;
		} else {
			return endTime.isBefore(startTime);
		}
	}

	validateMealTimes(type) {
		let mealTimes = {
			mealStartTime: `${this.mealStartTime.hour}:${this.mealStartTime.minute}`,
			mealEndTime: `${this.mealEndTime.hour}:${this.mealEndTime.minute}`
		}
		if (mealTimes.mealStartTime === mealTimes.mealEndTime) {
			return true;
		} else {
			let startTime = moment(this.starttime.hour + ':' + this.starttime.minute, 'HH:mm');;
			let endTime = moment(this.endtime.hour + ':' + this.endtime.minute, 'HH:mm');;
			let timeToValidate = moment(_.get(mealTimes, type), 'HH:mm');

			return timeToValidate.isBefore(endTime) && timeToValidate.isAfter(startTime);
		}
	}

	validateMealEndTime() {
		if (this.mealEndTime.hour == this.mealStartTime.hour && this.mealEndTime.minute == this.mealStartTime.minute) {
			return false;
		} else {
			let mealStartTime = moment(this.mealStartTime.hour + ':' + this.mealStartTime.minute, 'HH:mm');
			let mealEndTime = moment(this.mealEndTime.hour + ':' + this.mealEndTime.minute, 'HH:mm');

			return mealEndTime.isBefore(mealStartTime) || !this.validateMealTimes('mealEndTime');
		}
	}

	rateValidation() {
		let rateToValidate = _.toNumber(this.rate);

		if (!this.maxRate && !_.isNull(this.maxRate)) {
			return rateToValidate <= this.maxRate;
		} else {
			return true;
		}
	}

	closeModal() {
		this.activeModal.close({
			start_time: this.starttime.hour + ':' + this.starttime.minute,
			end_time: this.endtime.hour + ':' + this.endtime.minute,
			amount: this.rate == '0.00' ? '' : this.rate,
			meal_start_time: this.mealStartTime.hour + ':' + this.mealStartTime.minute,
			meal_end_time: this.mealEndTime.hour + ':' + this.mealEndTime.minute
		});
	}
}