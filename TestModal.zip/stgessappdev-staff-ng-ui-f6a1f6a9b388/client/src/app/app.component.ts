import { Component } from '@angular/core';
import { OauthService }  from '@stgutils-ngx/core';
import { Globals } from './shared/common/global/global.provider';
//import { Observable, timer } from 'rxjs';
import { SecurityService } from './shared/common/services/security.service';
import { TeamService } from "./shared/common/services/team.service";
import { UserService } from "./shared/common/services/user.service";
declare var ga: Function;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent{
  alertAt = 60;
  startTimer = true;
  appReady: boolean = false;
  constructor(
    public oauthService: OauthService,
    public globals: Globals,
    public securityService: SecurityService,
    public teamService: TeamService,
    public userService: UserService
  ) {
  }

  getRbac(){
    this.globals.rbacProfile = JSON.parse(this.oauthService.getRBACProfile());
    const proxyUser = this.globals.getParamValueQueryString('proxyUser');
    if(proxyUser != undefined && proxyUser.length != 0){
      this.globals.proxyUserName = proxyUser;
      this.userService.getUserProfile(proxyUser)
      .subscribe(res=>{
        this.globals.proxyUseProfile = res[0];
      });
    }
    this.globals.user_name = this.globals.rbacProfile.user_name;
    this.securityService.getAppConfig()
    .subscribe((res: any)=>{
      this.globals.base_urls = res.urls.base_urls;
      ga('create', res.ga.id, 'auto');
      ga('send', 'pageview',{'page': 'MyStaff-Homepage'});      
    });
    this.securityService.getStaffProfile()
    .subscribe((res:{data:Array<object>})=>{
      this.globals.staffProfile = {
        user_id: res.data[0]['userId'],
        emp_id: res.data[0]['empId'],
        paygroup_id: res.data[0]['defaultPayGroupId'],
        home_team: res.data[0]['empHomeTeam'],
        emp_name: res.data[0]['empName']
      };
      this.globals.staffProfile.first_name = this.globals.rbacProfile.first_name;
      this.globals.staffProfile.last_name = this.globals.rbacProfile.last_name;
      this.globals.setSettings(res.data[0]['config']);
      this.appReady = true;
    });
    this.teamService.getPayGroups()
    .subscribe((response: any) => {
      this.globals.paygroups = response;
    });    
  }
}
