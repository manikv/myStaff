import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgbModule, NgbActiveModal, } from '@ng-bootstrap/ng-bootstrap';
import { TemplatesRoutingModule } from './templates-routing.module';
import { BlockUIModule } from 'ng-block-ui';
import { TeamMultiTypeaheadEbsModule  } from '@staff/sharedModules/index';
import { ToastrService } from 'ngx-toastr';
import { TemplateDetailsComponent } from './template-details/template-details.component';
import { CoverageInput } from './template-details/ag-grid-templates/coverage-input-renderer.component';
import { CoverageEditor } from './template-details/ag-grid-templates/coverage-editor.component';
import { GroupHeader } from './template-details/ag-grid-templates/group-header-renderer.component';
import { LocationGroupHeader } from './template-details/ag-grid-templates/location-group-header-renderer.component';
import { TemplateComponent } from './template-details/template-details/template-details.component';
import { EventBaseScheduleService } from '@staff/shared/common/services/ebs.service';
import { EBSTemplateService } from '@staff/shared/common/services/ebs/template.service';
import { TemplateDetailsModule } from '@staff/ebs/common/template-details/template-details.module';
@NgModule({
  entryComponents: [
    CoverageInput,
    CoverageEditor,
    GroupHeader,
    LocationGroupHeader
  ],
  declarations: [
    TemplateDetailsComponent,
    CoverageInput,
    CoverageEditor,
    GroupHeader,
    LocationGroupHeader,
    TemplateComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    NgbModule,
    TemplatesRoutingModule,
    BlockUIModule.forRoot(),
    TeamMultiTypeaheadEbsModule,
    TemplateDetailsModule,
  ],
  providers: [
    NgbActiveModal,
    ToastrService,
    EventBaseScheduleService,
    EBSTemplateService
  ]
})
export class TemplatesModule {
}
