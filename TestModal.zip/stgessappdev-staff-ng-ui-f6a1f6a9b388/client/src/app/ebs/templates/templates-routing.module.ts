import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TemplateDetailsComponent } from './template-details/template-details.component';
import { TemplateComponent } from './template-details/template-details/template-details.component';
const routes: Routes = [
  {
    path: 'detail',
    component: TemplateDetailsComponent
  },
  {
    path: 'details',
    component: TemplateComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TemplatesRoutingModule { }
