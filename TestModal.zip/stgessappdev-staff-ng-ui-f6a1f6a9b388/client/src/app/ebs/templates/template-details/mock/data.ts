export const apiResponse = {
  "metadata": {
    "version": "1.0.0",
    "status": "Success",
    "http_status_code": "200",
    "resultCount": "0"
  },
  "data": [
    {
      "event_id": 10002,
      "event_name": "Google Day-1",
      "event_desc": "Google Day-1",
      "event_type": "Awards",
      "event_open_shifts": 100,
      "event_filled_shifts": 50,
      "event_sched_hours": 105,
      "event_sched_amount": 10005,
      "event_date": "11/10/2020",
      "event_start_time": "08:00 AM",
      "event_end_time": "05:00 PM",
      "event_schedule_start_time": "07:00 AM",
      "event_schedule_end_time": "09:00 PM",
      "event_status": "Open",
      "event_team_name": "BCATS ADMIN",
      "template_name": "NBA Basketball",
      "template_details": [
        {
          "cost_center_name": "BCATS GENERAL CONCES",
          "location_name": "Carolina Moonshine Bar-B-Que 101",
          "task_name": "Concession Food Svc Worker",
          "coverage": 20,
          "start_time": "08:00 AM",
          "break_start": "02:00 PM",
          "break_end": "02:30 PM",
          "end_time": "05:00 PM"
        },
        {
          "cost_center_name": "BCATS GENERAL CONCES",
          "location_name": "Carolina Moonshine Bar-B-Que 101",
          "task_name": "Cashier",
          "coverage": 20,
          "start_time": "08:00 AM",
          "break_start": "02:00 PM",
          "break_end": "02:30 PM",
          "end_time": "05:00 PM"
        },
        {
          "cost_center_name": "BCATS GENERAL CONCES",
          "location_name": "Carolina Moonshine Bar-B-Que 101",
          "task_name": "Bar Server",
          "coverage": 20,
          "start_time": "08:00 AM",
          "break_start": "02:00 PM",
          "break_end": "02:30 PM",
          "end_time": "05:00 PM"
        },{
          "cost_center_name": "BCATS GENERAL CONCES",
          "location_name": "Corona Light Cart 102",
          "task_name": "Concession Food Svc Worker",
          "coverage": 20,
          "start_time": "08:00 AM",
          "break_start": "02:00 PM",
          "break_end": "02:30 PM",
          "end_time": "05:00 PM"
        },
        {
          "cost_center_name": "BCATS GENERAL CONCES",
          "location_name": "Corona Light Cart 102",
          "task_name": "Cashier",
          "coverage": 20,
          "start_time": "08:00 AM",
          "break_start": "02:00 PM",
          "break_end": "02:30 PM",
          "end_time": "05:00 PM"
        },
        {
          "cost_center_name": "BCATS GENERAL CONCES",
          "location_name": "Corona Light Cart 102",
          "task_name": "Bar Server",
          "coverage": 20,
          "start_time": "08:00 AM",
          "break_start": "02:00 PM",
          "break_end": "02:30 PM",
          "end_time": "05:00 PM"
        },{
          "cost_center_name": "BCATS SUITES",
          "location_name": "Suite 1",
          "task_name": "Concession Food Svc Worker",
          "coverage": 20,
          "start_time": "08:00 AM",
          "break_start": "02:00 PM",
          "break_end": "02:30 PM",
          "end_time": "05:00 PM"
        },
        {
          "cost_center_name": "BCATS SUITES",
          "location_name": "Suite 1",
          "task_name": "Cashier",
          "coverage": 20,
          "start_time": "08:00 AM",
          "break_start": "02:00 PM",
          "break_end": "02:30 PM",
          "end_time": "05:00 PM"
        },
        {
          "cost_center_name": "BCATS SUITES",
          "location_name": "Suite 1",
          "task_name": "Bar Server",
          "coverage": 20,
          "start_time": "08:00 AM",
          "break_start": "02:00 PM",
          "break_end": "02:30 PM",
          "end_time": "05:00 PM"
        },{
          "cost_center_name": "BCATS SUITES",
          "location_name": "Suite 2",
          "task_name": "Concession Food Svc Worker",
          "coverage": 20,
          "start_time": "08:00 AM",
          "break_start": "02:00 PM",
          "break_end": "02:30 PM",
          "end_time": "05:00 PM"
        },
        {
          "cost_center_name": "BCATS SUITES",
          "location_name": "Suite 2",
          "task_name": "Cashier",
          "coverage": 20,
          "start_time": "08:00 AM",
          "break_start": "02:00 PM",
          "break_end": "02:30 PM",
          "end_time": "05:00 PM"
        },
        {
          "cost_center_name": "BCATS SUITES",
          "location_name": "Suite 2",
          "task_name": "Bar Server",
          "coverage": 20,
          "start_time": "08:00 AM",
          "break_start": "02:00 PM",
          "break_end": "02:30 PM",
          "end_time": "05:00 PM"
        }
      ]
    }
  ],
  "error": []
}
