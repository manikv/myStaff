import { Component } from "@angular/core";

import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
    selector: 'coverage-cell',
	styles: [
		'.child-field { width: 60px; margin-left: 60%; }.parent-field {width: 60px;margin-left:10px}.parent-span{display: inline-block;margin-top: 15px;font-weight: 500;}.parent-btn{margin-top: 5px}'
	],
    template: `
		<div class="input-group mb-3" style="line-height: normal; height: 100%" *ngIf="!isParent && !isMainParent">
			<input type="text" class="child-field ag-cell-edit-input" value={{value}}>
		</div>
		<div class="input-group mb-3" style="line-height: normal; height: 100%" *ngIf="isParent">
			<span class="parent-span"># Positions </span><input type="text" class="parent-field ag-cell-edit-input" value={{value}}><a href="#" class="btn btn-link btn-default parent-btn">Apply</a>
		</div>`
})
export class CoverageInput implements ICellRendererAngularComp {
	public params: any;
	value: any;
	isParent: boolean
	isMainParent: boolean

	agInit(params: any): void {
		this.params = params;
		this.value = params.valueFormatted ? params.valueFormatted : params.value;
		this.isParent = this.params.node.level == 1 && this.value == undefined;
		this.isMainParent = this.value == undefined;
	}

	refresh(): boolean {
		return false;
	}
}