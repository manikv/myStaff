import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Globals } from "@staff/shared/common/global/global.provider";
import { EBSTemplateService } from '@staff/shared/common/services/ebs/template.service';
@Component({
  selector: 'app-template-details',
  templateUrl: './template-details.component.html',
  styleUrls: ['./template-details.component.scss']
})
export class TemplateComponent implements OnInit{
  selectedTemplate: any = {
    event_template_name: '',
    template_type: '',
    event_template_id: ''
  };
  ebsTeamSelected;
  constructor(
    private router: Router,
    private globals: Globals,
    private ebsTemplateService: EBSTemplateService
  ){
  }

  ngOnInit(){
    this.selectedTemplate = this.globals.ebsTemplateSelected;
    this.ebsTeamSelected = this.globals.ebsTeamSelected;
  }

  onSave(data){
    data.map(v=>v.template_id=this.globals.ebsTemplateSelected.event_template_id);
    this.ebsTemplateService.updateTemplateTasks(this.globals.ebsTeamSelected,data.filter(res=>res.updated)).subscribe(res=>{});
  }

  goBack(){
    this.router.navigateByUrl('/ebs/events?eventTemplates=true')
  }
}
