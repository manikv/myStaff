import { Component, OnInit } from '@angular/core';
import { apiResponse } from './mock/data.js';
import { CoverageInput } from './ag-grid-templates/coverage-input-renderer.component';
import { CoverageEditor } from './ag-grid-templates/coverage-editor.component';
import { GroupHeader } from './ag-grid-templates/group-header-renderer.component';
import { LocationGroupHeader } from './ag-grid-templates/location-group-header-renderer.component';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import * as fromTemplateDetails from "@staff/store/stores/template-details.state";
import { Store, select } from '@ngrx/store';
import { TemplateDetail } from '@staff/store/entity/template-detail';

@Component({
  selector: 'app-template-details',
  templateUrl: './template-details.component.html',
  styleUrls: ['./template-details.component.scss']
})
export class TemplateDetailsComponent implements OnInit {
  private gridApi;
  private gridColumnApi;

  view: string = 'task';
  taskColumnDefs = [
    { "headerName": "Template", "field": "template_name", "rowGroup": true, "hide": true },
    { "headerName": "Team", "field": "task_name", "rowGroup": true, "hide": true },
    { "headerName": "Number of Task Coverage", "field": "coverage", cellRenderer: 'coverageInput' },
  ];
  locationColumnDefs = [
    { "headerName": "Template", "field": "template_name", "rowGroup": true, "hide": true },
    { "headerName": "Location", "field": "location_name", "rowGroup": true, "hide": true },
    { "headerName": "Number of Task Coverage", "field": "coverage", cellRenderer: 'coverageInput' },
  ];
  width = '98%';
  height = '630px';
  taskGridOptions: any = {
    defaultColDef: {
      resizable: true,
      suppressMenu: true,
    },
    suppressHorizontalScroll: false,
    columnDefs: this.taskColumnDefs,
    rowData: null,
    suppressMaxRenderedRowRestriction: true,
    suppressColumnVirtualisation: true,
    groupDefaultExpanded: -1,
    suppressAggFuncInHeader: true,
    autoGroupColumnDef: {
      headerName: 'Name',
      cellRenderer: 'agGroupCellRenderer',
      pinned: "left",
      field: 'location_name',
      cellRendererParams: {
        suppressCount: true,
        innerRenderer: 'groupHeader',
      }
    },
    sizeToFit: true,
    rowBuffer: 9999,
    groupIncludeFooter: false,
    groupIncludeTotalFooter: false
  };
  locationGridOptions: any = {
    defaultColDef: {
      resizable: true,
      suppressMenu: true,
    },
    suppressHorizontalScroll: false,
    columnDefs: this.locationColumnDefs,
    rowData: null,
    suppressMaxRenderedRowRestriction: true,
    suppressColumnVirtualisation: true,
    groupDefaultExpanded: -1,
    suppressAggFuncInHeader: true,
    autoGroupColumnDef: {
      headerName: 'Name',
      cellRenderer: 'agGroupCellRenderer',
      pinned: "left",
      field: 'task_name',
      cellRendererParams: {
        suppressCount: true,
        innerRenderer: 'locationGroupHeader',
      }
    },
    sizeToFit: true,
    rowBuffer: 9999,
    groupIncludeFooter: false,
    groupIncludeTotalFooter: false
  };
  context = { componentParent: this };

  data: TemplateDetail[] = [];
  frameworkComponents = {
    coverageInput: CoverageInput,
    coverageEditor: CoverageEditor,
    groupHeader: GroupHeader,
    locationGroupHeader: LocationGroupHeader
  };

  constructor(
    private modalService: NgbModal,
    public activeModal: NgbActiveModal
  ) {

  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    params.api.sizeColumnsToFit();
  }

  changeView(type: string) {
    this.view = type;
  }

  ngOnInit() {
  }
}
