import { Component } from "@angular/core";

import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
    selector: 'group-view-cell',
	styles: [
		'.add-button{position: absolute;right: 0;}.icon-indicator{margin-right:10px}.edit-btn{margin-right:10px;color:#6c757d}'
	],
	template: `<i class="fa fa-circle text-success icon-indicator" aria-hidden="true" *ngIf="isChild"></i>
	<button class="btn btn-link btn-default edit-btn" (click)="editTask()" *ngIf="isEditable"><i class="fa fa-pencil" aria-hidden="true"></i></button>
	{{value}}
	<span class="add-button">
	<button *ngIf="isParent" class="btn btn-link btn-default parent-btn" (click)="addLocation()"><i class="fa fa-plus-circle" aria-hidden="true"></i> Location</button>
	<button *ngIf="isParent" class="btn btn-link btn-default parent-btn" (click)="addTask()"><i class="fa fa-plus-circle" aria-hidden="true"></i> Task</button>
	</span>`
})
export class GroupHeader implements ICellRendererAngularComp {
	public params: any;
	value: any;
	isParent: boolean;
	isChild: boolean;
	isEditable: boolean;

	agInit(params: any): void {
		this.params = params;
		this.value = params.valueFormatted ? params.valueFormatted : params.value;
		this.isParent = this.params.node.level == 0;
		this.isChild = this.params.node.level == 2;
		this.isEditable = this.params.node.level == 1;
	}

	addLocation(){
		this.params.context.componentParent.addLocation();
	}

	addTask(){
		this.params.context.componentParent.addTask();
	}

	refresh(): boolean {
		return false;
	}
}
/*
template: `<button class="btn btn-link btn-default edit-btn" (click)="editTask()" *ngIf="isChild"><i class="fa fa-pencil" aria-hidden="true"></i></button>{{value}}
	<span class="add-button"><button *ngIf="isParent" class="btn btn-link btn-default parent-btn" (click)="addLocation()"><i class="fa fa-plus-circle" aria-hidden="true"></i>
	Location</button><button *ngIf="isParent" class="btn btn-link btn-default parent-btn" (click)="addTask()"><i class="fa fa-plus-circle" aria-hidden="true"></i>
	Task</button></span>`*/