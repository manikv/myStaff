import { Component, Input, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import * as _ from 'lodash';
import { Globals } from '../../../shared/common/global/global.provider';
import { CommonService } from '../../../shared/common/services/common.service';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import { ToastrService } from 'ngx-toastr';
import { EventBaseScheduleService } from '../../../shared/common/services/ebs.service';
import { TemplateTypeComponent } from '../../../shared/template-type-dropdown/template-type.component';

import { IDatasource, IGetRowsParams } from 'ag-grid-community';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { TeamTemplateService } from '../../../shared/common/services/teamtemplate.service';



@Component({
  selector: 'ebs-add-template',
  templateUrl: './add-template.component.html',
  styleUrls: ['./add-template.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AddTemplateComponent implements OnInit {
  @ViewChild('templatetypedropdown', { static: false }) private templatetypedropdown: TemplateTypeComponent;
  isCopy: boolean = false;
  template = {
    template_name: '',

    location: '',
    team_id: '',
    template_id: '',

    notes: '',
    scheduleTasks: [],
    copy_template_id: '',
    template_type_id: '',
    template_type_name:''
  };
  paginationPageSize = 5;
  eventTemplateGridOptions: any = {
    defaultColDef: {
      sortable: true,
      resizable: true,
    },
    copyHeadersToClipboard: true,
    suppressMaxRenderedRowRestriction: true,
    suppressColumnVirtualisation: true,
    groupDefaultExpanded: -1,
    rowBuffer: 9999,
    floatingFilter: true,
    rowModelType: 'infinite',
    cacheBlockSize: this.paginationPageSize,
    //processCellCallback : this.reportingCommonService.getExcelFormatting,

  };

  templateType: '';

  options = {
    types: [],
    componentRestrictions: { country: 'USA' }
  };
  hasData = false;
  @BlockUI() blockUI: NgBlockUI;
  @Input() selectedType: any = '';
  templateTypePlaceholder = 'Template type';
  isloaded = false;
  toastrMsg: string = '';
  headerCount: '';
  eventTemplateRowData = [];
  width = '100%';
  height = '300px';
  rowSelection = "single";
  selectedAssociates = [];
  context;
  gridApi: any;
  gridColumnApi: any;
  scheduler: any;
  resources = []; events = [];

  eventTemplateHeader: any = [
    {
      headerName: 'Template Name',
      field: 'event_template_name',
      filter: "agTextColumnFilter",
      checkboxSelection: true
    },
    {
      headerName: 'Template Type',
      field: 'template_type',
      filter: "agTextColumnFilter",
    },
  ];

  constructor(
    public globals: Globals,
    public activeModal: NgbActiveModal,
    public commonService: CommonService,
    private ebsService: EventBaseScheduleService,
    private toastr: ToastrService,
    private templateservice: TeamTemplateService
  ) {
  }

  ngOnInit() {
    this.headerCount = this.eventTemplateHeader.length;

    //this.setRowData();
  }

  loadTemplates() {
    this.isloaded = true;
  }

  passBack() {
    this.activeModal.close(0);
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    let teamName = this.globals.ebsTeamSelected;
    let dataSource = this.getTemplateData(teamName, this.paginationPageSize);
    this.gridApi.setDatasource(dataSource);
    params.api.sizeColumnsToFit();
  }

  addTemplate() {
    let payLoad = [];
    let user_name = this.globals.user_name;
    let team_name = this.globals.ebsTeamSelected;
    let team_id = this.globals.ebsTeamIdSelected;
    let templateItem = {
      event_template_name: this.template.template_name,
      event_template_desc: this.template.template_name,
      guest_count: 0,
      active_ind : 'Y',
      associate_count : 0,
      team_id: team_id,
      copy_template_id: this.template.copy_template_id,
      template_type_id: this.selectedType.template_type_id,
      template_type_name: this.selectedType.template_type_name,
      created_by : user_name,
      modified_by : user_name

    };
    //payLoad.push(templateItem);
    console.log("copy_template_id" + this.template.copy_template_id);
    this.ebsService.createTemplate(team_name, templateItem).subscribe((res: Response) => {
      this.toastrMsg = "Created " + this.template.template_name + "! <br/>";
      this.toastr.success(this.toastrMsg,
        'Create Template', {
        enableHtml: true,
        closeButton: true
      });
      setTimeout(() => { this.activeModal.close(1) }, 3000);
      this.ebsService.filter('load');
    }, err => {
      console.log('error --->', err);
      _.set('createTemplate', 'status', 'warning');

      this.toastrMsg = "FAILED to created the template! <br/>";
      this.toastr.error(this.toastrMsg,
        'Create Template', {
        enableHtml: true,
        closeButton: true
      });
    })
  }

  onSelectionChanged($event) {
    var selectedRows = this.gridApi.getSelectedRows();
    this.template.copy_template_id = selectedRows[0].event_template_id;    
    console.log("selectedRows" + selectedRows[0].event_template_id);
  }


  select($ev, component, isDateChange = false) {
    component.model = $ev;

  }

  parameterSelected(value) {
    this.selectedType = value;
    //this.loadTemplates();

    console.log(this.selectedType.template_type_id);
    console.log(this.selectedType.template_type_name);
    this.templateType = this.selectedType.template_type_name;
  }

  getTemplateData (ebsTeamSelected:string,paginationPageSize:number):IDatasource{
    const data : IDatasource = {
      getRows: (params: IGetRowsParams) => {
        this.blockUI.start('Loading...');
        let teamName = ebsTeamSelected;
        let page = params.endRow / paginationPageSize;
        console.log("teamName" + teamName);     
        let sortModel = '';      
        let searchModel = '';         
        
      if (typeof params.sortModel[0] !== 'undefined'){   
        sortModel = this.templateservice.getSortModel(params.sortModel[0] );
      }
     searchModel = this.templateservice.getSearchModel(params.filterModel,'');
     console.log(searchModel);
     console.log(this.templateType);     
     if(this.templateType !== '') 
       searchModel = this.templateservice.getSearchModel(params.filterModel,this.templateType);
     
      this.ebsService.getTemplateData(teamName,
        paginationPageSize.toString(),
        page.toString(),sortModel,searchModel)
        .subscribe((res: any) => {                  
          params.successCallback(res.data, res.metadata.result_count);    
        });
      }
    };
    return data;
  }

}


