import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { TeamTemplateComponent } from './team-template/team-template.component';
import { AddTemplateComponent } from './add-template/add-template.component';


const routes: Routes = [
  {
    path: 'team-template',
    component: TeamTemplateComponent
  },

  {
    path: 'add-template',
    component: AddTemplateComponent
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TeamTemplatesRoutingModule { }
