import {Component, Input, OnInit, ViewChild, ViewEncapsulation} from '@angular/core';
import * as _ from 'lodash';
import { Globals } from '@staff/shared/common/global/global.provider';
import { CommonService } from '@staff/shared/common/services/common.service';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { EventBaseScheduleService } from '../../../shared/common/services/ebs.service';
import { Router } from '@angular/router';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { TemplateDetails } from '@staff/ebs/common/template-details/template-details.component';
import { TeamTemplateService } from '../../../shared/common/services/teamtemplate.service';
import { IDatasource, IGetRowsParams } from 'ag-grid-community';
import {AgGridAngular} from "ag-grid-angular";

@Component({
  selector: 'app-copy-template',
  templateUrl: './copy-template.component.html',
  styleUrls: ['./copy-template.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CopyTemplateComponent implements OnInit {
    @ViewChild('agGrid') agGrid: AgGridAngular;
    @ViewChild(TemplateDetails) templatedata :TemplateDetails;
    @Input () selectedTeam: string = '';
    @Input () selectedEventId: number;
    @BlockUI() blockUI: NgBlockUI; 
    @Input() wkEndDate: any = '';
    @Input() payGrp_id: any = '';
  
  hasData = false;
  eventAddress: string = '';
  isloaded = true;
  isdetails = false;
  isloadedFrame = false;
  ifSelEventVisible: boolean= true;
  paginationPageSize = 20;
  gridApi: any;
  
  gridColumnApi: any;
  selectedTemplate:any;
  templateId:any;
  data:any;
  selectedType:any;
  paginationNumberFormatter = function (params) {
    return "[" + params.value.toLocaleString() + "]";
  };
  eventTemplateRowData = [];
  width = '100%';
  height = 'calc(100vh - 200px)';

  
  eventTemplateGridOptions: any = {
    defaultColDef: {
      sortable: true,
      resizable: true,
    },
    copyHeadersToClipboard: true,
    suppressMaxRenderedRowRestriction: true,
    suppressColumnVirtualisation: true,
    groupDefaultExpanded: -1,
    rowBuffer: 9999,
    floatingFilter: true,
    rowModelType: 'infinite',
    cacheBlockSize: this.paginationPageSize,
    rowSelection : "single"

  };

  eventTemplateHeader: any = [   
    {
      headerName: 'Template Name',
      field: 'event_template_name',
      filter: "agTextColumnFilter",
      checkboxSelection: true
    },
    {
      headerName: 'Template Type',
      field: 'template_type',
      filter: "agTextColumnFilter",
    },
    {
      headerName: 'Coverage',
      field: 'associate_count',      
      filter: "agTextColumnFilter",
      suppressMenu: true,
      cellRenderer: params => params.value ? params.value : 0
    },
    {
      headerName: 'Guest Attendence',
      field: 'guest_count',
      filter: "agTextColumnFilter",
      cellRenderer: params => params.value ? params.value : 0
    }
    
  ];





 
  toastrMsg: string = '';

  constructor(
    public globals: Globals,
    private modalService: NgbModal,
    public activeModal: NgbActiveModal,
    public commonService: CommonService,
    public scheduleService: EventBaseScheduleService,
    private toastr: ToastrService,
    private router: Router,
    private templateservice:TeamTemplateService
  ) {
    this.selectedTeam = this.globals.ebsTeamSelected;
    this.wkEndDate = this.globals.ebsWkEndSelected;
    this.payGrp_id = this.globals.ebsPayGrpId;
  }

  ngOnInit() {
  }

 

 
  goBack(){
    this.router.navigateByUrl('/ebs/events')
  }


  parameterSelected(value) {
    this.selectedType = value;
    console.log(this.selectedType.template_type_id);
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    let teamName = this.globals.ebsTeamSelected;
    let dataSource = this.getTemplateData(teamName, this.paginationPageSize);
    this.gridApi.setDatasource(dataSource);
    params.api.sizeColumnsToFit();
  }

  getTemplateData (ebsTeamSelected:string,paginationPageSize:number):IDatasource{
    const data : IDatasource = {
      getRows: (params: IGetRowsParams) => {
        this.blockUI.start('Loading...');
        let teamName = ebsTeamSelected;
        let page = params.endRow / paginationPageSize;
        console.log("teamName" + teamName);     
        let sortModel = '';      
        let searchModel = '';     
        
      if (typeof params.sortModel[0] !== 'undefined'){   
        sortModel = this.templateservice.getSortModel(params.sortModel[0] );
      }
     searchModel = this.templateservice.getSearchModel(params.filterModel,'');
     console.log(searchModel);
      this.scheduleService.getTemplateData(teamName,
        paginationPageSize.toString(),
        page.toString(),sortModel,searchModel)
        .subscribe((res: any) => {                  
          params.successCallback(res.data, res.metadata.result_count);    
        });
      }
    };
    return data;
  }
  

  
  onSelectionChanged($event){
    console.log("onSelectionChanged" );
    var selectedRows = this.gridApi.getSelectedRows();    
    this.templateId = selectedRows[0].event_template_id;
    console.log("selectedRows" + selectedRows[0].event_template_id);
    }

  showDetails(){
    console.log("added details loop" + this.templateId);    
    this.selectedTemplate = this.globals.ebsTemplateSelected;
    //window.addEventListener('addTaskEvent', this.addTask.bind(this));
    //window.addEventListener('addLocationEvent', this.addLocation.bind(this));
    // this.scheduleService.getTemplateDetailsData().subscribe(val=>{
    //   this.data = val;
    //  // this.setSchedulerData();
    // })
  
    this.isdetails = true;
    this.isloaded = false;
    this.isloadedFrame = true;    
    this.taskStartTime = '9:00';
    this.taskEndTime = '17:00';
    this.teamName = this.globals.ebsTeamSelected;
    this.templateDetailsId =  this.templateId;
  }

  teamName : any = 'C-6335';
  taskStartTime: any = '11:00';
  taskEndTime: any = '15:00';      
  templateDetailsId:any = '';
  
  onSave(data){
    data.map(v=>v.template_id='10002');
    console.log(data);
   // this.ebsTemplateService.updateTemplateTasks('6335',data.filter(res=>res.updated)).subscribe(res=>{});
  }

  addTasks(){
    console.log(this.templatedata.data);    
    let eventItem = {
      "event_id": this.globals.ebsEventSelected.event_id,
      "tasks" : this.templatedata.data,
      "team_name" : this.selectedTeam,
      "paygroup_id" : this.globals.ebsPayGrpId,
      "weekend_date" : this.globals.ebsWkEndSelected,
      "schedule_id" : 10021,
      "created_by": "string",  
      "modified_by": "string",  
      "team_id": this.globals.ebsEventSelected.team_id,      
      "template_id": this.templateId
    };
    //payLoad.push(eventItem);    
    this.scheduleService.createTeamTemplateHistory(this.selectedTeam, eventItem).subscribe(
      result => {
        this.toastrMsg = "Copied Tasks!";
        this.toastr.success(this.toastrMsg,
          '', {
            enableHtml: true,
            closeButton: true
          });
        setTimeout(() => {
        }, 1000);
      },
      error => {
        this.toastrMsg = "FAILED to copy tasks! <br/>";
        this.toastr.error(this.toastrMsg,
          '', {
            enableHtml: true,
            closeButton: true
          });
      }
    );
  }
}
