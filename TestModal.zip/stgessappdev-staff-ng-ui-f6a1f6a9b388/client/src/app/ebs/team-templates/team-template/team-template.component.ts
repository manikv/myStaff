import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { trigger, state, style, animate, transition, query } from '@angular/animations';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as _ from 'lodash';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Globals } from '../../../shared/common/global/global.provider';
import { CommonService } from '../../../shared/common/services/common.service';
import { EventBaseScheduleService } from '../../../shared/common/services/ebs.service';
import { AddTemplateComponent } from '../add-template/add-template.component';
import { IDatasource, IGetRowsParams } from 'ag-grid-community';
import {TeamTemplateService} from '../../../shared/common/services/teamtemplate.service';

@Component({
  selector: 'ebs-team-template',
  templateUrl: './team-template.component.html',
  animations: [
    trigger('smoothCollapse', [
      state('initial', style({
        height: '0',
        opacity: '0',
        overflow: 'hidden',
        padding: '5px'
      })),
      state('final', style({
        opacity: '1'
      })),
      transition('initial=>final', animate('150ms')),
      transition('final=>initial', animate('150ms'))
    ])],
  encapsulation: ViewEncapsulation.None
})
export class TeamTemplateComponent implements OnInit {
  @BlockUI() blockUI: NgBlockUI;
 
  
  date: any;
  heading: any = 'Event Template'

  paginationPageSize = 20;
  paginationNumberFormatter = function (params) {
    return "[" + params.value.toLocaleString() + "]";
  };
  eventTemplateRowData = [];
  width = '100%';
  height = 'calc(100vh - 200px)';
  rowSelection = "single";
  selectedAssociates = [];
  context;
  gridApi: any;
  gridColumnApi: any;
  private rowModelType;
  
  headerCount: number;
  state: string = 'initial';
  
  templateName:String;

  eventTemplateHeader: any = [
    {
      headerName: 'Edit',
      field: 'emp_fullname',
      width: 60,
      cellRenderer: function (params) {
        return '<i class="fa fa-pencil" aria-hidden="true"></i>'
      },
      onCellClicked:  function (params) {
        this.globals.ebsTemplateSelected = params.data;
        this.router.navigateByUrl('/ebs/templates/details');
      }.bind(this)
    },
    {
      headerName: 'Template Name',
      field: 'event_template_name',
      filter: "agTextColumnFilter",
      filterParams: {
        valueGetter: params => {          
          return params.data.event_template_name
        }
      }
    },
    {
      headerName: 'Template Type',
      field: 'template_type',
      filter: "agTextColumnFilter",
    },
    {
      headerName: 'Coverage',
      field: 'associate_count',      
      filter: "agTextColumnFilter",
      suppressMenu: true,
      cellRenderer: params => params.value ? params.value : 0
    },
    {
      headerName: 'Guest Attendence',
      field: 'guest_count',
      filter: "agTextColumnFilter",
      cellRenderer: params => params.value ? params.value : 0
    },
    {
      headerName: 'Active',
      field: 'active_ind',
      filter: "agTextColumnFilter",
    },
  ];



  frameworkComponents;
  overrideType = '';
  defaultValue = '0';
  isSubmitting: boolean = false;

  eventTemplateGridOptions: any = {
    defaultColDef: {
      sortable: true,
      resizable: true,
    },
    copyHeadersToClipboard: true,
    suppressMaxRenderedRowRestriction: true,
    suppressColumnVirtualisation: true,
    groupDefaultExpanded: -1,
    rowBuffer: 9999,
    floatingFilter: true,
    rowModelType: 'infinite',
    cacheBlockSize: this.paginationPageSize,
    

  };
  isloaded = false;

  constructor(
    private toastr: ToastrService,
    private modalService: NgbModal,
    public globals: Globals,
    public commonService: CommonService,
    private ebsService: EventBaseScheduleService,
    private templateService:TeamTemplateService,
    private router: Router
  ) {
     this.ebsService.listen().subscribe((m:any) => {   
      let teamName = this.globals.ebsTeamSelected;
      let dataSource = this.getTemplateData(teamName,this.paginationPageSize); 
     this.gridApi.setDatasource(dataSource);     
     
     })
     
  }


  onPageSizeChanged(newPageSize) {
    this.gridApi.paginationSetPageSize(Number(newPageSize));
  }


  ngOnInit() {    
    this.isloaded = true;
  }

  onSelectionChanged($event) {
    var selectedRows = this.gridApi.getSelectedRows();
    // this.timoffDetailsModalOpen(selectedRows)
  }


  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;   
    let teamName = this.globals.ebsTeamSelected;
    let dataSource = this.getTemplateData(teamName,this.paginationPageSize);
    params.api.setDatasource(dataSource);        
    params.api.sizeColumnsToFit();    
  }



  getTemplateData (ebsTeamSelected:string,paginationPageSize:number):IDatasource{
    const data : IDatasource = {
      getRows: (params: IGetRowsParams) => {
        this.blockUI.start('Loading...');
        let teamName = ebsTeamSelected;
        let page = params.endRow / paginationPageSize;
        console.log("teamName" + teamName);     
        let sortModel = '';      
        let searchModel = '';     
        
      if (typeof params.sortModel[0] !== 'undefined'){   
        sortModel = this.templateService.getSortModel(params.sortModel[0] );
      }
     searchModel = this.templateService.getSearchModel(params.filterModel,'');
     console.log(searchModel);
      this.ebsService.getTemplateData(teamName,
        paginationPageSize.toString(),
        page.toString(),sortModel,searchModel)
        .subscribe((res: any) => {                  
          params.successCallback(res.data, res.metadata.result_count);    
        });
      }
    };
    return data;
  }
  


  addTemplate() {

  let modalRef = this.modalService.open(AddTemplateComponent, { size: 'lg', backdropClass: 'z-1-backdrop' }); 
  modalRef.result.then((result) => {
    console.log("result:" + result);
    if (result == 1) {
      //new event added; refresh
     // this.getWeeklyEvents(this.selectedTeam, this.startDate, this.endDate, this.user_name);
    }
  });
}
}
