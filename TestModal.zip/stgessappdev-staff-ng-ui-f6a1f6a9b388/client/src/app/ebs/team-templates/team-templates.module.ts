import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import 'ag-grid-community';
import 'ag-grid-enterprise';

import { LicenseManager } from 'ag-grid-enterprise';
import { EventBaseScheduleService } from '../../shared/common/services/ebs.service';
import { TeamTemplatesRoutingModule } from './team-templates-routing.module';
import { AgGridModule } from 'ag-grid-angular';
import { BlockUIModule } from 'ng-block-ui';

LicenseManager.setLicenseKey("SoftwareONE_USA_on_behalf_of_Compass_Group_USA_MultiApp_5Devs_5Deployment_12_August_2020__MTU5NzE4NjgwMDAwMA==de1432ef47c510c631b782c11ab2920d");

import { TeamTemplateComponent } from './team-template/team-template.component';
import { AddTemplateComponent } from './add-template/add-template.component';
import { TemplateTypeDropdownModule } from '@staff/sharedModules/index';
import { TemplateDetailsModule } from '@staff/ebs/common/template-details/template-details.module';
import { TeamTemplateService } from '../../shared/common/services/teamtemplate.service';
import { CopyTemplateComponent } from "@staff/ebs/team-templates/copy-template/copy-template.component";



@NgModule({
  declarations: [
    TeamTemplateComponent,
    AddTemplateComponent,
    CopyTemplateComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    NgbModule,
    TeamTemplatesRoutingModule,   
    BlockUIModule.forRoot(),
    AgGridModule.withComponents(),     
    TemplateTypeDropdownModule,
    TemplateDetailsModule 

  ],
  providers: [
    EventBaseScheduleService,
    TeamTemplateService
  ],
  entryComponents: [
    TeamTemplateComponent,
    AddTemplateComponent,
  ],
  exports: [
    TeamTemplateComponent,
    AddTemplateComponent,
    CopyTemplateComponent
  ]

})
export class TeamTemplatesModule { };