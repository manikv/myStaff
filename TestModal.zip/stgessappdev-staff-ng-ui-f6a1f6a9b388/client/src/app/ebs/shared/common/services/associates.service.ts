import { Injectable } from '@angular/core';
import { Observable, forkJoin } from 'rxjs';
import { Observer } from 'rxjs/internal/types';
import { Globals } from '../../../../shared/common/global/global.provider';
import { EventBaseScheduleService } from '../../../../shared/common/services/ebs.service';
import * as moment from 'moment';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import { BurstService } from '../../../../shared/common/services/burst.service';

@Injectable()
export class AssociatesService {

    constructor(public eventBaseScheduleService: EventBaseScheduleService, public globals: Globals, public burstService: BurstService) { }

    getTeamAssociates(teamName: string): Observable<any> {
        let result = [];
        return new Observable((observer: Observer<any>) => {
            let getTeamAssociates = this.eventBaseScheduleService.getTeamAssociates(teamName);
            let getTeamScheduleAssociates = this.eventBaseScheduleService.getTeamScheduleAssociates( 'C-6335', 'TESTO06', 10201,  '01/01/2021', '01/08/2021');
            forkJoin([getTeamAssociates, getTeamScheduleAssociates]).subscribe(response => {
                let teamAssociates = [], scheduleAssociates = [];
                teamAssociates = response[0] || [];
                scheduleAssociates = response[1] || [];

                teamAssociates.forEach((associate) => {

                    let asso = {
                        empFullName: associate.emp_full_name,
                        empId: associate.emp_id,
                        empName: associate.emp_name,
                        empStatus: associate.emp_status,
                        hireDate: '10/10/2010', //associate.hireDate,
                        jobId: associate.job_id,
                        jobName: associate.job_name,
                        jobDesc: associate.job_desc,
                        checkBoxSelected: false,
                        complex: associate.complex,
                        email: 'abc@compass.com',
                        phoneNo: '704-353-5353',
                        starRating: 3.5 || 0,
                        schdHours: 0,
                        schedules: []
                    };
                    if (scheduleAssociates.length > 0) {
                        let filteredSchd = scheduleAssociates.filter(schd => { return schd.employee_id === associate.emp_id });
                        asso.schedules = filteredSchd;
                    }
                    //console.log('asso.schedules', filteredSchd);
                    result.push(asso);

                });

                observer.next(result);
                observer.complete();

            });


        });
    }


    createScheduleForAssociates(schedules) {
        console.log('schedules', schedules);
        let data = [{
            created_by: this.globals.user_name,
            created_date: moment().format('MM/DD/YYYY HH:mm'),
            employee_id: schedules.assignments[0].empId,
            errors: null,
            id: 0,
            personnel_number: null,
            processed_indicator: "P",
            scheduled_date: "11/10/2020",
            // updated_by: this.globals.user_name,
            //  updated_date: moment().format('MM/DD/YYYY HH:mm'),
            wbt_id: 12660,
            shifts: [
                {
                    break_end: "11/10/2020 21:00",
                    break_start: "11/10/2020 20:30",
                    shift_flag: 'save', //new, update, delete
                    department_desc: null,
                    department_id: 14892,
                    department_name: null,
                    end: "11/10/2020 23:00",
                    errors: null,
                    job_desc: schedules.assignments[0].jobDesc,
                    job_id: schedules.assignments[0].jobId,
                    job_name: null,
                    project_id: 103974,
                    start: "11/10/2020 17:00",
                    task_id: 154126,
                    task_name: null,
                    sched_hours: 0,
                    event_id: 10107,
                    location_id: null,
                    unpaid_minutes: 0
                }
            ]
        }];

        return new Observable((observer: Observer<any>) => {
            this.eventBaseScheduleService.createScheduleForAssociates('C-6335', 'TESTO06', data).subscribe(
                result => {
                    console.log(result);
                    observer.next(data);
                    observer.complete();
                },
                error => {
                    console.log(error);
                    observer.error(error);
                    observer.complete();
                }
            );
        });
    }


    getEmployeesForBurst(team_name: string, radius: number, shift_start_date: string, shift_end_date: string, all: boolean, district: boolean, schedHours: boolean): Observable<any> {
        return new Observable((observer: Observer<any>) => {
            this.burstService.getEmployeesByTeamRadiusDistrict(team_name, radius, shift_start_date, shift_end_date, all, district, schedHours).subscribe((response: any) => {
                    console.log("...called getEmployeesForBurst successfully !!");
                    let burstEmployeeTeamList = [];

                    response.map((associate) => {
                        let asso = {
                            empFullName: associate.first_name + ' ' + associate.last_name,
                            empId: associate.emp_id,
                            empName: associate.emp_name,
                            empStatus: associate.emp_status,
                            hireDate: '10/10/2010', //associate.hireDate,
                            jobId: associate.job_id,
                            jobName: associate.job_name,
                            jobDesc: associate.job_desc,
                            checkBoxSelected: false,
                            complex: associate.complex,
                            email: 'abc@compass.com',
                            phoneNo: '704-353-5353',
                            starRating: 3.5 || 0,
                            schdHours: associate.sched_hours || 0,
                            teamName: associate.team_name,
                            wbt_id: associate.wbt_id
                        };
                        burstEmployeeTeamList.push(asso);
                    });


                observer.next(burstEmployeeTeamList);
                    observer.complete();
                });
        });
    }

    getShiftBurstAssignments(burst_id: any): Observable<any> {
        let response: any = {};
        return new Observable((observer: Observer<any>) => {
            this.burstService.getShiftBurstAssignments(burst_id).subscribe(
                assign_res => {
                    observer.next(assign_res);
                    observer.complete();
                });
        })
    }


}
