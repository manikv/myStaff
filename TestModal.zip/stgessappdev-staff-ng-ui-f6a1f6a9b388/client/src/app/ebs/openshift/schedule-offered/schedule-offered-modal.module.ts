import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AgGridModule } from 'ag-grid-angular';
import { scheduleOfferedModalComponent } from './schedule-offered-modal.component';
import { BurstService } from '../../../shared/common/services/burst.service';

@NgModule({
    entryComponents: [
        scheduleOfferedModalComponent
    ],
    declarations: [
        scheduleOfferedModalComponent
    ],
    imports: [
        CommonModule,
        NgbModule,

    ],
    exports: [
       scheduleOfferedModalComponent
    ],
    providers: [
        BurstService
    ]
})
export class scheduleOfferedModalModule {
}
