import { Component, OnInit, ViewEncapsulation, Input } from '@angular/core';
import { NgbModal, NgbActiveModal, NgbCarousel, NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
import { interval, Observable, of, from, zip } from 'rxjs';
import { map, startWith, take, groupBy, mergeMap, reduce, toArray } from 'rxjs/operators';
import { Globals } from '../../../shared/common/global/global.provider';
import { AssociatesService } from '../../shared/common/services/associates.service';
import { BurstService } from '../../../shared/common/services/burst.service';
import { Observer } from "rxjs/internal/types";
import * as moment from 'moment';
import Swal from 'sweetalert2';
import { FormsModule } from '@angular/forms';



import * as _ from 'lodash';

@Component({
    templateUrl: './schedule-offered-modal.component.html',
    styleUrls: ['./schedule-offered-modal.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class scheduleOfferedModalComponent implements OnInit {

    height = 'calc(100vh - 350px)';
    notifiedList:any = [];
    acceptedList: any = [];
    scheduledList: any = [];
    declinedList: any = [];

    eventDetail: any = { taskName: 'waiter/waitress', date: '10/10/2020', startTime: '12:00 AM - 12:00 AM', mealTime: '12:00 AM - 12:00 AM', location:'2400 Yorkmont Road, Charlotte NC 28217', positions:20  };

    @Input() public taskDetail;

    constructor(public activeModal: NgbActiveModal, public globals: Globals, public scheduleAssociatesService: AssociatesService, private burstService: BurstService) {
        console.log(this.taskDetail);
    }

    ngOnInit() {

        this.scheduledOffered();
    }


    offerAccepted(item: any){
        item.unsavedResponse = true;
        this.scheduledList.push(item);
        this.acceptedList.forEach((emp, index) => {
            if (item === emp) this.acceptedList.splice(index, 1);
        });
    }

    offerDeclined(item: any) {
        item.unsavedResponse = true;
        this.declinedList.push(item);
        this.acceptedList.forEach((emp, index) => {
            if (item === emp) this.acceptedList.splice(index, 1);
        });
    }

    scheduledOffered(){

        this.scheduleAssociatesService.getShiftBurstAssignments(13985).subscribe(
            (res: any) => {
                res.map(as => {
                    console.log('as', as);
                    this.notifiedList.push(as);
                    if (as.employeeResponse === "Accepted" && as.managerResponse === "Published") {
                        this.acceptedList.push(as);
                    }

                    if (as.managerResponse === "Scheduled" && as.employeeResponse === "Accepted") {
                        this.scheduledList.push(as);
                    }

                    if (as.employeeResponse === "Declined" || as.managerResponse === "Declined") {
                        this.declinedList.push(as);
                    }
                });
            });
    }

    saveSchedule() {
        const data = {
            assignments: []
        };

        this.declinedList.forEach((emp) => {
            if (emp.unsavedResponse) {
                let item = {
                    empId: emp.empId,
                    managerResponse: 'Declined',
                    scheduleDate: emp.scheduleDate,
                    taskId: emp.taskId,
                    burstId: emp.burstId,
                    jobId: emp.jobId
                }
                data.assignments.push(item);
            }
        });

        this.scheduledList.forEach((emp) => {
            if (emp.unsavedResponse) {
                let item = {
                    empId: emp.empId,
                    managerResponse: 'Scheduled',
                    scheduleDate: emp.scheduleDate,
                    taskId: emp.taskId,
                    burstId: emp.burstId,
                    jobId: emp.jobId
                }
                data.assignments.push(item);
            }
        });


        console.log('data', data);
        // this.burstService.updateBurstAssignments(data).subscribe((response: any) => {

        //     if (response.error.length) {
        //         Swal.fire('Error!', response.error[1], 'error');
        //         return;
        //     }
        //     this.toasterAlert('success', 'Saved successfully');
        //     this.activeModal.close();
        // }, err => {

        //     Swal.fire('Error!', 'Something was wrong, please try again !', 'error');
        // });

        this.toasterAlert('success', 'Saved successfully');
             this.activeModal.close();
    }

    closeBooking(){

        this.burstService.updateManagerShiftBurst(121, 'Closed').subscribe(
            res => {
                this.toasterAlert('success', 'Booking closed successfully');
                this.closeModal();

            }, err => {
                console.log(err);
                this.toasterAlert('error', 'Error Occured - booking is not closed');
                this.closeModal();

            });

    }

    toasterAlert(iconVal, message) {
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        })

        Toast.fire({
            icon: iconVal,
            title: message
        })
    }

    closeModal(){
        this.activeModal.close(0);
    }
}