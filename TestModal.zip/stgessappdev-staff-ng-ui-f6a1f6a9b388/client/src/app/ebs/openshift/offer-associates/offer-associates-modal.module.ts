import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AgGridModule } from 'ag-grid-angular';
import { offerAssociatesModalComponent } from './offer-associates-modal.component';
import { BurstService } from '../../../shared/common/services/burst.service';

@NgModule({
    entryComponents: [
        offerAssociatesModalComponent
    ],
    declarations: [
        offerAssociatesModalComponent
    ],
    imports: [
        CommonModule,
        NgbModule,
        AgGridModule.withComponents([]),

    ],
    exports: [
       offerAssociatesModalComponent
    ],
    providers: [
        BurstService
    ]
})
export class offerAssociatesModalModule {
}
