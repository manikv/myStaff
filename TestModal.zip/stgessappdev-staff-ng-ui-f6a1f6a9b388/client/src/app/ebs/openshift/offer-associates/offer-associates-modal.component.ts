import { Component, OnInit, ViewChild, ViewEncapsulation, Input } from '@angular/core';
import { NgbModal, NgbActiveModal, NgbCarousel, NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
import { interval, Observable, of, from, zip } from 'rxjs';
import { map, startWith, take, groupBy, mergeMap, reduce, toArray } from 'rxjs/operators';
import { Globals } from '../../../shared/common/global/global.provider';
import { AssociatesService } from '../../shared/common/services/associates.service';
import { BurstService } from '../../../shared/common/services/burst.service';
import { Observer } from "rxjs/internal/types";
import * as moment from 'moment';
import Swal from 'sweetalert2';
import { FormsModule } from '@angular/forms';
import * as fromScheduling from "@staff/store/stores/scheduling.state";
import { Store, select } from '@ngrx/store';

import * as _ from 'lodash';

@Component({
    templateUrl: './offer-associates-modal.component.html',
    styleUrls: ['./offer-associates-modal.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class offerAssociatesModalComponent implements OnInit {
    isDefault: boolean = true;
    isCustom: boolean = false;
    defaultClass: any = 'toggle-switch-active';
    customClass: any = 'toggle-switch-inactive';
    width = '100%';
    height = 'calc(100vh - 350px)';
    susbcription: any;
    data: any = [];
    private gridApi: any;
    private gridColumnApi: any;
    burstTarget: string = '';
    poolCheck: boolean = true;
    districtCheck: boolean = true;
    myteamCheck: boolean = true;
    poolEmployeeList: any = [];
    districtEmployeeList: any = [];
    teamEmployeeList: any = [];
    selectedEmployees: any = [];


    eventDetail: any = { taskName: 'waiter/waitress', date: '10/10/2020', startTime: '12:00 AM - 12:00 AM', mealTime: '12:00 AM - 12:00 AM', location: '2400 Yorkmont Road, Charlotte NC 28217', positions: 20 };

    @Input() public taskDetail;

    constructor(public activeModal: NgbActiveModal, public globals: Globals, public scheduleAssociatesService: AssociatesService,
        private burstService: BurstService, private _store: Store<fromScheduling.ISchedulingState>) {
        console.log('taskDetail', this.taskDetail);
    }

    ngOnInit() {
        this.burstTarget = 'pool'; // default burst to pool
        this.getAssociatesForOpenShift();

    }

    associateColDef: any = [
        {
            field: 'jobDesc',
            rowGroup: true,
            hide: true,
        },
        {
            headerName: 'Team',
            field: 'teamName',
            filter: "agTextColumnFilter"

        },
        {
            headerName: 'Schedule Hours',
            field: 'schdHours',
            filter: "agTextColumnFilter",

        },
        {
            headerName: 'Status',
            field: 'disableAssociate',
            filter: "agTextColumnFilter",

        },
        {
            headerName: 'Rating',
            field: 'starRating',
            filter: "agTextColumnFilter",
            cellRenderer: function (params) {
                return '<div><span class="stars-container stars-' + params.value * 20 + '">★★★★★</span></div>'
            }

        },
        {
            headerName: 'Rank',
            field: 'starRating',
            filter: "agTextColumnFilter",
            minWidth: 60,
            maxWidth: 80,

        }, {
            headerName: 'Hire Date',
            field: 'hireDate',
            filter: "agTextColumnFilter",
        },
        {
            headerName: 'Phone No',
            field: 'phoneNo',
            filter: "agTextColumnFilter",
            minWidth: 110,
            maxWidth: 140,

        },
        {
            headerName: 'Email',
            field: 'email',
            filter: "agTextColumnFilter",
        }
    ];
    associateGridOptions: any = {
        defaultColDef: {
            sortable: true,
            resizable: true,
            flex: 1
        },
        rowSelection: 'multiple',
        rowMultiSelectWithClick: true,
        enableRangeSelection: true,
        onRangeSelectionChanged: this.onRangeSelectionChanged,
        suppressMaxRenderedRowRestriction: true,
        suppressColumnVirtualisation: true,
        groupDefaultExpanded: -1,
        rowBuffer: 9999,
        floatingFilter: true,
        autoGroupColumnDef: {
            headerName: 'Associates',
            field: 'empFullName',
            suppressSizeToFit: true,
            cellRenderer: 'agGroupCellRenderer',
            filter: "agTextColumnFilter",
            minWidth: 300,
            maxWidth: 500,
            cellRendererParams: {
                checkbox: true,
                // innerRenderer: this.checkbox

            },

        },
        groupSelectsChildren: true,

        isRowSelectable: function (rowNode) {
            // console.log('rowNode.data', rowNode.data);
            return rowNode.data ? !rowNode.data.disableAssociate : false;
        }


    };
    onSelectionChanged(event) {
        var selectedRows = this.gridApi.getSelectedRows();
        this.selectedEmployees = selectedRows;

    }
    onRangeSelectionChanged(event) {
        // console.log('has changed, started = ' + event.started);
        // console.log('has changed, finished = ' + event.finished);
        let nodes = event.api.getSelectedNodes();
        // console.log('event', event.api, nodes);
    }
    onGridReady(params) {
        // console.log('params', params);
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
    }

    toggleAssociate(value) {
        //  console.log('value', value);
        if (value === 'default') {
            this.isCustom = false;
            this.isDefault = true;
            this.defaultClass = 'toggle-switch-active';
            this.customClass = 'toggle-switch-inactive';

        }
        if (value === 'custom') {
            this.isCustom = true;
            this.isDefault = false;
            this.defaultClass = 'toggle-switch-inactive';
            this.customClass = 'toggle-switch-active';
            this.updateBookingTarget('myteam');
            this.districtCheck = false;
            this.poolCheck = false;
            this.getAssociatesForOpenShift();
        }

    }

    getAssociatesForOpenShift() {
        this.data = [];
        let date = moment().format('MM/DD/YYYY');
        let all = this.poolCheck;
        let district = this.districtCheck && !this.poolCheck ? true : false;
        if (this.burstTarget === 'myteam') {
            if (this.teamEmployeeList.length === 0) {
                this.scheduleAssociatesService.getEmployeesForBurst('6335', 5, moment(date).format('MM/DD/YYYY'), moment(date).format('MM/DD/YYYY'), all, district, true)
                    .subscribe((response: any) => {
                        this.teamEmployeeList = response;

                    }, err => {
                        console.log('error  ----> ', err);
                    });
            }

            setTimeout(() => {
                this.data = this.teamEmployeeList;
            }, 400);

        } else if (this.burstTarget === 'district') {
            if (this.districtEmployeeList.length === 0) {
                this.scheduleAssociatesService.getEmployeesForBurst('6335', 5, moment(date).format('MM/DD/YYYY'), moment(date).format('MM/DD/YYYY'), all, district, true)
                    .subscribe((response: any) => {
                        this.districtEmployeeList = response;

                    }, err => {
                        console.log('error  ----> ', err);
                    });
            }
            setTimeout(() => {
                this.data = this.districtEmployeeList;
            }, 400);
        } else {
            if (this.poolEmployeeList.length === 0) {
                this.scheduleAssociatesService.getEmployeesForBurst('6335', 5, moment(date).format('MM/DD/YYYY'), moment(date).format('MM/DD/YYYY'), all, district, true)
                    .subscribe((response: any) => {
                        this.poolEmployeeList = response;

                    }, err => {
                        console.log('error  ----> ', err);
                    });
            }
            this.data = this.poolEmployeeList;
        }

    }
    createBooking() {
        let employee_list = [];

        if (this.isCustom) {
            //  console.log(' this.selectedEmployees', this.selectedEmployees);
            this.selectedEmployees.forEach(employee => {
                let empName = employee.empName;
                let empJobId = employee.jobId;
                let empId = employee.empId;
                employee_list.push({ empName: empName, empJobId: empJobId, empId: empId });
            });
        } else {
            this.teamEmployeeList.forEach(employee => {
                let empName = employee.emp_name || employee.empName;
                let empJobId = employee.job_id || employee.jobId;
                let empId = employee.emp_id || employee.empId;
                employee_list.push({ empName: empName, empJobId: empJobId, empId: empId });
            });
        }
        console.log('employee_list', employee_list);

        let todayDate = moment().add(2, 'day').format('YYYY-MM-DD');

        let data = {
            burst_to_days: [
                moment(todayDate).format('MM/DD/YYYY')
            ],
            total_positions: this.taskDetail.coverage,
            paygroup_id: 10005,
            burst_name: 'Event - ' + this.taskDetail.location_name + ' - ' + this.taskDetail.task_id,
            tasks: [
                {
                    task_start_time: moment(todayDate + ' ' + this.taskDetail.start_time).format('YYYY-MM-DD HH:mm'),
                    task_end_time: moment(todayDate + ' ' + this.taskDetail.end_time).format('YYYY-MM-DD HH:mm'),
                    break_start_time: moment(todayDate + ' ' + this.taskDetail.break_strat).format('YYYY-MM-DD HH:mm'),
                    break_end_time: moment(todayDate + ' ' + this.taskDetail.break_end).format('YYYY-MM-DD HH:mm'),
                    task_id: this.taskDetail.task_id,
                    rate: "",
                    project_id: 102318,
                    name: this.taskDetail.task_name,
                    positions: [
                        {
                            count: this.taskDetail.coverage,
                            date: moment(todayDate).format('YYYY-MM-DD HH:mm'),
                            day: moment(todayDate).format('ddd')
                        }
                    ]
                }
            ],
            employees: employee_list,
            team_name: "6335",
            is_district: (this.burstTarget === 'district') ? true : false,
            is_pool: (this.burstTarget === 'pool') ? true : false,
            is_team: (this.burstTarget === 'myteam') ? true : false,
            burst_radius: 60,
            comments: "",
            additional_details: {
                details: "[{\"name\":\"Contact\",\"value\":\"Oms.Test06@cgdev.com\"}]"
            },
            user_name: "testo06"
        }
        console.log('dataTest', data);
        this.createBurst(data).subscribe(
            res => {
                //this.successToast('Burst Created for ' + moment(dat.scheduled_date).format('MM/DD/YYYY'));
                console.log('Burst Created for ');
                this.toasterAlert();
                this.closeModal();
            },
            error => {
                //this.errorToast('Error! Burst Creation for ' + moment(dat.scheduled_date).format('MM/DD/YYYY') + ' failed!');
                console.log('Error! Burst Creation for ');
            });
    }


    createBurst(burstData) {
        // burstData.user_name = this.globals.rbacProfile.user_name;
        return new Observable((observer: Observer<any>) => {

            console.log('data', burstData);
            this.burstService.creatBurst(burstData).subscribe(
                result => {
                    this.burstService.createBurstTasks(result['data']).subscribe(
                        burstTaskRes => {
                            burstTaskRes['data'].map((burstTaskAssRes, i) => {
                                this.burstService.createBurstAssigments([burstTaskAssRes]).subscribe(
                                    burstAssignmentsRes => {
                                        if (i === (burstTaskRes['data'].length - 1)) {
                                            observer.next(true);
                                            observer.complete();
                                        }
                                        this.burstService.updateManagerShiftBurst(burstTaskAssRes.burst_id, "Published").subscribe(burstassRes => { });

                                    });
                            });
                        }, error => {
                            observer.error(error);
                            observer.complete();
                        });
                },
                error => {
                    observer.error(error);
                    observer.complete();
                }
            );
        });
    }

    updateBookingTarget(targetName) {
        this.burstTarget = targetName;
    }

    toggleTeamDistrictPoolSelection(ev, targetName) {
        if (targetName === 'pool') {
            if (this.poolCheck) {
                this.poolCheck = false;
                this.updateBookingTarget('district');
            } else {
                this.poolCheck = true;
                this.districtCheck = true;
                this.updateBookingTarget('pool');

            }
        } else if (targetName === 'district') {
            if (this.districtCheck) {
                this.districtCheck = false;
                this.poolCheck = false;
                this.updateBookingTarget('myteam');
            } else {
                this.districtCheck = true;
                this.updateBookingTarget('district');

            }
        } else {
            //myteam
            this.updateBookingTarget('myteam');
            ev.target.checked = true;
            if (!this.districtCheck && !this.poolCheck) {
                Swal.fire('My Team cannot be unchecked', 'Cannot create booking without team');
            } else {
                this.districtCheck = false;
                this.poolCheck = false;
            }
            this.myteamCheck = true;
        }
        this.getAssociatesForOpenShift();
    }

    toasterAlert() {
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        })

        Toast.fire({
            icon: 'success',
            title: 'Saved successfully'
        })
    }


    closeModal() {
        this.activeModal.close(0);
    }
}