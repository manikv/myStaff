/**
 * Cell renderer component
 */
import { Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'br-template-coverage-input',
	template: `<input (click)="inputClick($event)" (blur)="inputChange($event)" class="form-control coverage-input margin-l-4" type="string" [(ngModel)]="coverage" />
	<i class="fa fa-check-circle text-success check-icon" aria-hidden="true" [hidden]="!showIcon"></i>
`,
	styles:[
		'.check-icon{position: absolute;left: 0;top: 16px;margin-left: calc(40% + 35px);}'
	]
})
export class BrTemplateCoverageInputComponent implements OnInit{
		@Input() coverage: string;
		@Input() groupname: any;
		@Input() groupparent: any;
		@Input() task: string;
		@Input() location: string;
		showIcon: boolean = false;

	ngOnInit(){
		this.groupname = this.groupname == "undefined" ? this.groupparent : this.groupname;
		this.groupname = this.groupname.replace(/\s+/g, '-').toLowerCase();
		window.addEventListener(this.groupname + 'Event', this.applyAll.bind(this));
	}

	applyAll(e){
		let _this = this;
		this.coverage = e.detail;
		this.showIcon = true;
		setTimeout(function(){
			_this.showIcon = false;
		},1200);
		const event = new CustomEvent('TemplateCoverageEvent', { detail: {coverage: e.detail, task_id: this.task, location_id: this.location}});
    	window.dispatchEvent(event);
	}

	inputClick(e){
		e.preventDefault();
		e.stopPropagation();
		e.target.select();
	}

	inputChange(e){
		e.preventDefault();
		e.stopPropagation();
		const event = new CustomEvent('TemplateCoverageEvent', { detail: {coverage: this.coverage, task_id: this.task, location_id: this.location}});
    	window.dispatchEvent(event);
	}
}
