import { Component } from "@angular/core";
import { IFilterAngularComp } from "ag-grid-angular";

@Component({
    selector: 'template-add-headrer-cell',
	styles: [
		'.check-group{padding-top:10px;}'
	],
	template: `
	<div class="row check-group" #header>
		<div class="col-sm-7">
			+/- Task
		</div>
		<div class="col-sm-5">
			Coverage
		</div>
	</div>`
})
export class TemplateAddHeader implements IFilterAngularComp {
	public params: any;
	value: any;
	className: string;

	agInit(params: any): void {
		this.params = params;
		this.className = this.params.filterParams.colDef.headerClass;
	}

	isFilterActive(): boolean {
		return true;
	}

	doesFilterPass(params: any): boolean {
		return true;
	}

	getModel(): any {
			return true;
	}

	setModel(model: any): void {
	}
}