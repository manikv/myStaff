# ebs-template-details

#Input
templateId: string /* Template ID */
teamName: string /* Team Name */
canTaskEdit: boolean /* Show the task time to edit, default is false */
showAddTaskLocation: boolean /* Show the add location and add task button, default is false */
taskStartTime: string /* hh:mm */
taskEndTime: string /* hh:mm */
hideSaveButton:boolean /* default true */

#Output
onSubmit /* Callback for save button */
