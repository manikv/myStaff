import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import * as fromTeam from "@staff/store/stores/team.state";
import { Store, select } from '@ngrx/store';
import { cloneDeep } from 'lodash';
import { ToastrService } from 'ngx-toastr';
import { Globals } from "@staff/shared/common/global/global.provider";
@Component({
  selector: 'lib-add-location',
  templateUrl: 'add-location.component.html',
  styles: [
    '.checkbox-list{margin-top:10px;height:150px;border:1px solid #ccc;overflow-y:scroll;}.checkbox-list>div{padding: 5px;border: 1px solid #f0f0f0;cursor: pointer;}.checkbox-list .form-check{padding-bottom: .25rem;}.checkbox-list>div:nth-child(even){}'
  ]
})
export class AddLocationComponent implements OnInit {
  selectedTeam;
  cost_centers = [];
  location = {
    location_name: '',
    location_desc: '',
    wbt_id: ''
  }
  disableSave: boolean = true;

  constructor(
    public activeModal: NgbActiveModal,
    public toastr:ToastrService,
    public globals: Globals,
    private _store: Store<fromTeam.ITeamState>
  ) { }

  ngOnInit(): void {
    this._store.dispatch(new fromTeam.GetTeamCostCentersLoad({selectedTeam: this.globals.ebsTeamSelected}));
    const data$ = this._store.pipe(select(fromTeam.allTeam));
    data$.subscribe(res => {
      this.cost_centers = cloneDeep(res.costCenters);
      if(res.teamLocationCreated){
        this.activeModal.dismiss('Cross click');
        this.toastr.success("Created " + this.location.location_name + "!",
          'Location Added', {
          enableHtml: true,
        });
      }else if(res.teamLocationAddedError){
        this.activeModal.dismiss('Cross click');
        this.toastr.error("Please try again later !",
          'Error', {
          enableHtml: true,
        });
      }
		});
  }

  selectCostCenter(i: number){
    this.disableSave = false;
    this.cost_centers.map(v=>{if(v.selected){v.selected=false}});
    this.cost_centers[i].selected = true;
    this.location.wbt_id = this.cost_centers[i].team_id;
  }

  addLocation(){
    this._store.dispatch(new fromTeam.CreateTeamLocation({selectedTeam: this.globals.ebsTeamSelected, data: this.location}));
  }
}
