/**
 * Cell renderer component
 */
import { Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'br-template-task-cell',
	template: `<button class="btn btn-link" (click)="editTask()"><i class="fa fa-pencil icon-indicator" aria-hidden="true"></i></button>{{taskname}}&nbsp;<span class="emp-no">({{departmentname}})</span>`,
	styles:[]
})
export class BrTemplateTaskCellComponent implements OnInit{
	@Input() groupname: any;
	@Input() groupparent: any;
	@Input() departmentname: string;
	@Input() taskname: string;
	@Input() taskid: string;

	ngOnInit(){
		this.groupname = this.groupname == "undefined" ? this.groupparent : this.groupname;
		this.groupname = this.groupname.replace(/\s+/g, '-').toLowerCase();
  }
    
	editTask(){
		const event = new CustomEvent('editTaskEvent', { detail: {task: this.taskname, department: this.departmentname, taskid: this.taskid}});
		window.dispatchEvent(event);
	};

}
