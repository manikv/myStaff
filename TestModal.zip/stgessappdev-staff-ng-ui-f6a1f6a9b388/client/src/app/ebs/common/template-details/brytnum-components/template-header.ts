/**
 * Cell renderer component
 */
import { Component } from '@angular/core';

@Component({
  selector: 'br-template-header',
  template: `
  <span class="template-header-add-button">
  <button class="btn btn-link btn-default" (click)="addLocation($event)"><i class="fa fa-plus-circle" aria-hidden="true"></i> Location</button>
  <button class="btn btn-link btn-default" (click)="addTask($event)"><i class="fa fa-plus-circle" aria-hidden="true"></i> Task</button>
</span>`
})
export class BrTemplateHeaderComponent {

  addLocation(e){
    e.preventDefault();
    e.stopPropagation();
    const event = new CustomEvent('addLocationEvent', {
      composed   : false,
      bubbles    : false,
      cancelable : true
    });
    window.dispatchEvent(event);
  }

  addTask(e){
    e.preventDefault();
    e.stopPropagation();
    const event = new CustomEvent('addTaskEvent', {
      composed   : false,
      bubbles    : false,
      cancelable : true
    });
    window.dispatchEvent(event);
  }
}
