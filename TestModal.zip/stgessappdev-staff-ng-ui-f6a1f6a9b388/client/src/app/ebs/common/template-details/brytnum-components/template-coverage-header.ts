/**
 * Cell renderer component
 */
import { Component, Input, OnInit} from '@angular/core';

@Component({
  selector: 'br-template-coverage-header',
  template: `<input [(ngModel)]="coverage" (click)="inputClick($event)" class="form-control coverage-input margin-l-1 pull-left" type="text"> <button class="btn btn-link" (click)="applyToAll($event)">Apply to All</button>`
})
export class BrTemplateCoverageHeaderComponent implements OnInit{
	@Input() groupname: string;
  coverage: string;
	ngOnInit(){
		this.groupname = this.groupname.replace(/\s+/g, '-').toLowerCase();
	}

  applyToAll(e){
    e.preventDefault();
    e.stopPropagation();
    const event = new CustomEvent(this.groupname + 'Event', { detail: this.coverage });
    window.dispatchEvent(event);
	}

	inputClick(e){
    e.preventDefault();
    e.stopPropagation();
    e.target.select();
	}
}
