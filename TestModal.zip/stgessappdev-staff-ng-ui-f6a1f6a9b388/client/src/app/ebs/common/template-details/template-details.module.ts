import { NgModule, CUSTOM_ELEMENTS_SCHEMA, Injector } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgbModule, NgbActiveModal, } from '@ng-bootstrap/ng-bootstrap';
import 'ag-grid-community';
import 'ag-grid-enterprise';
import { AgGridModule } from 'ag-grid-angular';
import { LicenseManager } from "ag-grid-enterprise";
LicenseManager.setLicenseKey("SoftwareONE_USA_on_behalf_of_Compass_Group_USA_MultiApp_5Devs_5Deployment_12_August_2020__MTU5NzE4NjgwMDAwMA==de1432ef47c510c631b782c11ab2920d");
import { BryntumAngularSharedModule } from 'bryntum-angular-shared';
import { TemplateDetails, TaskFilterPipe } from './template-details.component';
import { BrTemplateHeaderComponent } from './brytnum-components/template-header'
import { BrTemplateCoverageHeaderComponent } from './brytnum-components/template-coverage-header';
import { BrTemplateCoverageInputComponent } from './brytnum-components/template-coverage-input';
import { BrTemplateTaskCellComponent } from './brytnum-components/template-task-cell';
import { createCustomElement } from '@angular/elements';
import { AddTaskComponent } from './add-task/add-task.component';
import { AddLocationComponent } from './add-location/add-location.component';
import { TemplateAddHeader } from './ag-grid-templates/template-add-header.component';
import { TemplateAddRenderer } from './ag-grid-templates/template-add-renderer.component';
@NgModule({
	entryComponents: [
		BrTemplateHeaderComponent,
		BrTemplateCoverageHeaderComponent,
		BrTemplateCoverageInputComponent,
		BrTemplateTaskCellComponent,
		TemplateAddRenderer,
    TemplateAddHeader,
	],
	declarations: [
		TemplateDetails,
		BrTemplateHeaderComponent,
		BrTemplateCoverageHeaderComponent,
		BrTemplateCoverageInputComponent,
    AddTaskComponent,
    TemplateAddRenderer,
    AddLocationComponent,
		TemplateAddHeader,
		TaskFilterPipe
	],
	imports: [
		CommonModule,
		FormsModule,
		NgbModule,
		BryntumAngularSharedModule,
		AgGridModule.withComponents([TemplateAddRenderer, TemplateAddHeader]),
	],
	exports: [
		TemplateDetails
	],
	providers: [
		NgbActiveModal
	],
	schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class TemplateDetailsModule {
	constructor(injector: Injector) {
		customElements.get('br-template-header') || customElements.define('br-template-header', createCustomElement(BrTemplateHeaderComponent, {injector}));
    customElements.get('br-template-coverage-header') || customElements.define('br-template-coverage-header', createCustomElement(BrTemplateCoverageHeaderComponent, {injector}));
		customElements.get('br-template-coverage-input') || customElements.define('br-template-coverage-input', createCustomElement(BrTemplateCoverageInputComponent, {injector}));
		customElements.get('br-template-task-cell') || customElements.define('br-template-task-cell', createCustomElement(BrTemplateTaskCellComponent, {injector}));
  }
}
