import { Component, OnInit } from '@angular/core';
import { TemplateAddRenderer } from '../ag-grid-templates/template-add-renderer.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { TemplateAddHeader } from '../ag-grid-templates/template-add-header.component';
import * as fromTemplateDetails from "@staff/store/stores/template-details.state";
import { Store, select } from '@ngrx/store';
import * as fromTeam from "@staff/store/stores/team.state";
import { cloneDeep } from 'lodash';
import { EBSTeamService } from '@staff/shared/common/services/ebs/team.service';
import { EBSTemplateService } from '@staff/shared/common/services/ebs/template.service';
import { ToastrService } from 'ngx-toastr';
import { Globals } from "@staff/shared/common/global/global.provider";
@Component({
  selector: 'ebs-add-task',
  templateUrl: 'add-task.component.html',
  styleUrls: ['add-task.component.scss']
})
export class AddTaskComponent implements OnInit {
  locations = [];
  templates = [];
  selectedTaskid;
  private gridApi;
  private gridColumnApi;
  showTemplateGrid: boolean = false;
  columnDefs: any[] = [
    { headerName: "Location(s)", field: "location_name", filter: "agTextColumnFilter", width: 300, pinned: "left"}
  ];
  width='100%';
  height='400px';
  gridOptions: any = {
    defaultColDef: {
      resizable: true,
      suppressMenu: true,
    },
    rowHeight: 40,
    floatingFilter: true,
    columnDefs: this.columnDefs,
    rowData: null,
    suppressMaxRenderedRowRestriction:true,
    suppressColumnVirtualisation:true,
    groupDefaultExpanded: -1,
    suppressAggFuncInHeader: true,
    sizeToFit: true,
    rowBuffer: 9999,
    groupIncludeFooter: false,
    groupIncludeTotalFooter: false,
    context: {
      componentParent: this
    },
    onCellFocused: (e) =>{
      const event = new CustomEvent('focsuevent'+e.column.colId+'-'+e.rowIndex);
    	window.dispatchEvent(event);
    }
  };
  context = { componentParent: this };
  templateList: any[] = [];
  template_data: object[] = [];
  location = [];
  taskdisabled: boolean = false;
  taskname: string = '';
  data: any[] = [];
  updatedTemplate = [];
  frameworkComponents = {
    templateAddRenderer: TemplateAddRenderer,
    templateAddHeader: TemplateAddHeader
  };

  constructor(
    public activeModal: NgbActiveModal,
    public ebsTeamService: EBSTeamService,
    public ebsTemplateService: EBSTemplateService,
    public toastr:ToastrService,
    public globals: Globals,
    private _store: Store<fromTemplateDetails.ITemplateDetailsState>,
    private _teamstore: Store<fromTeam.ITeamState>
  ) { }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }
  ngOnInit(): void {
    this._teamstore.dispatch(new fromTeam.GetTeamSkillsLoad({selectedTeam: 'C-6335'}));
    const data$ = this._store.pipe(select(fromTemplateDetails.allTemplateDetails));
    data$.subscribe(res => {
      if(res.selectedTask && res.selectedTask.length > 0){
        this.taskname = res.selectedTask;
        this.taskdisabled = true;
        this.showTemplateGrid = true;
      } else {
        this.taskname = '';
        this.showTemplateGrid = false;
      }
      this.data = [];
      this.templateList= [];
      this.columnDefs = [
        { headerName: "Location(s)", field: "location_name", filter: "agTextColumnFilter", width: 300, pinned: "left"}
      ];
      this.data = cloneDeep(res.templateLocations || []);
      this.templateList = cloneDeep(res.complexTemplates || []);
      this.templateList.map((val, i)=>{
        this.columnDefs.push(
          {
            headerName: val.template_name,
            field: "template_name",
            cellRenderer: 'templateAddRenderer',
            headerClass: 'templateGridHeader-'+ (i+1)%6,
            cellClass: 'grid-border-cell',
            filter: "agNumberColumnFilter",
            floatingFilterComponent: 'templateAddHeader',
            floatingFilterComponentParams: {
              suppressFilterButton: true,
              class: 'templateGridHeader-'+ (i+1)%6,
            }
          }
        );
      });
      if(res.taskCoverage){
        res.taskCoverage.map(task=>{
          this.data.map(location=>{
            if(task.location_id === location.location_id){
              location.tasks.push(task);
            }
          });
        });
      }
      if(this.gridColumnApi){
        this.gridColumnApi.redrawRows();
      }
		});
  }

  createTask(): void {
    this.ebsTeamService.createTeamTask(this.globals.ebsTeamSelected, {skill_id:'12', task_name:this.taskname, team_id: this.globals.ebsTeamIdSelected}).subscribe((res:any)=>{
      this.selectedTaskid = res.data[0].task_id;
      this.showTemplateGrid = true;
    });
  }

  onTemplateCoverageChange(e){
    const index = this.updatedTemplate.findIndex(v=>v.location_id===e.location_id && v.template_name===e.template_name)
    if(index == -1){
      const selectedTemplateIndex = this.templateList.findIndex(v=>v.template_name == e.template_name);
      e.task_id = this.selectedTaskid;
      e.template_id = this.templateList[selectedTemplateIndex].template_id;
      this.updatedTemplate.push(e);
    } else {
      this.updatedTemplate[index].coverage = e.coverage;
    }
  }
  
  applyChanges(){
    this.ebsTemplateService.updateTemplateTasks(this.globals.ebsTeamSelected,this.updatedTemplate).subscribe(res=>{
      this.toastr.success("Templates changes saved!",
      'Templates updated ', {
      enableHtml: true,
      });
    });
    this.activeModal.dismiss();
  }

}
