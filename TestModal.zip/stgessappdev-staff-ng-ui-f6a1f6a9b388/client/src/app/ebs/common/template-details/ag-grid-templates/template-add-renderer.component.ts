import { Component, ViewChild, ElementRef } from "@angular/core";

import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
    selector: 'template-add-renderer-cell',
	styles: [
		'.check-group{padding-top:10px;}.wrapper-cell{padding: 5px}.changed-wrapper-cell{background:#d9fbe0}'
	],
	template: `
	<div class="row wrapper-cell" [ngClass]="changed?'changed-wrapper-cell':''">
		<div class="col-sm-6">
			<div class="checkbox-list">
				<div class="form-check">
					<input *ngIf="!showChecked" class="form-check-input" type="checkbox" id="row-{{value}}">
					<input *ngIf="showChecked" class="form-check-input" type="checkbox" id="row-{{value}}" checked="checked">
					<label class="form-check-label" for="row-{{value}}"></label>
				</div>
			</div>
		</div>
		<div class="col-sm-6">
			<input #input numbersOnly type="text" class="form-control" [(ngModel)]="rowInput" (change)="valueChange()" (blur)="onBlur()"/>
		</div>
	</div>`
})
export class TemplateAddRenderer implements ICellRendererAngularComp {
	public params: any;
	value: any;
	rowInput: number;
	showChecked: boolean = false;
	changed: boolean = false;
	@ViewChild('input') coverageElement: ElementRef;

	agInit(params: any): void {
		this.params = params;
		this.value = params.valueFormatted ? params.valueFormatted : params.value;
		if(this.params.data.coverage>0){
			this.rowInput = this.params.data.coverage;
			this.showChecked = true;
		}
		window.addEventListener('focsuevent'+this.params.column.colId+'-'+this.params.rowIndex, this.onFocus.bind(this));
	}
	
	refresh(): boolean {
		return false;
	}

	valueChange(): void {
		this.rowInput = Number((this.rowInput).toString().replace(/[^0-9.]*/g, ''));
		this.showChecked = true;
		this.changed = true;
	}

	onBlur(){
		if(this.changed){
			this.params.context.componentParent.onTemplateCoverageChange({
				coverage: this.rowInput ? this.rowInput : 0,
				department_id: this.params.data.cost_center_id,
				location_id: this.params.data.location_id,
				template_name: this.params.colDef.headerName
			});
		}
	}

	onFocus(){
		this.coverageElement.nativeElement.focus();
	}
}