import { Component, Input, OnInit, ViewChild, ViewEncapsulation, Output, EventEmitter } from '@angular/core';
import { Pipe, PipeTransform } from '@angular/core';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { SchedulerComponent } from 'bryntum-angular-shared';
import { EventBaseScheduleService } from "@staff/shared/common/services/ebs.service";
import { TemplateDetail } from '@staff/store/entity/template-detail';
import * as _ from 'lodash';
import * as fromTemplateDetails from "@staff/store/stores/template-details.state";
import { Store, select } from '@ngrx/store';
import { AddTaskComponent } from './add-task/add-task.component';
import { AddLocationComponent } from './add-location/add-location.component';
import { cloneDeep } from 'lodash';
@Component({
	selector: 'ebs-template-details',
	templateUrl: './template-details.component.html',
	styleUrls: ['./template-details.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class TemplateDetails implements OnInit {
	@Input() templateId: string;
	@Input() teamName: string;
	@Input() canTaskEdit: boolean = false;
	@Input() showAddTaskLocation: boolean = true;
	@Input() taskStartTime: string = '9:00';
	@Input() taskEndTime: string = '9:00';
	@Output() onSubmit = new EventEmitter();
	@Input() hideSaveButton: boolean = true;
	templateName: string = 'Default Template';
	data: TemplateDetail[] = [];
	view: string = 'task';
	events = [];
	schedulerConfig: any;
	locationSchedulerConfig: any;
	searchQuery: string;
	public isLoading: boolean = true;
	selectedTemplate: any = {
		event_template_name: '',
		template_type: ''
	};
	@ViewChild(SchedulerComponent, { static: false }) scheduler: SchedulerComponent;
	constructor(
		private modalService: NgbModal,
		public activeModal: NgbActiveModal,
		public eventBaseScheduleService: EventBaseScheduleService,
		private _store: Store<fromTemplateDetails.ITemplateDetailsState>
	) {
	}

	addLocation() {
		let modalRef = this.modalService.open(AddLocationComponent, { size: 'lg' });
		modalRef.componentInstance.selectedTeam = this.teamName;
		modalRef.result.then((result) => {
		});
	}

	addTask() {
		this._store.dispatch(new fromTemplateDetails.ResetSelectedTask());
		this._store.dispatch(new fromTemplateDetails.GetTemplateLocationsLoad({selectedTeam: 'C-6335'}));
		let modalRef = this.modalService.open(AddTaskComponent, { size: 'lg', windowClass: 'myCustomModalClass' });
		modalRef.result.then((result) => {
		});
	}

	editTask(e) {
		this._store.dispatch(new fromTemplateDetails.GetTaskCoverage({selectedTask: e.detail.task, selectedTaskTeam: 'C-6335'}));
		this._store.dispatch(new fromTemplateDetails.GetTemplateLocationsLoad({selectedTeam: 'C-6335'}));
		let modalRef = this.modalService.open(AddTaskComponent, { size: 'lg', windowClass: 'myCustomModalClass' });
		modalRef.componentInstance.selectedTaskid = e.detail.taskid;
		modalRef.result.then((result) => {
		});
	}

	changeView(type: string) {
		this.view = type;
	}

	ngOnInit() {
		this._store.dispatch(new fromTemplateDetails.GetTemplateDetailsLoad({ selectedTemplateId: this.templateId, selectedTeam: this.teamName }));
		const data$ = this._store.pipe(select(fromTemplateDetails.allTemplateDetails));
		data$.subscribe(res => {
			this.data = cloneDeep(res.data)
			this.setSchedulerData();
		});
		window.addEventListener('addTaskEvent', this.addTask.bind(this));
		window.addEventListener('addLocationEvent', this.addLocation.bind(this));
		window.addEventListener('TemplateCoverageEvent', this.updateTemplateCoverage.bind(this));
		window.addEventListener('editTaskEvent', this.editTask.bind(this));
	}

	setSchedulerData() {
		let startDate = new Date(),
			endDate = new Date(),
			_this = this;
		startDate.setHours(0, 0, 0, 0);
		endDate.setHours(24, 0, 0, 0);
		this.events = [];
		this.data.map(v => {
			let taskStartDate = new Date(),
			taskEndDate = new Date();
			if(this.canTaskEdit){
				taskStartDate.setHours(Number(this.taskStartTime.split(':')[0]), Number(this.taskStartTime.split(':')[1]), 0, 0);
				taskEndDate.setHours(Number(this.taskEndTime.split(':')[0]), Number(this.taskEndTime.split(':')[1]), 0, 0);
			} else {
				taskStartDate.setHours(9, 0, 0, 0);
				taskEndDate.setHours(17, 0, 0, 0);
			}
			v.id = v.location_id+'-'+v.task_id;
			this.events.push({
				id: this.events.length + 1,
				resourceId: v.id,
				startDate: taskStartDate,
				endDate: taskEndDate,
				name: this.canTaskEdit ? v.task_name+' @ '+v.location_name+'('+ v.department_name +')' : 'Set during scheduling',
				eventStyle: this.canTaskEdit ? 'colored' : 'disabled'
			});
		});
		this.schedulerConfig = {
			minHeight: '50em',
			startDate: startDate,
			endDate: endDate,
			viewPreset: {
				base: 'hourAndDay',
				tickWidth: 25,
				columnLinesFor: 1,
				mainHeaderLevel: 1
			},
			rowHeight: 47,
			barMargin: 13,
			multiEventSelect: false,
			mode: 'horizontal',
			columns: [
				{
					text: 'Task',
					width: 100,
					field: 'task_name',
					hidden: true
				},
				{
					text: this.templateName, field: 'location_name', width: 350, htmlEncode: false,
					renderer({ record }) {
						return `<i class="fa fa-circle text-success icon-indicator" aria-hidden="true"></i><div>${record.data.location_name}&nbsp;<span class="emp-no">(${record.data.department_name})</span></div>`;
					},
					headerRenderer: ({ column: { data: { text } } }) => _this.showAddTaskLocation ?
					`${text}
					<br-template-header></br-template-header>` : `${text}`
				},
				{
					text: 'Coverage', field: 'coverage', width: 300, htmlEncode: false,
					renderer({ record }) {
						return `<br-template-coverage-input location="${record.data.location_id}" task="${record.data.task_id}" coverage="${record.data.coverage}" groupname="${record.meta.groupRowFor}" groupparent="${record?.meta?.map?.resources?.groupParent?.meta?.groupRowFor}"></br-template-coverage-input>`;
					}
				}
			],
			events: this.events,
			resourceTimeRangesFeature: true,
			filterBarFeature: true,
			eventContextMenuFeature: false,
			eventDragFeature: this.canTaskEdit,
			readOnly: !this.canTaskEdit,
			zoomOnTimeAxisDoubleClick: false,
			headerContextMenuFeature: false,
			eventFilterFeature: false,
			features: {
				group: {
					field: 'task_name',
					renderer: ({ isFirstColumn, count, groupRowFor, record, column }) => isFirstColumn ? `${groupRowFor} (${count})` :
						column.text == 'Coverage' ? `<br-template-coverage-header groupname="${groupRowFor}"></br-template-coverage-header>` : ``
				}
			},
			resources: this.data
		};
		this.locationSchedulerConfig = {
			columns: [
				{
					text: 'Task',
					width: 100,
					field: 'location_name',
					hidden: true
				},
				{
					text: this.templateName, field: 'task_name', width: 300, htmlEncode: false,
					renderer({ record }) {
						return `<br-template-task-cell departmentname="${record.data.department_name}" taskname="${record.data.task_name}" taskid="${record.data.task_id}"  location="${record.data.location_id}" task="${record.data.task_id}" coverage="${record.data.coverage}" groupname="${record.meta.groupRowFor}" groupparent="${record?.meta?.map?.resources?.groupParent?.meta?.groupRowFor}"></br-template-task-cell>`;
					},
					headerRenderer: ({ column: { data: { text } } }) => _this.showAddTaskLocation ?
					`${text}
					<br-template-header></br-template-header>` : `${text}`
				},
				{
					text: 'Coverage', field: 'coverage', width: 300, htmlEncode: false,
					renderer({ record }) {
						return `<br-template-coverage-input location="${record.data.location_id}" task="${record.data.task_id}" coverage="${record.data.coverage}" groupname="${record.meta.groupRowFor}" groupparent="${record?.meta?.map?.resources?.groupParent?.meta?.groupRowFor}"></br-template-coverage-input>`;
					}
				}
			],
			features: {
				group: {
					field: 'location_name',
					renderer: ({ isFirstColumn, count, groupRowFor, record, column }) => isFirstColumn ? `${groupRowFor} (${count})` :
						column.text == 'Coverage' ? `<br-template-coverage-header groupname="${groupRowFor}"></br-template-coverage-header>` : ``
				}
			}
		};
		setTimeout(() => {
      this.isLoading = false;
    }, 400);
	}

	updateTemplateCoverage(e){
		if(e.detail.task_id && e.detail.location_id){
			const index = this.data.findIndex(v=>v.task_id==e.detail.task_id && v.location_id==e.detail.location_id)
			if(index != -1){
				this.data[index].coverage = Number(e.detail.coverage);
				this.data[index].updated = true;
			}
		}
	}

	save(){
		this.onSubmit.emit(this.data);
	}
}
@Pipe({
    name: 'templateFilter'
})
export class TaskFilterPipe implements PipeTransform {
	transform(items: TemplateDetail[], text: string): TemplateDetail[] {
		if (!items) { return []; }
		if (!text) { return items; }
		text = text.toLowerCase();
		return items.filter(it => {
				return it.task_name.toLowerCase().includes(text) || it.location_name.toLowerCase().includes(text);
		});
	}
}