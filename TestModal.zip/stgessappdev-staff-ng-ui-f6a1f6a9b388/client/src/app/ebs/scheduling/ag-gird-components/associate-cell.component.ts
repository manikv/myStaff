import { Component } from "@angular/core";

import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
    selector: 'associate-cell',
	styles: [],
	template: `
	<div *ngIf="isParent">{{value}}</div>
    <div *ngIf="!isParent">
        <span class="associate-stars-container mr-2 stars-{{starValue * 20}}">★</span>{{value}}
	</div>`
})
export class AssociateCell implements ICellRendererAngularComp {
	public params: any;
	value: any;
    isParent: boolean = true;
    starValue = 0;

	agInit(params: any): void {
		this.params = params;
		this.value = params.valueFormatted ? params.valueFormatted : params.value;
		this.isParent = this.params.node.level == 0;
		if(!this.isParent){
            this.starValue = this.params.data.starRating;
		}
	}

	refresh(): boolean {
		return false;
	}
}