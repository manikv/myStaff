import { Component } from "@angular/core";

import { ICellRendererAngularComp } from "ag-grid-angular";
import { UnsavedSchedule } from '@staff/store/entity/unsavedSchedule';
import { cloneDeep } from 'lodash';

@Component({
    selector: 'schedule-cell-rendrer',
	styles: [
		'.drop-zone>div{width:400%;margin:0 15px}.drop-zone{width: 98%;display: block;height: 98%;position: absolute; top: 2%; left: 2.5%;border-radius: 20px;overflow-x:auto;overflow-y:hidden}.emp-associate-list{float: left;width: 70px;overflow: hidden;margin-top: 40px;display:inline-block;font-size:1em;width:5.5em;height:5.5em;line-height:5.5em;text-align:center;border-radius:50%;vertical-align:middle;margin-right:1em;color:white;background-color:rgb(80,179,247); border:1px solid rgb(3,117,195);}.emp-associate-list .details{display:none;position:absolute;color: #000;top: 0;margin-left: -15px;}.emp-associate-list:hover span{display:block}.btn-drop-associate{position: absolute; right: 0; height: 100%; background: #fff; opacity: .5;}'
	],
	template: `
	<div class="row" *ngIf="isParent">
		<div class="col-sm-6 p-2">
            <div class="row">
                <div class="col-sm-4">
                    <b class="text-muted">Total Shift(s) Planned</b>
                </div>
                <div class="col-sm-2">
                    <b class="text-muted">Filled</b>
                </div>
                <div class="col-sm-2">
                    <b class="text-muted">Open</b>
                </div>
            </div>
		</div>
		<div class="col-sm-6 p-2 text-right">
            <button class="btn btn-link">
                <i class="fa fa-plus-circle" aria-hidden="true"></i>
                Schedule Employees
            </button>
		</div>
    </div>
    <div class="row drop-zone" *ngIf="!isParent"  [ngStyle]="{'background-color': task.taskbg}" (drop)="onDrop($event)">
        <div>
            <p *ngFor="let item of scheduled_associates" class="emp-associate-list">{{item.emp_first_name[0]}}{{item.emp_last_name[0]}}
                <span class="details">
                    <span class="popover fade bs-popover-end" role="tooltip">
                        <span class="popover-header">{{item.emp_full_name}}({{item.emp_name}}</span>
                        <span class="popover-body">And here's some amazing content. It's very engaging. Right?</span>
                    </span>
                </span>
            </p>
        </div>
        <button class="btn btn-link btn-drop-associate" (click)="addAssociates()">
            <i class="fa fa-plus-circle" aria-hidden="true"></i>
            Add Selected Associates
        </button>
    </div>`
})
export class ScheduleCellRendrer implements ICellRendererAngularComp {
	public params: any;
	value: any;
    isParent: boolean = true;
	task: any;
    scheduled_associates: any = [];

	agInit(params: any): void {
		this.params = params;
		this.value = params.valueFormatted ? params.valueFormatted : params.value;
		this.isParent = this.params.node.level == 0;
		if(!this.isParent){
            this.task = params.data;
            this.scheduled_associates = this.task.associates;
		}
	}

    onDrop($event){
        const userAgent = window.navigator.userAgent;
        const isIE = userAgent.indexOf('Trident/') >= 0;
        const associates: any = JSON.parse($event.dataTransfer.getData(
        isIE ? 'text' : 'application/json'
        ));
        this.params.context.componentParent.updateAssociate(new UnsavedSchedule(associates, cloneDeep(this.task), this.params.rowIndex));
    }

    addAssociates(){
        this.params.context.componentParent.updateAssociate(new UnsavedSchedule([], cloneDeep(this.task), this.params.rowIndex), true);
    }
    
	refresh(): boolean {
		return false;
	}
}