import { Component } from "@angular/core";

import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
    selector: 'task-name-cell',
	styles: [
		'.br-1{border-right: 1px solid #ccc; height: 55px}.button-row{margin-top:-20px; height:50px}'
	],
	template: `
	<div *ngIf="isParent">{{value}}</div>
	<div *ngIf="!isParent" class="p-3">
		<div class="row">
			<div class="col-sm-8 p-2">
				<span class="text-primary text-bold">{{task.task_name}}</span>
			</div>
			<div class="col-sm-4 p-2 text-right">
				<i class="fa fa-pencil-square-o mr-2" aria-hidden="true"></i>
				<i class="fa fa-trash" aria-hidden="true"></i>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-8 p-2">
				<div class="pb-1">
					<span class="text-muted">Shift</span>&nbsp;{{task.start_time}} - {{task.end_time}}
				</div>
				<div>
					<span class="text-muted">Meal</span>&nbsp;{{task.break_start}} - {{task.break_end}}
				</div>
			</div>
			<div class="col-sm-1 p-2">
				<div class="br-1">&nbsp;</div>
			</div>
			<div class="col-sm-3 p-2 text-right">
				<div class="pb-1"><span class="text-success">{{task.coverage}}</span> Open</div>
				<div><span class="text-danger">{{task.filled}}</span> Closed</div>
			</div>
		</div>
		<div class="row button-row pt-2">
			<div class="col-sm-6 p-2">
				<button class="btn btn-link" (click)="addSchedule()">
					<i class="fa fa-plus-circle" aria-hidden="true"></i>
					Schedule
				</button>
			</div>
			<div class="col-sm-6 p-2 text-right">
				<button class="btn btn-link" (click)="createOpenShift()">
					<i class="fa fa-plus-circle" aria-hidden="true"></i>
					Open Shift
				</button>
			</div>
		</div>
	</div>`
})
export class TaskNameCell implements ICellRendererAngularComp {
	public params: any;
	value: any;
	isParent: boolean = true;
	task = {
		cost_center_name:"",
		location_name:"",
		task_name:"",
		coverage:0,
		start_time:"",
		break_start:"",
		break_end:"",
		end_time:"",
		open: "",
		filled: 0,
		associates: []
	}

	agInit(params: any): void {
		this.params = params;
		this.value = params.valueFormatted ? params.valueFormatted : params.value;
		this.isParent = this.params.node.level == 0;
		if(!this.isParent){
			this.task = params.data;
			this.task.filled = this.task.associates.length;
		}
	}

	refresh(): boolean {
		return false;
	}

	createOpenShift() {

		this.params.context.componentParent.createOpenShift(this.params.data);

	}


	addSchedule() {

		this.params.context.componentParent.addSchedule(this.params.data);

	}
}