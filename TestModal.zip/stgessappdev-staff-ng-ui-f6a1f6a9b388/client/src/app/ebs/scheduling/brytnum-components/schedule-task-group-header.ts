import { Component, Input, OnInit} from '@angular/core';

@Component({
  	selector: 'br-schedule-task-group-header',
	template: `
	<div class="row">
		<div class="col-sm-6 p-2">
            <div class="row">
                <div class="col-sm-4">
                    <b class="text-muted">Total Shift(s) Planned</b>
                </div>
                <div class="col-sm-2">
                    <b class="text-muted">Filled</b>
                </div>
                <div class="col-sm-2">
                    <b class="text-muted">Open</b>
                </div>
            </div>
		</div>
		<div class="col-sm-6 p-2 text-right">
            <button class="btn btn-link">
                <i class="fa fa-plus-circle" aria-hidden="true"></i>
                Schedule Employees
            </button>
		</div>
	</div>
	`,
	styles:[]
})
export class BrScheduleTaskGroupHeaderComponent implements OnInit{
		@Input() details: any;
		task = {
			cost_center_name:"",
			location_name:"",
			task_name:"",
			coverage:0,
			start_time:"",
			break_start:"",
			break_end:"",
			end_time:"",
			open: "",
			filled: ""
		}

	ngOnInit(){
		// this.task = JSON.parse(this.details);
	}

}
