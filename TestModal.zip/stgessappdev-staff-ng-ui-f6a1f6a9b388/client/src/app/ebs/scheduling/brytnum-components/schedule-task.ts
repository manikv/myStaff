import { Component, Input, OnInit} from '@angular/core';

@Component({
  	selector: 'br-schedule-task',
	template: `
	<div class="row">
		<div class="col-sm-8 p-2">
			<span class="text-primary text-bold">{{task.task_name}}</span>
		</div>
		<div class="col-sm-4 p-2 text-right">
			<i class="fa fa-pencil-square-o mr-2" aria-hidden="true"></i>
			<i class="fa fa-trash" aria-hidden="true"></i>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-7 p-2">
			<div class="pb-1">
				<span class="text-muted">Shift</span>&nbsp;{{task.start_time}} - {{task.end_time}}
			</div>
			<div>
				<span class="text-muted">Meal</span>&nbsp;{{task.break_start}} - {{task.break_end}}
			</div>
		</div>
		<div class="col-sm-1 p-2">
			<div class="br-1">&nbsp;</div>
		</div>
		<div class="col-sm-4 p-2 text-right">
			<div class="pb-1"><span class="text-success">0</span> Open</div>
			<div><span class="text-danger">0</span> Closed</div>
		</div>
	</div>
	<div class="row button-row">
		<div class="col-sm-7 p-2">
			<div class="row">
				<div class="col-sm-6 p-2">
					<button class="btn btn-link">
						<i class="fa fa-plus-circle" aria-hidden="true"></i>
						Schedule
					</button>
				</div>
				<div class="col-sm-6 p-2">
					<button class="btn btn-link">
						<i class="fa fa-plus-circle" aria-hidden="true"></i>
						Open Shift
					</button>
				</div>
			</div>
		</div>
	</div>
	`,
	styles:['.br-1{border-right: 1px solid #ccc; height: 35px}.button-row{margin-top:-20px; height:50px}']
})
export class BrScheduleTaskComponent implements OnInit{
		@Input() details: any;
		@Input() groupname: any;
		@Input() groupparent: any;
		task = {
			cost_center_name:"",
			location_name:"",
			task_name:"",
			coverage:0,
			start_time:"",
			break_start:"",
			break_end:"",
			end_time:"",
			open: "",
			filled: ""
		}

	ngOnInit(){
		this.task = JSON.parse(this.details);
	}

}
