import { NgModule, CUSTOM_ELEMENTS_SCHEMA, Injector } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgbModule, NgbActiveModal, } from '@ng-bootstrap/ng-bootstrap';
import { SchedulingRoutingModule } from './scheduling-routing.module';
import { BlockUIModule } from 'ng-block-ui';
import { TeamMultiTypeaheadEbsModule  } from '@staff/sharedModules/index';
import { ToastrService } from 'ngx-toastr';
import { BryntumAngularSharedModule } from 'bryntum-angular-shared';
import { createCustomElement } from '@angular/elements';
import 'ag-grid-community';
import 'ag-grid-enterprise';
import { LicenseManager } from 'ag-grid-enterprise';
import { EventBaseScheduleService } from '../../shared/common/services/ebs.service';
import { AgGridModule } from 'ag-grid-angular';
LicenseManager.setLicenseKey("SoftwareONE_USA_on_behalf_of_Compass_Group_USA_MultiApp_5Devs_5Deployment_12_August_2020__MTU5NzE4NjgwMDAwMA==de1432ef47c510c631b782c11ab2920d");
import { ScheduleAssociatesService } from './schedule-associate-modal/schedule-associate-modal.service';
import { EventScheduleComponent } from '@staff/ebs/scheduling/event-schedule/event-schedule.component';
import { BrScheduleTaskComponent } from './brytnum-components/schedule-task';
import { BrScheduleTaskGroupHeaderComponent } from './brytnum-components/schedule-task-group-header';
import { TaskNameCell } from './ag-gird-components/task-name.component';
import { ScheduleCellRendrer } from './ag-gird-components/schedule-cell-rendrer.component';
import { AssociateCell } from './ag-gird-components/associate-cell.component';
@NgModule({
  entryComponents: [
    BrScheduleTaskComponent,
    BrScheduleTaskGroupHeaderComponent,
    TaskNameCell,
    ScheduleCellRendrer,
    AssociateCell
  ],
  declarations: [
    EventScheduleComponent,
    BrScheduleTaskComponent,
    BrScheduleTaskGroupHeaderComponent,
    TaskNameCell,
    ScheduleCellRendrer,
    AssociateCell
  ],
  imports: [
    CommonModule,
    FormsModule,
    NgbModule,
    SchedulingRoutingModule,
    BlockUIModule.forRoot(),
    TeamMultiTypeaheadEbsModule,
    BryntumAngularSharedModule,
    AgGridModule.withComponents([TaskNameCell, ScheduleCellRendrer])
  ],
  exports: [
    EventScheduleComponent,
    BrScheduleTaskComponent
  ],
  providers: [
    NgbActiveModal,
    ToastrService,
    EventBaseScheduleService,
    ScheduleAssociatesService
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class EbsSchedulingModule {
  constructor(injector: Injector) {
    // convert Angular Component to Custom Element and register it with browser
    customElements.define('br-schedule-task', createCustomElement(BrScheduleTaskComponent, {injector}));
    customElements.define('br-schedule-task-group-header', createCustomElement(BrScheduleTaskGroupHeaderComponent, {injector}));
  }
}
