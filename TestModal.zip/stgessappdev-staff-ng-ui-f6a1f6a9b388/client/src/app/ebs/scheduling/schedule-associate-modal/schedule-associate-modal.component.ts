import { Component, OnInit, ViewChild, ViewEncapsulation, Input } from '@angular/core';
import { NgbModal, NgbActiveModal, NgbCarousel, NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
import { NguCarouselConfig } from '../../../shared/carousel/ngu-carousel/ngu-carousel';
import { interval, Observable, of, from, zip } from 'rxjs';
import { map, startWith, take, groupBy, mergeMap, reduce, toArray } from 'rxjs/operators';
import { AssociatesService } from '../../shared/common/services/associates.service';
import { Globals } from '../../../shared/common/global/global.provider';
import * as moment from 'moment';
import Swal from 'sweetalert2';
import { FormsModule } from '@angular/forms';
import * as fromScheduling from "@staff/store/stores/scheduling.state";
import { Store, select } from '@ngrx/store';
import { cloneDeep } from 'lodash';
import * as _ from 'lodash';

@Component({
    templateUrl: './schedule-associate-modal.component.html',
    styleUrls: ['./schedule-associate-modal.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class ScheduleAssociateModalComponent implements OnInit {

    @Input() public selectedTaskDetail;
    @Input() public isTaskSelected;

    width = '100%';
    height = 'calc(100vh - 400px)';
    susbcription: any;
    data: any = [];
    private gridApi: any;
    private gridColumnApi: any;
    tasks: any = [];
    scheduleTaskList: any = [];
    locationList: any = [];
    selectedLocation: any ={
        indexValue : 0,
        disableRightArrow: false,
        disableLeftArrow: false
    };
    selectedTask: any;
    filled: boolean = false;
    notFilled: boolean = false;
    validateAssociatesAreSaved: boolean = false;
    showAlertForUnsavedAssociates: boolean = false;
    selectedEvent: any;

    public carouselTileItems$: Observable<number[]>;
    public carouselTileConfig1: NguCarouselConfig = {
        grid: { xs: 6, sm: 6, md: 6, lg: 6, all: 0 },
        speed: 250,
        point: {
            visible: true
        },
        touch: true,
        loop: false,
    };

    constructor(public activeModal: NgbActiveModal, public scheduleAssociatesService: AssociatesService,
        public globals: Globals, private _store: Store<fromScheduling.ISchedulingState>) {
    }

    associateColDef: any = [
        {
            field: 'jobDesc',
            rowGroup: true,
            hide: true,
        },
        {
            headerName: 'Schedule Hours',
            field: 'empName',
            filter: "agTextColumnFilter",

        },
        {
            headerName: 'Status',
            field: 'disableAssociate',
            filter: "agTextColumnFilter",

        },
        {
            headerName: 'Rating',
            field: 'starRating',
            filter: "agTextColumnFilter",
            cellRenderer: function (params) {
                return '<div><span class="stars-container stars-' + params.value * 20 + '">★★★★★</span></div>'
            }

        },
        {
            headerName: 'Rank',
            field: 'starRating',
            filter: "agTextColumnFilter",
            minWidth: 60,
            maxWidth: 80,

        }, {
            headerName: 'Hire Date',
            field: 'hireDate',
            filter: "agTextColumnFilter",


        },
        {
            headerName: 'Phone No',
            field: 'phoneNo',
            filter: "agTextColumnFilter",
            minWidth: 110,
            maxWidth: 140,

        },
        {
            headerName: 'Email',
            field: 'email',
            filter: "agTextColumnFilter",


        }
    ];


    associateGridOptions: any = {
        defaultColDef: {
            sortable: true,
            resizable: true,
            flex: 1
        },
        rowSelection: 'multiple',
        rowMultiSelectWithClick: true,
        enableRangeSelection: true,
        onRangeSelectionChanged: this.onRangeSelectionChanged,
        //copyHeadersToClipboard: true,
        suppressMaxRenderedRowRestriction: true,
        suppressColumnVirtualisation: true,
        groupDefaultExpanded: -1,
        rowBuffer: 9999,
        floatingFilter: true,
        autoGroupColumnDef: {
            headerName: 'Associates',
            field: 'empFullName',
            suppressSizeToFit: true,
            cellRenderer: 'agGroupCellRenderer',
            filter: "agTextColumnFilter",
            minWidth: 300,
            maxWidth: 500,
            cellRendererParams: {
                checkbox: true,
                // innerRenderer: this.checkbox

            },

        },
        groupSelectsChildren: true,

        isRowSelectable: function (rowNode) {
            // console.log('rowNode.data', rowNode.data);
            return rowNode.data ? !rowNode.data.disableAssociate : false;
        }


    };


    onGridReady(params) {
        // console.log('params', params);
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;

    }

    onSelectionChanged($event) {
        var selectedRows = this.gridApi.getSelectedNodes();
        this.validateAssociatesAreSaved = selectedRows.some(row => !row.data.preselected);
        console.log('selectedRows', selectedRows, this.validateAssociatesAreSaved);
    }

    onRangeSelectionChanged(event) {
        // console.log('has changed, started = ' + event.started);
        // console.log('has changed, finished = ' + event.finished);
        let nodes = event.api.getSelectedNodes();
        // console.log('event', event.api, nodes);
    }

    getSelectedLocation(option, indexValue, isTaskPreSelected) {
        this.selectedLocation = option;
        this.selectedLocation.indexValue = indexValue;
        this.selectedLocation.disableRightArrow = indexValue === this.locationList.length - 1 ? true : false;
        this.selectedLocation.disableLeftArrow = indexValue === 0 ? true : false;
        this.getTaskByLocation(this.selectedLocation.location_id, isTaskPreSelected);

    }

    getNextLocation() {

        let indexValue = this.selectedLocation.indexValue + 1;
        let nextValue = this.locationList[indexValue];
        this.selectedLocation = nextValue;
        this.selectedLocation.indexValue = indexValue;
        this.selectedLocation.disableRightArrow = indexValue === this.locationList.length - 1 ? true : false;
        this.getTaskByLocation(this.selectedLocation.location_id, false);
    }

    getPrevLocation() {
        let indexValue = this.selectedLocation.indexValue - 1;
        let nextValue = this.locationList[indexValue];
        this.selectedLocation = nextValue;
        this.selectedLocation.indexValue = indexValue;
        this.selectedLocation.disableLeftArrow = indexValue === 0 ? true : false;
        this.getTaskByLocation(this.selectedLocation.location_id, false);

    }

    // getTaskAssociates(values) {
    //     console.log('card click', values);
    // }


    getTaskByLocation(loctionId, isTaskPreSelected) {
        this.showAlertForUnsavedAssociates = this.validateAssociatesAreSaved ? true : false;
        this.tasks = [];
        this.tasks = this.scheduleTaskList.filter(task => { return task.location_id === loctionId });
        this.carouselTileItems$ = of(this.tasks);
        // console.log(this.tasks);
        if (isTaskPreSelected){
            let task = this.tasks.find(ts => { return ts.task_id === this.selectedTaskDetail.task_id })
            this.getSelectedTask(task);
        }else{
        this.getSelectedTask(this.tasks[0]);
        }

    }

    groupByLocation(tasks) {
        const result = {}, resultArray = [];
        for (let item of tasks) {
            if (!result[item.location_name]) {
                result[item.location_name] = [];
                resultArray.push({ tasks: result[item.location_name], location_name: item.location_name, location_id: item.location_id });
            }
            result[item.location_name].push(item);

        }
        return resultArray;
    }

    ngOnInit() {
        console.log('taskDettail - ng', this.selectedTaskDetail);
        this.selectedEvent = this.globals.ebsEventSelected;
        const data$ = this._store.pipe(select(fromScheduling.allScheduling));
        data$.subscribe(res => {
            if (res.tasksInitialLoad && res.associateInitialLoad && res.schedulesInitialLoad) {
                this.scheduleTaskList = cloneDeep(res.tasks);
                this.locationList = this.groupByLocation(this.scheduleTaskList);
                console.log('stored', res)
            }
            if (res.conflictMessage && res.conflictMessage.length > 0) {
                Swal.fire(res.conflictMessage);
            }
            //res.createScheduleComplete
            console.log('res value', res);
        });

        if (this.locationList.length > 0){
        if (this.isTaskSelected) {
            let findSelectedLocation = this.locationList.find(loc => { return loc.location_id === this.selectedTaskDetail.location_id });
            let indexValue = this.locationList.findIndex(x => x.location_id === this.selectedTaskDetail.location_id);
            this.getSelectedLocation(findSelectedLocation, indexValue, this.isTaskSelected );

        } else {

            this.selectedLocation = this.locationList[0];
            this.selectedLocation.indexValue = 0;
            this.selectedLocation.disableRightArrow = false;
            this.selectedLocation.disableLeftArrow = true;
            this.getTaskByLocation(this.locationList[0].location_id, false);

        }

        this.scheduleAssociatesService.getTeamAssociates('C-6335')
            .subscribe((response: any) => {
                // console.log('response', response);
                this.mapSchdAssociatesWithTask(response);
            }, err => {
                console.log('error  ----> ', err);
            });
        }

    }

    // mapSchdAssociatesWithTaskNode(response) {
    //     this.data = response;

    //     setTimeout(() => {

    //         this.gridApi.forEachNode((node) => {
    //             //console.log('node', node);
    //             if (node.data) {
    //                 node.data.schedules.forEach(associate => {
    //                     associate.shifts.forEach(shift => {
    //                         if (shift.task_id === this.selectedTask.task_id ){
    //                              node.setSelected(true);
    //                         }else{
    //                             node.data.disableAssociate = true;
    //                             console.log('node.data', node.data);
    //                         }
    //                 });
    //                 });
    //             }
    //         });
    //     }, 200);

    // }

    mapSchdAssociatesWithTask(response) {

        this.data = response;

        this.data.forEach(associate => {
            associate.disableAssociate = false;
            associate.preselected = false;
            if (associate.schedules.length > 0) {
                associate.schedules[0].shifts.forEach(sh => {

                    if (sh.task_id === this.selectedTask.task_id) {
                        associate.disableAssociate = false;
                        associate.scheduleShift = sh;
                        setTimeout(() => {
                            this.gridApi.forEachNode((node) => {
                                //console.log('node', node);
                                associate.preselected = true;
                                node.setSelected(node.data && node.data.empId === associate.empId);

                            });
                        }, 400);
                        console.log('associate', associate.empFullName);
                    } else {

                        associate.disableAssociate = true;

                    }
                });
            }
        });

    }

    getSelectedTask(item) {
        //  console.log('item', item);
        this.showAlertForUnsavedAssociates = this.validateAssociatesAreSaved ? true : false;
        if (!this.showAlertForUnsavedAssociates) {
            this.tasks.forEach(task => {
                task.selectedTile = false;
                if (task.task_name === item.task_name) {
                    task.selectedTile = true;
                    this.selectedTask = item;
                    if (this.data.length > 0) {
                        this.mapSchdAssociatesWithTask(this.data);
                    }
                }
            });
        } else {
            item = this.selectedTask;
            //this.alertSwal();
        }

    }

    changeSortOrder(chkbox) {
        var filteredTaskList = [];
        //console.log('chkbox', event, chkbox, this.filled, this.notFilled);
        if (chkbox === 1) {
            this.filled = !this.filled;
        } else {
            this.notFilled = !this.notFilled;
        }

        if (this.filled && chkbox === 1) {
            filteredTaskList = this.tasks.filter(task => { return task.coverage <= task.scheduled });
            this.notFilled = false;

        } else if (this.notFilled && chkbox === 2) {
            filteredTaskList = this.tasks.filter(task => { return task.coverage >= task.scheduled });
            this.filled = false;
        }
        else if (this.filled && this.notFilled) {
            filteredTaskList = this.tasks;
        }
        else {
            filteredTaskList = this.tasks;
        }

        // console.log('filteredTaskList', filteredTaskList, this.filled, this.notFilled);

        this.carouselTileItems$ = of(filteredTaskList);

    }

    saveAssociates() {
        var selectedRows = this.gridApi.getSelectedNodes();
        let  scheduleList = [],
            eventDate = moment(this.selectedEvent.event_start_time).format('MM/DD/YYYY');

        selectedRows.forEach(detail => {
           let item = detail.data;
            let schedule = {
                created_by: this.globals.user_name,
                created_date: moment().format('MM/DD/YYYY HH:mm'),
                employee_id: item.empId,
                scheduled_date: eventDate,
                wbt_id: this.globals.ebsTeamIdSelected,
                shifts: [
                    {
                        event_id: this.selectedEvent.event_id,
                        task_id: this.selectedTask.task_id,
                        location_id: this.selectedTask.location_id,
                        job_id: item.jobId,
                        project_id: 103974,
                        department_id: this.selectedTask.department_id,
                        start: moment(eventDate + ' ' + this.selectedTask.start_time).format('MM/DD/YYYY HH:mm'),
                        end: moment(eventDate + ' ' + this.selectedTask.end_time).format('MM/DD/YYYY HH:mm'),
                        break_end: moment(eventDate + ' ' + this.selectedTask.break_end).format('MM/DD/YYYY HH:mm'),
                        break_start: moment(eventDate + ' ' + this.selectedTask.break_strat).format('MM/DD/YYYY HH:mm'),
                        unpaid_minutes: 0,
                        sched_hours: 0,
                        shift_flag: 'save', //new, update, delete
                    }
                ]
            };
            scheduleList.push(schedule);
        });

        //console.log('schedules', scheduleList);

        this._store.dispatch(new fromScheduling.CreateScheduleForAssociates({ selectedTeam: 'C-6335', userName: this.globals.user_name, data: scheduleList }));

        this.showAlertForUnsavedAssociates = false;
        this.activeModal.close(0);

        //this.gridApi.deselectAll();
    }

    saveCloseAssociates() {
        console.log('saved & close');
        this.showAlertForUnsavedAssociates = false;
        this.gridApi.deselectAll();
        this.activeModal.close(0);
        this.toasterAlert();

    }

    closeModal() {
        this.activeModal.close(0);
    }

    toasterAlert() {
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        })

        Toast.fire({
            icon: 'success',
            title: 'Saved successfully'
        })
    }


    alertSwal() {
        // Swal.fire(
        //     'Save the associates for the task ' + this.selectedTask.task_name

        // )
        Swal.fire({
            title: 'Save Associates',
            text: 'Do you want to save changes for the task ' + this.selectedTask.task_name + '?',
            showDenyButton: true,
            showCancelButton: true,
            confirmButtonText: `Save`,
            denyButtonText: `Don't save`,
            backdrop: false,
            //icon: 'question'
        }).then((result) => {
            /* Read more about isConfirmed, isDenied below */
            if (result.isConfirmed) {
                // Swal.fire('Saved!', '', 'success');
                this.toasterAlert();
            } else if (result.isDenied) {
                Swal.fire('Changes are not saved', '', 'info')
            }
        })
    }
}
