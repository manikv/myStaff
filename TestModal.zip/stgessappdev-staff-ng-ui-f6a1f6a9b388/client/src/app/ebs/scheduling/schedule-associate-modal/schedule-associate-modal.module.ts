import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AgGridModule } from 'ag-grid-angular';
import { NguCarouselModule } from '../../../shared/modules/ngu-carousel.module';
import { ScheduleAssociateModalComponent } from './schedule-associate-modal.component';
import { AssociatesService } from '../../shared/common/services/associates.service';



@NgModule({
    entryComponents: [
        ScheduleAssociateModalComponent
    ],
    declarations: [
        ScheduleAssociateModalComponent,
    ],
    imports: [
        CommonModule,
        NgbModule,
        AgGridModule.withComponents([]),
        NguCarouselModule


    ],
    exports: [
        ScheduleAssociateModalComponent
    ],
    providers: [
        AssociatesService
    ]
})
export class ScheduleAssociateModalModule {
}
