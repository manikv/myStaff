import { Injectable } from '@angular/core';
import { forEach } from 'jszip';

import { Observable, forkJoin } from 'rxjs';
import { Observer } from 'rxjs/internal/types';

import { EventBaseScheduleService } from '../../../shared/common/services/ebs.service';


@Injectable()
export class ScheduleAssociatesService {

    constructor(public eventBaseScheduleService: EventBaseScheduleService) { }

    getTeamAssociates(teamName: string): Observable<any> {
        let result = [];
        return new Observable((observer: Observer<any>) => {
            let getTeamAssociates = this.eventBaseScheduleService.getTeamAssociates(teamName);
            let getTeamScheduleAssociates = this.eventBaseScheduleService.getTeamScheduleAssociates('C-6335', 'TESTO06', 10201, '11/11/2020', '11/18/2020',);

            forkJoin([getTeamAssociates, getTeamScheduleAssociates]).subscribe(response => {
            let teamAssociates = [], scheduleAssociates =[];
                teamAssociates = response[0];
                scheduleAssociates = response[1];
               // console.log(response[0], response[1]);

                teamAssociates.forEach((associate)=>{

                    let filteredSchd = scheduleAssociates.filter(schd => { return schd.employee_id === associate.emp_id });

                    let asso = {
                            empFullName: associate.emp_full_name,
                            empId: associate.emp_id,
                            empName: associate.emp_name,
                            empStatus: associate.emp_status,
                            hireDate: '10/10/2010', //associate.hireDate,
                            jobId: associate.job_id,
                            jobName: associate.job_name,
                            jobDesc: associate.job_desc,
                            checkBoxSelected: false,
                            complex: associate.complex,
                            email: 'abc@compass.com',
                            phoneNo: '704-353-5353',
                            starRating: 3.5 || 0,
                            schedules: []
                        };
                    asso.schedules = filteredSchd;
                    //console.log('asso.schedules', filteredSchd);
                    result.push(asso);

                });




                observer.next(result);
                observer.complete();

            });

            // this.eventBaseScheduleService.getTeamAssociates(teamName).subscribe(
            //     (response: any) => {

            //         response.map((associate) => {
            //             let asso = {
            //                 empFullName: associate.emp_full_name,
            //                 empId: associate.emp_id,
            //                 empName: associate.emp_name,
            //                 empStatus: associate.emp_status,
            //                 hireDate: '10/10/2010', //associate.hireDate,
            //                 jobId: associate.job_id,
            //                 jobName: associate.job_name,
            //                 jobDesc: associate.job_desc,
            //                 checkBoxSelected: false,
            //                 complex: associate.complex,
            //                 email: 'abc@compass.com',
            //                 phoneNo: '704-353-5353',
            //                 starRating: 3.5 || 0
            //             };
            //             result.push(asso);
            //         });

            //         observer.next(result);
            //         observer.complete();
            //     });


            // this.eventBaseScheduleService.getTeamScheduleAssociates('C-6335', '11/11/2020', '11/18/2020', 'TESTO06').subscribe(
            //     (response: any) => {

            //         // response.map((schdAssociate) => {
            //         //     let asso = {

            //         //     };
            //         //     result.push(asso);
            //         // });

            //         observer.next(result);
            //         observer.complete();
            //     });


        });
    }
}
