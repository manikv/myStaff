import { Component, ViewChild, AfterViewInit, Input, OnInit, ViewEncapsulation } from '@angular/core';
import * as moment from 'moment';
import { EventBaseScheduleService } from '../../../shared/common/services/ebs.service';
import { Globals } from "../../../shared/common/global/global.provider";
import * as _ from 'lodash';
import { BlockUI, NgBlockUI } from "ng-block-ui";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { Router } from '@angular/router';
import { ScheduleAssociatesService } from '../schedule-associate-modal/schedule-associate-modal.service';
import { SchedulerComponent } from 'bryntum-angular-shared';
import { TaskNameCell } from '../ag-gird-components/task-name.component';
import { ScheduleCellRendrer } from '../ag-gird-components/schedule-cell-rendrer.component';
import { AssociateCell } from '../ag-gird-components/associate-cell.component';
import * as fromScheduling from "@staff/store/stores/scheduling.state";
import { Store, select } from '@ngrx/store';
import Swal from 'sweetalert2';
import { Associate } from '@staff/store/entity/associate';
import { offerAssociatesModalComponent } from '../../openshift/offer-associates/offer-associates-modal.component';
import { ScheduleAssociateModalComponent } from '@staff/ebs/scheduling/schedule-associate-modal/schedule-associate-modal.component';


import { cloneDeep } from 'lodash';
@Component({
  selector: 'ebs-event-schedule',
  templateUrl: './event-schedule.component.html',
  styleUrls: ['./event-schedule.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EventScheduleComponent implements OnInit {
  @Input() event: any;
  width = '100%';
  showSchedule: boolean = false;
  height = 'calc(100vh - 250px)';
  susbcription: any;
  data: any = [];
  schedulingData: any = [];
  gridApi: any;
  schedulingGridApi: any
  tasks: any = [];
  locationList: any = [];
  loaded: boolean = false;
  assocatedata: any[] = [];
  view: string = 'summary';
  schedulerConfig: any;
  locationSchedulerConfig: any;
  public isLoading: boolean = true;
  rowSelection = 'multiple';
  gridWrapperClass = '';
  schedules;
  @ViewChild(SchedulerComponent, { static : false }) scheduler: SchedulerComponent;

  associateColDef: any = [
    {
      headerName: 'Associates',
      field: 'job_desc',
      filter: 'agTextColumnFilter',
      rowGroup: true,
      hide: true
    },
    {
      headerName: 'Hours',
      field: 'job_name',
      filter: 'agTextColumnFilter',
      width: 80,
      valueFormatter: function(params) {
        return params.value ? parseFloat((Number(params.value)/60).toString()).toFixed(2) : '';
      }
    }
  ];

  schedulingColDef: any = [
    {
      headerName: 'Task',
      field: 'location_name',
      filter: "agTextColumnFilter",
      rowGroup: true,
      hide: true,
      width: 30
    },
    {
      headerName: '',
      field: 'task_name',
      cellRenderer: 'scheduleCellRendrer'
    },
  ];

  associateGridOptions: any = {
    defaultColDef: {
      sortable: true,
      resizable: true
    },
    //copyHeadersToClipboard: true,
    suppressMaxRenderedRowRestriction: true,
    suppressColumnVirtualisation: true,
    groupDefaultExpanded: -1,
    rowBuffer: 9999,
    floatingFilter: true,
    enableMultiRowDragging: true,
    rowSelection: 'multiple',
    rowMultiSelectWithClick: true,
    groupSelectsChildren: true,
    autoGroupColumnDef: {
      headerName: 'Associates',
      field: 'emp_full_name',
      cellRenderer: 'agGroupCellRenderer',
      filter: "agTextColumnFilter",
      cellClass: 'drag-row',
      dndSource: true,
      rowDrag: true,
      dndSourceOnRowDrag: this.onRowDrag,
      cellRendererParams: {
        innerRenderer: 'associateCell',
        checkbox: true,
      }
    },
  };

  schedulingGridOptions: any = {
    defaultColDef: {
      sortable: true,
      flex: 1
    },
    context: {
      componentParent: this
    },
    getRowHeight: function(params){
      return params.node.group?50:150;
    },
    getRowStyle: function(params){
      return params.node.group?{'background-color': '#EEE'}:{};
    },
    suppressMaxRenderedRowRestriction: true,
    suppressColumnVirtualisation: true,
    groupDefaultExpanded: -1,
    rowBuffer: 9999,
    floatingFilter: true,
    autoGroupColumnDef: {
      headerName: '',
      field: 'task_name',
      cellRenderer: 'agGroupCellRenderer',
      filter: "agTextColumnFilter",
      width: 300,
      pinned: 'left',
      cellRendererParams: {
        innerRenderer: 'taskNameCell',
      }
    },
  };
  unsavedAssignmentsCount = 0;

  frameworkComponents = {
    taskNameCell : TaskNameCell,
    scheduleCellRendrer: ScheduleCellRendrer
  };

  associateframeworkComponents = {
    associateCell: AssociateCell
  };

  unsavedAssignments: any;

  constructor(
    public scheduleAssociatesService: ScheduleAssociatesService,
    public eventBaseScheduleService: EventBaseScheduleService,
    private _store: Store<fromScheduling.ISchedulingState>,
    private modalService: NgbModal,
    private globals: Globals
) {
  }

  onRowDrag(params) {
    const e = params.dragEvent;
    let jsonObject = [];
    const selectedRows = params.rowNode.gridApi.getSelectedRows();
    if(selectedRows.length > 0){
      jsonObject = selectedRows;
    }else if(params.rowNode.group){
      params.rowNode.allLeafChildren.map(v=>{
        jsonObject.push(v.data);
      });
    } else {
      jsonObject.push(params.rowNode.data);
    }
    const jsonData = JSON.stringify(jsonObject);
    const userAgent = window.navigator.userAgent;
    const isIE = userAgent.indexOf('Trident/') >= 0;
    if (isIE) {
      e.dataTransfer.setData('text', jsonData);
    } else {
      e.dataTransfer.setData('application/json', jsonData);
      e.dataTransfer.setData('text/plain', jsonData);
    }
  }

  onGridReady(params) {
    console.log('params', params);
    this.gridApi = params.api;
    // this.gridColumnApi = params.columnApi;
  }

  onSchedulingGridReady(params) {
    console.log('params', params);
    this.schedulingGridApi = params.api;
  }

  onSelectionChanged($event) {
    const selectedRows = this.gridApi.getSelectedNodes();
    if(selectedRows.length>0){
      this.gridWrapperClass = 'show-drop-associate';
    }else{
      this.gridWrapperClass = '';
    }
  }

  changeView(type: string) {
    this.view = type;
  }

  ngOnInit() {
    console.log(this.event);
    console.log(this.globals);
    this._store.dispatch(new fromScheduling.ResetScheduleTaskAssociate());
    this._store.dispatch(new fromScheduling.GetComplexAssociatesLoad(this.globals.ebsTeamSelected));
    this._store.dispatch(new fromScheduling.GetComplexSchedulesLoad({
      selected_team: this.globals.ebsTeamSelected,
      user_name: this.globals.user_name,
      event_id: this.event.event_id,
      week_start: this.event.event_sched_start_time,
      week_end: this.event.event_sched_end_time
    }));
    this._store.dispatch(new fromScheduling.GetComplexTasksLoad({
      selected_team: this.globals.ebsTeamSelected,
      event_id: this.event.event_id}));
    const data$ = this._store.pipe(select(fromScheduling.allScheduling));
    data$.subscribe(res => {
      if(res.tasksInitialLoad && res.associateInitialLoad && res.schedulesInitialLoad){
        this.loaded = res.associateInitialLoad;
        this.assocatedata = res.associates;
        this.schedules = res.schedules;
        this.data = res.tasks;
        this.schedulingData = cloneDeep(res.tasks);
        this.setAssignments();
        this.setSchedulerData();
        if(this.data.length > 0){
          this.showSchedule = true;
        }
      }
      if(res.unsavedSchedules){
        const data = cloneDeep(res.unsavedSchedules);
        this.schedulingData.map(t=>{
          if(t.task_id === data.task.task_id && t.location_id === data.task.location_id){
            data.associates.map(a=>{
              t.associates.push(cloneDeep(a));
            });
            this.schedulingGridApi.redrawRows({rowNodes: [this.schedulingGridApi.getDisplayedRowAtIndex(data.rowIndex)]});
          }
        });
        this.gridApi.deselectAll();
      }
      if(res.conflictMessage && res.conflictMessage.length>0){
        Swal.fire(res.conflictMessage);
      }
      this.unsavedAssignmentsCount = res.unsavedAssignmentsCount ? res.unsavedAssignmentsCount : 0;
      this.unsavedAssignments = res.unsavedAssignments;
    });
  }

  setAssignments(){
    this.schedulingData.map(t=>{
      this.schedules.map(s=>{
        s.shifts.map(a=>{
          if(t.task_id === a.task_id){
            const i = t.associates.findIndex(v=>v.emp_id===s.employee_id);
            if(i == -1){
              const index = this.assocatedata.findIndex(v=>v.emp_id===s.employee_id);
              t.associates.push(cloneDeep(this.assocatedata[index]));
            }
          }
        });
      });
    });
  }

  setSchedulerData() {
    let startDate = new Date(),
      endDate = new Date();
    startDate.setHours(0, 0, 0, 0);
    endDate.setHours(24, 0, 0, 0);
    this.schedulerConfig = {
      minHeight: 'calc(100vh - 250px)',
      startDate: startDate,
      endDate: endDate,
      reserveScrollbar : true,
      eventRenderer : ({ eventRecord, resourceRecord, tplData }) => {
        // tplData.event.draggable = false;
        eventRecord.draggable = false;
        if (eventRecord.data.eventOverNight) {
          tplData.style = '';  //cust-b-style
          tplData.iconCls =  'fa fa-moon-o';
        }
        if (eventRecord.data.schdStartTime && !eventRecord.data.schdEndTime) {
          return `<div>${eventRecord.data.schdStartTime}</div>`
        } else if (eventRecord.data.schdEndTime && !eventRecord.data.schdStartTime) {
          return `<div>${eventRecord.data.schdEndTime}</div>`
        } else if (eventRecord.data.schdStartTime && eventRecord.data.schdEndTime ) {
          return `<div>${eventRecord.data.schdStartTime}</div>
                  <div>${eventRecord.data.schdEndTime}</div>`
        }
      },
      viewPreset: {
        base: 'hourAndDay',
        tickWidth: 25,
        columnLinesFor: 1,
        mainHeaderLevel: 1,
        headers: [
          {
            unit: 'd',
            align: 'center',
            dateFormat: 'ddd - MM/DD'
          },
          {
            unit: 'h',
            align: 'center',
            dateFormat: 'h A'
          }
        ]
      },
      rowHeight: 120,
      barMargin: 13,
      multiEventSelect: false,
      mode: 'horizontal',
      columns: [
        {
          text: 'Task',
          width: 300,
          field: 'task_id',
          htmlEncode: false,
          renderer({ record }) {
            return `<br-schedule-task details='${JSON.stringify(record.data)}' groupname='${record.meta.groupRowFor}' groupparent='${record?.meta?.map?.resources?.groupParent?.meta?.groupRowFor}' style='display:block;width:100%;padding:10px'></br-schedule-task>`;
          }
        }
      ],
      events: [],
      resourceTimeRangesFeature: true,
      filterBarFeature: true,
      eventContextMenuFeature: false,
      eventDragFeature: false,
      readOnly: true,
      zoomOnTimeAxisDoubleClick: false,
      headerContextMenuFeature: false,
      eventFilterFeature: false,
      features: {
        timeRanges: {
          showCurrentTimeLine: true
        },
        group: {
          field: 'location_name',
          renderer: ({ isFirstColumn, count, groupRowFor, record, column }) => isFirstColumn ? `${groupRowFor} (${count})` :
            column.text == 'Coverage' ? `${groupRowFor}` : `<br-schedule-task-group-header style='display:block;width:52vw;padding:10px'></br-schedule-task-group-header>`
        }
      },
      resources: this.data
    };
    this.isLoading = false;
  }

  onDragOver(event) {
    //console.log(event);
    event.preventDefault();
  }

  onDrop(event) {
    this.isLoading = true;
    const index = event.path[1].getAttribute('data-index') ? Number(event.path[1].getAttribute('data-index')) : 0;
    const userAgent = window.navigator.userAgent;
    const isIE = userAgent.indexOf('Trident/') >= 0;
    if(index != 0){
      let groupBefore = 0;
      for (let i = 0; i < (index+2); i++) {
        if(event.path[2].children[i].classList.contains('b-group-row')){
          groupBefore++;
        }
      }
      const task: any = this.scheduler.resources[index-groupBefore];
      const assoicateData: any = JSON.parse(event.dataTransfer.getData(
        isIE ? 'text' : 'application/json'
      ));
      this.schedulerConfig.events.push({
        id            : task.task_id,
        resourceId    : task.task_id,
        task_id       : task.task_id,
        empId            : assoicateData.empId,
        startDate     : '2020-12-10 ' + task.start_time,
        endDate       : '2020-12-10 ' + task.end_time,
        name          : assoicateData.empFullName,
        eventColor    : "green",
        eventStyle    : "line",
        cls           : 'meal-break',
        editable      : false,
        sortOrder     : 2
      });
    }
    event.preventDefault();
    this.isLoading = false;
  }

  updateAssociate(data, addOption = false){
    if(addOption){
      data.associates = this.gridApi.getSelectedRows();
    }
    this._store.dispatch((new fromScheduling.SetComplexUnsavedAssignments(data)));
  }

  addSchedule(ev) {
   // console.log(ev);
    const modalRef = this.modalService.open(ScheduleAssociateModalComponent,{ backdrop: 'static', size: 'lg', windowClass: 'myCustomModalClass' });
    modalRef.componentInstance.selectedTaskDetail = ev;
    modalRef.componentInstance.isTaskSelected = true;

  }


  createOpenShift(ev) {
    console.log(ev);
    const modalRef = this.modalService.open(offerAssociatesModalComponent, { backdrop: 'static', size: 'lg', windowClass: 'myCustomModalClass' });
    modalRef.componentInstance.taskDetail = ev;
  }

  saveAssignment(){
    this._store.dispatch((new fromScheduling.CreateScheduleForAssociates({
      selectedTeam: this.globals.ebsTeamSelected,
      userName: this.globals.user_name,
      data: this.unsavedAssignments
    })));
  }
}
