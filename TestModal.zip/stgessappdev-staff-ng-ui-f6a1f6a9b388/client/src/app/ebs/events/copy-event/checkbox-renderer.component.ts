import { Component, OnDestroy } from '@angular/core';

import { ICellRendererAngularComp } from  "ag-grid-angular";

@Component({
  selector: 'checkbox-renderer',
  template: `
    <input
      type="checkbox"
      (click)="checkedHandler($event)"
      [checked]="params.value"
    />
`,
})
export class CheckboxRenderer implements ICellRendererAngularComp, OnDestroy {
   params: any;
   parent: any;

  agInit(params: any): void {
    this.params = params;
    this.parent = this.params.context.componentParent;
  }

  checkedHandler(event) {
    let checked = event.target.checked;
    let colId = this.params.column.colId;
    this.params.node.setDataValue(colId, checked);
    // if(checked){
      this.parent.cellClicked(this.params);
    // }
  }

  ngOnDestroy(): void {
  }

  refresh(params: any): boolean {
    return false;
  }


}
