import {Component, Input, OnInit, ViewChild} from '@angular/core';
import {Globals} from "@staff/shared/common/global/global.provider";
import {EventBaseScheduleService} from "@staff/shared/common/services/ebs.service";
import * as moment from "moment";
import {Observable, forkJoin, throwError} from 'rxjs';
import {catchError, map} from "rxjs/operators";
import {CheckboxRenderer} from "@staff/ebs/events/copy-event/checkbox-renderer.component";
import {AgGridAngular} from "ag-grid-angular";
import {ActivatedRoute} from "@angular/router";
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-sel-event-schedule',
  templateUrl: './sel-event-schedule.component.html',
  styleUrls: ['./sel-event-schedule.component.scss']
})
export class SelEventScheduleComponent implements OnInit {
@Input ()  selectedEventId: number;
@Input ()  selectedEventName: string;
@Input ()  selectedStartDate: any;
@Input ()  selectedEndDate: any;
@ViewChild('agGrid') agGrid: AgGridAngular;


  selEventId : number;
  selEventName: string = '';
  selStartDate: any;
  selEndDate: any;

  width = '100%';
  height = 'calc(100vh - 400px)';
  gridData: any = [];
  private gridApi: any;
  private gridColumnApi: any;
  rowSelection = 'multiple';
  eventTypePlaceholder = 'Select';

  startDate: any;
  endDate: any;
  userName: string='';
  selectedTeam: string = '';
  associates: any;
  tasksAndLoc: any;

  context: any;

  toastrMsg: string = '';

  constructor(
    public globals: Globals,
    public scheduleService: EventBaseScheduleService,
    private route: ActivatedRoute,
    private toastr: ToastrService,
  ) { }

  colDefs: any = [
    // {
    //   headerName: 'Copy?',
    //   field: 'copyAssociate',
    //   colId: 'copyAssociate',
    //   cellRenderer: "checkboxRenderer",
    //   width: 50,
    // },
    {
      headerName: 'Emp Name',
      field: 'emp_full_name',
      width: 100,
      checkboxSelection: true
    },
    // {
    //   headerName: 'Emp Id',
    //   field: 'employee_id',
    //   width: 100,
    //   hidden: true
    // },
    {
      headerName: 'Schedule Hours',
      field: 'sched_hours',
      width: 100
    },
    {
      headerName: 'Task Name',
      field: 'task_name',
      width: 100
    },
    {
      headerName: 'Location Name',
      field: 'location_name',
      width: 100
    }
  ];

  eventsGridOptions: any = {
    // frameworkComponents : {
    //   checkboxRenderer: CheckboxRenderer
    // },
    defaultColDef: {
      sortable: true,
      resizable: true,
      flex: 1
    },
    // rowSelection: 'single',
    // rowMultiSelectWithClick: false,
    // enableRangeSelection: false,
    // onRangeSelectionChanged: this.onRangeSelectionChanged,
    //copyHeadersToClipboard: true,
    suppressMaxRenderedRowRestriction: true,
    suppressColumnVirtualisation: true,
    groupDefaultExpanded: -1,
    rowBuffer: 9999,
    floatingFilter: true,
    // autoGroupColumnDef: {
    //   headerName: 'Employee Name',
    //   field: 'emp_full_name',
    //   suppressSizeToFit: true,
    //   cellRenderer: 'agGroupCellRenderer',
    //   filter: "agTextColumnFilter",
    //   minWidth: 300,
    //   maxWidth: 500,
    //   cellRendererParams: {
    //     checkbox: true,
    //     // innerRenderer: this.checkbox
    //   },
    // },
    groupSelectsChildren: true
  };


  currencyFormatter(params) {
    if(params.value != undefined){
      if (Number(params.value)>0){
        return Number(params.value).toLocaleString('en-US', { style: 'currency', currency: 'USD' });
      }else if (Number(params.value) === 0) {
        return '$0.00';
      }else {
        return '('+Number(params.value*-1).toLocaleString('en-US', { style: 'currency', currency: 'USD' })+')';
      }
    }else{
      return '';
    }
  }

  ngOnInit() {
    this.selEventId = this.selectedEventId;
    this.selEventName = this.selectedEventName;
    this.startDate = this.selectedStartDate;
    this.endDate = this.selectedEndDate;
    this.userName = this.globals.user_name;
    this.selectedTeam = this.globals.ebsTeamSelected;

    this.context = { componentParent : this}

    //for testing purpose
    if (!this.selectedTeam) this.selectedTeam = 'C-6335';

    if (this.startDate && this.endDate && this.selectedTeam) {
      let start_date = moment(this.startDate).format("MM/DD/YYYY 00:00");
      let end_date   = moment(this.endDate).format("MM/DD/YYYY 23:59");

      this.gridData = [];
      forkJoin({
        associates: this.scheduleService.getTeamScheduleAssociates(this.selectedTeam, this.userName, this.selEventId, start_date, end_date),
        tasksAndLoc: this.scheduleService.getTeamTemplateHistory(this.selectedTeam, this.selEventId.toString())
      })
        .subscribe(({associates, tasksAndLoc}) => {
        this.mapData(associates, tasksAndLoc);
      })

    // let associates = this.scheduleService.getTeamScheduleAssociates(this.selectedTeam, start_date, end_date, this.userName, this.selEventId);
    // let tasksAndLoc = this.scheduleService.getTeamTemplateHistory(this.selectedTeam, this.selEventId.toString())
    //   .pipe( map(response=>response), catchError(SelEventScheduleComponent.handleError));
    // forkJoin([associates,tasksAndLoc]).subscribe( resp => {
    //     console.log ("associates: "+resp[0]);
    //     console.log ("tasksAndLoc: "+resp[1]);
    //     this.mapData(resp[0], resp[1]);
    // })
    }


  }

  // private static handleError(error) {
  //   return throwError(error);
  // }

  mapData(associates,tasksAndLoc){
    this.associates = associates;  //save the list to be used later during save
    this.tasksAndLoc = tasksAndLoc; //save the list to be used later during save


    let rows = [];
    associates.map(item=>{
       if (item.shifts.length>0){
         item.shifts.map(shft =>{
           let task_loc = tasksAndLoc.tasks.filter(t=>{
             return t.task_id===shft.task_id && t.location_id===shft.location_id})
           rows.push ({
             copyAssociate : false,
             employee_id: item.employee_id,
             emp_full_name: item.emp_full_name,
             sched_hours: shft.sched_hours,
             task_id: shft.task_id,
             task_name: (task_loc.length>0?task_loc[0].task_name:'Missing Task name'),
             location_id: shft.location_id,
             location_name: (task_loc.length>0?task_loc[0].location_name:'Missing Location name'),
           })
         })
       } else {
         rows.push({
             copyAssociate: false,
             employee_id: item.employee_id,
             emp_full_name: item.emp_full_name,
             sched_hours: 0,
             task_id: null,
             task_name: null,
             location_id: null,
             location_name: null
         })
       }

    })
    this.gridData = rows;
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }

  copyEvent() {
    const selectedNodes = this.agGrid.api.getSelectedNodes();
    const selectedData = selectedNodes.map(node => node.data );

    //update  this.associates, this.tasksAndLoc with the new eventid
    let copyToEventId  = Number(this.route.snapshot.paramMap.get('event_id'));
    console.log("copyToEventId:"+copyToEventId);
    this.tasksAndLoc.event_id = copyToEventId;

    let selAssociates = [];
    selectedData.map(sel=>{
      let assoRow = this.associates.filter(a=>{
              return a.employee_id === sel.employee_id
      });
      assoRow.map(a=> {
        a.shifts.map(shft => {
          shft.event_id = copyToEventId
          shft.break_start = (shft.break_start===null?moment(shft.start).format("MM/DD/YYYY 00:00"):shft.break_start)
          shft.break_end = (shft.break_start===null?moment(shft.end).format("MM/DD/YYYY 00:00"):shft.break_end)
        })
      })
      selAssociates.push(assoRow[0]);
    });

    //post the changes
    this.scheduleService.createScheduleForAssociates(this.selectedTeam, this.userName, selAssociates).subscribe(
      result => {
        this.toastrMsg = "Created schedules!";
        this.toastr.success(this.toastrMsg,
          '', {
            enableHtml: true,
            closeButton: true
          });
        setTimeout(() => {
        }, 1000);
      },
      error => {
        this.toastrMsg = "FAILED to create schedules! <br/>";
        this.toastr.error(this.toastrMsg,
          '', {
            enableHtml: true,
            closeButton: true
          });
      }
    );
    this.scheduleService.createTeamTemplateHistory(this.selectedTeam, this.tasksAndLoc).subscribe(
      result => {
        this.toastrMsg = "Created Team Template History!";
        this.toastr.success(this.toastrMsg,
          '', {
            enableHtml: true,
            closeButton: true
          });
        setTimeout(() => {
        }, 1000);
      },
      error => {
        this.toastrMsg = "FAILED to create Team Template History! <br/>";
        this.toastr.error(this.toastrMsg,
          '', {
            enableHtml: true,
            closeButton: true
          });
      }
    );





  }






}
