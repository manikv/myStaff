import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelEventScheduleComponent } from './sel-event-schedule.component';

describe('SelEventScheduleComponent', () => {
  let component: SelEventScheduleComponent;
  let fixture: ComponentFixture<SelEventScheduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelEventScheduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelEventScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
