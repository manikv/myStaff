import {Component, Input, OnInit, ViewChild, ViewEncapsulation} from '@angular/core';
import {DatePickerModel} from "@staff/shared/common/components/datepicker/datepicker.component";
import {ConfirmDialog} from "@staff/shared/dialogs/confirm-dialog/confirm-dialog.component";
import * as moment from "moment";
import {Globals} from "@staff/shared/common/global/global.provider";
import {EventBaseScheduleService} from "@staff/shared/common/services/ebs.service";
import {CheckboxRenderer} from "@staff/ebs/events/copy-event/checkbox-renderer.component";
import {AgGridAngular} from "ag-grid-angular";
import {ActivatedRoute} from "@angular/router";
import {ToastrService} from "ngx-toastr";

@Component({
  selector: 'app-copy-event',
  templateUrl: './copy-event.component.html',
  styleUrls: ['./copy-event.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CopyEventComponent implements OnInit {
  @Input () selectedTeam: string = '';
  @Input () selectedEventId: number;
  @ViewChild('agGrid') agGrid: AgGridAngular;

  ifSelEventVisible: boolean= true;
  ifReviewEventVisible: boolean= false;
  ifCopySchSelected: boolean = false;

  // datePickerModel: DatePickerModel = { id: 'ATC-start-date', required: true, validFormat: true }
  // datePickerModel1: DatePickerModel = { id: 'ATC-end-date', required: true, validFormat: true }
  startDateModel: DatePickerModel = {id:'ATC-start-date',required:true,validFormat:true, maxDate: null, minDate: null, errorText: 'start date'};
  endDateModel: DatePickerModel = {id:'ATC-end-date',required:true,validFormat:true, maxDate: null, minDate: null, errorText: 'end date'};

  width = '100%';
  height = 'calc(100vh - 400px)';
  gridData: any = [];
  private gridApi: any;
  private gridColumnApi: any;
  rowSelection = 'single';   //'multiple';
  eventTypePlaceholder = 'Select';

  startDate: any;
  endDate: any;
  eveType: string='';
  userName: string='';

  selCopyEventID: number;
  selCopyEventName: string = '';

  context: any;

  toastrMsg: string = '';

  constructor(
    public globals: Globals,
    public scheduleService: EventBaseScheduleService,
    private route: ActivatedRoute,
    private toastr: ToastrService,
  ) { }

  columnDefs: any = [
    {
      headerName: 'Select',
      field: 'copyEvt',
      pinned: 'left',
      width: 35,
      colId: 'evtSelected',
      cellRenderer: function cellTitle(params, index) {
        return params.value ? '<div class="ngSelectionCell"><input name="selected'+index+'" type="radio" checked /></div>' : '<div class="ngSelectionCell"><input name="selected'+index+'" type="radio" /></div>';
      },
      cellStyle: {border: 'none'},
      valueSetter: function(params) {
        return params.newValue;  //true;
      }
    },
    {
      headerName: 'Event Name',
      field: 'event_name',
      colId: 'name',
      width: 200,
      filter: 'agTextColumnFilter',
      cellRenderer: "agGroupCellRenderer",
      checkboxSelection: false
    },
    {
      headerName: 'Copy Schedule?',
      field: 'copySch',
      colId: 'copySch2',
      cellRenderer: "checkboxRenderer"
    },
    {
      headerName: 'Date',
      field: 'eventDate',
      colId: 'date',
      width: 125,
      filter: 'agTextColumnFilter',
      sort: "asc"
    },
    {
      headerName: 'Event Type',
      field: 'event_type',
      filter: 'agTextColumnFilter',
      width: 200
    },
    {
      headerName: 'Est Guests',
      field: 'est_guests',
      filter: 'agTextColumnFilter',
      width: 50
    },
    {
      headerName: 'Scheduled Hours',
      field: 'event_sched_hours',
      filter: 'agTextColumnFilter',
      width: 100
    },
    {
      headerName: 'Scheduled Amount',
      field: 'event_sched_amount',
      filter: 'agTextColumnFilter',
      width: 75,
      valueFormatter: params => this.currencyFormatter(params),
      // cellStyle: {textAlign: "right"}
    },
    {
      headerName: 'Address',
      field: 'location',
      filter: 'agTextColumnFilter',
      width: 250,
    }
  ];

  eventsGridOptions: any = {
    frameworkComponents : {
      checkboxRenderer: CheckboxRenderer
    },
    defaultColDef: {
      sortable: true,
      resizable: true,
      flex: 1
    },
    // rowSelection: 'single',
    // rowMultiSelectWithClick: false,
    // enableRangeSelection: false,
    // onRangeSelectionChanged: this.onRangeSelectionChanged,
    //copyHeadersToClipboard: true,
    suppressMaxRenderedRowRestriction: true,
    suppressColumnVirtualisation: true,
    groupDefaultExpanded: -1,
    rowBuffer: 9999,
    floatingFilter: true,
    // autoGroupColumnDef: {
    //   headerName: 'Event Name',
    //   field: 'event_name',
    //   suppressSizeToFit: true,
    //   cellRenderer: 'agGroupCellRenderer',
    //   filter: "agTextColumnFilter",
    //   minWidth: 300,
    //   maxWidth: 500,
    //   cellRendererParams: {
    //     checkbox: true,
    //     // innerRenderer: this.checkbox
    //   },
    // },
    groupSelectsChildren: true
  };


  currencyFormatter(params) {
    if(params.value != undefined){
      if (Number(params.value)>0){
        return Number(params.value).toLocaleString('en-US', { style: 'currency', currency: 'USD' });
      }else if (Number(params.value) === 0) {
        return '$0.00';
      }else {
        return '('+Number(params.value*-1).toLocaleString('en-US', { style: 'currency', currency: 'USD' })+')';
      }
    }else{
      return '';
    }
  }

  ngOnInit() {
    //for testing purpose
    if (this.selectedTeam==='') {this.selectedTeam='C-6335';}

    this.userName = this.globals.user_name;

    ////having to do this due to bootstrap issue
    // this.startDateModel.minDate =  {year: 2018, month: 1, day: 1};
    // this.endDateModel.maxDate =  {year: 3000, month: 12, day: 31};  // moment().add(-2, 'years');

    if (this.startDate && this.endDate) {
      // get the events in the selected data range
      this.getEvents();
    }

    this.context = { componentParent : this}

  }

  getEvents(){
    let start_date = moment(this.startDate).format("MM/DD/YYYY 00:00");
    let end_date   = moment(this.endDate).format("MM/DD/YYYY 23:59");

    this.gridData = [];

    this.scheduleService
      .getEvents(this.selectedTeam, start_date, end_date, this.userName)
      .subscribe((resp: any) => {
        if (resp)
          this.mapData(resp);
      }, err => {
        console.log('error --->', err);
        this.mapData([[]]);
      });
  }

  mapData(eventItems){
    eventItems.map(item=>{
      item.eventDate = moment(item.event_start_time).format("MM/DD/YYYY")
      item.copySch = false;
      item.copyEvt = false;
    })

    this.gridData = eventItems;
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }

  onRowSelected($event) {
    if ($event.node.isSelected()) {
      $event.data.copySch = true;
      $event.node.setDataValue("evtSelected", true);
      // $event.node.setSelected("evtSelected", true);
      this.ifCopySchSelected = true;
    } else {
      if ($event.data) $event.data.copySch = false;
      $event.node.setDataValue("evtSelected", false);
    }
  }

  cellClicked($evt) {
    console.log("CellClicked");
    $evt.node.setSelected(true);
    var tmp: boolean = $evt.data.copySch;
    if ($evt.column.colId === "copySch2") {
      this.gridApi.forEachNode((node) => {
        node.data.copyEvt = false;
        node.data.copySch = false;
      });
      $evt.data.copyEvt = true;
      $evt.data.copySch = tmp;
      $evt.api.redrawRows();
      this.ifCopySchSelected = $evt.data.copySch;
    }
    if ($evt.column.colId === "evtSelected") {
        $evt.data.copySch = true;
        this.gridApi.forEachNode((node) => {
          if (!node.selected) {
            node.data.copySch = false;
          }
        });
    }
    this.selCopyEventID = $evt.data.event_id;
    this.selCopyEventName  = $evt.data.event_desc;

  }

  dtParamSelected(value, parameterKey) {
    let selDt = moment(value.month + "/" + value.day + "/" + value.year).format ("MM/DD/YYYY");
    if (parameterKey=='stdate') {
      this.startDate = moment(selDt).format ("MM/DD/YYYY 00:00");
      this.endDateModel.minDate = value;
    } else {
      this.endDate = moment(selDt).format ("MM/DD/YYYY 23:59");
      this.startDateModel.maxDate = value;
    }
    if (this.startDate && this.endDate) {
      this.getEvents();
    }


  }

  gotoSelSch() {
    this.ifSelEventVisible = false;
    this.ifReviewEventVisible= true;
  }

  copyTasks() {
    const selectedNodes = this.agGrid.api.getSelectedNodes();
    const selectedData = selectedNodes.map(node => node.data );

    //update this.tasksAndLoc with the new eventid
    let copyToEventId  = Number(this.route.snapshot.paramMap.get('event_id'));
    console.log("copyToEventId:"+copyToEventId);

    this.scheduleService.getTeamTemplateHistory(this.selectedTeam, this.selCopyEventID.toString())
     . subscribe((t:any)=>{
       t.event_id = copyToEventId;
       this.scheduleService.createTeamTemplateHistory(this.selectedTeam, t).subscribe(
        result => {
          this.toastrMsg = "Copied Tasks!";
          this.toastr.success(this.toastrMsg,
            '', {
              enableHtml: true,
              closeButton: true
            });
          setTimeout(() => {
          }, 1000);
        },
        error => {
          this.toastrMsg = "FAILED to copy tasks! <br/>";
          this.toastr.error(this.toastrMsg,
            '', {
              enableHtml: true,
              closeButton: true
            });
        }
      );
  })





    }



}
