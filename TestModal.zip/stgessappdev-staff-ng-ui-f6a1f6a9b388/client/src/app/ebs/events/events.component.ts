import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { Globals } from "../../shared/common/global/global.provider";
import * as moment from "moment";
import * as _ from 'lodash';
import { EventBaseScheduleService } from "../../shared/common/services/ebs.service";
import { Scheduler, WidgetHelper } from "bryntum-scheduler/scheduler.umd.js";
import { EventSummaryComponent } from "./summary/event-summary.component";
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EventsComponent implements OnInit {

  @ViewChild("eventSummary", { static: false }) eventSummary: EventSummaryComponent;
  teamComponent: any;
  selectedTeam: any;
  selectedTeamId:any;
  prevSearchTeam: any = '';
  itemStorage = localStorage.getItem('prevEBSSearchedTeam');
  defaultTeamDropDown: any = this.itemStorage ? JSON.parse(this.itemStorage) : null;
  filterType = "COMPLEX";
  heading: any = 'Event Summary';
  state: string = 'initial';
  maxValue: number = 0;
  isSubmitting: boolean = false;
  dateHelper: any;
  days = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
  weekStartDay: number = 0;  // default to Sunday, will change for paygroup
  startDate: any; endDate: any;
  resources = []; events = [];
  params: any;
  table: any;
  user_name: any;
  wk_ending_date: any = '';
  payGrp_id: any = '';


  constructor(
    private globals: Globals,
    public scheduleService: EventBaseScheduleService,
    private route: ActivatedRoute
  ) { }

  dataLoaded: boolean = false;
  tabSelected: any = 'Summary';

  ngOnInit() {
    const isEventTemplate: string = this.route.snapshot.queryParamMap.get('eventTemplates');
    this.dataLoaded = false;
    const paygroup = this.getPaygroup(this.teamComponent ? this.teamComponent.paygrp_id : null);
    let changeDate = (value) => this.changeDate(value);
    [this.dateHelper] = WidgetHelper.append([
      {
        type: 'date',
        value: moment(this.endDate.toDate()),  //.subtract(1, 'days').toDate(),
        step: '7d',
        picker: {
          // weekStartDay: this.weekStartDay,
          disabledDates: (date) => date.getDay() !== (this.weekStartDay - 1) % 7
        },
        onChange({ value }) {
          changeDate(value);
        }
      }
    ], { appendTo: document.getElementById('datehelper') });
    this.refreshStartDay();
    if(isEventTemplate){
      this.tabSelected = 'Templates';
    }
  }

  changeDate(end_date) {
    this.startDate = moment(end_date).subtract(6, 'days');
    this.endDate = moment(end_date);
    this.setGlobalData(this.globals.ebsTeamSelected, this.globals.ebsPayGrpId);
    this.setEventSummary();
  }

  logTabChange(selectedTab) {
    this.tabSelected = selectedTab;
  }

  selectTeam($event) {
    this.dataLoaded = true;
    this.teamComponent = $event;
    this.selectedTeam = $event.team_name;
    this.selectedTeamId = $event.team_id;
    this.setGlobalData($event.team_name, $event.team_pay_group_id);
    this.setEventSummary();
  }

  setStorage(value) {
    this.prevSearchTeam = value;
    localStorage.setItem('prevEBSSearchedTeam', JSON.stringify(value));
  }

  setGlobalData(team_name, paygroup_id) {
    this.globals.ebsPayGrpId = paygroup_id;
    this.globals.ebsTeamSelected = team_name;
    this.globals.ebsWkEndSelected = this.endDate;
    this.globals.ebsWkStartSelected = this.startDate;
    this.globals.ebsTeamIdSelected = this.selectedTeamId;
  }

  getPaygroup(paygroup_id) {
    // use selected team's paygroup_id, ff it's not set, then use from user's MyStaff profile
    if (!paygroup_id) {
      if (this.globals.proxyUserName && this.globals.proxyUseProfile)
        paygroup_id = this.globals.proxyUseProfile.pay_group_id;
      else
        paygroup_id = this.globals.staffProfile.paygroup_id;
    }
    const fallbackPaygroup = {
      description: "Fri-Thurs Hourly",
      end_date: moment().startOf("week").add(-2, "days").format("MM/DD/YYYY"),
      id: 10005,
      name: "FRI-THURS HOURLY",
      start_date: moment().startOf("week").add(4, "days").format("MM/DD/YYYY"),
    };
    const paygroups = this.globals.paygroups || [];
    const paygroup = paygroups.find(row => row.id === paygroup_id) || fallbackPaygroup;
    this.startDate = moment(paygroup.start_date, 'MM-DD-YYYY');
    this.endDate = moment(paygroup.end_date, 'MM-DD-YYYY');
    this.setWeekStartDay(paygroup);
    this.setGlobalData(this.globals.ebsTeamSelected, paygroup_id);
    this.payGrp_id = paygroup_id;
    return paygroup;
  }

  setWeekStartDay(paygroup) {
    let day = paygroup.name.substring(0, 3).toLowerCase();

    this.weekStartDay = _.findIndex(this.days, (d) => {
      return d.substring(0, 3) == day;
    });
  }

  refreshStartDay() {
    this.dateHelper.value = moment(this.endDate); //.subtract(1, 'days').toDate();
    this.wk_ending_date = moment(this.dateHelper.value).format("MM/DD/YYYY");
    this.dateHelper.picker.refresh();
  }

  setEventSummary() {
    if(this.eventSummary){
      this.eventSummary.payGroupId = this.globals.ebsPayGrpId;
      this.eventSummary.wk_ending_date = this.globals.ebsWkEndSelected;
      this.eventSummary.wk_starting_date = this.globals.ebsWkStartSelected;
      this.eventSummary.selectedTeam = this.globals.ebsTeamSelected;
      this.eventSummary.getGlobals();
      this.eventSummary.setScheduler();
      this.eventSummary.getEvents();
    }
  }
}
