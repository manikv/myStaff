import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EventsComponent } from './events.component';
import { EventDetailsComponent } from './event-details/event-details.component';
import { AddEventComponent } from "./add-event/add-event.component";

const routes: Routes = [
  {
    path: '',
    component: EventsComponent
  },
  {
    path: 'details/:event_id',
    component: EventDetailsComponent
  },
  {
    path: 'add',
    component: AddEventComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EventsRoutingModule { }
