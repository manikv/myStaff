import {Component, Input, OnInit, ViewChild, ViewEncapsulation} from '@angular/core';
import * as _ from 'lodash';
import { Globals } from '@staff/shared/common/global/global.provider';
import { CommonService } from '@staff/shared/common/services/common.service';
import { GooglePlaceModule  } from 'ngx-google-places-autocomplete';
import { Address } from 'ngx-google-places-autocomplete/objects/address';
import { DatepickerComponent } from '@staff/shared/common/components/datepicker/datepicker.component';
import { TimepickerModalComponent } from '@staff/shared/timepicker-modal/timepicker-modal.component';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import * as moment from 'moment';
import { ToastrService } from 'ngx-toastr';
import { EventBaseScheduleService } from '../../../shared/common/services/ebs.service';
import { interval } from 'rxjs';
import { map } from 'rxjs/operators';
import { ScheduleAssociateModalComponent } from '@staff/ebs/scheduling/schedule-associate-modal/schedule-associate-modal.component';
import { Router } from '@angular/router';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { TemplateDetails } from '@staff/ebs/common/template-details/template-details.component';
import { TeamTemplateService } from '../../../shared/common/services/teamtemplate.service';
import { IDatasource, IGetRowsParams } from 'ag-grid-community';




@Component({
  selector: 'app-add-event',
  templateUrl: './add-event.component.html',
  styleUrls: ['./add-event.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AddEventComponent implements OnInit {
  
  @BlockUI() blockUI: NgBlockUI;
  event = {
    event_name: '',
    event_type: '',
    location: '',
    dates: {
      start_date: '',
      end_date: '',
      dates_description: ''
    },
    times: {
      start_time: '',
      end_time: '',
      times_description: ''
    },
    estimated_guests: '',
    estimated_revenue: '',
    confidential_notes: '',
    notes: '',
    scheduleTasks: [],
    // event_sched_start_time: '',
    // event_sched_end_time: '',
    event_sched_amount: 0,
    event_sched_hours: 0,
    sched_dates: {
      start_date: '',
      end_date: '',
      dates_description: ''
    },
    sched_times: {
      start_time: '',
      end_time: '',
      times_description: ''
    },

  };
  options = {
    types: [],
    componentRestrictions: { country: 'USA' }
  };
  hasData = false;
  eventAddress: string = '';
  isloaded = false;
  isdetails = false;
  isloadedFrame = false;
  paginationPageSize = 20;
  gridApi: any;
  gridColumnApi: any;
  selectedTemplate:any;
  templateId:any;
  data:any;
  paginationNumberFormatter = function (params) {
    return "[" + params.value.toLocaleString() + "]";
  };
  eventTemplateRowData = [];
  width = '100%';
  height = 'calc(100vh - 200px)';

  
  eventTemplateGridOptions: any = {
    defaultColDef: {
      sortable: true,
      resizable: true,
    },
    copyHeadersToClipboard: true,
    suppressMaxRenderedRowRestriction: true,
    suppressColumnVirtualisation: true,
    groupDefaultExpanded: -1,
    rowBuffer: 9999,
    floatingFilter: true,
    rowModelType: 'infinite',
    cacheBlockSize: this.paginationPageSize,
    rowSelection : "single"

  };

  eventTemplateHeader: any = [   
    {
      headerName: 'Template Name',
      field: 'event_template_name',
      filter: "agTextColumnFilter",
      checkboxSelection: true
    },
    {
      headerName: 'Template Type',
      field: 'template_type',
      filter: "agTextColumnFilter",
    },
    {
      headerName: 'Coverage',
      field: 'associate_count',      
      filter: "agTextColumnFilter",
      suppressMenu: true,
      cellRenderer: params => params.value ? params.value : 0
    },
    {
      headerName: 'Guest Attendence',
      field: 'guest_count',
      filter: "agTextColumnFilter",
      cellRenderer: params => params.value ? params.value : 0
    }
    
  ];


  // @ViewChild('placesRef', { static: false }) placesRef: GooglePlaceDirective;
  @ViewChild("dates", { static: false }) dates: DatepickerComponent;
  @ViewChild('templateComponent', { static: false }) private templateComponent: TemplateDetails;
  @Input() selectedTeam : any = '';
  @Input() wkEndDate: any = '';
  @Input() payGrp_id: any = '';

  public handleAddressChange(address: Address) {
    console.log("Address:"+ address);
    this.eventAddress = address.formatted_address;
    console.log("eventAddress:"+ this.eventAddress);
  }

  eventTypePlaceholder = 'Select Event Type';
  @Input() selectedType : any = '';
  toastrMsg: string = '';

  constructor(
    public globals: Globals,
    private modalService: NgbModal,
    public activeModal: NgbActiveModal,
    public commonService: CommonService,
    public scheduleService: EventBaseScheduleService,
    private toastr: ToastrService,
    private router: Router,
    private templateservice:TeamTemplateService
  ) {
    this.selectedTeam = this.globals.ebsTeamSelected;
    this.wkEndDate = this.globals.ebsWkEndSelected;
    this.payGrp_id = this.globals.ebsPayGrpId;
  }

  ngOnInit() {
  }

  update() {
    //save this Event
    let paygrpId= this.payGrp_id;
    let weekEndDate = moment(this.wkEndDate).format("MM/DD/YYYY 00:00");

    this.scheduleService.getDeptSummary(this.selectedTeam, paygrpId, weekEndDate)
      .subscribe((resp: any) => {
        if (resp) {
          console.log("got Dept Summary id:"+ resp[0].sched_id);
          this.createEvent(resp[0].sched_id);
        } else {
          //DeptSummary not found
          //add Dept Summary record for the selected Complex and all its CC
          let payLoad = [];
          let item = {
            "dept_name": this.selectedTeam,
            "paygrp_id": paygrpId,
            "week_end_date": weekEndDate
          };
          payLoad.push(item);
          this.scheduleService.createDeptSummary(payLoad).subscribe((res: any) => {
            console.log("res[0].sched_id from CreateDeptSummary:" + res.data[0].sched_id);
            this.createEvent(res.data[0].sched_id);
          }, error =>  {
            console.log("Error from CreateDeptSummary:" + error);
          });
        }

      },error => {
          console.log("didnt Dept Summary:"+ error);
        } );
  }

  createEvent(schedId) {
    //save this Event
    let user_name = this.globals.user_name;
    let sched_id = '';  //83595291; //83595291=>for cc 6335;   83595285=> for complex C-6335;
    let paygrpId= this.payGrp_id;
    let weekEndDate = moment(this.wkEndDate).format("MM/DD/YYYY 00:00");

    let start_time = moment(this.event.dates.start_date + " " + this.event.times.start_time).format("MM/DD/YYYY HH:mm");
    let end_time = moment(this.event.dates.end_date + " " + this.event.times.end_time).format("MM/DD/YYYY HH:mm");

    this.event.sched_dates.start_date = this.event.dates.start_date;
    this.event.sched_dates.end_date = this.event.dates.end_date;

    let sched_start_time = moment(this.event.sched_dates.start_date + " " + this.event.sched_times.start_time).format("MM/DD/YYYY HH:mm");
    let sched_end_time = moment(this.event.sched_dates.end_date + " " + this.event.sched_times.end_time).format("MM/DD/YYYY HH:mm");

    sched_id = schedId;
    let payLoad = [];
    let eventItem = {
      "department": {
        "dept_name": this.selectedTeam,
        "sched_id": sched_id,
        "paygrp_id": paygrpId,
        "week_end_date": weekEndDate
      },
      "description": this.event.event_name,
      "end_time": end_time,
      "name": this.event.event_name,
      "notes": this.event.notes,
      "start_time": start_time,
      "status": "Draft",
      "confidential_notes": this.event.confidential_notes,
      "est_guests": this.event.estimated_guests,
      "est_revenue": this.event.estimated_revenue,
      "event_type": this.selectedType.template_type_name, //this.event.event_type,
      "location": this.event.location,
      "event_sched_start_time": sched_start_time,
      "event_sched_end_time": sched_end_time,
      "event_sched_amount": this.event.event_sched_amount,
      "event_sched_hours": this.event.event_sched_hours
    };
    payLoad.push(eventItem);

    this.scheduleService.createEvent(user_name, payLoad).subscribe((res: Response) => {
      this.toastrMsg = "Created " + this.event.event_name + " for " + moment(this.event.dates.start_date).format("MM/DD/YYYY") + "! <br/>";
      this.toastr.success(this.toastrMsg,
      'Create Event', {
      enableHtml: true,
      closeButton: true
      });
      setTimeout(() => {
      this.activeModal.close(1)
      }, 3000);
    }, err => {
      console.log('error --->', err);
      _.set('createEvent', 'status', 'warning');

      this.toastrMsg = "FAILED to created the event! <br/>";
      this.toastr.error(this.toastrMsg,
      'Create Event', {
      enableHtml: true,
      closeButton: true
      });
    });

  }

  updateEventDate(value: any) {
    this.event.dates = {
      start_date: null,
      end_date : null,
      dates_description : ''
    };

    console.log(value);

    if (moment(value, 'MM/DD/YYYY', true).format()!="Invalid date" || value.year ) {
      console.log("Valid date:" + value);
      this.event.dates = {
        start_date: moment(value.year + "/" + value.month + "/"+ value.day).format("YYYY-MM-DD"),
        end_date : moment(value.year + "/" + value.month + "/"+ value.day).format("YYYY-MM-DD"),
        dates_description : value.month + "/"+ value.day
      }
    }
  }

  updateSchedEventDate(value: any) {
    this.event.sched_dates = {
      start_date: null,
      end_date : null,
      dates_description : ''
    };

    if (moment(value, 'MM/DD/YYYY', true).format()!="Invalid date" || value.year ) {
      this.event.sched_dates = {
        start_date: moment(value.year + "/" + value.month + "/"+ value.day).format("YYYY-MM-DD"),
        end_date : moment(value.year + "/" + value.month + "/"+ value.day).format("YYYY-MM-DD"),
        dates_description : value.month + "/"+ value.day
      }
    }
  }

  openTimepickerModal(caller: string) {
    let modalRef = this.modalService.open(TimepickerModalComponent,{ size: 'lg', backdropClass: 'z-1-backdrop', windowClass: 'myTimePickerModalClass' });
    modalRef.result.then((result) => {
      console.log(result);
      let description = `${result.start_time.format('hh:mm A')} - ${result.end_time.format('hh:mm A')}`;

      if (caller === 'event') {
        this.event.times = {
          start_time: result.start_time.format('hh:mm A'),
          end_time: result.end_time.format('hh:mm A'),
          times_description: description
        }
      } else {
        this.event.sched_times = {
          start_time: result.start_time.format('hh:mm A'),
          end_time: result.end_time.format('hh:mm A'),
          times_description: description
        }
      }
    });
  }

  goBack(){
    this.router.navigateByUrl('/ebs/events')
  }

  addAssociate() {
    //console.log('modal');
    //this.modalService.open(ScheduleAssociateModalComponent, { backdrop: 'static', size: 'lg', windowClass: 'myCustomModalClass' });
    this.isloaded = true;
    this.isloadedFrame = true;
    
  }

  parameterSelected(value) {
    this.selectedType = value;
    console.log(this.selectedType.template_type_id);
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    let teamName = this.globals.ebsTeamSelected;
    let dataSource = this.getTemplateData(teamName, this.paginationPageSize);
    this.gridApi.setDatasource(dataSource);
    params.api.sizeColumnsToFit();
  }

  getTemplateData (ebsTeamSelected:string,paginationPageSize:number):IDatasource{
    const data : IDatasource = {
      getRows: (params: IGetRowsParams) => {
        this.blockUI.start('Loading...');
        let teamName = ebsTeamSelected;
        let page = params.endRow / paginationPageSize;
        console.log("teamName" + teamName);     
        let sortModel = '';      
        let searchModel = '';     
        
      if (typeof params.sortModel[0] !== 'undefined'){   
        sortModel = this.templateservice.getSortModel(params.sortModel[0] );
      }
     searchModel = this.templateservice.getSearchModel(params.filterModel,'');
     console.log(searchModel);
      this.scheduleService.getTemplateData(teamName,
        paginationPageSize.toString(),
        page.toString(),sortModel,searchModel)
        .subscribe((res: any) => {                  
          params.successCallback(res.data, res.metadata.result_count);    
        });
      }
    };
    return data;
  }
  

  
  onSelectionChanged($event){
    console.log("onSelectionChanged" );
    var selectedRows = this.gridApi.getSelectedRows();    
    this.templateId = selectedRows[0].event_template_id;
    console.log("selectedRows" + selectedRows[0].event_template_id);
    }

  showDetails(){
    console.log("added details loop" + this.templateId);    
    this.selectedTemplate = this.globals.ebsTemplateSelected;
    //window.addEventListener('addTaskEvent', this.addTask.bind(this));
    //window.addEventListener('addLocationEvent', this.addLocation.bind(this));
    // this.scheduleService.getTemplateDetailsData().subscribe(val=>{
    //   this.data = val;
    //  // this.setSchedulerData();
    // })

    this.isdetails = true;
    this.isloaded = false;
    this.isloadedFrame = true;
  }
  
  onSave(e){
    console.log(e);
  }
}
