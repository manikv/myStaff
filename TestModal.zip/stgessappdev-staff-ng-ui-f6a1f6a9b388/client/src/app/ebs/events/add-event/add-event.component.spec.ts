import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEventModule } from '../add-event.module';
import { AppModule } from '../../app.module';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { APP_BASE_HREF } from '@angular/common';
import {AddEventComponent} from './add-event.component';

describe('AddEventComponent', () => {
  let component: AddEventComponent;
  let fixture: ComponentFixture<AddEventComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        AppModule,
        AddEventModule
      ],
      declarations: [AddEventComponent],
      providers: [
        { provide: APP_BASE_HREF, useValue: '/' }
      ],
    })
    .compileComponents();
    fixture = TestBed.createComponent(AddEventComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    console.log('beforeEach')
  });

  it('should create', () => {
    console.log('create')
    expect(component).toBeTruthy();
  });
});
