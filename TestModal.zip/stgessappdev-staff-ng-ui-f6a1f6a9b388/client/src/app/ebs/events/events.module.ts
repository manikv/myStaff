import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgbModule, NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import 'ag-grid-community';
import 'ag-grid-enterprise';
import { EventsRoutingModule } from './events-routing.module';
import { EventsComponent } from './events.component';
import { EventSummaryComponent } from './summary/event-summary.component';
import { AddEventComponent } from './add-event/add-event.component';
import { AgGridModule } from 'ag-grid-angular';
import { LicenseManager } from 'ag-grid-enterprise';
LicenseManager.setLicenseKey('SoftwareONE_USA_on_behalf_of_Compass_Group_USA_MultiApp_5Devs_5Deployment_12_August_2020__MTU5NzE4NjgwMDAwMA==de1432ef47c510c631b782c11ab2920d');
import { BlockUIModule } from 'ng-block-ui';
import {TeamMultiTypeaheadEbsModule, TemplateTypeDropdownModule} from '@staff/sharedModules/index';
import { NotificationService } from '../../shared/common/services/notification.service';
import { DatepickerModule } from '../../shared/common/components/datepicker/datepicker.module';
import { ToastrService } from 'ngx-toastr';
import { BryntumAngularSharedModule } from 'bryntum-angular-shared';
// import { GooglePlaceDirective, GooglePlaceModule } from 'ngx-google-places-autocomplete';
import { EventBaseScheduleService } from '../../shared/common/services/ebs.service';
import { GooglePlaceModule } from 'ngx-google-places-autocomplete';
import { EventDetailsComponent } from './event-details/event-details.component';
import { TeamTemplatesModule } from '../team-templates/team-templates.module';
import { CopyEventComponent } from "@staff/ebs/events/copy-event/copy-event.component";
import { SelEventScheduleComponent } from '@staff/ebs/events/copy-event/sel-event-schedule/sel-event-schedule.component';
import { CheckboxRenderer } from './copy-event/checkbox-renderer.component';
import { ScheduleAssociateModalModule } from '@staff/ebs/scheduling/schedule-associate-modal/schedule-associate-modal.module';
import { EbsSchedulingModule } from '../scheduling/scheduling.module';
import { TemplateDetailsModule } from '@staff/ebs/common/template-details/template-details.module';
import { offerAssociatesModalModule } from '../openshift/offer-associates/offer-associates-modal.module';
import { scheduleOfferedModalModule } from '../openshift/schedule-offered/schedule-offered-modal.module';

@NgModule({
  declarations: [
    EventsComponent,
    EventSummaryComponent,
    AddEventComponent,
    EventDetailsComponent,
    CopyEventComponent,
    SelEventScheduleComponent,
    CheckboxRenderer
  ],
  imports: [
    CommonModule,
    FormsModule,
    NgbModule,
    EventsRoutingModule,
    BlockUIModule.forRoot(),
    TeamMultiTypeaheadEbsModule,
    GooglePlaceModule,
    EventsRoutingModule,
    DatepickerModule,
    TeamTemplatesModule,
    ScheduleAssociateModalModule,
    TemplateTypeDropdownModule,
    AgGridModule.withComponents(),
    TemplateDetailsModule,
    EbsSchedulingModule,
    offerAssociatesModalModule,
    scheduleOfferedModalModule
  ],
  providers: [
    NgbActiveModal,
    NotificationService,
    ToastrService,
    EventBaseScheduleService
  ]
})
export class EventsModule { }
