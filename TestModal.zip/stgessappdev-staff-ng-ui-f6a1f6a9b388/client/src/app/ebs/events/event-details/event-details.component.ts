import {Component, OnInit, ViewChild, ViewEncapsulation, Input, AfterViewInit} from '@angular/core';
import * as _ from 'lodash';
import { Globals } from '../../../shared/common/global/global.provider';
import { CommonService } from '../../../shared/common/services/common.service';
import { GooglePlaceModule  } from 'ngx-google-places-autocomplete';
import { Address } from 'ngx-google-places-autocomplete/objects/address';
import { DatepickerComponent } from '../../../shared/common/components/datepicker/datepicker.component';
import { TimepickerModalComponent } from '../../../shared/timepicker-modal/timepicker-modal.component';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import { ToastrService } from 'ngx-toastr';
import { EventBaseScheduleService } from '../../../shared/common/services/ebs.service';
import { ScheduleAssociateModalComponent } from '@staff/ebs/scheduling/schedule-associate-modal/schedule-associate-modal.component';
import { scheduleOfferedModalComponent } from '../../openshift/schedule-offered/schedule-offered-modal.component';
import { Router } from '@angular/router';
import { interval } from 'rxjs';
import { map } from 'rxjs/operators'
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-event-details',
  templateUrl: './event-details.component.html',
  styleUrls: ['./event-details.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EventDetailsComponent implements OnInit{
  event = {
    event_name: '',
    event_type: '',
    location: '',
    dates: {
      start_date: '',
      end_date: '',
      dates_description: ''
    },
    times: {
      start_time: '',
      end_time: '',
      times_description: ''
    },
    estimated_guests: '',
    estimated_revenue: '',
    confidential_notes: '',
    notes: '',
    scheduleTasks: [],
    // event_sched_start_time: '',
    // event_sched_end_time: '',
    event_sched_amount: 0,
    event_sched_hours: 0,
    sched_dates: {
      start_date: '',
      end_date: '',
      dates_description: ''
    },
    sched_times: {
      start_time: '',
      end_time: '',
      times_description: ''
    },

  };
  options = {
    types: [],
    componentRestrictions: { country: 'USA' }
  };
  hasData = false;
  dataLoaded = false;
  eventAddress: string = '';

  // @ViewChild('placesRef', { static: false }) placesRef: GooglePlaceDirective;
  @ViewChild("dates", { static: false }) dates: DatepickerComponent;
  selectedTeam : any = '';
  wkEndDate: any = '';
  payGrp_id: any = '';
  eventId: any = '';
  userName: any = '';

  public handleAddressChange(address: Address) {
    console.log("Address:"+ address);
    this.eventAddress = address.formatted_address;
    console.log("eventAddress:"+ this.eventAddress);
  }

  toastrMsg: string = '';

  constructor(
    public globals: Globals,
    private modalService: NgbModal,
    public activeModal: NgbActiveModal,
    public commonService: CommonService,
    public scheduleService: EventBaseScheduleService,
    private toastr: ToastrService,
    private route: ActivatedRoute,
    private router: Router
  ) {
  }


  ngOnInit() {
    this.selectedTeam = this.globals.ebsTeamSelected;
    this.wkEndDate = this.globals.ebsWkEndSelected;
    this.payGrp_id = this.globals.ebsPayGrpId;
    this.event = this.globals.ebsEventSelected;
    this.userName = this.globals.user_name;

    this.eventId = this.route.snapshot.paramMap.get('event_id');

    if (this.eventId || this.selectedTeam) this.hasData = true;
    if (this.eventId) {
      //get event info
      this.scheduleService
        //API needs to have some data in the fields other then eventid; hence passing dummy data for dates
        .getEventsById(this.selectedTeam, moment(this.wkEndDate).format("MM/DD/YYYY 00:00"), moment(this.wkEndDate).format("MM/DD/YYYY 23:59"), this.userName, this.eventId)
        .subscribe((resp: any) => {
          console.log('resp --->', resp);
          this.mapData(resp[0]);
          this.dataLoaded = true;
        }, err => {
          console.log('error --->', err);
          this.dataLoaded = false;
        });
    }
  }

  mapData(eventItems) {
    if (eventItems) {
      this.event = {
        event_name: eventItems.event_name,
        event_type: eventItems.event_type,
        location: eventItems.location || '5400 Yorkmount Road, Charlotte, NC - 28217',
        dates: {
          start_date: moment(eventItems.event_start_time).format("MM/DD/YYYY"),
          end_date: moment(eventItems.event_end_time).format("MM/DD/YYYY"),
          dates_description: moment(eventItems.event_start_time).format("MM/DD/YYYY")
        },
        times: {
          start_time: moment(eventItems.event_start_time).format("MM/DD/YYYY hh:mm"),
          end_time: moment(eventItems.event_start_time).format("MM/DD/YYYY hh:mm"),
          times_description: moment(eventItems.event_start_time).format("hh:mm A")+ " - " + moment(eventItems.event_end_time).format("hh:mm A")
        },
        estimated_guests: eventItems.est_guests || 10,
        estimated_revenue: eventItems.event_revenue || '11,000',
        confidential_notes: eventItems.confidential_notes,
        notes: eventItems.event_notes,
        scheduleTasks: [],
        event_sched_amount: eventItems.event_sched_amount,
        event_sched_hours: eventItems.event_sched_hours,
        sched_dates: {
          start_date: moment(eventItems.event_sched_start_time).format("MM/DD/YYYY"),
          end_date: moment(eventItems.event_sched_end_time).format("MM/DD/YYYY"),
          dates_description: moment(eventItems.event_sched_start_time).format("MM/DD/YYYY")
        },
        sched_times: {
          start_time: eventItems.event_sched_start_time,
          end_time: eventItems.event_sched_end_time,
          times_description: eventItems.event_sched_start_time? (moment(eventItems.event_sched_start_time).format("hh:mm A")+ " - " + moment(eventItems.event_sched_end_time).format("hh:mm A")): '',
        },
      };
    }
  }

  update() {
    //Update this Event
    let user_name = this.globals.user_name;
    let payLoad = [];
    //for now, only these fields can be updated
    let eventItem = {
      "event_id": this.eventId,
      "notes": this.event.notes,
      "confidential_notes": this.event.confidential_notes,
      "est_guests": this.event.estimated_guests,
      "est_revenue": this.event.estimated_revenue,
      "event_sched_amount": this.event.event_sched_amount,
      "event_sched_hours": this.event.event_sched_hours
    };
    payLoad.push(eventItem);

    this.scheduleService.updateEvent(user_name, payLoad).subscribe((res: Response) => {
      this.toastrMsg = "Event " + this.event.event_name + " for " + moment(this.event.dates.start_date).format("MM/DD/YYYY") + " is updated! <br/>";
      this.toastr.success(this.toastrMsg,
        'Create Event', {
           enableHtml: true,
           closeButton: true
      });
      setTimeout(() => {
         this.activeModal.close(1)
        }, 3000);
    }, err => {
      console.log('error --->', err);
      _.set('updateEvent', 'status', 'warning');

      this.toastrMsg = "FAILED to update the event! <br/>";
      this.toastr.error(this.toastrMsg,
        'Update Event', {
          enableHtml: true,
          closeButton: true
        });
    })


  }

  goBack(){
    this.router.navigateByUrl('/ebs/events')
  }

  addAssociateModal() {
    console.log('modal');
    const modalRef = this.modalService.open(ScheduleAssociateModalComponent, { backdrop: 'static', size: 'lg', windowClass: 'myCustomModalClass' });
    modalRef.componentInstance.selectedTaskDetail = {};
    modalRef.componentInstance.isTaskSelected = false;
  }

  scheduleOfferedModal(){
    const modalRef = this.modalService.open(scheduleOfferedModalComponent, { backdrop: 'static', size: 'lg', windowClass: 'myCustomModalClass' });
    modalRef.componentInstance.taskDetail = {taskName: 'testing1123'};

  }



}
