import {Component, ViewChild, AfterViewInit, Input, OnInit, ViewEncapsulation} from '@angular/core';
import {Scheduler, WidgetHelper} from 'bryntum-scheduler/scheduler.umd.js';
import * as moment from 'moment';
import { EventBaseScheduleService } from '@staff/shared/common/services/ebs.service';
import {Globals} from "@staff/shared/common/global/global.provider";
import { TeamMultiTypeaheadEbsComponent } from "@staff/shared/team-multi-typeahead-ebs/team-multi-typeahead-ebs.component";
import * as _ from 'lodash';
import {BlockUI, NgBlockUI} from "ng-block-ui";
// import {AddEventComponent} from "../add-event/add-event.component";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { Router } from '@angular/router';

@Component({
  selector: 'app-event-summary',
  templateUrl: './event-summary.component.html',
  styleUrls: ['./event-summary.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EventSummaryComponent implements  AfterViewInit  {
  @ViewChild('teamdropdown', { static: false }) private teamdropdown: TeamMultiTypeaheadEbsComponent;
  @BlockUI() blockUI: NgBlockUI;

  @Input () ifTeamSelected: boolean = false;

  teamComponent: any;
  selectedTeam: any;
  heading: any = 'Event Summary';
  state: string = 'initial';
  maxValue: number = 0;
  isSubmitting: boolean = false;
  scheduler : any;
  weekStartDay: number = 0;  // default to Sunday, will change for paygroup
  startDate : any; endDate: any;
  resources = []; events = [];
  params : any;
  table : any;
  user_name: any;
  wk_ending_date: any = '';
  payGroupId: any = '';
  wk_starting_date: any = '';

  constructor(
    public globals: Globals,
    public scheduleService: EventBaseScheduleService,
    private modalService: NgbModal,
    private router: Router
  ){
    this.getGlobals();
  }

  getEvents() {
    this.getWeeklyEvents(this.selectedTeam, this.wk_starting_date, this.wk_ending_date, this.globals.user_name);
  }

  getWeeklyEvents(team_name, start_date, end_date, user_name){
    this.scheduler.maskBody('<div style="padding: 5px 10px;">Loading...</div>');
    this.resources = []; this.events = [];

    start_date = moment(start_date).format("MM/DD/YYYY 00:00");
    end_date   = moment(end_date).format("MM/DD/YYYY 23:59");

    this.scheduleService
      .getEvents(team_name, start_date, end_date, user_name)
      .subscribe((resp: any) => {
        this.mapData(resp);
        this.scheduler.unmaskBody();
      }, err => {
        console.log('error --->', err);
        this.mapData([[]]);
        this.scheduler.unmaskBody();
      });
  }

  mapData(eventItems) {
    this.events = []; this.resources=[];
    if (eventItems) {
      eventItems.map(eveItem => {
        let event = {
          id: eveItem.event_id,
          resourceId: 1,
          name: eveItem.event_name,
          startDate: moment(eveItem.event_start_time).format("YYYY-MM-DD 00:15:00"),
          endDate: moment(eveItem.event_end_time).format("YYYY-MM-DD 23:57:00"),   //.add(1,'days')
          startTime: moment(eveItem.event_start_time).format("hh:mm A"),
          endTime: moment(eveItem.event_end_time).format("hh:mm A"),
          // total: eveItem.event_open_shifts + eveItem.event_filled_shifts,
          total: eveItem.event_open_shifts? eveItem.event_open_shifts:0,
          scheduled: eveItem.event_filled_shifts?eveItem.event_filled_shifts:0,
          totHrs: eveItem.event_sched_hours? eveItem.event_sched_hours:0,
          // totAmt: eveItem.event_sched_amount?eveItem.event_sched_amount.toLocaleString('en-US', {maximumFractionDigits:2,style: 'currency', currency: 'USD'}):0,
          totAmt: eveItem.event_sched_amount?eveItem.event_sched_amount.toLocaleString('en-US', {maximumFractionDigits:2}):0,
          //cls: eveItem.unscheduled == 0 ? "ebs-event-filled" : eveItem.scheduled == 0 ? 'ebs-event-draft' : 'ebs-event-partial',
          cls: eveItem.event_status === 'Draft'? 'ebs-event-draft' : eveItem.event_filled_shifts>=eveItem.event_open_shifts ? 'ebs-event-filled' : 'ebs-event-partial',
          desc: eveItem.event_name,
          // notes: (eveItem.notes == null ? '' : eveItem.notes),
          // iconCls: "b-fa",
          resizable: false,
          draggable: false,
          status: (eveItem.status === 'Draft' ? 'Draft' : ''),
          data: eveItem
        };
        this.events.push(event);
      });
    }

    // this.scheduler.zoomToLevel('dayAndWeek', { zoomLevel: 12 });
    let resource = {
      id: 1,
      name: this.selectedTeam,
      events: []
    };
    this.resources.push(resource);
    this.resources = _.sortBy(this.resources, function(resource) {
      return resource.name;
    });
    this.scheduler.resources = this.resources;
    if (this.events.length >0) this.scheduler.events= this.events;
    this.scheduler.startDate = this.startDate.toDate();
    this.scheduler.endDate = this.endDate.toDate();
    this.scheduler.weekStartDay = this.weekStartDay;

    this.scheduler.unmaskBody();
    // this.refreshStartDay();
  }

  ngAfterViewInit() {
    this.setScheduler();
    this.getEvents();
  }

  setScheduler () {
    this.startDate = moment(this.wk_starting_date, 'MM-DD-YYYY');
    this.endDate = moment(this.wk_ending_date, 'MM-DD-YYYY').add(1, 'days').subtract(1, 'milliseconds');
    //
    // this.startDate = moment(this.wk_starting_date,'MM-DD-YYYY 00:00');
    // this.endDate = moment(this.wk_ending_date,'MM-DD-YYYY 23:59');

    // this.startDate = moment(this.wk_starting_date).add(0, 'days').format('MM-DD-YYYY 00:00');
    // this.endDate = moment(this.wk_ending_date).add(1, 'days').format('MM-DD-YYYY 23:59');


    let scheduler = new Scheduler({
      adopt      : 'container',
      rowHeight  : 100,
      // barMargin  : 5,
      weekStartDay: this.weekStartDay,
      startDate  : this.startDate.toDate(),
      endDate    : this.endDate.toDate(),
      // eventStyle : 'line',
      height     :  'calc(100vh - 200px)',
      mode       : 'horizontal',
      autoAdjustTimeAxis : true,
      zoomOnTimeAxisDoubleClick: false,
      zoomOnMouseWheel: false,
      readOnly   : true,
      //viewPreset : 'dayAndWeek',
      viewPreset : {
        base       : 'dayAndWeek',
        timeResolution: {
          unit: 'minute',
          increment: 15,
        },
        headers    : [
          {
            unit: 'day',
            dateFormat : 'ddd MM/DD'
          },
        ]
      },
      features : {
        filterBar  : true,
        timeRanges : {
          enableResizing      : true,
          showCurrentTimeLine : false,
          showHeaderElements  : true
        },
        headerContextMenu : {
          // Remove all right-click menu items before menu is shown
          processItems({ items }) {
            items.length = 0;
          }
        },
        eventResize : false,
        eventDrag: false

      },
      columns : [],
      events : this.events,
      resources : this.resources,
      eventRenderer : ({ eventRecord, resourceRecord, tplData}) => {
        {
          return `<div class="ebs-event-info">
                    <div class="ebs-event-name">${eventRecord.name}</div>
                    <div>Filled Shifts: ${eventRecord.scheduled}/${eventRecord.total}</div>
                    <div>${eventRecord.startTime} - ${eventRecord.endTime}</div>
                    <div>Hrs: ${eventRecord.totHrs}   $: ${eventRecord.totAmt}</div>
                </div> `
        }
      },
    });
    this.scheduler = scheduler;
    let _this = this;
    this.scheduler.on('eventclick', function (sch, event) {
      _this.globals.ebsEventSelected = sch.eventRecord.data.data;
      _this.router.navigateByUrl('/ebs/events/details/'+sch.eventRecord.data.data.event_id);
    });
  }

  getGlobals(){
    this.payGroupId = this.globals.ebsPayGrpId;
    this.selectedTeam = this.globals.ebsTeamSelected;
    if (!this.globals.ebsWkStartSelected) {
      this.wk_starting_date = moment().format("MM/DD/YYYY");
    } else {
      this.wk_starting_date = this.globals.ebsWkStartSelected;
    }
    if (!this.globals.ebsWkEndSelected) {
      this.wk_ending_date = moment().add(6, 'days').format("MM/DD/YYYY")
    } else {
      this.wk_ending_date = this.globals.ebsWkEndSelected;}
  }

  addEvent(){
    this.router.navigateByUrl('/ebs/events/add');
  }
}


