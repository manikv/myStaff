import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PtoHistoryComponent } from './pto-history/pto-history.component';

const routes: Routes = [
  {
    path: 'history',
    component: PtoHistoryComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PtoRoutingModule { }
