import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PtoRoutingModule } from './pto-routing.module';
import { PtoHistoryComponent } from './pto-history/pto-history.component';
import { PtoService } from '../shared/common/services/pto.service';
import { ScheduleService } from '../shared/common/services/schedule.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import 'ag-grid-community';
import 'ag-grid-enterprise';
import { AgGridModule } from 'ag-grid-angular';
import { LicenseManager } from "ag-grid-enterprise";
LicenseManager.setLicenseKey("SoftwareONE_USA_on_behalf_of_Compass_Group_USA_MultiApp_5Devs_5Deployment_12_August_2020__MTU5NzE4NjgwMDAwMA==de1432ef47c510c631b782c11ab2920d");
import { BlockUIModule } from 'ng-block-ui';
import { timeoffDetailsComponent, ConfirmationModalComponent } from "./pto-details/pto-details.component";
import {FormsModule} from "@angular/forms";
import { TeamMultiTypeaheadModule, AssociateMultiTypeheadModule  } from '@staff/sharedModules/index';
import { DatepickerModule } from '../shared/common/components/datepicker/datepicker.module';
import { ReportingCommonService } from '../reporting/common/reporting.common.service';

@NgModule({
  entryComponents: [
    timeoffDetailsComponent,
    ConfirmationModalComponent,
    PtoHistoryComponent
  ],
  declarations: [
    PtoHistoryComponent,
    timeoffDetailsComponent,
    ConfirmationModalComponent
  ],
  imports: [
    CommonModule,
    PtoRoutingModule,
    NgbModule,
    TeamMultiTypeaheadModule,
    AssociateMultiTypeheadModule,
    DatepickerModule,
    BlockUIModule.forRoot(),
    AgGridModule.withComponents(),
    FormsModule

  ],
  exports: [
    timeoffDetailsComponent,
    PtoHistoryComponent,
    ConfirmationModalComponent
  ],
  providers: [
    PtoService,
    ScheduleService,
    ReportingCommonService
  ]
})
export class PtoModule { }
