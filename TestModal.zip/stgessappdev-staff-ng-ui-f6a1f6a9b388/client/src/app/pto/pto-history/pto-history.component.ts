import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { trigger, state, style, animate, transition, query } from '@angular/animations';
import * as excelStyles from '../../reporting/common/excelStyles/excelStyles';
import { ReportingCommonService } from '../../reporting/common/reporting.common.service';
import { ToastrService } from 'ngx-toastr';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as _ from 'lodash';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Globals } from '../../shared/common/global/global.provider';
import { CommonService } from '../../shared/common/services/common.service';
import { TeamMultiTypeaheadComponent } from '../../shared/team-multi-typeahead/team-multi-typeahead.component';
import { PtoService } from '../../shared/common/services/pto.service';
import * as moment from 'moment';
import { timeoffDetailsComponent } from '../pto-details/pto-details.component';
import { format } from 'date-fns'
import { DatePickerModel } from '../../shared/common/components/datepicker/datepicker.component';

@Component({
  selector: 'app-pto-history',
  templateUrl: './pto-history.component.html',
  styleUrls: ['./pto-history.component.scss'],
  animations: [
    trigger('smoothCollapse', [
      state('initial', style({
        height: '0',
        opacity: '0',
        overflow: 'hidden',
        padding: '5px'
      })),
      state('final', style({
        opacity: '1'
      })),
      transition('initial=>final', animate('150ms')),
      transition('final=>initial', animate('150ms'))
    ])],
  encapsulation: ViewEncapsulation.None
})
export class PtoHistoryComponent implements OnInit {
  @ViewChild('teamdropdown') private teamdropdown: TeamMultiTypeaheadComponent;
  @BlockUI() blockUI: NgBlockUI;

  teamComponent: any;
  associeteComponent: any;
  startDateModel: DatePickerModel = {id:'PTOH-start-date',required:true,validFormat:true, maxDate: null, errorText: 'start date'};
  endDateModel: DatePickerModel = {id:'PTOH-end-date',required:true,validFormat:true, minDate: null, errorText: 'end date'};

  isCollapsed: boolean = false;
  selectedTeam: any;
  selectedOverrideType: any = [];
  date: any;
  heading: any = 'Time Off Requests - History'
  paginationPageSize = 20;
  xlsStyles = excelStyles.EXCEL_STYLES;
  massUrl = '/api/associate/setup';
  setEmployeeOverridesUrl = '/ui/api/employees/overrides';
  timesheetRowData = [];
  width = '100%';
  height = 'calc(100vh - 200px)';
  rowSelection = "single";
  selectedAssociates = [];
  context;
  gridApi: any;
  gridColumnApi: any;
  gridloaded: boolean = true;
  headerCount: number;
  state: string = 'initial';
  helpContent = [];
  helpContentShow: boolean = false;
  maxValue: number = 0;
  hasError: boolean = false;
  intialLoad: boolean = true;
  subteam: boolean = false;

  timesheetHeader: any = [
    {
      headerName: 'Full name',
      field: 'emp_fullname',
      resizable: true,
      hide: true,
      rowGroup: true,
      cellClass: "allCell"
    },
    {
      headerName: 'Balance Type',
      field: 'balance_name',
      resizable: true,
      filter: "agTextColumnFilter",
      suppressMenu: true,
      cellClass: "allCell"
    },
    {
      headerName: 'Date of Request',
      field: 'tor_created_date',
      resizable: true,
      filter: "agTextColumnFilter",
      suppressMenu: true,
      cellClass: "allCell"
    },
    {
      headerName: 'Status',
      field: 'toa_status',
      resizable: true,
      filter: "agTextColumnFilter",
      suppressMenu: true,
      rowGroup: true,
      cellClass: "allCell"
    },
    {
      headerName: 'Time Off Date Range',
      resizable: true,
      field: 'dates',
      cellClass: "allCell"
    },
    {
      headerName: 'Total Time Off Requested',
      field: 'reqDaysHrs',
      resizable: true,
      cellClass: "allCell"
    },
    {
      headerName: 'Associate Comments',
      field: 'tor_comment',
      resizable: true,
      filter: "agTextColumnFilter",
      suppressMenu: true,
      cellClass: "allCell"
    },
    {
      headerName: 'Manager Comments',
      field: 'toa_comment',
      resizable: true,
      filter: "agTextColumnFilter",
      suppressMenu: true,
      cellClass: "allCell"
    },
  ];
  frameworkComponents;
  overrideType = '';
  defaultValue = '0';
  isSubmitting: boolean = false;

  timesheetGridOptions: any = {
    defaultColDef: {
      sortable: true,
      resizable: true
    },
    copyHeadersToClipboard: true,
    suppressMaxRenderedRowRestriction:true,
    suppressColumnVirtualisation:true,
    groupDefaultExpanded: -1,
    rowBuffer: 9999,
    floatingFilter: true,
    excelStyles: excelStyles.EXCEL_STYLES,
    processCellCallback : this.reportingCommonService.getExcelFormatting,
    autoGroupColumnDef: {
      width: 200,
      headerName: 'Name',
      cellRenderer:'agGroupCellRenderer',
      field: 'emp_fullname',
      cellClass: "allCell",
      cellRendererParams: {
        suppressCount: true
      },
      pinned: "left",
      filter: "agTextColumnFilter",
      suppressMenu: true
    }
  };
  isloaded = false;

  constructor(
    private toastr: ToastrService,
    private modalService: NgbModal,
    public globals: Globals,
    private ptoService: PtoService,
    public commonService: CommonService,
    private reportingCommonService: ReportingCommonService
  ) {

  }

  onBtnExport() {
    var params: any = {
      allColumns: false,
      columnGroups: false,
      exportMode: "xlsx",
      fileName: this.heading,
      selectAll: true,
      onlySelected: false,
      sheetName: this.heading,
      skipFooters: false,
      skipGroups: false,
      skipHeader: false,
      skipPinnedBottom: false,
      skipPinnedTop: false,
      // processCellCallback : this.reportingCommonService.getExcelFormatting,
      customHeader: this.generateCustomHeader()
    }
    this.onPageSizeChanged(this.gridApi.paginationGetTotalPages()*this.gridApi.paginationGetRowCount());
    this.gridApi.exportDataAsExcel(params);
    this.onPageSizeChanged(this.paginationPageSize);
  }

  generateCustomHeader(){
    let initHeader = [
      [],
      [
        {
          styleId: "staffHeader",
          data: {
            type: "String",
            value: "MY STAFF REPORTS"
          },
          mergeAcross: 2
        },
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: "Run by "+ this.globals.rbacProfile.user_name
          }
        }
      ],
      [
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: this.heading
          },
          mergeAcross: 2
        },
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: "Run at " +format(new Date(), 'MM/DD/YYYY HH:mm a')
          }
        }
      ],
      []
    ];
    //this.buildParamterDataExcel(initHeader);
    return initHeader;
  }

  buildParamterDataExcel(initHeader){
    let headers: any = [];
    this.timesheetHeader.map((para: any) => {
      if(para.headerName){
        headers.push({
          styleId: "pageHeader",
          data: {
            type: "String",
            value: para.headerName
          }
        });
      }
    })
    initHeader.push(headers);
    initHeader.push([]);
  }

  selectedAssociate($event){
    this.teamComponent = undefined;
    setTimeout(() => {
      this.associeteComponent = $event;
    }, 100);
  }

  selectTeam($event){
    this.associeteComponent = undefined;
    setTimeout(() => {
      this.teamComponent = $event;
    }, 100);
  }

  onPageSizeChanged(newPageSize) {
    this.gridApi.paginationSetPageSize(Number(newPageSize));
  }


  ngOnInit() {
    this.headerCount = this.timesheetHeader.length;
    let team_name = this.globals.staffProfile.home_team;
  }

  onSelectionChanged($event){
    var selectedRows = this.gridApi.getSelectedRows();
    this.timoffDetailsModalOpen(selectedRows)
  }

  timoffDetailsModalOpen(filteredList) {
    let modalRef = this.modalService.open(timeoffDetailsComponent, { backdrop: "static", size: 'lg' });
    modalRef.componentInstance.timeoffDetail = filteredList;
    modalRef.result.then((result) => {
      if (result) {
        // console.log(result);
        //  if (result == 1) {
        //    this.getTimeoffRequests();  //reset the list in HomePage
        //  }
      }
    });
  }

  private setRowData() {
    this.isloaded = false;
    this.timesheetRowData = [];
    const team_name: any = this.teamComponent != null ? this.teamComponent.team_name : this.associeteComponent.team_name;
    Promise.all([
      this.loadAssociates('', team_name)
    ]).then(resp => {
      // console.log('response all', this.timesheetRowData);
      this.isloaded = true;
    });
  }

  changeParameter(value, parameterKey) {
    switch (parameterKey) {
      case 'selectedTeam':
        this.selectedTeam = value;
        break;
    }
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }

  setHelpContentIntial() {
    this.helpContent = [
      {
        content: 'Select Team, Override type and Date',
        end: true,
        top: '145px',
        left: '20%'
      },
      {
        content: 'Load Associates',
        end: true,
        top: '145px',
        left: '60%'
      }
    ];
    this.helpContentShow = true;
  }

  formValid() {
    return this.selectedTeam !== undefined && this.selectedOverrideType !== undefined && this.commonService.validateDateFormatTyped(this.date) && this.date !== null
  }

  loadAssociates(approvalStatus, team_name) {
    let   user_name = this.globals.user_name;

    console.log ("subteam:"+ this.subteam);

    return new Promise((resolve, reject) => {
      this.ptoService.getUserTimeoffRequest(user_name, team_name, approvalStatus, this.subteam).subscribe(data => {
        let grpbytorid = data.reduce(function (rv, x) {
          (rv[x['tor_id']] = rv[x['tor_id']] || []).push(x);
          return rv;
        }, {});
        let sstartDay = this.startDateModel.value ? new Date(this.startDateModel.value .year, this.startDateModel.value .month - 1 , this.startDateModel.value .day) : null;
        let eendDay = this.endDateModel.value ? new Date(this.endDateModel.value .year, this.endDateModel.value .month - 1 , this.endDateModel.value .day) : null;
        const emp_id = this.associeteComponent != null ? this.associeteComponent.emp_id : false;

        let startDay = moment(sstartDay).format("MM/DD/YYYY");
        let endDay = moment(eendDay).format("MM/DD/YYYY");

        for (let key in grpbytorid) {
          const startDate =  ( grpbytorid[key].length > 1 ? moment(grpbytorid[key][0]['tod_start_time']).format("MMM D") : moment(grpbytorid[key][0]['tod_start_time']).format("MMM D, YYYY") );
          const endDate = ( grpbytorid[key].length > 1 ? ' - ' + moment(grpbytorid[key][grpbytorid[key].length-1]['tod_end_time']).format("MMM D, YYYY") : '' );
          if (moment(startDay).isAfter(moment(grpbytorid[key][0]['tod_start_time']).format("MM/DD/YYYY"))) {
            continue;
          }
          if (moment(moment(grpbytorid[key][0]['tod_end_time']).format("MM/DD/YYYY")).isAfter(endDay)) {
            continue;
          }
          if(emp_id && emp_id != grpbytorid[key][0]['emp_id']){
            continue;
          }
          let totDays = 0, totHrs = 0, tor_days=[],
            req_toff_type = grpbytorid[key][0]['balance_type'];
          let availDaysHrs = 0;

          grpbytorid[key].map(record => {
            let diff;
            if (req_toff_type === 'DAYS') {
              if (record.tod_day_type === "FD") {
                totDays += 1;
                record.requestedDays = 1;
              } else {
                totDays += .5;
                record.requestedDays = .5;
              }
              record.toff_type = "Day";
            } else {
              let startTime = moment(record.tod_start_time),
                endTime = moment(record.tod_end_time);
              diff = moment.duration(endTime.diff(startTime));
              totHrs =  Math.round((diff.asHours() + totHrs) * 10) / 10;
              record.tot_type = "Hours";
              record.totHrs = Math.round((diff.asHours()) * 10) / 10 + ' Hours';
            }
            record.day_formatted = moment(record.tod_date).format("ddd, MMM");
            record.date_formatted = moment(record.tod_date).format("Do");
            tor_days.push(record);
          });

          this.timesheetRowData.push({
            wbu_id: grpbytorid[key][0]['wbu_id'],
            toa_is_approved: grpbytorid[key][0]['toa_is_approved'],
            toa_comment: grpbytorid[key][0]['toa_comment'],
            override_id: Number(grpbytorid[key][0]['override_Id']),
            tod_id: grpbytorid[key][0]['tod_id'],
            tod_date: grpbytorid[key][0]['tod_date'],
            tor_start_time: grpbytorid[key][0]['tor_start_time'],
            tor_end_time: grpbytorid[key][0]['tor_end_time'],
            tcode_id: Number(grpbytorid[key][0]['tcode_id']),
            tor_id: grpbytorid[key][0]['tor_id'],
            tofftyp_id: grpbytorid[key][0]['tofftyp_id'],
            emp_fullname: grpbytorid[key][0]['emp_fullname'],
            emp_name: grpbytorid[key][0]['emp_name'],
            emp_id: grpbytorid[key][0]['emp_id'],
            toff_start_date: startDate,
            toff_end_date: endDate,
            reqDaysHrs: (req_toff_type === 'DAYS' ? (totDays.toString() + (totDays>1?' Days':' Day')) : totHrs + ' Hours'),
            availableDays: availDaysHrs,
            dates:  startDate + endDate,
            tofftyp_name: grpbytorid[key][0]['tofftyp_name'],
            tor_comment: grpbytorid[key][0]['tor_comment'],
            toa_status: grpbytorid[key][0]['toa_status'],
            balance_name: grpbytorid[key][0]['balance_name'],
            tor_created_date: moment(grpbytorid[key][0]['tor_created_date']).format('MM/DD/YYYY'),
            tordays: tor_days,
            team_name: grpbytorid[key][0]['wbt_name']
          })
        }
        resolve(true);
      }, err => {
        reject(err);
      });
    });
  }

}
