import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PtoHistoryComponent } from './pto-history.component';

describe('PtoHistoryComponent', () => {
  let component: PtoHistoryComponent;
  let fixture: ComponentFixture<PtoHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PtoHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PtoHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
