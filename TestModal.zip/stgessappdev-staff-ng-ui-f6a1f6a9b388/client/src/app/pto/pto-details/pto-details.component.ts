import { Component , OnInit, Input } from '@angular/core';
import { NgbActiveModal, NgbModal} from "@ng-bootstrap/ng-bootstrap";
import { ScheduleService } from '../../shared/common/services/schedule.service';
import { PtoService } from '../../shared/common/services/pto.service';
import * as _ from 'lodash';
import * as moment from 'moment';
import { Globals } from '../../shared/common/global/global.provider';
import {Observable} from "rxjs";
import {Observer} from "rxjs/internal/types";
import { BurstService } from '../../shared/common/services/burst.service';
import { NotificationService } from '../../shared/common/services/notification.service';


@Component({
  selector: '.page-pto-details',
  templateUrl: 'pto-details.component.html',
  styleUrls: ['pto-details.component.scss']
})

export class timeoffDetailsComponent implements OnInit {
  @Input() public timeoffDetail;

  items = [];
  schedule_conflicts = [];
  //deleteShift: Array<boolean> = [];
  //burstShift: Array<boolean> = [];
  approvedUsersList: Array<any> = [];
  approvedUserColors: any = ['#FCD0C5', '#FCEFC5', '#E8FCC5', '#C5FCEF', '#C5F2FC', '#EBC5FC', '#FCC5DA', '#CFC5FC', '#C5FCCA', '#EAC5FC'];
  days: Array<any> = [];

  removeScheduleList: Array<any> = [];
  isApproveDisable = false;

  approve = 'Approve';
  manager = '';

  reqDate = '';

  constructor(
    public activeModal: NgbActiveModal,
    private modalService: NgbModal,
    private scheduleService: ScheduleService,
    private ptoService: PtoService,
    private globals: Globals,
    private burstService: BurstService,
    private notificationService: NotificationService
  ) {}

  ngOnInit() {

    this.manager = this.globals.staffProfile.last_name + ', ' + this.globals.staffProfile.first_name;
    this.ptoRequestStatus('','',true);
    this.getTimeoffBalances();
    if(this.timeoffDetail[0]['toa_status'] === 'PENDING'){
      this.getApprovedUsers();
    }
    this.removeSchedule();
  }

  getTimeoffBalances() {
    let availDaysHrsNum = 0;
    let availDaysHrsStr = '';
    this.ptoService.getUserBalances(String(this.timeoffDetail[0]['emp_name']))
      .subscribe(res => {
          for (const rec of res) {
            availDaysHrsNum = (this.timeoffDetail[0].tordays[0]['balance_id'] == rec['balance_id']) ? rec['balance_value'] : availDaysHrsNum
          }
        availDaysHrsStr =  (Math.round((availDaysHrsNum) * 100) / 100).toFixed(2);

        this.timeoffDetail[0].availableBalance = (this.timeoffDetail[0].tordays[0].balance_type==='DAYS'? availDaysHrsStr+' Days' : availDaysHrsStr+' Hours');

        }
      );
    this.items = this.timeoffDetail[0].tordays;
    this.items.map((day, index)=>{
      this.items[index].tod_date = moment(day.tod_date).format('MM/DD/YYYY');
      this.items[index].formatted_tod_start_time = moment(day.tod_start_time).format('MM/DD hh:mm a');
      this.items[index].formatted_tod_end_time = moment(day.tod_end_time).format('MM/DD  hh:mm a');
      this.days.push(moment(day.tod_end_time).format('MMM DD'));
    });

    this.items.map(day=>{
      this.scheduleService.getDailySchedule(day.emp_name, day.tod_date).
      subscribe((data:any) => {
        if (data.length>0) {
          data.map((schconf, index) => {
              let schconfshifts = schconf.shifts;
              schconfshifts.map((shft)=> {
                this.schedule_conflicts.push({
                  date: moment(schconf.scheduled_date).format('MM/DD'),
                  start: moment(shft.start).format('hh:mm a'),
                  end: moment(shft.end).format('hh:mm a'),
                  raw_data: [data[index]],
                  remove: false,
                  createBooking: false,
                  project_id: shft.project_id
                })
              })
          });
        }
      });
    });
  }

  getApprovedUsers() {
    this.approvedUsersList = [];
    let   user_name = this.globals.user_name,
          team_name = String(this.timeoffDetail[0]['team_name']),
          approvalStatus = 'APPROVED'

    this.ptoService.getUserTimeoffRequest(user_name, team_name, approvalStatus)
      .subscribe(
        (data:any)  => {
          for (const rec of data) {
              let dt: any = moment(rec.tod_end_time).format('MMM DD');
              if (this.days.includes(dt)) {

                const item = this.approvedUsersList.find((x: any) => x.day = dt );
                const row = {
                  "name": rec.emp_fullname,
                  "date": moment(rec.tod_end_time).format('MM/DD/YY'),
                  "backgroundColor": this.approvedUserColors[Math.floor(Math.random()*this.approvedUserColors.length)]
                };

                if(item) {
                  item.details.push(row)
                } else {
                  this.approvedUsersList.push({
                    day: dt,
                    details: [row]
                  })
                }
              }
          }
        },
        err => {
          console.log(err)
        },
      );


  }

  showCommentInput() {
    let modalRef = this.modalService.open(ConfirmationModalComponent, { backdrop: 'static', size: 'lg', backdropClass: 'darker-backdrop' });
    modalRef.componentInstance.managerResponseType = 'Decline';
    modalRef.result.then((result) => {
      console.log("Result:"+ result);
      if (!result) {
         //comment is blank; do nothing
         } else if (result === 'cancel') {
         //cancel button clicked; do nothing
       } else {
        //comment entered
        let validate = false;
        this.ptoRequestStatus('Decline', result, validate);
        this.activeModal.close(1)
      }
    })

  }

  managerResponse(response) {
    // //this.ptoRequestStatus(response);
    // let modalRef = this.modalService.open(ConfirmationModalComponent, { backdrop: 'static', size: 'sm', backdropClass: 'darker-backdrop' });
    // modalRef.componentInstance.managerResponseType = response;
    // modalRef.result.then((result) => {
    //   //answered No; don't do anything
    //   }, (reason) => {
    //   //update the db
    //   this.ptoRequestStatus(response)
    //   this.activeModal.close(1)
    //   });
    this.ptoRequestStatus(response, '', false)
  }

  ptoRequestStatus(approvalStatus, managerComment, validate) {
    let tmpDet = [], stat: string ='';

    if (!approvalStatus) {
      stat=''
    } else {
      stat = (approvalStatus === this.approve ? 'Y' : 'N');
    }

    this.reqDate = moment(this.timeoffDetail[0].tor_created_date).format("MMM DD, YYYY");

    let timeoffItem = {
      wbu_id:  this.timeoffDetail[0].wbu_id,
      toa_is_approved: stat,
      toa_comment: managerComment,
      request_emp_id:  this.timeoffDetail[0].emp_id,
      override_typ_id:  this.timeoffDetail[0].override_id,
      time_off_details : []
    };
    let tordays = this.timeoffDetail[0].tordays;
    tordays.map(record => {
        tmpDet.push({
          tod_id: record['tod_id'],
          tor_id: record['tor_id'],
          tod_date: moment(record['tod_date']).format('YYYY-MM-DD'),
          tod_start_time: record['tod_start_time'],
          tod_end_time: record['tod_end_time'],
          tcode_id: record['tcode_id']
        });
      });
    timeoffItem.time_off_details = tmpDet;

    this.setTimeoffApproval(timeoffItem, validate, approvalStatus);

  }

  setTimeoffApproval(timeoffItem, validate, approvalStatus) {
    this.ptoService.setTimeoffApproval(this.globals.user_name, timeoffItem, validate)
      .subscribe((res: Response) => {
        if (res['error'].length > 0) {
          this.isApproveDisable = true;
          this.setErrors(res['error'])
        }else if (!validate) {
          this.createBooking();
          (approvalStatus === this.approve ) ? this.removeSchedule() : '';
          if (approvalStatus === this.approve ) {
            var comment = "Time Off Request APPROVED by " + this.globals.staffProfile.last_name + ', ' + this.globals.staffProfile.first_name + " for " + this.timeoffDetail[0].balance_name + " " + this.timeoffDetail[0].dates;
            this.createNotification(comment, 'APPROVED')
          } else {
            var comment = "Time Off Request DECLINED by " + this.globals.staffProfile.last_name + ', ' + this.globals.staffProfile.first_name + " for " + this.timeoffDetail[0].balance_name + " " + this.timeoffDetail[0].dates;
            this.createNotification(comment, 'DECLINED')
          }
          this.activeModal.close(1)
        }
      }, err => {
        console.log('error --->', err);
        _.set(timeoffItem, 'status', 'warning');
      })
  }

  setErrors(errors) {
    errors.map((error) => {
      this.items.map((item) => {
        if(moment(item.tod_date).format("MM/DD/YYYY") === moment(error.date).format("MM/DD/YYYY")){
          item.error = error.message
        }
      });
    });
  }

  removeSchedule(){
    for (const item of this.removeScheduleList) {
      this.scheduleService.deleteSchedule(item.personnel_number, moment(item.scheduled_date.split(' ')[0]).format('MM/DD/YYYY'), item).subscribe(resp => {
        console.log('response ->', resp);
      });
    }
  }

  addItemToRemoveSchedule(item){
    const data = item.raw_data[0];
    const schedule = this.removeScheduleList.find(x => x.id == data.id);
    if (schedule) {
      if(schedule.shifts.length>1){
        data.shifts.map(shift=>{if(shift.project_id==item.project_id){shift.delete_shift = item.remove}});
      }else{
        const index = this.removeScheduleList.indexOf(schedule);
        this.removeScheduleList.splice(index, 1);
      }
    } else {
      data.shifts.map(shift=>{if(shift.project_id==item.project_id){shift.delete_shift = true}});
      this.removeScheduleList.push(data);
    }
  }

  createNotification(msg, status) {
    const payload = {
      "application_name" : "Time Off",
      "category":"APPLICATION",
      "actionable":true,
      "subject": status,
      "body": msg, // + " for user " + this.timeoffDetail[0].emp_fullname,
      "source_reference":"",
      "type":'Request',
      "start_time": moment().format(),
      "end_time":  moment(this.timeoffDetail[0].tod_date).format(),
      "user_name": this.timeoffDetail[0].emp_name,
      "priority": "1",
    }


    this.notificationService.createNotification(payload)
      .subscribe((res: Response) => {
        console.log(res);

      }, err => {
        console.log('error --->', err);
        _.set("", 'status', 'warning');
      })


  }


  createBooking() {
    this.schedule_conflicts.map(dat => {
      if(dat.createBooking){
        this.createBurst(dat).subscribe(
          res => {
            //this.successToast('Burst Created for ' + moment(dat.scheduled_date).format('MM/DD/YYYY'));
            console.log('Burst Created for ' + moment(dat.scheduled_date).format('MM/DD/YYYY'));
          },
          error => {
            //this.errorToast('Error! Burst Creation for ' + moment(dat.scheduled_date).format('MM/DD/YYYY') + ' failed!');
            console.log('Error! Burst Creation for ' + moment(dat.scheduled_date).format('MM/DD/YYYY') + ' failed!');
          });
      }
    });
  }

  // createBooking() {
  //   this.burstShift.map((flag, i) => {
  //     if (flag) {
  //       this.schedule_conflicts[i].raw_data.map(dat => {
  //         this.createBurst(dat).subscribe(
  //           res => {
  //             //this.successToast('Burst Created for ' + moment(dat.scheduled_date).format('MM/DD/YYYY'));
  //           },
  //           error => {
  //             //this.errorToast('Error! Burst Creation for ' + moment(dat.scheduled_date).format('MM/DD/YYYY') + ' failed!');
  //           });
  //       });
  //     }
  //   });
  // }

  createBurst(burstData: any) {
    burstData.user_name = this.globals.rbacProfile.user_name;
    return new Observable((observer: Observer<any>) => {
      let data = {
        burst_to_days: [moment(burstData.raw_data[0].scheduled_date).format('MM/DD/YYYY')],
        total_positions: 1,
        paygroup_id: this.globals.staffProfile.paygroup_id,
        burst_name: burstData.raw_data[0].shifts[0].task_name + ' - Booking',
        tasks: [{
          task_start_time: moment(burstData.raw_data[0].shifts[0].start).format('YYYY-MM-DD HH:mm'),
          task_end_time: moment(burstData.raw_data[0].shifts[0].end).format('YYYY-MM-DD HH:mm'),
          break_start_time: moment(burstData.raw_data[0].shifts[0].break_start).format('YYYY-MM-DD HH:mm'),
          break_end_time: moment(burstData.raw_data[0].shifts[0].break_end).format('YYYY-MM-DD HH:mm'),
          category_id: null,
          task_id: burstData.raw_data[0].shifts[0].task_id,
          rate: "",
          name: burstData.raw_data[0].shifts[0].task_name,
          positions: []
        }],
        team_name: burstData.wbt_id,
        is_district: true,
        is_pool: true,
        is_team: true,
        burst_radius: 30,
        comments: ""
      };
      this.burstService.creatBurst(data).subscribe(
        result => {
          this.burstService.createBurstTasks(result['data']).subscribe(
            burstTaskRes => {
              burstTaskRes['data'].map((burstTaskAssRes, i) => {
                this.burstService.createBurstAssigments([burstTaskAssRes]).subscribe(
                  burstAssignmentsRes => {
                    if (i === (burstTaskRes['data'].length - 1)) {
                      observer.next(true);
                      observer.complete();
                    }
                    this.burstService.updateManagerShiftBurst(burstTaskAssRes.burst_id, "Published").subscribe(burstassRes => { });
                  });
              });
            }, error => {
              observer.error(error);
              observer.complete();
            });
        },
        error => {
          observer.error(error);
          observer.complete();
        }
      );
    });
  }

  passBack() {
    //this.activeModal.dismiss('Cross click')
    this.activeModal.close(0);
  }

}

@Component({
  template: `
      <div class="modal-header">
        <div class="row row-border-end ml-1 pb-2 pt-2">
          <h5 class="modal-title" id="modal-basic-title">Enter the reason for declining:</h5>
        </div>

      </div>
      <div class="modal-body">
        <div class="input-group-lg">
          <label class="font-bold font-italic text-secondary">Max {{maxChar}} characters long</label>
          <textarea type="text" [(ngModel)]="managerComment" class="form-control" maxlength={{maxChar}}  > </textarea>
          <span *ngIf="managerComment"  class="pull-left char font-bold font-italic text-secondary">{{ maxChar-managerComment.length }} characters left</span>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-primary" (click)="passBack()" type="submit">Submit</button>
        <button type="button" class="btn btn-secondary" (click)="activeModal.close('cancel')">Cancel</button>
      </div>
  `
})
export class ConfirmationModalComponent implements OnInit {
  @Input() public managerResponseType;
  public managerComment;
   maxChar:Number = 150;

  constructor(public activeModal: NgbActiveModal) {  }

  ngOnInit(): void {
    //console.log("managerResponseType:"+ this.managerResponseType)
  }

  passBack() {
    this.activeModal.close(this.managerComment);
  }
}


// @Component({
//   template: `
//       <div class="modal-body">
//         <div *ngIf="managerResponseType=='Approve'">
//           <p>Are you sure you want to APPROVE ?</p>
//         </div>
//         <div *ngIf="managerResponseType=='Decline'">
//           <p>Are you sure you want to DECLINE ?</p>
//         </div>
//       </div>
//       <div class="modal-footer">
//         <button type="button" class="btn btn-primary" (click)="activeModal.dismiss('yes')">Yes</button>
//         <button type="button" class="btn btn-secondary" (click)="activeModal.close('no')">No</button>
//       </div>
//   `
// })
// export class ConfirmationModalComponent implements OnInit {
//   @Input() public managerResponseType;
//
//   constructor(public activeModal: NgbActiveModal) { }
//
//   ngOnInit(): void {
//   }
// }
