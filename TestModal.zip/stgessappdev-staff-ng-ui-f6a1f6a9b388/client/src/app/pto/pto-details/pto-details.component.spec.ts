import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { timeoffDetailsComponent } from './pto-details.component';

describe('timeoffDetailsComponent', () => {
  let component:timeoffDetailsComponent;
  let fixture: ComponentFixture<timeoffDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ timeoffDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(timeoffDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
