import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ToastrModule } from 'ngx-toastr';

import { SessionExpirationAlert, SessionInteruptService } from '@stgutils-ngx/core';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { Globals } from './shared/common/global/global.provider';
import { SecurityService } from './shared/common/services/security.service';
import { EventsService } from './shared/common/events/events.service';
import { TeamService } from "./shared/common/services/team.service";
import { UserService } from "./shared/common/services/user.service";
import { TimepickerModalComponent } from "./shared/timepicker-modal/timepicker-modal.component";
import { TimepickerModule } from "./shared/timepicker/timepicker.module";
import { FormsModule } from "@angular/forms";

/* store */
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { reducer as templatereducer } from '@staff/store/reducers/template-details.reducer';
import { TemplatesEffects } from '@staff/store/effects/template-details.effects';
import { TemplateLocationsEffects } from '@staff/store/effects/template-locations.effects';
import { reducer as schedulingreducer } from '@staff/store/reducers/scheduling.reducer';
import { AssociatesEffects } from '@staff/store/effects/associates.effects';
import { SchedulesEffects } from '@staff/store/effects/schedules.effects';
import { TasksEffects } from '@staff/store/effects/tasks.effects';
import { reducer as teamreducer } from '@staff/store/reducers/team.reducer';
import { TeamEffects } from '@staff/store/effects/team.effects';
/* store service */
import { EBSTemplateService } from '@staff/shared/common/services/ebs/template.service';
import { EventBaseScheduleService } from '@staff/shared/common/services/ebs.service';
import { EBSTeamService } from '@staff/shared/common/services/ebs/team.service';
@NgModule({
  declarations: [
    AppComponent,
    TimepickerModalComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    SessionExpirationAlert.forRoot({ totalMinutes: 120 }),
    ToastrModule.forRoot(),
    TimepickerModule,
    FormsModule,
    StoreModule.forRoot({
      templateDetails: templatereducer,
      scheduling: schedulingreducer,
      team: teamreducer
    }),
    EffectsModule.forRoot([
      TemplatesEffects,
      TemplateLocationsEffects,
      AssociatesEffects,
      SchedulesEffects,
      TasksEffects,
      TeamEffects
    ]),
    StoreDevtoolsModule.instrument({
      maxAge: 15
    }),
  ],
  providers: [
    Globals,
    SecurityService,
    EventsService,
    TeamService,
    UserService,
    EBSTemplateService,
    EventBaseScheduleService,
    EBSTeamService,
    { provide: LocationStrategy, useClass: HashLocationStrategy }
  ],
  bootstrap: [AppComponent],
  entryComponents: [
    TimepickerModalComponent
  ]
})
export class AppModule { }
