import { Component, OnInit, Output, EventEmitter, Input, ViewChild } from '@angular/core';
import { Select2Data } from '../../shared/common/components/select/select2-utils';
import { TimesheetService } from '../../shared/common/services/timesheet.service';
import { Globals } from '../common/global/global.provider';
import * as _ from 'lodash';
import { Select2 } from '../common/components/select/select2.component';

@Component({
  selector: 'app-override-type-dropdown',
  templateUrl: './override-type.component.html'
})
export class OverrideTypeDropdownComponent implements OnInit {
  data: Select2Data = [];
  susbcription: any;
  grouping = ['HOLIDAY','TIPS','WEATHER'];
  @ViewChild('stgselect') private stgselect: Select2;

  @Input() selectedValues: any;
  @Input() placeholder: string = 'Override Types';
  @Input() typeaheadInterval?: number = 700;

  @Output() overrideTypeSelected = new EventEmitter<any>();

  constructor(private timesheetService: TimesheetService, public globals: Globals) { }

  ngOnInit() {
    this.getOverrideTypes();
  }

  update(value: any) {
    this.overrideTypeSelected.emit(value);
  }

  setValue(val){
    this.stgselect.select(val, false, true);
  }

  getOverrideTypes() {
    if (this.susbcription) {
      this.susbcription.next();
    }
    this.susbcription = this.timesheetService.getOverrideTypesData()
      .subscribe((response: any) => {
        let selectedData = [], override_group:any = {};
        this.grouping.map(group=>override_group[group]=[]);
        override_group.OTHER=[];
        response.map(override => {
          let inGroup = false;
          for(var group of this.grouping) {
            if(override.override_description.toUpperCase().split(group).length > 1){
              _.set(override, 'group', group)
              override_group[group].push({ label: override.override_description, value: override });
              inGroup = true;
              break;
            }else if(group==='TIPS' && override.override_description.toUpperCase() === 'BANQUET-GRATUITY'){
              _.set(override, 'group', group)
              override_group[group].push({ label: override.override_description, value: override });
              inGroup = true;
              break;
            }
          }
          if(!inGroup){
            _.set(override, 'group', 'NONE')
            override_group.OTHER.push({ label: override.override_description, value: override });
          }
        });
        for (var key in override_group) {
          selectedData.push({value: key, label: key, disabled: true });
          override_group[key].forEach(override=>selectedData.push(override));
        }
        if (selectedData.length > -1) { this.data = selectedData; }
      }, err => {
        console.log('error  ----> ', err);
      });
    let selectedData = [];
    this.data.forEach(override => selectedData.push(override));
    if (selectedData.length > -1) {
      this.data = selectedData;
    }
  }
}
