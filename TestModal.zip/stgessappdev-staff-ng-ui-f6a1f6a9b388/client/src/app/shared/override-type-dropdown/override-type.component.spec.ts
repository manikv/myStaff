import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OverrideTypeDropdownComponent } from './override-type.component';
import  { OverrideTypeDropdownModule} from '@staff/sharedModules/override-type-dropdown.module';
import { AppModule } from '../../app.module';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('BalancesDropdownComponent', () => {
  let component: OverrideTypeDropdownComponent;
  let fixture: ComponentFixture<OverrideTypeDropdownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        AppModule,
        OverrideTypeDropdownModule
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
    fixture = TestBed.createComponent(OverrideTypeDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should getOverrideTypes', () => {
    component.getOverrideTypes()
    expect(component.data.length).toBeGreaterThanOrEqual(0);
  });
});
