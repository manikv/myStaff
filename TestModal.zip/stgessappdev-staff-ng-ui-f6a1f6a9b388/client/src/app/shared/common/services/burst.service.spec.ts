import { TestBed } from '@angular/core/testing';

import { BurstService } from './burst.service';

describe('BurstService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BurstService = TestBed.get(BurstService);
    expect(service).toBeTruthy();
  });
});
