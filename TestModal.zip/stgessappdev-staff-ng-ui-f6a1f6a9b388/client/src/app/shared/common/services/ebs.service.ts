import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Observable, Observer,Subject } from 'rxjs';

@Injectable()
export class EventBaseScheduleService {

  constructor(private http: HttpClient) { }

  private handleError(error) {
    return throwError(error);
  }

  getData(api_url: string, params: any) {
    return this.http.get(`${environment.api_url}` + '/ui' + api_url, { params })
      .pipe(
        map((response: { data: Array<object>, metadata: { resultCount: number } }) => response)
        , catchError(this.handleError)
      );
  }

  createEvent(user_name: string, payload: any) {
    return  this.http.post(`${environment.api_url}`+ environment.urls.ebs.createEvent.replace('{user_name}', user_name), payload);
  }

  updateEvent(user_name: string, payload: any) {
    return  this.http.put(`${environment.api_url}`+ environment.urls.ebs.updateEvent.replace('{user_name}', user_name), payload);
  }

  getEvents(team_name:string, start_time:string, end_time:string, user_name:string) {
    return this.http.get(`${environment.api_url}` + environment.urls.ebs.getEvents.replace('{user_name}', user_name).replace('{team_name}', team_name).replace('{start_time}', start_time).replace('{end_time}', end_time)).pipe(map((response: { data: Array<object> }) => response.data), catchError(this.handleError));
  }

  getEventsById( team_name:string, start_time:string, end_time:string, user_name:string, event_id:number,) {
    return this.http.get(`${environment.api_url}` + environment.urls.ebs.getEventsById.replace('{user_name}', user_name).replace('{team_name}', team_name).replace('{start_time}', start_time).replace('{end_time}', end_time).replace('{event_id}', event_id.toString(event_id))).pipe(map((response: { data: Array<object> }) => response.data), catchError(this.handleError));
  }

  createTemplate(team_name: string, payload: any) {
    console.log("create team_name" + payload);
    return  this.http.post(`${environment.api_url}`+ environment.urls.ebs.createTeamTemplates.replace('{team_name}', team_name), payload);
  }

  getebsTeamSchedule(user_name:string) {
    return this.http.get(`${environment.api_url}` + environment.urls.ebs.getebsTeamSchedule.replace('{user_name}', user_name).replace('{limit}', '10').replace('{page}', '5')).pipe(map((response: {data:Array<object>}) => response.data),catchError(this.handleError));
  }

  getDeptSummary(dept_name:string, paygrp_id:string, week_end_date:string) {
    return this.http.get(`${environment.api_url}` + environment.urls.ebs.getDeptSummary.replace('{dept_name}', dept_name).replace('{paygrp_id}', paygrp_id).replace('{week_end_date}', week_end_date)).pipe(map((response: { data: Array<object> }) => response.data), catchError(this.handleError));
  }

  getTemplateData( team_name: string,limit: string,page: string,sort:any,search:any) {
    console.log("team_name" + team_name);
    return this.http.get(`${environment.api_url}` +  environment.urls.ebs.getTeamTemplates.replace('{team_name}', team_name).replace('{limit}', limit).replace('{page}', page).replace('{sort}', sort).replace('{search}', search)).pipe(map((response: {data:Array<object>}) => response),catchError(this.handleError));

  }
  //change environment url to associates
  getTeamAssociates(team_name: string) {
    return this.http.get(`${environment.api_ebs_url}` + environment.urls.ebs.getTeamAssociates.replace('{team_name}', team_name))
      .pipe(map((response: { data: Array<object> }) => response.data), catchError(this.handleError));

  }

  getEventTypeData() {
    return this.http.get(`${environment.api_url}${environment.urls.ebs.getEventTypes}`)
      .pipe(map((response: { data: Array<object> }) => response.data),
        catchError(this.handleError));
  }

  getTemplateHistoryData(team_name: string, template_id: string) {
    return this.http.get(`${environment.api_url}${environment.urls.ebs.getebsTemplateDetails}`.replace('{team_name}', team_name).replace('{template_id}', template_id))
      .pipe(map((response: { data: Array<object> }) => response.data),
        catchError(this.handleError));
  }

  getTemplateLocations(team_name: string) {
    return this.http.get(`${environment.api_url}${environment.urls.ebs.getebsTemplateLocations}`.replace('{team_name}', team_name))
      .pipe(map((response: { data: Array<object> }) => response.data),
        catchError(this.handleError));
  }

  private listner = new Subject<any>();
  listen(): Observable<any>{
    return this.listner.asObservable();
  }
  filter(filterBy:string){
     this.listner.next(filterBy);
  }

  getTeamScheduleAssociates(team_name: string, user_name: string, event_id: number, week_start?: string, week_end?: string,) {
    let httpParams: any;

    //for testing purpose
    // if (!event_id) { event_id = '10107'; }

    if (week_start) {
      httpParams = new HttpParams().set('user_name', user_name).set('week_start', week_start).set('week_end', week_end).set('event_id', event_id.toString());
    } else {
      httpParams = new HttpParams().set('user_name', user_name).set('event_id', event_id.toString());
    }

    return this.http.get(`${environment.api_ebs_url}` + environment.urls.ebs.getTeamScheduleAssociates.replace('{team_name}', team_name),{params: httpParams})
      .pipe(map((response: { data: Array<object> }) => response.data), catchError(this.handleError));
  }

  createDeptSummary(payload:any) {
    return  this.http.post(`${environment.api_url}`+ environment.urls.ebs.createDeptSummary, payload);
  }

  createScheduleForAssociates(team_name: string, user_name: string, payload: any) {
    // let httpParams = new HttpParams().set('user_name', user_name)
     return this.http.post(`${environment.api_url}` + environment.urls.ebs.createScheduleForAssociates.replace('{team_name}', team_name).replace('{user_name}', user_name), payload);
   }

  getLocations( team_name: string,limit: string,page: string) {
    return this.http.get(`${environment.api_url}` +  environment.urls.ebs.getTeamLocations.replace('{team_name}', team_name).replace('{limit}', limit).replace('{page}', page)).pipe(map((response: {data:Array<object>}) => response),catchError(this.handleError));
  }

  getTeamTemplateHistory( team_name: string,event_id: string) {
    return this.http.get(`${environment.api_url}` +  environment.urls.ebs.getTeamTemplateHistory.replace('{team_name}', team_name).replace('{event_id}', event_id)).pipe(map((response: {data:Array<object>}) => response),catchError(this.handleError));
  }

  createTeamTemplateHistory(team_name: string, payload: any) {
    return this.http.post(`${environment.api_url}` + environment.urls.ebs.createTeamTemplateHistory.replace('{team_name}', team_name), payload);
  }

}
