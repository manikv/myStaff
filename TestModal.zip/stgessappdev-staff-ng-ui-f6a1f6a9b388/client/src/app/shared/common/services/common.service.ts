import { Injectable } from '@angular/core';
import { DatePipe } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  datePipe = new DatePipe('en-US');
  datePattern =/^([0-9]{2})\/([0-9]{2})\/([0-9]{4})$/;
  constructor() { }

  generateParameterString(object) {
    let parameterString = '';

    for ( const key in object ) {
      let valueToUse = encodeURIComponent(object[key]);
      if (key === 'weekStartingDate' || key === 'weekEndingDate') {
          valueToUse = object[key];
      }
      parameterString += key + '=' + valueToUse + '&';
    }

    // remove last & character
    if (parameterString.length > 0) {
        parameterString = parameterString.substr(0, parameterString.length - 1);
    }

    return parameterString;
  }

  setDateFormat(date, format = 'MM/dd/yyyy') {
    const dateObj = typeof date === 'object' ? new Date(date.year, date.month - 1 , date.day) : new Date(date);
    return this.datePipe.transform(dateObj, format);
  }

  validateBasicStructere(val){
    let date = val.split('/');
    let newDate = [];
    if (date.length === 3 ){
      newDate = date.map((item, index) => {
        if (item.length == 1 && index != (date.length -1)){
            return '0' + item;
        } else {
          return item;
        }
      });

      val = newDate.join('/');
    }

    return val
  }

  getEmployeeCatInfo() {
    return [
      {
        text: 'ALL',
        value: 'ALL'
      },
      {
        text: 'FULL-TIME',
        value: 'FULL-TIME'
      },
      {
        text: 'PART-TIME',
        value: 'PART-TIME'
      },
      {
        text: 'NON-EXEMPT',
        value: 'NON-EXEMPT'
      },
      {
        text: 'EXEMPT',
        value: 'EXEMPT'
      }
    ];
  }

  validateDateFormat(value) {
    if ( !value || this.datePattern.test(value) || typeof value === 'object') {
        return true;
    } else {
       return false;
    }
  }

  validateDateFormatTyped(value){
    if(typeof value === 'object'){
      return true;
    }
    return this.datePattern.test(value);
  }

  makeid(length) {
    let text = '';
    const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

    for (let i = 0; i < length; i++) {
      text += possible.charAt(Math.floor(Math.random() * possible.length));
    }

    return text;
  }

  objArrayToString(arr, fielToConcat){
    let result = '';
    if ( arr ) {
      arr.map((item, index) => {
        const value = item[fielToConcat] ? item[fielToConcat] : item;
        result += value;
        if( index !== arr.length - 1 ) {
          result += ',';
        }
      });
    }
    return result;
  }
}
