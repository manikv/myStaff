import { TestBed } from '@angular/core/testing';

import { TeamEbsService } from './team-ebs.service';

describe('TeamEbsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TeamEbsService = TestBed.get(TeamEbsService);
    expect(service).toBeTruthy();
  });
});
