import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
@Injectable()
export class PtoService {
  constructor(private http: HttpClient) {
  }

  private handleError(error) {
    return throwError(error);
  }

  getUserBalances(personnel_number: string) {
    return this.http.get(`${environment.api_url}` + environment.urls.ess.getUserBalances.replace('{personnel_number}', personnel_number)).pipe(map((response: {data:Array<object>}) => response.data),catchError(this.handleError));
  }

  getUserTimeoffRequest(username: string, team_name: string, approval_status: string, sub_teams: any = false ) {
     return this.http.get(`${environment.api_url}` + environment.urls.getUserTimeoffRequests.replace('{user_name}', username),{params: {team_name, approval_status, sub_teams}}).pipe(map((response: {data:Array<object>}) => response.data),catchError(this.handleError));
  }

  setTimeoffApproval(user_name: string, payload: any, validate: any) {
    return  this.http.post(`${environment.api_url}`+ environment.urls.setTimeoffApproval.replace('{user_name}', user_name).replace('{validate}', validate), payload);
  }
}
