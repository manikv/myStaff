import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
@Injectable()
export class BurstService {
  constructor(private http: HttpClient) {
  }

  private handleError(error) {
    return throwError(error);
  }

  getBurstApprovals(username, month_end_date){
    return this.http.get(`${environment.api_url}` + environment.urls.ess.getBurstApprovals.replace('{user_name}', username), {params: {username, month_end_date}}).pipe(map((response: {data:Array<object>}) => response.data),catchError(this.handleError));
  }

  updateBurstAssignments(data) {
    return  this.http.put(`${environment.api_url}${environment.urls.ess.saveBurstAssigments}`, data);
  }

  creatBurst( data: any){
    return  this.http.post(`${environment.api_url}` + environment.urls.createBurst , data);
  }

  createBurstTasks( data: any){
    return  this.http.post(`${environment.api_url}` + environment.urls.createBurstTasks , data);
  }

  createBurstAssigments( data: any){
    return  this.http.post(`${environment.api_url}` + environment.urls.createBurstAssignments , data);
  }

  updateManagerShiftBurst(burst_id: any, burst_status:any){
    return  this.http.put(`${environment.api_url}` + environment.urls.updateManagerShiftBurst.replace('{burst_id}', burst_id).replace('{burst_status}', burst_status),''
    );
  }

  getWeeklyWorkhoursSummary(perno:any, week_end_date: any){
    return this.http.get(`${environment.api_url}` + environment.urls.ess.getWeeklyWorkhoursSummary.replace('{personnel_number}', perno).replace('{week_end_date}', week_end_date)).pipe(map((response: {data:Array<object>}) => response.data),catchError(this.handleError));
  }

  getBurstPositions(burst_id: any) {
    return this.http.get(`${environment.api_url}` + environment.urls.getBurstPositions.replace('{burst_id}', burst_id))
    .pipe(map((response: {data: Array<object>}) => response.data),
    catchError(this.handleError));
  }

  getEmployeesByTeamRadiusDistrict(team_name: string, radius: number, shift_start_date: string, shift_end_date: string, all = false, district = false, schedHours = false) {
    // var getAll = all? 'true':'false';
    // var isdistrict = district? 'true':'false';
    let httpParams = new HttpParams().set('all', all ? 'true' : 'false').set('district', district ? 'true' : 'false').set('schedHours', schedHours ? 'true' : 'false');
    return this.http.get(`${environment.api_url}` + environment.urls.getEmployeesByTeamRadiusDistrict.replace('{team_name}', team_name).replace('{radius}', radius.toString()).replace('{shift_start_date}', shift_start_date.toString()).replace('{shift_end_date}', shift_end_date.toString()), { params: httpParams }).pipe(map((response: { data: Array<object> }) => response.data), catchError(this.handleError));
  }

  getShiftBurstAssignments(burstId: any) {
    let httpParams = new HttpParams().set('burstId', burstId);
    return this.http.get(`${environment.api_url}${environment.urls.getBurstAssigments}`, { params: httpParams })
      .pipe(map((response: { data: Array<object> }) => response.data), catchError(this.handleError));

  }



}
