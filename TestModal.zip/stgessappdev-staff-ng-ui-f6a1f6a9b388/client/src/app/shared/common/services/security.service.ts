import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class SecurityService {

  constructor(private http: HttpClient) { }

  private handleError(error) {
    return throwError(error);
  }

  getSecuredObjects(pageName: string){
    return  this.http.get(`${environment.api_url}`+ environment.urls.getSecuredObjects.replace('{pageName}', pageName)).pipe(map((response: {data:Array<object>}) => response.data),catchError(this.handleError));
  }

  getAppConfig(){
    return  this.http.get(`${environment.api_url}`+ environment.urls.getAppConfig);
  }

  getStaffProfile(){
    return  this.http.get(`${environment.api_url}`+ environment.urls.getStaffProfile);
  }

  getReportCalendarPreset(paygroup_id: string){
    return  this.http.get(`${environment.api_url}`+ environment.urls.getReportCalendarPreset.replace('{paygroup_id}', paygroup_id)).pipe(map((response: {data:Array<object>}) => response.data));
  }
}
