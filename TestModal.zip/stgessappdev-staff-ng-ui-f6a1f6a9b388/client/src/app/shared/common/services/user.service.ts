import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class UserService {
  constructor(private http: HttpClient) {
  }

  private handleError(error) {
    return throwError(error);
  }

  getUserProfile(user_name: string) {
    return  this.http.get(`${environment.api_url}`+ environment.urls.getUserProfile.replace('{user_name}', user_name)).pipe(map((response: {data:Array<object>}) => response.data),catchError(this.handleError));
  }
}
