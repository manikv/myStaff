import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import * as moment from "moment";
@Injectable()

export class ScheduleService {
  myTimeZone: string ="America/New_York";

  constructor(private http: HttpClient) {
  }

  private handleError(error) {
    return throwError(error);
  }

  private defaultOptions(payload) {
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
      body: payload,
    };
  }

  getWeeklySchedules(team_name: string, weekday: string) {
    return this.http.get(`${environment.api_url}` + environment.urls.ess.getWeeklySchedules, {
      params: {
        weekday,
        team_name
      }
    }).pipe(map((response: { data: Array<object> }) => response.data), catchError(this.handleError));
  }

  getDailySchedule(personnel_number: any, schedule_date: any) {
    let httpParams = new HttpParams().set('schedule_date', schedule_date);
    return this.http.get(`${environment.api_url}` + environment.urls.ess.getDailySchedule.replace('{personnel_number}', personnel_number), {params: httpParams}).pipe(map((response: { data: Array<object> }) => response.data));
  }

  getDailyPunches(team_name: any, work_date: any) {
    return this.http.get(`${environment.api_url}` + environment.urls.getDailyPunches.replace('{team_name}', team_name).replace('{work_date}', work_date)).pipe(map((response: { data: Array<object> }) => response.data));
  }

  deleteSchedule(personnel_number, schedule_date, payload: any) {
    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
      body: payload,
    };
    return this.http.delete(`${environment.api_url}` + environment.urls.deleteSchedule.replace('{personnel_number}', personnel_number).replace('{schedule_date}', schedule_date), options);
  }

  validateAvailability(personnel_number, payload: any) {
    const url = `${environment.api_url}` + environment.urls.validateAvailability
      .replace('{personnel_number}', personnel_number);
    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    };

    return this.http.post(url, payload, options).pipe(map((response: { data: Array<object> }) => response.data), catchError(this.handleError));
  }

  updateAvailability(update_availability, payload: any) {
    const url = `${environment.api_url}` + environment.urls.updateAvailability
      .replace('{update_availability}', update_availability ? 'true' : 'false');
    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
    };

    return this.http.post(url, payload, options).pipe(map((response: { data: Array<object> }) => response.data), catchError(this.handleError));
  }

  getWeeklyAvailability(team_name: string, week_end: string, user_name: string) {
    return this.http.get(`${environment.api_url}` + environment.urls.ess.getWeeklyAvailability, {
      params: {
        week_end,
        team_name,
        user_name
      }
    }).pipe(map((response: { data: Array<object> }) => response.data), catchError(this.handleError));
  }


  setAttendance(team_name:string, strDateTime:string, attendanceNumbers:any, schedules: any, punches: any): any {
    let attendance: any = [];
    attendance.push({
          attendanceNumbers: attendanceNumbers,
          scheduledList: [],
          atWorkList: [],
          absentList: [],
          scheduleList: [],
          punchList: []
     });
     attendance[0].attendanceNumbers.map(type => type.unitCount = 0);
    //first sort the punches
    punches.map(punch => {
      punch.punches.sort((a, b) => (this.getPunchDateformat(a.punch_string) > this.getPunchDateformat(b.punch_string)) ? 1 : -1);
    });

    schedules.map(schedule => {
          if (schedule.shifts && schedule.shifts.length) {
            const name = schedule.last_name + ', ' + schedule.first_name;
            const perno = schedule.personnel_number;
            const shifts = [];
            let empWorkStatus = false;
            const punchIndex = punches.map(o => o.emp_name).indexOf(schedule.personnel_number);
            let at_work_indicator = false, punched_out = false, punchout_time;
            if(punchIndex!=-1){
              at_work_indicator = punches[punchIndex].at_work;
              // punches[punchIndex].punches.sort((a, b) => (a.getPunchDateformat(punch_string) > b.getPunchDateformat(punch_string)) ? 1 : -1);
              punched_out = punches[punchIndex].punches[punches[punchIndex].punches.length-1].punch_type=='OUT';
              empWorkStatus = true;
            }
            schedule.shifts.map((shft) => {
              shifts.push({
                starDate: moment(shft.start).format('h:mm A'),
                endDate: moment(shft.end).format('h:mm A'),
                department_name: shft.department_name + '-' + shft.department_desc !== null ? shft.department_desc : ''
              })
            });
            attendance[0].attendanceNumbers[0].unitCount++;
            attendance[0].scheduledList.push({
              name,
              team: team_name,
              perno,
              shifts,
              //punches: tmpPunches
              punchIn: [],
              punchMin: [],
              punchMout: [],
              punchOut: []
            });
            if (at_work_indicator) {
              let pIn=[], pMin=[], pMout=[], pOut=[];
              punches[punchIndex].punches.map((pnch) => {
                switch(pnch.punch_type) {
                  case 'IN'       : { pIn.push(this.getPunchDateformat_hr(pnch.punch_string)); break; }
                  case 'MEAL_IN'  : { pMin.push(this.getPunchDateformat_hr(pnch.punch_string)); break; }
                  case 'MEAL_OUT' : { pMout.push(this.getPunchDateformat_hr(pnch.punch_string)); break; }
                  case 'OUT'      : { pOut.push(this.getPunchDateformat_hr(pnch.punch_string)); break; }
               }
              });
              attendance[0].attendanceNumbers[1].unitCount++;   //at work
              attendance[0].atWorkList.push({
                name,
                team: team_name,
                perno,
                shifts,
                //punches: tmpPunches
                punchIn: pIn,
                punchMin: pMin,
                punchMout: pMout,
                punchOut: pOut
              })
            } else if (moment(schedule.shifts[0].start).isBefore(moment(strDateTime))) {
              if (at_work_indicator) {
                //he's at work; hence not absent
              } else if (!at_work_indicator && punched_out) {
                //he finished the schedule and punched out;  hence not absent
                //may be early or on time punch out
                let pIn=[], pMin=[], pMout=[], pOut=[];
                punches[punchIndex].punches.map((pnch) => {
                  switch(pnch.punch_type) {
                    case 'IN'       : { pIn.push(this.getPunchDateformat_hr(pnch.punch_string)); break; }
                    case 'MEAL_IN'  : { pMin.push(this.getPunchDateformat_hr(pnch.punch_string)); break; }
                    case 'MEAL_OUT' : { pMout.push(this.getPunchDateformat_hr(pnch.punch_string)); break; }
                    case 'OUT'      : { pOut.push(this.getPunchDateformat_hr(pnch.punch_string)); break; }
                  }
                });
                attendance[0].attendanceNumbers[1].unitCount++;   //at work
                attendance[0].atWorkList.push({
                  name,
                  team: team_name,
                  perno,
                  shifts,
                  //punches: tmpPunches
                  punchIn: pIn,
                  punchMin: pMin,
                  punchMout: pMout,
                  punchOut: pOut
                })
              } else if (!empWorkStatus) {
                attendance[0].attendanceNumbers[2].unitCount++;   //he's absent
                attendance[0].absentList.push({
                  name,
                  team: team_name,
                  perno,
                  shifts,
                  punchIn: [],
                  punchMin: [],
                  punchMout: [],
                  punchOut: []
                });
              }
            }
          }
        });
        punches.map(pp=>{
          //not scheduled but has punches
          const scheduleIndex = attendance[0].atWorkList.map(o => o.perno).indexOf(pp.emp_name);
          if(scheduleIndex==-1){
            let pIn=[], pMin=[], pMout=[], pOut=[];
            pp.punches.map((pnch) => {
              switch(pnch.punch_type) {
                case 'IN'       : { pIn.push(this.getPunchDateformat_hr(pnch.punch_string)); break; }
                case 'MEAL_IN'  : { pMin.push(this.getPunchDateformat_hr(pnch.punch_string)); break; }
                case 'MEAL_OUT' : { pMout.push(this.getPunchDateformat_hr(pnch.punch_string)); break; }
                case 'OUT'      : { pOut.push(this.getPunchDateformat_hr(pnch.punch_string)); break; }
              }
            });
            attendance[0].attendanceNumbers[1].unitCount++;   //at work
            attendance[0].atWorkList.push({
              name: pp.emp_lastname+', '+pp.emp_firstname,
              perno: pp.emp_name,
              team: team_name,
              shifts:[{
                starDate:"No",
                endDate:"Schedules",
              }],
              punchIn: pIn,
              punchMin: pMin,
              punchMout: pMout,
              punchOut: pOut
            })
          }
        });
        attendance[0].scheduleList = schedules;
        attendance[0].punchList = punches;

    return attendance;
  }


  getPunchDateformat(dtString: string) {
    return moment(dtString.replace(" ",''), 'YYYYMMDDHHmm').format("MM/DD/YYYY hh:mm A");

  }

  getPunchDateformat_hr(dtString: string) {
    return moment(dtString.replace(" ",''), 'YYYYMMDDHHmm').format("hh:mm A")
  }

}
