import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { environment } from '@env/environment';
import { throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

@Injectable()
export class HomepageService {

  constructor(private http: HttpClient) { }

  private handleError(error) {
    return throwError(error);
  }

  getDashboard(user_name: string) {
    return this.http.get(`${environment.api_url}` + environment.urls.getDashboard.replace('{user_name}', user_name)).pipe(map((response: { data: Array<object> }) => response.data));
  }

  getDashboardUnauth(user_name: string, user_id: string) {
    return this.http.get(`${environment.api_url}` + environment.urls.getDashboardUnauth.replace('{user_name}', user_name).replace('{user_id}', user_id)).pipe(map((response: { data: Array<object> }) => response.data));
  }

  checkDashboardUnauthStatus(user_name: string, emp_id: string, work_date) {
    return this.http.get(`${environment.api_url}` + environment.urls.checkDashboardUnauthStatus.replace('{user_name}', user_name).replace('{emp_id}', emp_id).replace('{work_date}', work_date)).pipe(map((response: { data: Array<object> }) => response.data));
  }

  getAccordion(user_name: string) {
    return this.http.get(`${environment.api_url}` + environment.urls.getDashboardActivityLinks.replace('{user_name}', user_name)).pipe(map((response: { data: Array<object> }) => response.data));
  }

  getDashboardAnnouncement(user_name: string) {
    return this.http.get(`${environment.api_url}` + environment.urls.getDashboardAnnouncement.replace('{user_name}', user_name)).pipe(map((response: { data: Array<object> }) => response.data));
  }

  getWidgetGridData(type: string, user_name: string, page: string, limit: string, user_id) {
    console.log(user_id);
    return this.http.get(`${environment.api_url}` + environment.urls.getWidgetGridData.replace('{user_id}', user_id).replace('{type}', type).replace('{user_name}', user_name).replace('{page}', page).replace('{limit}', limit), { headers: new HttpHeaders({ 'accept': 'application/json' }) });
  }

  getWidgetGridUnauthTimesheetData(user_name: string, user_id: string) {
    return this.http.get(`${environment.api_url}` + environment.urls.getWidgetGridUnauthTimesheetData.replace('{user_name}', user_name), { headers: new HttpHeaders({ 'accept': 'application/json' }) }).pipe(map((response: { data: Array<object> }) => response.data));
  }
}
