import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../../../environments/environment';
import {throwError} from 'rxjs';
import {catchError, map} from 'rxjs/operators';

@Injectable()
export class NotificationService {
  constructor(private http: HttpClient) {
  }

  private handleError(error) {
    return throwError(error);
  }

  createNotification (payload: any) {
    return this.http.post(`${environment.api_url}` + environment.urls.notification.createUserNotification, payload);
  }

}
