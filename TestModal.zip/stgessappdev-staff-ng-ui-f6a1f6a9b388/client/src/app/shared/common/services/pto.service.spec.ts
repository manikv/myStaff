import { TestBed } from '@angular/core/testing';

import { PtoService } from './pto.service';

describe('PtoService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PtoService = TestBed.get(PtoService);
    expect(service).toBeTruthy();
  });
});
