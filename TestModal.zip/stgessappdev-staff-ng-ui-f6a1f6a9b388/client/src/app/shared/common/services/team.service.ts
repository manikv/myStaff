import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class TeamService {
  constructor(private http: HttpClient) {
  }

  private handleError(error) {
    return throwError(error);
  }

  getTeams(currentPage: string, modelInput: string) {
    return this.http.get(`${environment.api_url}` + environment.urls.teamsTypehead, { params: { query: modelInput, page: currentPage } });
  }

  getTeamsData(limit: number, page: number = 1, sorts: string, teamName: string, userName: string, query: string, complex:string) {
    return this.http.get(`${environment.api_url}` + environment.urls.teamsTypeahead, {
      params: {
        limit: limit.toString(),
        page: page.toString(),
        sorts,
        team_name: teamName,
        user_name: userName,
        complex: complex,
        query
      }
    });

  }

  getAssociates(limit: number, page: any = 1, sorts: string, teamName: string, userName: string, query: string) {
    return this.http.get(`${environment.api_url}` + environment.urls.associateTypeahead, {
      params: {
        limit: limit.toString(),
        page: page.toString(),
        sorts,
        team_name: teamName,
        user_name: userName,
        query
      }
    });
  }

  getTeamAllLocationsServer(team_name: string){
    return  this.http.get(`${environment.api_url}`+  environment.urls.ebs.getTeamAllLocations.replace('{team_name}', team_name));
  }

  getBalancesTypesData() {
    return this.http.get(`${environment.api_url}${environment.urls.getBalanceTypes}`)
      .pipe(map((response: { data: Array<object> }) => response.data),
        catchError(this.handleError));
  }

  getOverrideNamesData(){
    return this.http.get(`${environment.api_url}${environment.urls.getOverrideNames}`)
      .pipe(map((response: { data: Array<object> }) => response.data),
        catchError(this.handleError));
  }

  getPayGroups() {
    return this.http.get(`${environment.api_url}${environment.urls.getPayGroups}`)
      .pipe(map((response: { data: Array<object> }) => response.data),
        catchError(this.handleError));
  }
}
