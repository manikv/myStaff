import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
@Injectable()
export class OLD_EventsService {
  constructor(private http: HttpClient) {
  }

  private handleError(error) {
    return throwError(error);
  }

  getEvents(username: string, team_name: string, search: string ) {
    return this.http.get(`${environment.api_ebs_url}`+ environment.urls.ebs.getEvents.replace('{user_name}', username).replace('{search}', search)).pipe(map((response: {data:Array<object>}) => response.data),catchError(this.handleError));
  }

}
