import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../../environments/environment';
import { throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

@Injectable()
export class EBSTeamService {

  constructor(private http: HttpClient) { }

  private handleError(error) {
    return throwError(error);
  }

  getTeamCostCenters(team_name: string) {
    return this.http.get(`${environment.api_url}${environment.urls.ebs.getTeamCostCenters}`.replace('{team_name}', team_name))
      .pipe(map((response: { data: Array<object> }) => response.data),
        catchError(this.handleError));
  }

  getTeamSkills(team_name: string) {
    return this.http.get(`${environment.api_url}${environment.urls.ebs.getTeamSkills}`.replace('{team_name}', team_name))
      .pipe(map((response: { data: Array<object> }) => response.data),
        catchError(this.handleError));
  }

  createTeamLocation(team_name: string, user_name: string, data: object) {
    return this.http.post(`${environment.api_url}${environment.urls.ebs.createTeamLocation}`.replace('{team_name}', team_name).replace('{user_name}', user_name), data)
  }

  createTeamTask(team_name: string, data: object) {
    return this.http.post(`${environment.api_url}${environment.urls.ebs.createTeamTask}`.replace('{team_name}', team_name), data)
  }

}
