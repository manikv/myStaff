import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { IDatasource, IGetRowsParams } from 'ag-grid-community';
import { EventBaseScheduleService } from './ebs.service';

@Injectable()
export class TeamTemplateService {
    private ebsService: EventBaseScheduleService;

constructor(private http: HttpClient) { }

    getSortModel(sortModel:any){      
        // if(params.sortModel[0].colId === 'event_template_name') {
        //   sortField = 'templateName';
        // }
        // else if(params.sortModel[0].colId === 'template_type'){
        //   console.log("teamName" + params.sortModel[0].colId);
        //   sortField = 'templateTypeName';
        // }
        // sortModel = '[{"property"='+sortField+',"direction"='+params.sortModel[0].sort+'}]'; 
        let sortField = '';
        if(sortModel.colId === 'event_template_name') {      
            sortField = 'templateName';
          }else if(sortModel.colId === 'template_type'){
              console.log("teamName" + sortModel.colId);
               sortField = 'templateTypeName';
          }
             sortModel = '[{"property"='+sortField+',"direction"='+sortModel.sort+'}]'; 
             return sortModel;
      }
    
      getSearchModel(filtermodel:any,dropfilter:string){
        let searchModel : string = '';
        let searchString : string = '{search: ['+searchModel+']}';
        let templateType = '';
        let templateName = '';
        let coverage = '';
        let guestCount = '';
        let active = '';
        let addDrop ='';
        
        if(filtermodel.template_type)
            templateType = '{property:templateTypeName , value : "'+filtermodel.template_type.filter+'" , operator : "LIKE"}';
        if(filtermodel.event_template_name)
            templateName = '{property:templateName , value : "'+filtermodel.event_template_name.filter+'" , operator : "LIKE"}';
        if(filtermodel.guest_count)
           guestCount = '{property:guestCount , value : "'+filtermodel.guest_count.filter+'" , operator : "EQUAL"}'; 
        if(filtermodel.associate_count)
            coverage = '{property:associateCount , value : "'+filtermodel.associate_count.filter+'" , operator : "EQUAL"}';   
        if(filtermodel.active_ind)
            active = '{property:activeInd , value : "'+filtermodel.active_ind.filter+'" , operator : "LIKE"}';        
        
        if(dropfilter !== '')
            addDrop = '{property:templateTypeName , value : "'+dropfilter+'" , operator : "LIKE"}';
        let allSearch = [templateType,templateName,guestCount,coverage,active,addDrop];
        searchModel= allSearch.filter(Boolean).map(elem=>elem.replace(/\s+/g, ' ').trim()).join(", ");    
            searchString =   '{search: ['+searchModel+']}';
            console.log(searchModel);
         return searchString;
      }
    

      getTemplateData (ebsTeamSelected:string,paginationPageSize:number):IDatasource{
        const data : IDatasource = {
          getRows: (params: IGetRowsParams) => {
            //this.blockUI.start('Loading...');
            let teamName = ebsTeamSelected;
            let page = params.endRow / paginationPageSize;
            console.log("teamName" + teamName);     
            let sortModel = '';      
            let searchModel = '';     
            
          if (typeof params.sortModel[0] !== 'undefined'){   
            sortModel = this.getSortModel(params.sortModel[0] );
          }
         searchModel = this.getSearchModel(params.filterModel,'');
         console.log(searchModel);
          this.ebsService.getTemplateData(teamName,
            paginationPageSize.toString(),
            page.toString(),sortModel,searchModel)
            .subscribe((res: any) => {                  
              params.successCallback(res.data, res.metadata.result_count);    
            });
          }
        };
        return data;
      }

}