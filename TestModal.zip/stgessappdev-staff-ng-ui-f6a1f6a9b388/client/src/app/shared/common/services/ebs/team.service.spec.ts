import { TestBed } from '@angular/core/testing';

import { EBSTemplateService } from './template.service';

describe('EBSTemplateService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EBSTemplateService = TestBed.get(EBSTemplateService);
    expect(service).toBeTruthy();
  });
});
