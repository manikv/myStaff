import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../../environments/environment';
import { throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

@Injectable()
export class EBSTemplateService {

  constructor(private http: HttpClient) { }

  private handleError(error) {
    return throwError(error);
  }

  updateTemplateTasks(team_name: string, data: any) {
    return this.http.put(`${environment.api_url}${environment.urls.ebs.updateebsTemplateTasks}`.replace('{team_name}', team_name), data)
      .pipe(map((response: { data: Array<object> }) => response.data),
        catchError(this.handleError));
  }

  getTemplateDetailsData(team_name: string, template_id: string) {
    return this.http.get(`${environment.api_url}${environment.urls.ebs.getebsTemplateDetails}`.replace('{team_name}', team_name).replace('{template_id}', template_id))
      .pipe(map((response: { data: Array<object> }) => response.data),
        catchError(this.handleError));
  }

  getTemplateLocations(team_name: string) {
    return this.http.get(`${environment.api_url}${environment.urls.ebs.getebsTemplateLocations}`.replace('{team_name}', team_name))
      .pipe(map((response: { data: Array<object> }) => response.data),
        catchError(this.handleError));
  }

  getTemplateCoverage(team_name: string, task_name: string) {
    return this.http.get(`${environment.api_url}${environment.urls.ebs.getTemplateCoverage}`.replace('{team_name}', team_name).replace('{task_name}', task_name))
      .pipe(map((response: { data: Array<object> }) => response.data),
        catchError(this.handleError));
  }

}
