import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

@Injectable()
export class TimesheetService {

  constructor(private http: HttpClient) { }

  private handleError(error) {
    return throwError(error);
  }

  getMassData(api_url: string, params: any) {
    return this.http.get(`${environment.api_url}` + '/ui' + api_url, { params })
      .pipe(
        map((response: { data: Array<object>, metadata: { resultCount: number } }) => response)
        , catchError(this.handleError)
      );
  }

  getOverrideTypesData() {
    return this.http
      .get(`${environment.api_url}` + environment.urls.getOverrideTypes)
      .pipe(map((response: { data: Array<object> }) => response.data),
        catchError(this.handleError));
  }

  setEmployeesOverride(api_url, body, params) {
    return this.http
      .post(`${environment.api_url}${api_url}`, body, { params: params })
      .pipe(map((response: { data: Array<object> }) => response.data),
        catchError(this.handleError));
  }

  getEmployeesOverride(params){
    return this.http.get(`${environment.api_url}${environment.urls.getOverrideEmployess}`, {params: params});
  }

  getEmployeesTrainingOverride(params){
    console.log(`${environment.api_url}${environment.urls.getOverrideTrainingEmployes.replace('{team_name}', params.team_name)}`)
    return this.http.get(`${environment.api_url}${environment.urls.getOverrideTrainingEmployes.replace('{team_name}', params.team_name).replace('{work_date}', params.work_date).replace('{subteam_flag}', params.subteam_flag)}`);
  }
}
