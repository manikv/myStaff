import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class TeamEbsService {
  constructor(private http: HttpClient) {
  }

  private handleError(error) {
    return throwError(error);
  }

  getTeamsData(limit: number, page: number = 1, sorts: string, teamName: string, userName: string, query: string, complex:string) {
    return this.http.get(`${environment.api_url}`+ environment.urls.ebs.getebsTeamSchedule .replace('{user_name}', userName), {
      params: {
        limit: limit.toString(),
        page: page.toString(),
        sorts,
        team_name: teamName,
        // user_name: userName,
        complex: complex,
        // query
      }
    });




  }


}
