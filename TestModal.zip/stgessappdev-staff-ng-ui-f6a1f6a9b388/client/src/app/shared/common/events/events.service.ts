import { Injectable } from '@angular/core';
import {IEvent, Event} from './events.interface.'

@Injectable()
export class EventsService {
  private selectedDateChangeEvent: IEvent<Date> = new Event<Date>();
  private selectedWeekendDateChangeEvent: IEvent<Date> = new Event<Date>();
  private selectedPaygroupChangeEvent: IEvent<number> = new Event<number>();

  constructor() { }

  public get selectedDateChange(): IEvent<Date> {
    return this.selectedDateChangeEvent;
  }

  public get selectedWeekendDateChange(): IEvent<Date> {
    return this.selectedWeekendDateChangeEvent;
  }

  public get selectedPaygroupChange(): IEvent<number> {
    return this.selectedPaygroupChangeEvent;
  }
}