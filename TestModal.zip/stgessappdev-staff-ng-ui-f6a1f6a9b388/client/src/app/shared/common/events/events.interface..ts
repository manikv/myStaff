import { Subscription } from "rxjs";
import { Subject } from "rxjs"

export interface IEvent<T> {

    publish(payload: T): void,

    subscribe(callback: (payload: T) => void): Subscription
}

export class Event<T> implements IEvent<T> {

    private subject = new Subject<any>();

    constructor() { }

    public publish(payload: T): void {
        this.subject.next(payload);
    }

    public subscribe(callback: (payload: T) => void): Subscription {
        let subscription = this.subject.asObservable().subscribe(callback);
        return subscription;
    }
}