import { TestBed } from '@angular/core/testing';

import { Globals } from './global.provider';

describe('Global Provider', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: Globals = TestBed.get(Globals);
    expect(service).toBeTruthy();
  });
});
