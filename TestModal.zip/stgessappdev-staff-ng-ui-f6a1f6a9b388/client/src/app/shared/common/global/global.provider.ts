import { Injectable } from "@angular/core";
import { HttpParams } from '@angular/common/http';

@Injectable()
export class Globals {
  env:string;
  logoutUrl:string;
  timeout:number;
  rbacProfile:any;
  staffProfile:any
  proxyUserName: string;
  proxyUseProfile: any;
  user_name: string;
  base_urls: any;
  paygroups: any;
  settings: any = {
    dbs_weekly_search_maxsize: 200,
    restrictFutureDate: false,
    restrictFutureShiftBurstDate: false,
    drag_highlight_associate: false,
    drag_highlight_conflict_shift: false,
    drag_select_single_employee: false,
    drag_select_multi_employee: false,
    dbs_shift_based_scheduling: false,
    drag_highlight_associate_color: "green",
    drag_conflict_associate_color: "yellow",
    drag_drop_associate_color: "#5b9bd1",
    drag_select_associate_color: "#5b9bd1",
    drag_highlight_associate_color_border: "#36AA1C",
    dbs_enable_set_geolocation: false,
    dbs_shift_burst_rate_max: 50,
    mass_timesheet_days_restriction_min: 90,
    mass_timesheet_days_restriction_max: 36
  };

  balanceIcons = [
    {
      icon: 'plus',
      type: 'sick'
    }, {
      icon: 'airplane',
      type: 'vacation'
    }, {
      icon: 'clock',
      type: 'default'
    }];

  ebsPayGrpId: any;
  ebsTeamSelected: any;
  ebsWkEndSelected: any;
  ebsWkStartSelected: any;
  ebsTeamIdSelected: any;
  ebsEventSelected: any;
  ebsTemplateSelected: any;

  setSettings(settingsValue){
      settingsValue.forEach(configObj => {
        if(configObj.configName === "dbs_weekly_search_maxsize"){
            this.settings.dbs_weekly_search_maxsize = configObj.configValue;
        }else if(configObj.configName === "drag_highlight_associate"){
          this.settings.drag_highlight_associate = configObj.configValue === 'Y' ? true: false;
        }else if(configObj.configName === "drag_highlight_conflict_shift"){
          this.settings.drag_highlight_conflict_shift = configObj.configValue === 'Y' ? true: false;
        }else if(configObj.configName === "drag_select_single_employee"){
          this.settings.drag_select_single_employee = configObj.configValue === 'Y' ? true: false;
        }else if(configObj.configName === "drag_select_multi_employee"){
          this.settings.drag_select_multi_employee = configObj.configValue === 'Y' ? true: false;
        }else if(configObj.configName === "dbs_shift_based_scheduling"){
          this.settings.dbs_shift_based_scheduling = configObj.configValue === 'Y' ? true: false;
        }else if(configObj.configName === "drag_highlight_associate_color"){
          this.settings.drag_highlight_associate_color = configObj.configValue;
        }else if(configObj.configName === "drag_conflict_associate_color"){
          this.settings.drag_conflict_associate_color = configObj.configValue;
        }else if(configObj.configName === "drag_select_associate_color"){
          this.settings.drag_select_associate_color = configObj.configValue;
        }else if(configObj.configName === "drag_drop_associate_color"){
          this.settings.drag_drop_associate_color = configObj.configValue;
        }else if(configObj.configName === "drag_highlight_associate_color_border"){
          this.settings.drag_highlight_associate_color_border = configObj.configValue;
        }else if(configObj.configName === "dbs_enable_set_geolocation"){
          this.settings.dbs_enable_set_geolocation = configObj.configValue === 'Y' ? true: false;
        }else if(configObj.configName === "dbs_shift_burst_rate_max"){
          this.settings.dbs_shift_burst_rate_max = configObj.configValue;
        }else if(configObj.configName === "mass_timesheet_days_restriction_min"){
          this.settings.mass_timesheet_days_restriction_min = configObj.configValue;
        }else if(configObj.configName === "mass_timesheet_days_restriction_max"){
          this.settings.mass_timesheet_days_restriction_max = configObj.configValue;
        }
    });
  }

  getParamValueQueryString( paramName ) {
    const url = window.location.href;
    let paramValue;
    if (url.includes('?')) {
      const httpParams = new HttpParams({ fromString: url.split('?')[1] });
      paramValue = httpParams.get(paramName);
    }
    return paramValue;
  }

  getIconType(balance_description) {
    let icon = this.balanceIcons.find(icon => balance_description.toLowerCase().includes(icon.type));

    if (!icon) {
      icon = this.balanceIcons.find(icon => icon.type == 'default');
    }
    return icon.icon;
  };

  random_bg_color() {
    var x = Math.floor(Math.random() * 256);
    var y = Math.floor(Math.random() * 256);
    var z = Math.floor(Math.random() * 256);
    return "rgb(" + x + "," + y + "," + z + ", 0.1)";
  }

  setIntervalX(callback, delay, repetitions) {
    var x = 0;
    var intervalID = window.setInterval(function () {

      callback();

      if (++x === repetitions || repetitions===0) {
        window.clearInterval(intervalID);
      }
    }, delay);
    return intervalID;
  }

  clearIntervalX(intervalID) {
    window.clearInterval(intervalID);
  }

}
