import { Injectable } from '@angular/core';
import { DropdownModule } from './dropdown.module';

@Injectable({
  providedIn: DropdownModule
})
export class DropdownService {

  constructor() { }
}
