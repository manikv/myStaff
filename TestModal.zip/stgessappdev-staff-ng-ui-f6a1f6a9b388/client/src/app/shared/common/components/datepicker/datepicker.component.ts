import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { NgbCalendar } from '@ng-bootstrap/ng-bootstrap';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { CommonService } from '../../services/common.service';
declare const document: any;
import { format } from 'date-fns'
import { range } from 'd3';

const equals = (one: NgbDateStruct, two: NgbDateStruct) =>
  one && two && two.year === one.year && two.month === one.month && two.day === one.day;

const before = (one: NgbDateStruct, two: NgbDateStruct) =>
  !one || !two ? false : one.year === two.year ? one.month === two.month ? one.day === two.day
    ? false : one.day < two.day : one.month < two.month : one.year < two.year;

const after = (one: NgbDateStruct, two: NgbDateStruct) =>
  !one || !two ? false : one.year === two.year ? one.month === two.month ? one.day === two.day
    ? false : one.day > two.day : one.month > two.month : one.year > two.year;


export class DatePickerModel {
  id?: any;
  type?;
  day?= 5;
  format?;
  required?;
  default?;
  disable?;
  className?;
  value?
  validFormat?= false;
  firstDayOfWeek?= 7;
  minDate? = null;
  maxDate? = null;
  inputDisable? = false;
  errorText?;
}

@Component({
  selector: 'app-datepicker',
  templateUrl: './datepicker.component.html',
  styleUrls: ['./datepicker.component.scss']
})
export class DatepickerComponent implements OnInit {

  private _datepikerModelInput = new BehaviorSubject<DatePickerModel>(undefined);
  datepicketModel = new DatePickerModel();
  isValidFormat = true;
  errorMsg = 'Incorrect format: it should be MM/DD/YYYY';
  @Output() changeDate = new EventEmitter();

  @Input()
  set datepicketModelInput(value) {
    if (value !== undefined) {
      this._datepikerModelInput.next(value);
    }
  };
  @Input() dayOfTheWeekEnable?;
  @Input() rangeDates?;
  @Input() cssStyle:string = '';

  types: Array<string> = ['weekendday', 'month', 'weekly'];
  bsValue;
  dayOfWeekArray: Array<number> = [0, 1, 2, 3, 4, 5, 6];
  daysDisabled = [];
  bsConfig: Partial<NgbCalendar>;
  isDisabled;
  selectedRangeDates = [];
  selectedDate: any;

  constructor(
    private commonService: CommonService
  ) { }

  ngOnInit() {
    this._datepikerModelInput.subscribe(model => {
      this.datepicketModel = model;
      this.setDefault();
    }, err => console.log(err));
    if (this.dayOfTheWeekEnable) {
      this.isDisabled = (date: NgbDate, current: { month: number }) => {
        let datFormatted = new Date(`${date.month}/${date.day}/${date.year}`);
        return datFormatted.getDay().toString() !== this.dayOfTheWeekEnable;
      }
    }
  }

  checkMinValue(val, text = "The Date"){
    if (this.datepicketModel && this.datepicketModel.minDate){
      const min = this.datepicketModel.minDate;
      const result = new Date(min.year, min.month - 1, min.day) <= new Date(val) ;
      if(!result) {
        this.isValidFormat = false;
        this.errorMsg = text+' must be after ' + min.month+'/'+min.day+'/'+min.year;
      }
      return result;
    }
    return true;
  }

  checkMaxValue(val, text = "The Date"){
    if (this.datepicketModel && this.datepicketModel.maxDate){
      const max = this.datepicketModel.maxDate;
      const result = new Date(max.year, max.month - 1, max.day) >= new Date(val);
      if(!result) {
        this.isValidFormat = false;
        this.errorMsg = text+' must be before ' + + max.month+'/'+max.day+'/'+max.year;
      }
      return result;
    }
    return true;
  }

  handlerChange(value: any, blur=false) {
    if (this.datepicketModel.validFormat) {
      let validity = this.commonService.validateDateFormat(value);
      if(validity || blur){
        this.isValidFormat = validity;
        if (this.isValidFormat && this.validateParam(value)) {
          const rigthDate = new Date(value);
          if(this.checkMaxValue(value,this.datepicketModel.errorText) && this.checkMinValue(value,this.datepicketModel.errorText))  {
            value = { day: rigthDate.getDate(), month: rigthDate.getMonth() + 1, year: rigthDate.getFullYear() };
          } else {
            value = null
          }
          setTimeout(this.setValueCallb(value), 200);
        }
      }
    }

    this.selectedDate = value;
    if (this.rangeDates) {
      this.setHighlightDays();
    }
    this.changeDate.emit(value);
  }

  setValueCallb: any = (value) => {
    this.datepicketModel.value = value
  }

  private validateParam(value) {
    return (value && value !== '' && value !== null && value !== 'null' && typeof value !== 'object');
  }

  isInside = date => after(date, this.formatDate(this.rangeDates.start_date)) && before(date, this.formatDate(this.rangeDates.end_date));

  validateFormat(value: any) {
    if (this.validateParam(value)) {
      value = this.commonService.validateBasicStructere(value);
      document.getElementById(this.datepicketModel.id).value = value;
      this.handlerChange(value, true);
    }
  }


  setHighlightDays() {
    let start_date = new Date(this.rangeDates.start_date);
    let end_date = new Date(this.rangeDates.end_date);
    let currentDate = new Date(this.selectedDate.year, this.selectedDate.month - 1, this.selectedDate.day);
    this.selectedRangeDates = []
    for (let i = end_date.getDay(); i != start_date.getDay(); i--) {
      currentDate = new Date(currentDate.getUTCFullYear(), currentDate.getUTCMonth(), currentDate.getUTCDate() - 1);
      this.selectedRangeDates.push(currentDate);
      if (i == 0) {
        i = 7;
      }
    }
  }

  formatDate(date) {
    date = new Date(date);
    return { day: date.getUTCDay(), month: date.getUTCMonth(), year: date.getUTCFullYear() };
  }

  setDefault() {
    if (this.datepicketModel.default) {
      const date = new Date(this.datepicketModel.default);
      this.datepicketModel.value = { day: date.getDate(), month: date.getMonth() + 1, year: date.getFullYear() };
    }
  }

  highlighted(date) {
    const d = new Date(date.year, date.month - 1, date.day);
    if (this.selectedDate) {
      return this.selectedRangeDates.find(date => date.toString() == d.toString());
    } else {
      return false;
    }
  }

  setValue(dateVal) {
    this.datepicketModel.value = { day: Number(format(new Date(dateVal), 'DD')), month: Number(format(new Date(dateVal), 'MM')), year: Number(format(new Date(dateVal), 'YYYY')) };
    this.handlerChange(this.datepicketModel.value)
    this.changeDate.emit(this.datepicketModel.value);
  }

  setDateValue(dateVal) {
    this.datepicketModel.value = dateVal;
  }

  isWeekend(date: NgbDateStruct) {
    const d = new Date(date.year, date.month - 1, date.day);
    return d.getDay() === 0 || d.getDay() === 6;
  }

  openCalendar(d){
    if(this.datepicketModel.inputDisable){
      d.toggle();
    }
  }
}