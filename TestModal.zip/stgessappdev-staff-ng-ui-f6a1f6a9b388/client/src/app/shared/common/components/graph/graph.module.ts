import { NgModule } from '@angular/core';
import { GraphComponent } from './graph.component';
import {  SparklineChartDirective } from './sparkline-chart.directive'

@NgModule({
  declarations: [GraphComponent, SparklineChartDirective],
  imports: [
  ],
  exports: [
    GraphComponent
  ],
  providers:[
  ]
})
export class GraphModule { }
