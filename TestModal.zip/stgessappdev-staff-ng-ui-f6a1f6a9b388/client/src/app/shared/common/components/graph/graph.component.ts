import { Component, OnInit, Input } from '@angular/core';
import {  SparklineChartOptions } from './sparkline-chart.directive'
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';

export class GraphModel{
  description: String;
  value: any;
  options: SparklineChartOptions;
}

@Component({
  selector: 'app-graph',
  templateUrl: './graph.component.html',
  styles: []
})
export class GraphComponent implements OnInit {

  graphModel = new GraphModel();
  _graphModelInput = new BehaviorSubject<GraphModel>(undefined);
  constructor() { }

  @Input()
  set graphModelInput(value) {
      if (value !== undefined) {
          this._graphModelInput.next(value);
      }
  }

  ngOnInit() {
    this._graphModelInput.subscribe(model => {
      this.graphModel = model;
    }, err => console.log(err));
  }

  ngOnDestroy(): void {
    this._graphModelInput.unsubscribe();
  }

}
