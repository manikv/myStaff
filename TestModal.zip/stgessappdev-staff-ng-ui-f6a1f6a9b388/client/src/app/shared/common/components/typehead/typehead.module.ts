import { NgModule } from '@angular/core';
import { TypeheadComponent } from './typehead.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ClickOutsideModule } from 'ng-click-outside';

@NgModule({
  declarations: [TypeheadComponent],
  imports: [
    CommonModule,
    FormsModule,
    NgbModule,
    ClickOutsideModule
  ],
  exports: [TypeheadComponent]
})
export class TypeheadModule { }
