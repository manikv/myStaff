import { Component, OnInit, Input, Output, EventEmitter, ViewChild, OnChanges, SimpleChanges, SimpleChange } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import {NgbTypeahead} from '@ng-bootstrap/ng-bootstrap';
import {Observable, Subject, merge} from 'rxjs';
import {debounceTime, distinctUntilChanged, filter, map} from 'rxjs/operators';
import { CommonService } from '../../services/common.service';

export class TypeheadModel {
  label?: string;
  selected?: string;
  states: Array<any> = [];
  id?;
  type?: string;
  placeholder?;
  pagination?;
  disabled?:any = false;
  width?;
  height?;
  appendToBody?;
  scrollable?:any = false;
  viewNumber?: number;
  minLength?: number;
  default?;
  customTemplate?;
  hideResultOnBlur?:any = false;
}


@Component({
  selector: 'app-typehead',
  templateUrl: './typehead.component.html'
})
export class TypeheadComponent implements OnInit, OnChanges {

  private _typeheadModelInput = new BehaviorSubject<TypeheadModel>(undefined);
  typeheadModel = new TypeheadModel();
  model: any = '';
  showTooltip = false;

  @ViewChild('instance', { static: true }) instance: NgbTypeahead;
  focus$ = new Subject<string>();
  click$ = new Subject<string>();

  constructor(
    private commonService: CommonService
  ) { }

  @Output() typeaheadOnBlur = new EventEmitter<any>();
  @Output() itemSelected = new EventEmitter<any>();
  @Output() pageChange = new EventEmitter<any>();

  @Input()
  set typeheadModelInput(value) {
    if (value !== undefined) {
      this._typeheadModelInput.next(value);
    }
  }

  @Input() loadStates;
  @Input() page: any = 1;
  @Input() resultCount = null;

  ngOnChanges(changes: SimpleChanges) {

  }

  ngOnInit() {
    this._typeheadModelInput.subscribe(model => {
      this.typeheadModel = model;
      if ( !this.typeheadModel.id ) { this.typeheadModel.id = this.commonService.makeid(6); }
    }, err => console.log('OnInit ', err));
  }

  selectItem(item) {
    this.model = item;
    this.itemSelected.emit(item);
    this.showTooltip = false;
  }

  hidePopUp(){
    setTimeout(() => {
      this.showTooltip = false;
    }, 3000);
  }

  nextPage() {
    this.page++;
    this.pageChange.emit(this.page);
  }

  previusPage() {
    if (this.page <= 1) { return; }
    this.page--;
    this.pageChange.emit(this.page);
  }

  getText(text: any) {
    this.page = 1;
    this.typeaheadOnBlur.emit(text);
  }

  search = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(200), distinctUntilChanged());
    const clicksWithClosedPopup$ = this.click$.pipe(filter(() => !this.instance.isPopupOpen()));
    const inputFocus$ = this.focus$;

    return merge(debouncedText$, inputFocus$, clicksWithClosedPopup$).pipe(
      map(term => (term === '' ? this.typeheadModel.states
        : this.typeheadModel.states.filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1)).slice(0, 10))
    );
  }

}
