import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export class DropdownModel {
  label: string;
  data: Array<any>;
  default?;
  disabled?:any = false;
  type?: string;
}
@Component({
  selector: 'stg-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.scss']
})
export class DropdownComponent implements OnInit {
  private _dropdownModelInput = new BehaviorSubject<DropdownModel>(undefined);
  dropdownModel = new DropdownModel();
  constructor() { }

  @Input()
  set dropdownModelInput(value) {
      if (value !== undefined) {
          this._dropdownModelInput.next(value);
      }
  };

  @Output() changeValue = new EventEmitter();

  ngOnInit() {
    this._dropdownModelInput.subscribe(model => {
      this.dropdownModel = model;
      if ( this.dropdownModel.default ) { this.setValue({target: { value: this.dropdownModel.default } } )}
    }, err => console.log(err));
  }

  ngOnDestroy(): void {
    this._dropdownModelInput.unsubscribe();
  }

  setValue(evt) {
    this.changeValue.emit(evt.target.value)
  }

}
