import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CountUpDirective } from './count-up.directive';

describe('CountUpDirective', () => {
  let component: CountUpDirective;
  let fixture: ComponentFixture<CountUpDirective>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CountUpDirective ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CountUpDirective);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
