import { Directive,ElementRef, Input, Output, EventEmitter, OnChanges, SimpleChanges, NgZone, Inject, PLATFORM_ID } from '@angular/core';
import { CountUp, CountUpOptions } from 'countup.js';
import { isPlatformBrowser } from '@angular/common';

@Directive({
	selector: '[countUp]'
})
export class CountUpDirective implements OnChanges {

	countUp: CountUp;
	// the value you want to count to
	@Input('countUp') endVal: number;
	previousEndVal: number;

	@Input() options: CountUpOptions = {};
	@Input() reanimateOnClick = true;
	@Output() complete = new EventEmitter<void>();

	constructor(
		private el: ElementRef,
		private zone: NgZone,
		@Inject(PLATFORM_ID) private platformId: Object,
	) { }

	ngOnChanges(changes: SimpleChanges) {
		if (!isPlatformBrowser(this.platformId)) {
			return;
		}
		if (changes.endVal && changes.endVal.currentValue !== undefined) {
			if (this.previousEndVal !== undefined) {
				this.options = {
					...this.options,
					startVal: this.previousEndVal
				};
			}
			this.countUp = new CountUp(this.el.nativeElement, this.endVal, this.options);
			this.animate();
			this.previousEndVal = this.endVal;
		}
	}

	private animate() {
		this.zone.runOutsideAngular(() => {
			this.countUp.reset();
			this.countUp.start(() => {
				this.zone.run(() => {
					this.complete.emit();
				});
			});
		});
	}
}