import { AfterViewInit, Component, ViewChild, ViewContainerRef } from "@angular/core";
import { ICellEditorAngularComp } from "ag-grid-angular";
import * as moment from "moment";

@Component({
    selector: 'hour-cell',
    template: `<input #input [(ngModel)]="value" type="time" (blur)="onBlurEvent($event)" [disabled]="isDisabled">`
})
export class HourEditor implements ICellEditorAngularComp, AfterViewInit {
    private params: any;
    public value: any;
    parent: any;
    isDisabled = false;
    @ViewChild('input', { read: ViewContainerRef }) public input;

    agInit(params: any): void {
        this.params = params;
        this.parent = this.params.context.componentParent;
        this.isDisabled = params.data.is_redlined == 'Y';
        this.value = (this.params.value !== null && this.params.value !== '' && this.params.value !== undefined) ? moment(this.params.value).format('HH:mm') : '00:00';
    }
    
    getValue(): any {
            let date = moment(this.params.data.work_date).format('YYYY-MM-DD');
        if (this.value) {
            return `${date} ${this.value}`;
        }
        return;
    }

    onBlurEvent(event): void {
        this.parent.gridApi.stopEditing();
    }

    ngAfterViewInit() {
        window.setTimeout(() => {
            this.input.element.nativeElement.select();
        });
    }
}