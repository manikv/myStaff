import { AfterViewInit, Component, ViewChild, ViewContainerRef, OnDestroy } from "@angular/core";
import { ICellEditorAngularComp } from "ag-grid-angular";

@Component({
    selector: 'numeric-cell',
    template: `<input #input (keydown)="onKeyDown($event)" appTwoDigitDecimaNumber appMaxNumber [maxNumber]="maxNumber" [(ngModel)]="value" style="width: 100%" (blur)="onBlurEvent($event)">`
})
export class NumericEditor implements ICellEditorAngularComp, AfterViewInit {
    private params: any;
    public value: number;
    private cancelBeforeStart: boolean = false;
    private validCharacters = ['.', 'Backspace', 'Enter', 'ArrowLeft', 'ArrowRight']
    maxNumber: number;
    parent: any;
    isDisabled = false;
    @ViewChild('input', { read: ViewContainerRef }) public input;

    agInit(params: any): void {
        this.params = params;

        this.parent = this.params.context.componentParent;
        this.value = this.params.value;
        this.cancelBeforeStart = params.charPress && ('1234567890.'.indexOf(params.charPress) < 0);
        this.maxNumber = this.parent.selectedOverrideType.max_value;
        this.isDisabled = params.data.is_redlined == 'Y';
    }

    getValue(): any {
        return this.value;
    }

    isCancelBeforeStart(): boolean {
        return this.cancelBeforeStart;
    }

    onKeyDown(event: KeyboardEvent): void {
        const charCode = this.getCharCodeFromEvent(event);
        const charStr = event.key ? event.key : String.fromCharCode(charCode);
        if (!this.isKeyPressedNumeric(charStr)) {
            if (event.preventDefault) event.preventDefault();
        }
    }

    onBlurEvent(event): void {
        this.parent.gridApi.stopEditing();
    }

    ngAfterViewInit() {
        window.setTimeout(() => {
            this.input.element.nativeElement.select();
        });
    }

    private getCharCodeFromEvent(event): any {
        event = event || window.event;
        return (typeof event.which == "undefined") ? event.keyCode : event.which;
    }

    private isCharNumeric(charStr): boolean {
        return !!/\d/.test(charStr);
    }

    private isKeyPressedNumeric(charStr): boolean {
        return this.isCharNumeric(charStr) || this.validCharacters.includes(charStr);
    }
}