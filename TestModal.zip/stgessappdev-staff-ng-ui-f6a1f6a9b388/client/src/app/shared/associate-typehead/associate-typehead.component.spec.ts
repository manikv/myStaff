import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssociateTypeheadComponent } from './associate-typehead.component';
import { AssociateTypeheadModule } from '@staff/sharedModules/associate-typehead.module';
import { AppModule } from '../../app.module';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('AssociateTypeheadComponent', () => {
  let component: AssociateTypeheadComponent;
  let fixture: ComponentFixture<AssociateTypeheadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        AppModule,
        AssociateTypeheadModule
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
    fixture = TestBed.createComponent(AssociateTypeheadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should getAssociates', () => {
    component.getAssociates();
    expect(component.basicTypeheadModel.states.length).toBeGreaterThanOrEqual(0);
  });
});
