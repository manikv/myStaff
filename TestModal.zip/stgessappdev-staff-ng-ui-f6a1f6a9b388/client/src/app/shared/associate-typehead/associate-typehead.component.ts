import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { TypeheadModel } from '../../shared/common/components/typehead/typehead.component';
import { TeamService } from '../common/services/team.service';
import { Globals } from '../common/global/global.provider';

@Component({
  selector: 'app-associate-typehead',
  templateUrl: './associate-typehead.component.html',
  styleUrls: ['./associate-typehead.component.scss']
})
export class AssociateTypeheadComponent implements OnInit {

  basicTypeheadModel = new TypeheadModel();
  modelInput = '';
  currentPage = '1';
  associates = [];
  resultCount = null;
  susbcription: any;
  @Output() associateSelected = new EventEmitter<any>();

  constructor(private teamService: TeamService, public globals: Globals) { }


  ngOnInit() {
    this.getAssociates();
  }

  getAssociates() {
    const params = this.getParams();

    if (this.susbcription) { this.susbcription.unsubscribe(); }

    this.susbcription = this.teamService.getAssociates(
      params.limit,
      params.page,
      params.sorts,
      params.team_name,
      params.userName,
      this.modelInput
    ).subscribe((response: any) => {
      this.associates = response.data;
      this.resultCount = response.metadata ? response.metadata.resultCount : null;
      const result = response.data.map(item => {
        return item.emp_fullname;
      });
      this.basicTypeheadModel.states = result;
    });
  }

  getParams() {
    return {
      limit: 10,
      page: this.currentPage,
      userName: this.globals.user_name || '',
      team_name: '',
      sorts: ''
    };
  }

  setAssociateSelected(item) {
    const associateId = item.split('-').pop().trim();
    const associate = this.associates.find(x => x.emp_fullname === associateId);
    this.associateSelected.emit(associate);
    this.getEmployees(associate.emp_name);
  }

  setPage(page) {
    this.currentPage = page;
    this.getAssociates();
  }

  getEmployees(text) {
    this.currentPage = '1';
    this.modelInput = text;
    this.getAssociates();
  }

}
