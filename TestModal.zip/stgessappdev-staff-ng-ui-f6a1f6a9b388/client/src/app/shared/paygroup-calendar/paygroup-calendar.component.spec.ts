import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaygroupCalendarComponent } from './paygroup-calendar.component';
import { PaygroupCalendarModule } from '@staff/sharedModules/paygroup-calendar.module';
import { AppModule } from '../../app.module';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('PaygroupCalendarComponent', () => {
  let component: PaygroupCalendarComponent;
  let fixture: ComponentFixture<PaygroupCalendarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        AppModule,
        PaygroupCalendarModule
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
    fixture = TestBed.createComponent(PaygroupCalendarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should create', () => {
    let paygroup = {
      id: 10005,
      name: "FRI-THURS HOURLY",
      description: "Fri-Thurs Hourly",
      start_date: "01/10/2020",
      end_date: "01/16/2020"
    }
    component.changePaygroup(paygroup)
    expect(component.rangeDates.start_date).toEqual(paygroup.start_date);
  });
});
