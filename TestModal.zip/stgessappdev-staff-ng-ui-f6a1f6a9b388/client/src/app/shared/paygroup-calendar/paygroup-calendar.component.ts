import { Component, OnInit, Output, EventEmitter, Input, ViewChild } from '@angular/core';
import { Select2Data } from '../../shared/common/components/select/select2-utils';
import { TeamService } from '../common/services/team.service';
import { Globals } from '../common/global/global.provider';
import { tickStep } from 'd3';
import { DatepickerComponent } from '../common/components/datepicker/datepicker.component';

@Component({
  selector: 'app-paygroup-calendar',
  templateUrl: './paygroup-calendar.component.html',
  styleUrls: ['./paygroup-calendar.component.scss']
})
export class PaygroupCalendarComponent implements OnInit {
  data: Select2Data = [];
  susbcription: any;
  rangeDates: any;
  dayOfTheWeek: string;
  loadingCalendar: boolean = false;
  @ViewChild("enddate") enddate: DatepickerComponent;

  @Input() selectedValues: any;
  @Input() placeholder: string = 'Pay Group';

  @Output() paygroupSelected = new EventEmitter<any>();
  @Output() dateSelected = new EventEmitter<any>();

  constructor(private teamService: TeamService, public globals: Globals) { }

  ngOnInit() {
    //this.getPayGroups();
  }

  update(value: any) {
    this.dateSelected.emit(value);
  }

  changePaygroup(paygroup) {
    this.loadingCalendar = false;
    this.rangeDates = {
      start_date: paygroup.start_date,
      end_date: paygroup.end_date
    }
    this.dayOfTheWeek = this.getDayOfTheWeek(paygroup.end_date);
    this.loadingCalendar = true;
    this.paygroupSelected.emit(paygroup.id);
    this.enddate.setValue(paygroup.end_date);
  }

  getDayOfTheWeek(date) {
    let dateFormatted = new Date(date);
    return dateFormatted.getDay().toString();
  }

  selectDefaultPaygroup(paygroup) {
    this.enddate.setValue(paygroup.end_date);
  }
}
