import { Component } from "@angular/core";

import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
    selector: 'input-cell',
    template: `<a (click)="goToLink()" class="grid-link">{{value}}</a>`,
    styles: [`.grid-link {
        color: #0080a5!important;
        cursor: pointer;
    }`]
})
export class LinkText implements ICellRendererAngularComp {
    public params: any;
    value: any;
    parent: any;

    agInit(params: any): void {
        this.params = params;
        this.value = params.valueFormatted ? params.valueFormatted : params.value;
        this.parent = this.params.context.componentParent;
    }

    refresh(): boolean {
        return false;
    }

    goToLink() {
       this.parent.context.componentParent.linkClicked(this.params.data);
    }
}
