import { Component } from "@angular/core";

import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
    selector: 'refresh-row-cell',
    template: `<i class="fa fa-undo reset-row" aria-hidden="true" (click)="resetRow()" *ngIf="showIcon"></i>`,
    styles: [`i { width: 100%;line-height: normal; height: 100% }`]
})
export class ResetRow implements ICellRendererAngularComp {
    public params: any;
    public showIcon: boolean = false;
    public parent: any;

    agInit(params: any): void {
        this.params = params;
        this.parent = this.params.context.componentParent;
        let selectedAssociates = this.parent.selectedAssociates;
        this.showIcon = (selectedAssociates.find(associate => associate.emp_id == this.params.data.emp_id) && !this.parent.isSubmitting) || (this.parent.selectedAssociates.length > 0  && this.parent.errorRows.length !== 0 );
    }

    public resetRow() {
        this.parent.resetRow(this.params.data, this.params.node)
    }

    refresh(): boolean {
        return false;
    }
}