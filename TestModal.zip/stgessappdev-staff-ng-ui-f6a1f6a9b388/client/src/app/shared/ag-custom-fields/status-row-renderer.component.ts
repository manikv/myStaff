import { Component } from "@angular/core";

import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
    selector: 'status-row-cell',
    template: `<i class="fa fa-spinner fa-pulse" aria-hidden="true" *ngIf="status == 'submitting'"></i>
        <i class="fa fa-check" aria-hidden="true" *ngIf="status == 'submitted'"></i>
        <i class="fa fa-times" aria-hidden="true" *ngIf="status == 'error'"></i>
        <i class="fa fa-exclamation-triangle" aria-hidden="true" *ngIf="status == 'warning'"></i>`,
    styles: [`i { width: 100%;line-height: normal }`,
        `i.fa-check { color: #2e7d32 }`,
        `i.fa-times { color: #d50000 }`,
        `i.fa-exclamation-triangle { color: #ffc107 }`]
})
export class StatusRow implements ICellRendererAngularComp {
    public params: any;
    status: string;

    agInit(params: any): void {
        this.params = params;
        this.status = params.value;
    }

    refresh(): boolean {
        return false;
    }
}