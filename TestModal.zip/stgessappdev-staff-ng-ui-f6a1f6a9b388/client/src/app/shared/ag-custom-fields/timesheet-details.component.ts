import { Component } from "@angular/core";
import {DomSanitizer,SafeResourceUrl,} from '@angular/platform-browser';
import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
    selector: 'timsheet-details',
    template: `<iframe id="timesheet-details" *ngIf="loaded" width="100%" height="260" [src]="url" frameborder="0"></iframe>`,
})
export class TimsheetDetails implements ICellRendererAngularComp {
    public params: any;
    url: SafeResourceUrl;
    loaded: boolean = false;

    agInit(params: any): void {
        this.params = params;
        this.url = this.sanitizer.bypassSecurityTrustResourceUrl('/action/dailytimesheet.action?action=LoadEmployeeAction&EMBEDDED=Y&EMPLOYEE_IDS='+params.data.emp_id+'&START_DATE='+params.data.ts_date+'%20000000&END_DATE='+params.data.ts_date+'%20000000&DATE_SELECTION=7');
        this.loaded = true;
        setTimeout(function(){
            let elStyle = document.createElement('style'),
                framedetails: any = document.getElementById('timesheet-details');
            elStyle.type="text/css"
            elStyle.appendChild(document.createTextNode(".wb_newedit{display:none!important}"));
            framedetails.contentDocument.head.append(elStyle);
            framedetails.contentDocument.addEventListener("click", function($ev){
                console.log($ev.target);
            });
        }, 1000);
    }

    refresh(): boolean {
        return false;
    }

    constructor(public sanitizer:DomSanitizer){}
}