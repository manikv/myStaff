import { Component } from "@angular/core";

import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
    selector: 'input-cell',
	styles: [
		'.disabled { pointer-events: none; cursor-pointer: unset; }'
	],
    template: `
        <span *ngIf="isDisabled">{{value}}</span>
        <div class="input-group mb-3" style="line-height: normal; height: 100%" [ngClass]="{'has-error': hasError}" *ngIf="!isDisabled">
            <input type="text" style="width: 100%" (focus)="selectAllContent($event)" class="ag-cell-edit-input" value={{value}}>
        </div>`
})
export class CustomInput implements ICellRendererAngularComp {
    public params: any;
    value: any;
    hasError: boolean = false;
    parent: any;
    isDisabled = false;

    agInit(params: any): void {
        this.params = params;
        this.parent = this.params.context.componentParent;
        this.value = params.valueFormatted ? params.valueFormatted : params.value;
        this.isDisabled = params.data.is_redlined == 'Y';
        if (this.parent.selectedOverrideType.max_value !== null && this.parent.selectedOverrideType.override_id != 160) {
            if (Number(params.value) > Number(this.parent.selectedOverrideType.max_value)) {
                this.hasError = true;
            }
        }
    }

    refresh(): boolean {
        return false;
    }

    selectAllContent(evt) {
        evt.target.select();
    }
}