import { Component, OnInit, Output, EventEmitter, Input, ViewChild, OnDestroy } from '@angular/core';
import { Select2Data } from '../common/components/select/select2-utils';
import { Globals } from '../common/global/global.provider';
import { SecurityService } from '../common/services/security.service';
import { format } from 'date-fns'
import { Select2 } from '../common/components/select/select2.component';
import { Subscription } from "rxjs";
import { EventsService } from '../common/events/events.service';

@Component({
  selector: 'app-calendar-preset',
  templateUrl: './calendar-preset.component.html'
})
export class CalendarPresetComponent implements OnInit, OnDestroy {
  data: Select2Data = [];
  selectedPaygroup: any;
  private _selectedPaygroupEventSubscription: Subscription = null;
  @ViewChild('stgselect') private stgselect: Select2;
  @Input() selectedValues: any;
  @Input() placeholder: string = 'Pre select option';
  @Input() showDay: any = true;
  @Input() showOnlyCurrentPayweek: any = false;

  @Output() preselectSelected = new EventEmitter<any>();

  constructor(private securityService: SecurityService, public globals: Globals, private eventService: EventsService) { }

  ngOnInit() {
    if(!this.showOnlyCurrentPayweek){
      this.selectedPaygroup = this.globals.staffProfile.paygroup_id;
      this.setPaygroupOptions(this.selectedPaygroup);
      this._selectedPaygroupEventSubscription = this.eventService.selectedPaygroupChange.subscribe((payload) => {
        if (payload !== this.selectedPaygroup) {
          this.selectedPaygroup = payload;
          this.setPaygroupOptions(this.selectedPaygroup);
        }
      });
    }else{
      let _my = this;
      this.data.push({ label: 'Previous Pay Period', value: 'previouspayperiod' });
      setTimeout(function(){_my.stgselect.select({ label: 'Previous Pay Period', value: 'previouspayperiod' }, true, true)}, 200);
    }
  }

  setPaygroupOptions(paygroup_id) {
    this.data = [];
    this.securityService.getReportCalendarPreset(paygroup_id)
      .subscribe((response: any) => {
        let dayArray = [], weekArray = [], monthArray = [];
        response.reverse();
        response.forEach((pre: any) => {
          if (pre.preselect.toUpperCase().split('DAY').length > 1) {
            dayArray.push({ label: pre.preselect, value: pre })
          } else if (pre.preselect.toUpperCase().split('WEEK').length > 1) {
            weekArray.push({ label: pre.preselect, value: pre })
          } else if (pre.preselect.toUpperCase().split('MONTH').length > 1) {
            monthArray.push({ label: pre.preselect, value: pre })
          }
        });
        if (response.length > -1) {
          if (this.showDay) {
            this.data.push({ value: 'WEEK', label: 'WEEK', disabled: true });
            this.data = this.data.concat(weekArray);
            this.data.push({ value: 'MONTH', label: 'MONTH', disabled: true });
            this.data = this.data.concat(monthArray);
            this.data.push({ value: 'DAY', label: 'DAY', disabled: true });
            this.data = this.data.concat(dayArray);
          } else {
            this.data.push({ value: 'WEEK', label: 'WEEK', disabled: true });
            this.data = this.data.concat(weekArray);
            this.data.push({ value: 'MONTH', label: 'MONTH', disabled: true });
            this.data = this.data.concat(monthArray);
          }
        }
        this.data.push({ value: 'CUSTOM', label: 'CUSTOM', disabled: true });
        this.data.push({ label: 'Custom Date', value: 'CUSTOMDATE' });
      }, err => {
        console.log('error  ----> ', err);
      });
  }

  update(value: any) {
    this.preselectSelected.emit(value);
  }

  checkCustomValue(type, date: any) {
    let selectedDate: any = (date ? format(new Date(date.month + '/' + date.day + '/' + date.year), 'MM/DD/YYYY') : null), checkIndex = 0;
    this.data.map((val: any) => {
      if (typeof val.value !== 'string' && val.value[type] === selectedDate) {
        checkIndex++;
      }
    });
    if (checkIndex === 0) {
      this.stgselect.select({ label: 'Custom Date', value: 'CUSTOMDATE' });
    }
  }

  ngOnDestroy() {
    this._selectedPaygroupEventSubscription.unsubscribe();
  }
}