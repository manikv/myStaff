import { Directive, ElementRef, HostListener, Input } from '@angular/core';
import * as _ from 'lodash';

@Directive({
  selector: '[appMaxNumber]'
})
export class MaxNumberDirective {
  isFirst = true;
  constructor(private el: ElementRef) {
  }
  @Input() maxNumber: number;
  private specialKeys: Array<string> = ['End', 'Home', '-', 'ArrowLeft', 'ArrowRight'];
  @HostListener('keydown', ['$event'])
  onKeyDown(event: any) {

    this.maxNumber = _.isNull(this.maxNumber) ? this.maxNumber : _.toNumber(this.maxNumber);

    if (this.specialKeys.indexOf(event.key) !== -1) {
      return;
    }
    
    if (this.maxNumber !== null) {      
      const current = this.el.nativeElement.value;
      const val = this.isFirst ? Number(event.key):Number(current + event.key);
      const target = event.target.parentElement.parentElement.classList;
      if (val > this.maxNumber) {
        target.add('has-error');
      } else {
        target.remove('has-error');
      }
      this.isFirst = false;
    }
  }
}