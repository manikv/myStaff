import { Component, OnInit, Output, EventEmitter, Input, ViewChild } from '@angular/core';
import { Select2Data } from '../../shared/common/components/select/select2-utils';
import { TeamService } from '../common/services/team.service';
import { Globals } from '../common/global/global.provider';
import { EventsService } from '../common/events/events.service';
import { Select2 } from '../common/components/select/select2.component';

@Component({
  selector: 'app-team-multi-typeahead',
  templateUrl: './team-multi-typeahead.component.html',
  styleUrls: ['./team-multi-typeahead.component.scss']
})
export class TeamMultiTypeaheadComponent implements OnInit {
  data: Select2Data = [];
  susbcription: any;
  page: any = 1;
  resultCount = 0;
  identityParam = 'id';
  @ViewChild('stgselect') private stgselect: Select2;

  @Input() selectedValues: any;
  @Input() default: any = null;
  @Input() placeholder: string = 'Home Team';
  @Input() typeaheadInterval?: number = 700;
  @Input() multiple?: boolean = true;
  @Input() complex?: boolean = true;

  @Output() teamSelected = new EventEmitter<any>();
  @Output() updateFullItem = new EventEmitter<any>();

  constructor(private teamService: TeamService, public globals: Globals, private eventsService: EventsService) { }

  ngOnInit() { }

  update(value: any) {
    this.teamSelected.emit(value);
    if (value && value.paygrp_id !== null) {
      this.eventsService.selectedPaygroupChange.publish(value.paygrp_id);
    }
  }

  getFullItem(option){
    this.updateFullItem.emit(option)
  }


  optionsClicked() {
    // show default options when dropdown is clicked
    this.getTeams('');
  }

  changeOfPage(data) {
    this.page = data.page;
    this.getTeams(data.search, false);
  }

  setValue(val, noFocus=false, noEmit=false){
    this.stgselect.select(val, noFocus, noEmit);
  }

  getTeams(query: string, restartPage = true) {
    if (restartPage) { this.page = 1; }

    const params = {
      limit: 10,
      page: this.page,
      userName: this.globals.user_name || '',
      team_name: '',
      sorts: '',
      complex: this.complex.toString()
    };

    if (this.susbcription) { this.susbcription.unsubscribe(); }

    this.susbcription = this.teamService.getTeamsData(
      params.limit,
      params.page,
      params.sorts,
      params.team_name,
      params.userName,
      query,
      params.complex
    ).subscribe((response: any) => {
      let selectedData = [];
      this.resultCount = response && response.metadata ? response.metadata.resultCount : 0;
      if (this.resultCount > 0) {
        response.data.forEach(team => selectedData.push({ label: team.team_name + ' - ' + team.team_desc, value: team }));
        this.data = selectedData;
      } else {
        this.data = [];
      }
    }, err => {
      console.log('error  ----> ', err);
    });
  }
}
