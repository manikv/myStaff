import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TeamMultiTypeaheadComponent } from './team-multi-typeahead.component';

describe('TeamMultiTypeaheadComponent', () => {
  let component: TeamMultiTypeaheadComponent;
  let fixture: ComponentFixture<TeamMultiTypeaheadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TeamMultiTypeaheadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TeamMultiTypeaheadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
