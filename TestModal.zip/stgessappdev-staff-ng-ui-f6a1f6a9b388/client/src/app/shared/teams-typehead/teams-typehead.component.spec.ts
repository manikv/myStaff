import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TeamsTypeheadComponent } from './teams-typehead.component';

describe('TeamsTypeheadComponent', () => {
  let component: TeamsTypeheadComponent;
  let fixture: ComponentFixture<TeamsTypeheadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TeamsTypeheadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TeamsTypeheadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
