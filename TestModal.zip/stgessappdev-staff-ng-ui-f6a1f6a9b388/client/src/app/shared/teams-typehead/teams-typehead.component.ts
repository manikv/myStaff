import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { TypeheadModel } from '../../shared/common/components/typehead/typehead.component';
import { TeamService } from '../common/services/team.service';

@Component({
  selector: 'app-teams-typehead',
  templateUrl: './teams-typehead.component.html',
  styleUrls: ['./teams-typehead.component.scss']
})
export class TeamsTypeheadComponent implements OnInit {

  basicTypeheadModel = new TypeheadModel();
  modelInput = '';
  currentPage = '1';
  teams = [];
  resultCount = null;
  susbcription: any;
  
  constructor(private teamService: TeamService){}

  @Output() teamSelected = new EventEmitter<any>();

  ngOnInit() {
    this.getTeams();
  }

  getTeams() {
    if (this.susbcription) { this.susbcription.unsubscribe(); }

    this.susbcription = this.teamService.getTeams(this.currentPage, this.modelInput)
    .subscribe((response: any) => {
      this.teams = response.data;
      this.resultCount = response.metadata ? response.metadata.resultCount : null;
      const result = response.data.map(item => {
        return  item.team_name;
      });
      this.basicTypeheadModel.states = result;
    });
  }

  setTeamSelected(item) {
    this.modelInput = item;
    const team = this.teams.find(x => x.team_name === item);
    this.teamSelected.emit(team);
    this.getTeams();
  }

  setPage(page) {
    this.currentPage = page;
    this.getTeams();
  }

  getTeamsInfo(text) {
    this.currentPage = '1';
    this.modelInput = text;
    this.getTeams();
  }
}
