import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OddEvenTeamComponent } from './odd-even-team-dropdown.component';
import  { PaygroupDropdownModule} from '@staff/sharedModules/paygroup-dropdown.module';
import { AppModule } from '../../app.module';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('OddEvenTeamComponent', () => {
  let component: OddEvenTeamComponent;
  let fixture: ComponentFixture<OddEvenTeamComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        AppModule,
        PaygroupDropdownModule
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
    fixture = TestBed.createComponent(OddEvenTeamComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
