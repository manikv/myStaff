import { Component, OnInit, Output, EventEmitter, Input, ViewChild, AfterViewInit } from '@angular/core';
import { Select2Data } from '../common/components/select/select2-utils';
import { Select2 } from '../common/components/select/select2.component';
import { Subscription } from "rxjs";

@Component({
  selector: 'app-odd-even-team-dropdown',
  templateUrl: './odd-even-team-dropdown.component.html'
})
export class OddEvenTeamComponent implements AfterViewInit{
  data: Select2Data = [{ label:"ODD Location(s)", value: "ODD" },{ label:"EVEN Location(s)", value: "EVEN" }];
  susbcription: any;
  selectedPaygroup: any;
  @ViewChild('stgselect') private stgselect: Select2;

  @Input() selectedValues: any;
  @Input() placeholder: string = 'Select Location(s)';
  @Output() teamSelected = new EventEmitter<any>();

  ngAfterViewInit(){
    let _my = this;
    setTimeout(function(){_my.stgselect.select({ label:"ODD Location(s)", value: "ODD" })}, 200);
  }

  update(value: any) {
    this.teamSelected.emit(value);
  }
}
