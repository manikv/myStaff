import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Select2Module } from '../common/components/select/select2.module';


import { AssociateMultiTypeaheadComponent } from '../associate-multi-typeahead/associate-multi-typeahead.component';

@NgModule({
  declarations: [
    AssociateMultiTypeaheadComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    Select2Module
  ],
  exports: [
    AssociateMultiTypeaheadComponent
  ]
})
export class AssociateMultiTypeheadModule { }
