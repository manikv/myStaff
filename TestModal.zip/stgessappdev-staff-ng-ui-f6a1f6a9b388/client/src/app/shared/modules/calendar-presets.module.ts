import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { CalendarPresetComponent } from '../calendar-preset/calendar-preset.component';
import { Select2Module } from '../common/components/select/select2.module';

@NgModule({
  declarations: [
    CalendarPresetComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    Select2Module
  ],
  exports: [
    CalendarPresetComponent
  ]
})
export class CalendarPresetModule { }
