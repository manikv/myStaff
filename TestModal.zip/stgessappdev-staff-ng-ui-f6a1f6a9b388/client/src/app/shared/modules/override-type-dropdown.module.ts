import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Select2Module } from '../common/components/select/select2.module';

import { OverrideTypeDropdownComponent } from '../override-type-dropdown/override-type.component';

@NgModule({
  declarations: [
    OverrideTypeDropdownComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    Select2Module
  ],
  exports: [
    OverrideTypeDropdownComponent
  ]
})
export class OverrideTypeDropdownModule { }
