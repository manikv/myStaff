import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { AssociateTypeheadComponent } from '../associate-typehead/associate-typehead.component';
import { TypeheadModule } from '../common/components/typehead/typehead.module';

import { Select2Module } from '../common/components/select/select2.module';

@NgModule({
  declarations: [
    AssociateTypeheadComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    TypeheadModule,
    Select2Module
  ],
  exports: [
    AssociateTypeheadComponent
  ]
})
export class AssociateTypeheadModule { }
