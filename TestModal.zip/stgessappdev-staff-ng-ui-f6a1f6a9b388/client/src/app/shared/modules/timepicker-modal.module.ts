import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TimepickerModule } from '../timepicker/timepicker.module';

// import { TimepickerModalComponent } from '../timepicker-modal/timepicker-modal.component';

@NgModule({
  declarations: [
    // TimepickerModalComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    TimepickerModule
  ],
  exports: [
    // TimepickerModalComponent
  ]
})
export class TimepickerModalModule { }
