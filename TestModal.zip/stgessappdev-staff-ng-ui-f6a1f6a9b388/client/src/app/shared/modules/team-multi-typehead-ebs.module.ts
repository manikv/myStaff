import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Select2Module } from '../common/components/select/select2.module';

import { TeamMultiTypeaheadEbsComponent } from '../team-multi-typeahead-ebs/team-multi-typeahead-ebs.component';

@NgModule({
  declarations: [
    TeamMultiTypeaheadEbsComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    Select2Module
  ],
  exports: [
    TeamMultiTypeaheadEbsComponent
  ]
})
export class TeamMultiTypeaheadEbsModule { }
