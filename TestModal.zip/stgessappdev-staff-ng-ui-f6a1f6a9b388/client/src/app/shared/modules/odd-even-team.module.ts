import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OddEvenTeamComponent } from '../odd-even-team/odd-even-team-dropdown.component';
import { Select2Module } from '../common/components/select/select2.module';

@NgModule({
  declarations: [
    OddEvenTeamComponent
  ],
  imports: [
    CommonModule,
    Select2Module
  ],
  exports: [
    OddEvenTeamComponent
  ]
})
export class OddEvenTeamModule { }
