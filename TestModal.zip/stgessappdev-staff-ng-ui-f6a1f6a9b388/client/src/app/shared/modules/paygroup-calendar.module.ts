import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ClickOutsideModule } from 'ng-click-outside';
import { DatepickerModule } from '../common/components/datepicker/datepicker.module';
import { PaygroupCalendarComponent } from '../paygroup-calendar/paygroup-calendar.component';
import { PaygroupDropdownModule } from './paygroup-dropdown.module';

@NgModule({
  declarations: [
      PaygroupCalendarComponent,
    ],
  imports: [
    CommonModule,
    FormsModule,
    NgbModule,
    ClickOutsideModule,
    DatepickerModule,
    PaygroupDropdownModule
  ],
  exports: [PaygroupCalendarComponent]
})
export class PaygroupCalendarModule { }
