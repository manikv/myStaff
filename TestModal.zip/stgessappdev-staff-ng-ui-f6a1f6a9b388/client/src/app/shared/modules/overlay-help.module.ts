import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OverlayHelpComponent } from '../overlay-help/overlay-help.component';

@NgModule({
  declarations: [
    OverlayHelpComponent
  ],
  imports: [
    CommonModule,
  ],
  exports: [
    OverlayHelpComponent
  ]
})
export class OverlayHelpModule { }
