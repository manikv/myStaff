import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { TeamsTypeheadComponent } from '../teams-typehead/teams-typehead.component';
import { TypeheadModule } from '../common/components/typehead/typehead.module';

@NgModule({
  declarations: [
    TeamsTypeheadComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    TypeheadModule
  ],
  exports: [
    TeamsTypeheadComponent
  ]
})
export class TeamTypeaheadModule { }
