import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Select2Module } from '../common/components/select/select2.module';

import { OverrideNamesDropdownComponent } from '../override-names-dropdown/override-names-dropdown.component';

@NgModule({
  declarations: [
    OverrideNamesDropdownComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    Select2Module
  ],
  exports: [
    OverrideNamesDropdownComponent
  ]
})
export class OverrideNamesDropdownModule { }
