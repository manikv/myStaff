export class TeamLocationModel {
    active: boolean;
    address1: string;
    address2: string;
    attendance_attributes: {
        geo_fence_radius: number;
        primary_location: boolean;
    }
    city: string;
    country: string;
    location_code: string;
    location_description: null
    location_name: string;
    longitude_latitude: string;
    state: string;
    type: string;
    zip: string;
    constructor(){
        this.active = false;
        this.location_name = '';
        this.address1 = '';
        this.attendance_attributes = {
            geo_fence_radius: 0,
            primary_location: false
        };
    }
};