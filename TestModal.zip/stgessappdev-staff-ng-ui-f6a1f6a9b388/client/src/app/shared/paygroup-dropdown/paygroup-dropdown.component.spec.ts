import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaygroupDropdownComponent } from './paygroup-dropdown.component';
import  { PaygroupDropdownModule} from '@staff/sharedModules/paygroup-dropdown.module';
import { AppModule } from '../../app.module';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('PaygroupDropdownComponent', () => {
  let component: PaygroupDropdownComponent;
  let fixture: ComponentFixture<PaygroupDropdownComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        AppModule,
        PaygroupDropdownModule
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
    fixture = TestBed.createComponent(PaygroupDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should getPayGroups', () => {
    component.getPayGroups();
    expect(component.data.length).toBeGreaterThanOrEqual(0);
  });
});
