import { Component, OnInit, Output, EventEmitter, Input, ViewChild } from '@angular/core';
import { Select2Data } from '../../shared/common/components/select/select2-utils';
import { TeamService } from '../common/services/team.service';
import { Globals } from '../common/global/global.provider';
import { Select2 } from '../common/components/select/select2.component';
import { EventsService }  from '../common/events/events.service';
import { Subscription } from "rxjs";

@Component({
  selector: 'app-paygroup-dropdown',
  templateUrl: './paygroup-dropdown.component.html'
})
export class PaygroupDropdownComponent implements OnInit {
  data: Select2Data = [];
  susbcription: any;
  private _selectedPaygroupEventSubscription: Subscription = null;
  selectedPaygroup: any;
  @ViewChild('stgselect') private stgselect: Select2;

  @Input() selectedValues: any;
  @Input() placeholder: string = 'Pay Groups';
  @Input() showAllOption: any = false;
  @Output() paygroupSelected = new EventEmitter<any>();

  constructor(private teamService: TeamService, public globals: Globals, private eventService: EventsService) { }

  ngOnInit() {
    this.selectedPaygroup = this.globals.staffProfile.paygroup_id;
    this.getPayGroups();
    this._selectedPaygroupEventSubscription = this.eventService.selectedPaygroupChange.subscribe((payload) => {
      if(payload !== this.selectedPaygroup){
        this.selectedPaygroup = payload;
        this.selectPaygroup(this.selectedPaygroup);
      }
    });
  }

  selectPaygroup(paygroup){
    this.data.map((pay: any)=>{
      if(pay.value.id === paygroup){
        this.stgselect.select(pay);
        this.paygroupSelected.emit(pay.value);
      }
    });    
  }

  update(value: any) {
    this.paygroupSelected.emit(value);
  }

  getPayGroups() {
    if (this.susbcription) {
      this.susbcription.next();
    }
    this.susbcription = this.teamService.getPayGroups()
      .subscribe((response: any) => {
        let selectedData = [], defaultPaygroup: any;
        if(this.showAllOption){
          selectedData.push({label: 'All', value: {id:""}})
        }
        response.forEach((paygroup, i) => {
          selectedData.push({ label: paygroup.description, value: paygroup});
          defaultPaygroup = this.globals.staffProfile.paygroup_id === paygroup.id ? paygroup : defaultPaygroup;
        });
        if (selectedData.length > -1) {
          this.data = selectedData;
          let _my = this;
          if(this.showAllOption){
            setTimeout(() => {
              _my.stgselect.select({ label: 'All', value: {id:""}});
            }, 100);
          }else{
            setTimeout(() => {
              _my.stgselect.select({ label: defaultPaygroup.description, value: defaultPaygroup});
              setTimeout(() => {
                _my.paygroupSelected.emit(defaultPaygroup);
              },100);
            }, 100);
          }
        }
      }, err => {
        console.log('error  ----> ', err);
      });
    let selectedData = [];
    if(this.showAllOption){
      selectedData.push({label: 'All', value: {id:""}})
    }
    this.data.forEach(paygroup => selectedData.push(paygroup));
    if (selectedData.length > -1) {
      this.data = selectedData;
    }
  }
}
