import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { Select2Data } from '../../shared/common/components/select/select2-utils';
import { TeamService } from '../common/services/team.service';
import { Globals } from '../common/global/global.provider';

@Component({
  selector: 'app-balances-dropdown',
  templateUrl: './balances-dropdown.component.html'
})
export class BalancesDropdownComponent implements OnInit {
  data: Select2Data = [];
  susbcription: any;

  @Input() selectedValues: any;
  @Input() placeholder: string = 'Balance option';
  @Input() typeaheadInterval?: number = 700;

  @Output() balancesSelected = new EventEmitter<any>();

  constructor(private teamService: TeamService, public globals: Globals) { }

  ngOnInit() {
    //this.getTeams('');
    this.getBalances('');
  }

  update(value: any) {
    // this.selectedValues = value;
    // this.teamSelected.emit(this.selectedValues);
    this.balancesSelected.emit(value);
  }

  optionsClicked() {
    //show default options when dropdown is clicked
    //this.getBalances('');
  }

  getBalances(query: string) {

    if (this.susbcription) { this.susbcription.next(); }

    this.susbcription = this.teamService.getBalancesTypesData()
      .subscribe((response: any) => {
        let selectedData = [];
        response.forEach(balance => selectedData.push({ label: balance.name, value: balance }));
        if (selectedData.length > -1) { this.data = selectedData; }
      }, err => {
        console.log('error  ----> ', err);
      });
  }

}
