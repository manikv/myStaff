import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BalancesDropdownComponent } from './balances-dropdown.component';
import { BalancesDropdownModule} from '@staff/sharedModules/balances-dropdown.module';
import { AppModule } from '../../app.module';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('BalancesDropdownComponent', () => {
  let component: BalancesDropdownComponent;
  let fixture: ComponentFixture<BalancesDropdownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        AppModule,
        BalancesDropdownModule
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
    fixture = TestBed.createComponent(BalancesDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should getBalances', () => {
    component.getBalances('');
    expect(component.data.length).toBeGreaterThanOrEqual(0);
  });
});
