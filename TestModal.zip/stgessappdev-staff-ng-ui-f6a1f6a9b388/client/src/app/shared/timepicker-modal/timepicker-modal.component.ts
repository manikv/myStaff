import { Component, Input } from '@angular/core';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import * as moment from "moment";
import * as _ from "lodash";

@Component({
	templateUrl: './timepicker-modal.component.html',
	styles: [
		'.error { font-size: .5rem; color: red; }'
	]
})
export class TimepickerModalComponent {
	starttime: any = {hour: 8, minute: 0};
	endtime: any = {hour: 17, minute: 0};
	meridian = true;
	constructor(public activeModal: NgbActiveModal) { }

	isAddDisabled() {
		return this.validateEndTime();

	}

	validateEndTime() {
		let startTime = moment(this.starttime.hour + ':' + this.starttime.minute, 'HH:mm');
		let endTime = moment(this.endtime.hour + ':' + this.endtime.minute, 'HH:mm');
		if (startTime.format('HH:mm') === endTime.format('HH:mm')) {
			return true;
		} else {
			return endTime.isBefore(startTime);
		}
	}

	closeModal() {
		this.activeModal.close({
			start_time: moment(this.starttime.hour + ':' + this.starttime.minute, 'HH:mm'),
			end_time: moment(this.endtime.hour + ':' + this.endtime.minute, 'HH:mm'),
		});
	}
}