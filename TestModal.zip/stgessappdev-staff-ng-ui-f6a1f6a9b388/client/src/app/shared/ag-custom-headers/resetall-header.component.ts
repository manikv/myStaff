import { Component } from '@angular/core';

@Component({
    selector: 'app-loading-overlay',
    template: `<i class="fa fa-undo" aria-hidden="true" (click)="resetRow()" *ngIf="showIcon"></i>`,
    styles: [`i { width: 100%;line-height: normal; height: 100% }`]
})
export class ResetAllHeader {
    private params: any;
    private parent: any;
    showIcon: boolean;

    agInit(params): void {
        this.params = params;
        this.parent = this.params.context.componentParent
        this.showIcon = (this.parent.selectedAssociates.length > 0 && !this.parent.isSubmitting) || (this.parent.selectedAssociates.length > 0  && this.parent.errorRows.length !== 0 );
    }

    public resetRow() {
        this.parent.resetAllRows();
    }
}