import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { Select2Data } from '../../shared/common/components/select/select2-utils';
import { TeamService } from '../common/services/team.service';
import { Globals } from '../common/global/global.provider';
@Component({
  selector: 'app-associate-multi-typeahead',
  templateUrl: './associate-multi-typeahead.component.html',
  styleUrls: ['./associate-multi-typeahead.component.scss']
})

export class AssociateMultiTypeaheadComponent implements OnInit {

  data: Select2Data = [];
  susbcription: any;
  page: any = 1;
  resultCount = 0;
  identityParam = 'emp_name';

  @Input() selectedValues: any;

  @Input() placeholder: string = 'Associate';
  @Input() multiple: any = true;

  @Input() typeaheadInterval?: number = 500;

  @Output() associateSelected = new EventEmitter<any>();


  constructor(private teamService: TeamService, public globals: Globals) { }

  ngOnInit() { }

  update(value: any) {
    this.associateSelected.emit(value);
  }

  changeOfPage(data) {
    this.page = data.page;
    this.getAssociates(data.search, false);
  }

  optionsClicked() {
    // show default options when dropdown is clicked
    this.getAssociates('');
  }

  getAssociates(query: string, restartPage = true) {
    if (restartPage) { this.page = 1; }

    const limit = 10, page = this.page, user_name = this.globals.user_name || '', team_name = '', sorts = '';

    if (this.susbcription) { this.susbcription.unsubscribe(); }

    this.susbcription = this.teamService.getAssociates(limit, page, sorts, team_name, user_name, query)
      .subscribe((response: any) => {
        let assocData = [];
        this.resultCount = response.metadata ? response.metadata.resultCount : 0;
        if (this.resultCount > 0) {
          response.data.forEach(employee => {
            assocData.push({ label: employee.emp_fullname + ' - ' + employee.emp_name, value: employee });
          });
          this.data = assocData;
        } else {
          this.data = [];
        }
      });
  }

}
