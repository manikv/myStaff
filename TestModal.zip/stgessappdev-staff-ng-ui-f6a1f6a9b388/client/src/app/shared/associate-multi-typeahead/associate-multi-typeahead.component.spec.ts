import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssociateMultiTypeaheadComponent } from './associate-multi-typeahead.component';
import { AppModule } from '../../app.module';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { APP_BASE_HREF } from '@angular/common';
import {AssociateMultiTypeheadModule} from '@staff/sharedModules/associate-multi-typehead.module';

describe('AssociateMultiTypeaheadComponent', () => {
  let component: AssociateMultiTypeaheadComponent;
  let fixture: ComponentFixture<AssociateMultiTypeaheadComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        AppModule,
        AssociateMultiTypeheadModule
      ],
      declarations: [AssociateMultiTypeaheadComponent],
      providers: [
        { provide: APP_BASE_HREF, useValue: '/' }
      ],
    })
    .compileComponents();
    fixture = TestBed.createComponent(AssociateMultiTypeaheadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    console.log('beforeEach')
  });

  it('should create', () => {
    console.log('create')
    expect(component).toBeTruthy();
  });

  it('should test getAssociates function', () => {
    console.log('getAssociates')
    let query = 'Man';
    component.getAssociates(query);
    expect(component.data.length).toBeGreaterThan(0);
  });
});
