import { Component, OnInit, Output, EventEmitter, Input, ViewChild, ViewEncapsulation } from '@angular/core';
import { Select2Data } from '../common/components/select/select2-utils';
import { TeamEbsService } from '../common/services/team-ebs.service';
import { Globals } from '../common/global/global.provider';
import { EventsService } from '../common/events/events.service';
import { Select2 } from '../common/components/select/select2.component';

@Component({
  selector: 'app-team-multi-typeahead-ebs',
  templateUrl: './team-multi-typeahead-ebs.component.html',
  styleUrls: ['./team-multi-typeahead-ebs.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TeamMultiTypeaheadEbsComponent implements OnInit {
  data: Select2Data = [];
  susbcription: any;
  page: any = 1;
  resultCount = 0;
  identityParam = 'id';
  @ViewChild('stgselect') private stgselect: Select2;

  @Input() selectedValues: any;
  @Input() default: any = null;
  @Input() placeholder: string = 'Home Team';
  @Input() typeaheadInterval?: number = 700;
  @Input() multiple?: boolean = true;
  @Input() complex?: boolean = true;
  // @Input() hierarchy_id?: any = null;
  @Input() filterType?: any = null;


  @Output() teamSelected = new EventEmitter<any>();
  @Output() updateFullItem = new EventEmitter<any>();

  constructor(private teamService: TeamEbsService, public globals: Globals, private eventsService: EventsService) { }

  ngOnInit() { }

  update(value: any) {
    this.teamSelected.emit(value);
    if (value && value.paygrp_id !== null) {
      this.eventsService.selectedPaygroupChange.publish(value.paygrp_id);
    }
  }

  getFullItem(option){
    this.updateFullItem.emit(option)
  }


  optionsClicked() {
    // show default options when dropdown is clicked
    this.getTeams('');
  }

  changeOfPage(data) {
    this.page = data.page;
    this.getTeams(data.search, false);
  }

  setValue(val, noFocus=false, noEmit=false){
    this.stgselect.select(val, noFocus, noEmit);
  }

  getTeams(query: string, restartPage = true) {
    if (restartPage) { this.page = 1; }
    const params = {
      limit: 100,
      page: this.page,
      userName: this.globals.user_name || '',
      team_name: query,
      sorts: '',
      complex: this.complex.toString()
    };

    if (this.susbcription) { this.susbcription.unsubscribe(); }

    this.susbcription = this.teamService.getTeamsData(
      params.limit,
      params.page,
      params.sorts,
      params.team_name,
      params.userName,
      query,
      params.complex
    ).subscribe((response: any) => {
      let selectedData = [];
      this.resultCount = response && response.metadata ? response.metadata.result_count : 0;
      if (this.resultCount > 0) {
        response.data.forEach(team => selectedData.push({ label: team.team_name + ' - ' + team.team_desc, value: team }));
        if (this.filterType) {
          //selectedData = selectedData.filter(v => v.value['hierarchy_id'] === this.hierarchy_id);
          selectedData = selectedData.filter(v => v.value['team_type'] === this.filterType);
        }
        this.data = selectedData;
      } else {
        this.data = [];
      }
    }, err => {
      console.log('error  ----> ', err);
    });
  }
}
