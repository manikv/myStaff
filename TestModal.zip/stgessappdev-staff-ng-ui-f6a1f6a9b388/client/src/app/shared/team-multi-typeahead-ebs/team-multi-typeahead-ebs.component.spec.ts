import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TeamMultiTypeaheadEbsComponent } from './team-multi-typeahead-ebs.component';

describe('TeamMultiTypeaheadEbsComponent', () => {
  let component: TeamMultiTypeaheadEbsComponent;
  let fixture: ComponentFixture<TeamMultiTypeaheadEbsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TeamMultiTypeaheadEbsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TeamMultiTypeaheadEbsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
