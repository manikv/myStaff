import {Component, EventEmitter, Input, OnInit, Output, ViewChild } from "@angular/core";
import {Select2Data} from "../common/components/select/select2-utils";
import {TeamService} from "../common/services/team.service";
import {Globals} from "../common/global/global.provider";
import { Select2 } from '../common/components/select/select2.component';

@Component({
  selector: 'app-override-names-dropdown',
  templateUrl: './override-names-dropdown.component.html'
})

export class OverrideNamesDropdownComponent implements OnInit {
  data: Select2Data = [];
  subscription: any;
  @ViewChild('stgselect') private stgselect: Select2;

  @Input() selectedValues: any;
  @Input() placeholder: string = 'Override Name';
  @Input() typeaheadInterval?: number = 700;
  @Input() showAllOption: any = false;
  @Output() overridenameSelected = new EventEmitter<any>();

  constructor(private teamService: TeamService, public globals: Globals) { }


  ngOnInit() {
    this.getOverrideNames('');
  }

  getOverrideNames( query: string){
    if (this.subscription) { this.subscription.next(); }

    this. subscription =  this.teamService.getOverrideNamesData()
      .subscribe((response: any) => {
        let selectedData = [];
        if(this.showAllOption){
          selectedData.push({label: 'All', value: ""})
        }
        response.forEach(ovrname => selectedData.push({label: ovrname.ovr_typ_name, value: ovrname}));
        if ( selectedData.length > -1 ) { this.data = selectedData;}
        if(this.showAllOption){
          let _my = this;
          setTimeout(() => {
            _my.stgselect.select({ label: 'All', value: ""});
          }, 100);
        }
      }, err => {
        console.log('error  ----> ', err);
      });

  }

  update(value: any) {
    this.overridenameSelected.emit(value);
  }


}
