import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { Select2Data } from '../../shared/common/components/select/select2-utils';
import { TeamService } from '../common/services/team.service';
import { Globals } from '../common/global/global.provider';

@Component({
  selector: 'app-location-dropdown',
  templateUrl: './location-dropdown.component.html',
  styleUrls: ['./location-dropdown.component.scss']
})
export class LocationDropdownComponent implements OnInit {

  data: Select2Data = [];
  susbcription: any;

  @Input() selectedValue: any;
  @Input() placeholder: string = 'Balance option';
  //@Input() typeaheadInterval?: number = 700;

  @Output() selectedLocation = new EventEmitter<any>();

  constructor(private teamService: TeamService, public globals: Globals) { }

  ngOnInit() {
    //this.getLocations('');
   this.getTeamLocations('6336');
  }

  update(value: any) {
    this.selectedLocation.emit(value);
  }

  optionsClicked() {
    //show default options when dropdown is clicked
    //this.getBalances('');
  }

  getLocations(query: string) {

    if (this.susbcription) { this.susbcription.next(); }

    this.susbcription = this.teamService.getBalancesTypesData()
      .subscribe((response: any) => {
        let selectedData = [];
        response.forEach(balance => selectedData.push({ label: balance.name, value: balance }));
        if (selectedData.length > -1) { this.data = selectedData; }
      }, err => {
        console.log('error  ----> ', err);
      });
  }

  isActive(element, index, array) { 
    return (element.active && !element.attendance_attributes.primary_location); 
  }

  getTeamLocations(teamName){
    this.teamService.getTeamAllLocationsServer(teamName).subscribe(
    locRes=>{
        this.data = locRes['data'].filter(this.isActive);
    });
  }

}
