import { Component, OnInit, Output, EventEmitter, Input, ViewChild } from '@angular/core';
import { Select2Data } from '../../shared/common/components/select/select2-utils';
import { EventBaseScheduleService } from '../common/services/ebs.service';
import { Globals } from '../common/global/global.provider';
import * as _ from 'lodash';
import { Select2 } from '../common/components/select/select2.component';

@Component({
  selector: 'app-template-type-dropdown',
  templateUrl: './template-type.component.html'
})
export class TemplateTypeComponent implements OnInit {
  data: Select2Data = [];
  susbcription: any;
  
  @ViewChild('stgselect', { static: false }) private stgselect: Select2;

  @Input() selectedValues: any;
  @Input() placeholder: string = 'Template Types';
  @Input() typeaheadInterval?: number = 700;

  @Output() templateTypeSelected = new EventEmitter<any>();

  
  constructor(private ebsService: EventBaseScheduleService, public globals: Globals) { }

  ngOnInit() {
    this.getTemplateTypes();
  }

  update(value: any) {
    this.templateTypeSelected.emit(value);
  }

  setValue(val){
    this.stgselect.select(val, false, true);
  }

  getTemplateTypes() {
    
    if (this.susbcription) { this.susbcription.next(); }

    this.susbcription = this.ebsService.getEventTypeData()
      .subscribe((response: any) => {
        let selectedData = [];
        response.forEach(templateType => selectedData.push({ label: templateType.template_type_name, value: templateType }));
        
        if (selectedData.length > -1) { 
          this.data = selectedData;           
        }
      }, err => {
        console.log('error  ----> ', err);
      });
  }

}
