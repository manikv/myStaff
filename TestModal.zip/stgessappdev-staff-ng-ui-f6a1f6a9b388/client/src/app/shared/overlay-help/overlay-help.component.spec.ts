import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OverlayHelpComponent } from './overlay-help.component';
import  { OverlayHelpModule} from '@staff/sharedModules/overlay-help.module';
import { AppModule } from '../../app.module';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('OverlayHelpComponent', () => {
  let component: OverlayHelpComponent;
  let fixture: ComponentFixture<OverlayHelpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        AppModule,
        OverlayHelpModule
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
    fixture = TestBed.createComponent(OverlayHelpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OverlayHelpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

});
