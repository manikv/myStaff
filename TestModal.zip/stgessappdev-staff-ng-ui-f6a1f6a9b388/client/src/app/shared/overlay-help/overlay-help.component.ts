import { Component, OnInit, Input  } from '@angular/core';

@Component({
  selector: 'app-overlay-help',
  templateUrl: './overlay-help.component.html',
  styleUrls: ['./overlay-help.component.scss']
  
})
export class OverlayHelpComponent implements OnInit{
  private helpShow: boolean = false;
  helpStop: boolean = false;
  @Input() name: string;
  @Input() helpContent: any;
  @Input()
  set blinkHelp(value) {
    this.helpShow = true;
    let _my = this;
    setTimeout(function(){_my.helpShow = false}, 7000);
  }
  
  ngOnInit(){
    let helpShowCount = Number(localStorage.getItem(this.name))||0;
    if(helpShowCount>2){
      this.helpStop = true;
    }
    localStorage.setItem(this.name, (helpShowCount+1).toString())
  }
}
