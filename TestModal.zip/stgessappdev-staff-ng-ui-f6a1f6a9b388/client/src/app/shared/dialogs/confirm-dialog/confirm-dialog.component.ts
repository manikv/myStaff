import { Component, Input, Output, EventEmitter } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
    selector: 'ngbd-modal-content',
    templateUrl: './confirm-dialog.component.html'
})
export class ConfirmDialog {
    @Input() config;
    @Output() res: EventEmitter<any> = new EventEmitter();;

    constructor(public activeModal: NgbActiveModal) { }

    confirm() {
        this.res.emit(true);
        this.activeModal.close();
    }

    cancel() {
        this.res.emit(false);
        this.activeModal.close();
    }
}