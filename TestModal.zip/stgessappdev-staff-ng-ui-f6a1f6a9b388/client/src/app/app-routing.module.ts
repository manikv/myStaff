import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: 'maintenance',
    loadChildren: () => import('./maintenance-forms/maintenance-forms.module').then(m => m.MaintenanceFormsModule)
  },
  {
    path: 'home',
    loadChildren: () => import('./homepage/homepage.module').then(m => m.HomepageModule)
  },
  {
    path: 'reporting',
    loadChildren: () => import('./reporting/reporting.module').then(m => m.ReportingModule)
  },
  {
    path: 'timesheet',
    loadChildren: () => import('./timesheets/timesheet.module').then(m => m.TimesheetModule)
  },
  {
    path: 'pto',
    loadChildren: () => import('./pto/pto.module').then(m => m.PtoModule)
  },
  {
    path: 'ebs/events',
    loadChildren: () => import('./ebs/events/events.module').then(m => m.EventsModule)
  },
  {
    path: 'ebs/templates',
    loadChildren: () => import('./ebs/templates/templates.module').then(m => m.TemplatesModule)
  },
  {
    path: 'schedule',
    loadChildren: () => import('./scheduling/scheduling.module').then(m => m.SchedulingModule)
  },
  {
    path: 'availability',
    loadChildren: () => import('./availability/availability.module').then(m => m.AvailabilityModule)
  },
  {
    path: '',
    redirectTo: 'maintenance',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
