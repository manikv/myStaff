import { Component, OnInit, Input } from '@angular/core';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { BurstService } from '../../shared/common/services/burst.service';
import Swal from 'sweetalert2';
import * as moment from 'moment';
import { AlertComponent } from 'app/reporting/common/reporting.component';

@Component({
  selector: 'app-booking-details',
  templateUrl: './booking-details.component.html',
  styleUrls: ['./booking-details.component.scss']
})
export class BookingDetailsComponent implements OnInit {

  @Input() item: any;
  @Input() btnLoadingArray: any;

  selectedItem: any;
  totalScheduled: any = 0;
  openPositions: any = 0;
  filledPositions: any = 0;
  procesing: any = false;
  is_approaching_ot: boolean = false;
  isPositionFilled: boolean = false;

  constructor(
    private modalService: NgbModal,
    public activeModal: NgbActiveModal,
    private burstService: BurstService
  ) { }

  ngOnInit() {
    this.selectedItem = { ...this.item };
    this.selectedItem.requestedOn = moment(this.selectedItem.employeeResponseDate).format('MM/DD/YYYY h:mm A');
    this.selectedItem.scheduleDateForm = moment(this.selectedItem.scheduleDate).format('MM/DD/YYYY');
    this.openPositions = this.selectedItem.open_position;

      Promise.all([
        this.getWeeklyWorkhoursSummary(),
        this.getBurstPositions()
      ]).then(resp => {
        this.isPositionFilled = this.filledPositions >= this.openPositions ? true : false;
      });
    }

  getWeeklyWorkhoursSummary() {
    return new Promise((resolve, reject) => {
      this.burstService.getWeeklyWorkhoursSummary(this.selectedItem.empName,
        moment(this.selectedItem.weekendDate).format('MM/DD/YYYY')).subscribe((data: any) => {
          for (let itemResponse of data) {
            for (const week of itemResponse.workdays) {
              this.totalScheduled += parseFloat(week.scheduled_hours);
            }
          }
          this.is_approaching_ot = this.totalScheduled >= 40;
          this.totalScheduled = this.totalScheduled.toFixed(2);
          resolve(data);
      }, err => {
        resolve(0);
      });
    });
  }

  getBurstPositions() {
    return new Promise((resolve, reject) => {
      this.burstService.getBurstPositions(this.selectedItem.burstId).subscribe((data: any) => {
        data.map(pos => {
          this.filledPositions = pos.filled_positions;
        });
        resolve(data);
      }, err => {
        resolve(0);
      });
    });
  }

  close() {
    this.activeModal.close(0);
  }

  managerResponse(managerResponse) {
    const data = {
      assignments: [
        {
          empId: this.item.empId,
          managerResponse: managerResponse,
          scheduleDate: this.item.scheduleDate,
          taskId: this.item.taskId,
          burstId: this.item.burstId,
          jobId: this.item.jobId
        }
      ]
    };
    this.procesing = true;
    this.burstService.updateBurstAssignments(data).subscribe((response: any) => {
      this.procesing = false;
      if (response.error.length) {
        Swal.fire('Error!', response.error[1], 'error');
        return;
      }
      Swal.fire('Success!', managerResponse === 'Declined' ? managerResponse : 'Approved!', 'success');
      this.activeModal.close(this.item);
    }, err => {
      this.procesing = false;
      Swal.fire('Error!', 'Something was wrong, please try again !', 'error');
    });
  }
}
