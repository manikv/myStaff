import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {FormsModule} from "@angular/forms";
import {BookingDetailsComponent} from './booking-details.component'

@NgModule({
  entryComponents: [
    
  ],
  declarations: [
    BookingDetailsComponent
  ],
  imports: [
    CommonModule,
    NgbModule,
    FormsModule
  ],
  exports: [
    BookingDetailsComponent
  ]
})
export class BookingDetailsModule { }
