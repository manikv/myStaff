import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EbsAlertComponent } from './ebs-alert.component';

describe('EbsAlertComponent', () => {
  let component: EbsAlertComponent;
  let fixture: ComponentFixture<EbsAlertComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EbsAlertComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EbsAlertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
