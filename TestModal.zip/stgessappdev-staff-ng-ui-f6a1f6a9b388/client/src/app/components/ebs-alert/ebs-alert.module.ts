import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {FormsModule} from "@angular/forms";
import { EbsAlertComponent } from './ebs-alert.component'

@NgModule({
  entryComponents: [
    
  ],
  declarations: [
    EbsAlertComponent
  ],
  imports: [
    CommonModule,
    NgbModule,
    FormsModule
  ],
  exports: [
    EbsAlertComponent
  ]
})
export class EbsAlertModule { }
