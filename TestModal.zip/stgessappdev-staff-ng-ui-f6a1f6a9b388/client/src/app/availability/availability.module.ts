import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AvailabilityRoutingModule } from './availability-routing.module';
import { AvailabilityManageComponent } from './manage/availability-manage.component';
import { PtoService } from '../shared/common/services/pto.service';
import { ScheduleService } from '../shared/common/services/schedule.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import 'ag-grid-community';
import 'ag-grid-enterprise';
import { AgGridModule } from 'ag-grid-angular';
import { LicenseManager } from "ag-grid-enterprise";
LicenseManager.setLicenseKey("SoftwareONE_USA_on_behalf_of_Compass_Group_USA_MultiApp_5Devs_5Deployment_12_August_2020__MTU5NzE4NjgwMDAwMA==de1432ef47c510c631b782c11ab2920d");
import { BlockUIModule } from 'ng-block-ui';
import {FormsModule} from "@angular/forms";
import { TeamMultiTypeaheadModule, AssociateMultiTypeheadModule  } from '@staff/sharedModules/index';
import { DatepickerModule } from '../shared/common/components/datepicker/datepicker.module';
import { ReportingCommonService } from '../reporting/common/reporting.common.service';
import { BryntumAngularSharedModule } from 'bryntum-angular-shared';

@NgModule({
  entryComponents: [
    AvailabilityManageComponent
  ],
  declarations: [
    AvailabilityManageComponent
  ],
  imports: [
    CommonModule,
    AvailabilityRoutingModule,
    NgbModule,
    TeamMultiTypeaheadModule,
    AssociateMultiTypeheadModule,
    DatepickerModule,
    BlockUIModule.forRoot(),
    AgGridModule.withComponents(),
    FormsModule,
    BryntumAngularSharedModule
  ],
  exports: [
    AvailabilityManageComponent
  ],
  providers: [
    PtoService,
    ScheduleService,
    ReportingCommonService
  ]
})
export class AvailabilityModule { }
