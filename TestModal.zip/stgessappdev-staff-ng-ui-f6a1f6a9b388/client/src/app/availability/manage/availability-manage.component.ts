import { Component, OnInit, ViewEncapsulation, ViewChild, AfterViewInit } from '@angular/core';
import { trigger, state, style, animate, transition, query } from '@angular/animations';
import * as _ from 'lodash';
import { BlockUI, NgBlockUI } from 'ng-block-ui';
import { Globals } from '../../shared/common/global/global.provider';
import { TeamMultiTypeaheadComponent } from '../../shared/team-multi-typeahead/team-multi-typeahead.component';
import * as moment from 'moment';
import { ScheduleService } from "../../shared/common/services/schedule.service";
import { Scheduler, WidgetHelper, DateHelper } from "bryntum-scheduler/scheduler.umd.js";

import jQuery from 'jquery';
import 'jszip';
import 'pdfmake';
import 'datatables.net-dt';
import 'datatables.net-buttons-dt';
import 'datatables.net-buttons/js/buttons.html5.js';
import 'datatables.net-buttons/js/buttons.print.js';
import { Button } from 'protractor';
import { Z_ERRNO } from 'zlib';

@Component({
  selector: 'app-availability-manage',
  templateUrl: './availability-manage.component.html',
  styleUrls: ['./availability-manage.component.scss'],
  animations: [
    trigger('smoothCollapse', [
      state('initial', style({
        height: '0',
        opacity: '0',
        overflow: 'hidden',
        padding: '5px'
      })),
      state('final', style({
        opacity: '1'
      })),
      transition('initial=>final', animate('150ms')),
      transition('final=>initial', animate('150ms'))
    ])],
  encapsulation: ViewEncapsulation.None
})

export class AvailabilityManageComponent implements OnInit, AfterViewInit {
  @ViewChild('teamdropdown') private teamdropdown: TeamMultiTypeaheadComponent;
  @BlockUI() blockUI: NgBlockUI;

  teamComponent: any;
  selectedTeam: any;
  heading: any = 'Availability-Manage';
  state: string = 'initial';
  maxValue: number = 0;
  isSubmitting: boolean = false;
  scheduler : any;
  dateHelper: any;
  days = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
  weekStartDay: number = 0;  // default to Sunday, will change for paygroup
  startDate : any; endDate: any;
  resources = []; events = [];
  params : any;
  table : any;
  prevSearchTeam: any = '';
  itemStorage = localStorage.getItem('previousSearchedTeam');
  defaultTeamDropDown: any = this.itemStorage ? JSON.parse(this.itemStorage) : null;

  constructor(
    public globals: Globals,
    public scheduleService: ScheduleService
  ){ }

  getPaygroup(paygroup_id) {
    // use selected team's paygroup_id, ff it's not set, then use from user's MyStaff profile
    if (!paygroup_id) {
      if (this.globals.proxyUserName && this.globals.proxyUseProfile)
        paygroup_id = this.globals.proxyUseProfile.pay_group_id;
      else
        paygroup_id = this.globals.staffProfile.paygroup_id;
    }

    const fallbackPaygroup = {
      description: "Fri-Thurs Hourly",
      end_date: moment().startOf("week").add(-2, "days").format("MM/DD/YYYY"),
      id: 10005,
      name: "FRI-THURS HOURLY",
      start_date: moment().startOf("week").add(4, "days").format("MM/DD/YYYY"),
    };

    const paygroups = this.globals.paygroups || [];
    const paygroup = paygroups.find(row => row.id === paygroup_id) || fallbackPaygroup;

    this.startDate = moment(paygroup.start_date, 'MM-DD-YYYY');
    this.endDate = moment(paygroup.end_date, 'MM-DD-YYYY').add(1, 'days').subtract(1, 'milliseconds');
    this.setWeekStartDay(paygroup);

    return paygroup;
  }

  setWeekStartDay(paygroup) {
    let day = paygroup.name.substring(0, 3).toLowerCase();

    this.weekStartDay = _.findIndex(this.days, (d)=> {
      return d.substring(0, 3) == day;
    });
  }

  ngOnInit() {
    if (this.globals.proxyUserName) {
      const profile = this.globals.proxyUseProfile;
      this.teamdropdown.setValue({
        label: profile.home_team +' - '+ profile.team_description,
        value: { team_name: profile.home_team }
      }, false, false);
    }
    else if (this.prevSearchTeam) {
      this.defaultTeamDropDown = this.prevSearchTeam;
      this.teamdropdown.setValue(this.prevSearchTeam, false, true);
    }
  }

  selectTeam($event) {
    setTimeout(() => {
      this.teamComponent = $event;
      this.getTeamAvailability($event.team_name, $event.paygrp_id);
    }, 100);
  }

  getWeeklyAvailability(team_name, end_date, user_name) {
    this.scheduler.maskBody('<div style="padding: 5px 10px;">Loading...</div>');
    this.scheduleService
      .getWeeklyAvailability(team_name, end_date, user_name)
      .subscribe((resp: any) => {
        this.mapData(resp);
        this.scheduler.unmaskBody();
      }, err => {
        console.log('error --->', err);
        this.mapData([[]]);
        this.scheduler.unmaskBody();
      });
  }

  getTeamAvailability(team_name, paygroup_id) {
    const paygroup = this.getPaygroup(paygroup_id);
    this.getWeeklyAvailability(team_name, paygroup.end_date, this.globals.user_name);
  }

  private getAvailabilityFromContext(eventRecord) {
    return {
      emp_id: eventRecord.resourceId,
      availability_id: eventRecord.availability_id,
      start_date: moment(eventRecord.data.startDate).format("MM-DD-YYYY"),
      start_time: moment(eventRecord.data.startDate).format("hh:mm"),
      end_date: moment(eventRecord.data.endDate).format("MM-DD-YYYY"),
      end_time: moment(eventRecord.data.endDate).format("hh:mm"),
      day_of_week: [
        moment(eventRecord.data.startDate).format("dddd").toUpperCase()
      ],
      is_available: true,
      is_deleted: false,
      //comments: null,
      //id: event.data.id,
    };
  }

  private getAvailabilityFromContexts(eventRecord, values) {
    return {
      emp_id: eventRecord.resourceId,
      availability_id: eventRecord.availability_id,
      start_date: moment(values.startDate).format("YYYY-MM-DD"),
      start_time: moment(values.startDate).format("HH:MM"),
      end_date: moment(values.endDate).format("YYYY-MM-DD"),
      end_time: moment(values.endDate).format("HH:MM"),
      day_of_week: [
        moment(eventRecord.data.startDate).format("dddd").toUpperCase()
      ],
      is_available: true,
      is_deleted: false,
      //comments: null,
      //id: event.data.id,
    };
  }

  private getAvailabilityFromDeleteContext(eventRecord) {
    return {
      emp_id: eventRecord.resourceId,
      availability_id: eventRecord.availability_id,
      start_date: moment(eventRecord.data.startDate).format("YYYY-MM-DD"),
      start_time: moment(eventRecord.data.startDate).format("hh:mm"),
      end_date: moment(eventRecord.data.endDate).format("YYYY-MM-DD"),
      end_time: moment(eventRecord.data.endDate).format("hh:mm"),
      day_of_week: [
        moment(eventRecord.data.startDate).format("dddd").toUpperCase()
      ],
      is_available: true,
      is_deleted: false,
      //comments: null,
      //id: event.data.id,
    };
  }

  validateAvailability(eventRecord, deleting) {
    const resourceRecord = _.find(this.resources, { id: eventRecord.resourceId });
    const data = this.getAvailabilityFromContext(eventRecord);
    if (deleting)
      data.is_deleted = true;

    return this.scheduleService.validateAvailability(resourceRecord.emp_no, [data]);
  }

  updateAvailability(eventRecord, values, deleting) {
    const data = this.getAvailabilityFromContexts(eventRecord, values);
    if (deleting) {
      data.is_deleted = true;
      data.is_available = false;
    }

    return this.scheduleService.updateAvailability(true, [data]);
  }

  deleteAvailability(eventRecord, deleting) {
    const data = this.getAvailabilityFromDeleteContext(eventRecord);
    if (deleting) {
      data.is_deleted = true;
      data.is_available = false;
    }

    return this.scheduleService.updateAvailability(true, [data]);
  }

  changeDate(end_date) {
    this.startDate = moment(end_date).subtract(6, 'days');
    this.endDate = moment(end_date).add(1, 'days').subtract(1, 'milliseconds');
    this.getWeeklyAvailability(this.teamComponent.team_name, moment(end_date).format("MM/DD/YYYY"), this.globals.user_name);
  }

  mapData(res) {
    let days = this.days;
    let resources = [];
    let events = [];
    let endDate = this.endDate;

    _.each(res[0] || [], function(item) {
      let resource = _.find(resources, { id: item.emp_id });

      if (!resource) {
        resource = {
          id: item.emp_id,
          name: item.emp_fullname,
          emp_no: item.emp_name,
          job: item.job_desc,
          searchText: item.emp_fullname + '\n' + item.emp_name, // combine values from both fields so that column search/filter will work on both fields
          events: [],
        };

        resources.push(resource);
      }

      let sDate = moment(item.start_date).toDate();
      let eDate = moment(item.end_date).add(1, 'days').toDate();

      let availableDays = _.map(days, function(day) {
        return !!_.find(item.days_of_week, function(d) {
          return (d || "").toLowerCase() === day;
        });
      });

      if (availableDays.length > 0) {
        while (sDate < eDate && sDate < endDate) {
          let currentDay = sDate.getDay();

          if (availableDays[currentDay]) {
            let allDayEvent = item.start_time == '00:00' && (item.end_time == '23:59' || item.end_time == '00:00');
            let eventDate = moment(sDate).format("YYYY-MM-DD");
            let eventStartDate = moment(eventDate + ' ' + item.start_time).toDate();
            let eventEndDate = allDayEvent ? moment(eventStartDate).add(1, 'days').toDate() : moment(eventDate + ' ' + item.end_time).toDate();

            if (sDate <= eventStartDate && eventEndDate <= eDate) {
              let event = {
                id: events.length + 1,
                resourceId: resource.id,
                startDate: eventStartDate,
                endDate: eventEndDate,
                availability_id: item.availability_id,
                name: resource.name + ' (' + resource.emp_no + ')',
                //eventColor: allDayEvent ? 'green': 'blue',
                eventStyle: allDayEvent ? 'colored' : 'line'
              };

              resource.events.push(event);
              events.push(event);
            }
          }

          sDate = moment(sDate).add(1, 'days').toDate();
        }
      }
    });

    this.events = events;
    this.scheduler.events = this.events;

    this.resources = _.sortBy(resources, function(resource) {
      return resource.name;
    });
    this.scheduler.resources = this.resources;

    this.scheduler.zoomToLevel('dayAndWeek', { zoomLevel: 12 });

    this.scheduler.startDate = this.startDate.toDate();
    this.scheduler.endDate = this.endDate.toDate();
    this.scheduler.weekStartDay = this.weekStartDay;

    this.refreshStartDay();
    this.generateDataTable();
  }

  setStorage(value) {
    this.prevSearchTeam = value;
    localStorage.setItem('previousSearchedTeam', JSON.stringify(value));
  }

  ngAfterViewInit() {
    // this will set startDate and endDate
    const paygroup = this.getPaygroup(this.teamComponent ? this.teamComponent.paygrp_id : null);

    let scheduler = new Scheduler({
      adopt      : 'container',
      rowHeight  : 48,
      barMargin  : 5,
      weekStartDay: this.weekStartDay,
      startDate  : this.startDate.toDate(),
      endDate    : this.endDate.toDate(),
      eventStyle : 'line',
      height     :  'calc(100vh - 135px)',
      mode       : 'horizontal',
      autoAdjustTimeAxis : true,
      zoomOnTimeAxisDoubleClick: false,
      zoomOnMouseWheel: false,
      //readOnly   : true,
      //viewPreset : 'dayAndWeek',
      viewPreset : {
        base       : 'dayAndWeek',
        timeResolution: {
          unit: 'minute',
          increment: 15,
        },
        headers    : [
          {
            unit: 'week',
            dateFormat : 'w.W MMM YYYY'
          },
          {
            unit: 'day',
            dateFormat : 'ddd M/D'
          },
        ]
      },
      features : {
        filterBar  : true,
        excelExporter : {
          // Choose the date format for date fields
          dateFormat : 'YYYY-MM-DD HH:mm',
        },
        timeRanges : {
          enableResizing      : true,
          showCurrentTimeLine : false,
          showHeaderElements  : true
        },
        headerContextMenu : {
          // Remove all right-click menu items before menu is shown
          processItems({ items }) {
            items.length = 0;
          }
        },
        eventResize : false,
        eventDrag: false,
        eventEdit: {
          editorConfig: {
            modal: true,
            title: 'Details',
            cls: 'availability-editor',
          },
          startTimeConfig: {
            onChange(event) {
              console.log("startTimeOnchange", event);
            }
          },
          endTimeConfig: {
            onChange(event) {
              console.log("endTimeOnchange", event);
              if (event.oldValue) {
                // default behavior of Bryntum is to keep the same event duration when start date/time is changed
                // we're going to check if it pushes end time past today's midnight and set it to midnight if it does
                const widgetMap = event.source.parent.widgetMap;
                const startDateField = widgetMap.startDateField;
                const endDateField = widgetMap.endDateField;
                const endTimeField = widgetMap.endTimeField;
                const midnight = moment(startDateField.value).startOf('day').add(1, 'days');
                let startTime = moment(event.value);
                let endTime = moment(endDateField.value).hours(startTime.hours()).minutes(startTime.minutes());
                if (endTime.isAfter(midnight)) {
                  endDateField.value = midnight.toDate();
                  endTimeField.value = midnight.toDate();
                }
              }
            }
          },
          extraItems: [
            {
              type      : 'container',
              name      : 'customPanelText',
              id        : 'custom-panel',
              index     : 8,
              cls       : 'custom-panel',
              html      : '<div class="custom-panel-text">Confirm that you want to do this action</div>',
              width     : '100%',
              visible   : false,
            },
          ],
        }
      },
      columns : [
        {
          text: 'Name',
          field: 'searchText',
          width: '15em',
          htmlEncode : false,
          editor: false,
          renderer : ({ record }) => `<div>${record.name}<br /><span class="emp-no">(${record.emp_no})</span></div>`,
        },
        {
          text: 'Job',
          field: 'job',
          width: '16em',
          editor: false,
        }
      ],
      listeners: {
        thisObj: this,
        beforeEventAdd({ source, eventRecord, resources, resourceRecords }) {
          //console.log("beforeEventAdd", source, eventRecord, resourceRecords);
        },
        afterEventAdd({ source, eventRecord, resources, resourceRecords }) {
          //console.log("beforeEventAdd", source, eventRecord, resourceRecords);
        },
        beforeEventDelete({ eventRecords, context }) {
          console.log("beforeEventDelete", context, eventRecords);

          //const confirmationPanel = this.scheduler.eventEdit.extraItems[0];

          // force save if confirmation panel is shown
          //if (confirmationPanel.visible) {
            this.deleteAvailability(eventRecords[0], true)
              .subscribe( (resp: any) => {
                console.log("delete success!");
                context.finalize(true);
              }, err => {
                console.log("delete error!", err);
                context.finalize(false);
              });
            return false;
          //}
        },
        beforeEventSave({ context, source, eventRecord, resourceRecords, values }) {
          console.log("beforeEventSave", context, source, eventRecord, resourceRecords);
          context.async = true;
          console.log(values);
          this.updateAvailability(eventRecord, values, false)
            .subscribe( (resp: any) => {
              console.log("update success!");
              context.finalize(true);
            }, err => {
              console.log("update error!", err);
              context.finalize(false);
            });
          return false;

          // context.async = true;

          // this.validateAvailabilityForUpdate(context)
          //   .subscribe( (resp: any) => {
          //     console.log(resp);
          //     context.finalize(true);
          //   }, err => {
          //     context.finalize(false);
          //   });

          // return false;
        },
        afterEventSave({ source, eventRecord, resources, resourceRecords }) {
          const allDayEvent = eventRecord.duration === 1;
          eventRecord.eventStyle = allDayEvent ? 'colored' : 'line';
          //console.log("afterEventSave", source, eventRecord, resourceRecords);
        },
        beforeEventResizeFinalize({ context }) {
          //context.async = true;

          // this.validateAvailability(context)
          //   .subscribe( (resp: any) => {
          //     console.log(resp);
          //     context.finalize(true);
          //   }, err => {
          //     context.finalize(false);
          //   });


          // setTimeout(() => {
          //   const startDate = context.startDate;
          //   const endDate = context.endDate;
          //   const pass = false;

          //   if (!pass) {
          //     context.eventRecord.override = {
          //       startDate: startDate,
          //       endDate: endDate,
          //     };
          //   }

          //   context.finalize(pass);

          //   if (pass) {
          //     context.eventRecord.eventStyle = context.eventRecord.data.duration === 1 ? 'colored' : 'line';
          //     context.eventRecord.data.eventStyle = context.eventRecord.eventStyle;
          //   }
          //   else {
          //     scheduler.editEvent(context.eventRecord);
          //   }
          // }, 0);
        },
        beforeEventEdit({ source : scheduler, eventEdit, eventRecord, resourceRecord, eventElement }) {
          //console.log("beforeEventEdit", eventEdit);

          //eventEdit.editor.items[8].hide();

          var items = eventEdit._editorConfig.bbar;

          // switch Delete and Save buttons
          if (items[1].ref === 'saveButton') {
            const saveButton = items[1];
            const deleteButton = items[2];
            const cancelButton = items[3];

            deleteButton.color = 'b-red';
            saveButton.color = 'b-blue';

            items.length = 1;

            items.push(deleteButton);
            items.push(cancelButton);
            items.push(saveButton);
          }

          if (!eventRecord.data.resourceId) {
            // creating new event, assign resource
            eventRecord.data.resourceId = resourceRecord.data.id;
            eventRecord.data.availability_id = resourceRecord.data.id;
            eventRecord.data.name = resourceRecord.data.name + ' (' + resourceRecord.data.emp_no + ')';

            // detect is even was created by dragging or by double clicking/using Add Event menu option,
            // and adjust end date to be on the start date's midnight
            if (moment(eventRecord.data.endDate).startOf('day').isAfter(moment(eventRecord.data.startDate).startOf('day'))) {
              eventRecord.data.endDate = moment(eventRecord.data.startDate).startOf('day').add(1, 'days').toDate();
            }
          }
        },
        beforeEventEditShow({ source : scheduler, eventEdit, eventRecord, resourceRecord, eventElement, editor }) {
          //console.log("eventEditShow", editor, eventEdit);
          editor.widgetMap.nameField.disabled = true;
          editor.widgetMap.resourceField.visible = false;
          editor.widgetMap.startDateField.disabled = true;
          editor.widgetMap.endDateField.disabled = true;
          editor.items[8].hide();
        }
      },
      events : this.events,
      resources : this.resources,

      // Specialized body template with header and footer
      eventBodyTemplate : data => `
        <div class="b-sch-event-header event-center">${data.headerText}</div>
        <div class="b-sch-event-footer">${data.footerText}</div>
      `,

      eventRenderer({ eventRecord })  {
        if (eventRecord.startDate.getHours() == 0 && eventRecord.startDate.getMinutes() == 0
           && ((eventRecord.endDate.getHours() == 23 && eventRecord.endDate.getMinutes() == 59) || (eventRecord.endDate.getHours() == 0 && eventRecord.endDate.getMinutes() == 0))) {
          return {
            headerText : 'available',
            footerText : ''
          };
        }

        let startFormat = (eventRecord.startDate.getMinutes() == 0) ? 'ha': 'h:mma';
        let endFormat = (eventRecord.endDate.getMinutes() == 0) ? 'ha': 'h:mma';

        return {
          headerText : DateHelper.format(eventRecord.startDate, startFormat) + '-' + DateHelper.format(eventRecord.endDate, endFormat),
          footerText : ''
        };
      }
    });

    this.scheduler = scheduler;

    let changeDate = (value) => this.changeDate(value);

    [this.dateHelper] = WidgetHelper.append([
      {
        type  : 'date',
        value : moment(scheduler.endDate).subtract(1, 'days').toDate(),
        step  : '7d',
        picker: {
          // weekStartDay: this.weekStartDay,
          disabledDates: (date) => date.getDay() !== (this.weekStartDay - 1) % 7
        },
        onChange({ value }) {
            changeDate(value);
        }
      }
    ], { appendTo : document.getElementById('datehelper')});

    this.refreshStartDay();
    this.generateDataTable();
  }

  getEventText(resource, date) {
    const m = moment;
    let events = _.filter(resource.events, function(event) {
      return m(event.startDate).isSame(date, 'day');
    });

    return _.map(events, function(event) {
      let startFormat = (event.startDate.getMinutes() === 0) ? 'ha': 'h:mma';
      let endFormat = (event.endDate.getMinutes() === 0) ? 'ha': 'h:mma';

      return DateHelper.format(event.startDate, startFormat) + '-' + DateHelper.format(event.endDate, endFormat);
    }).join('<br />\r\n');
  };

  generateDataTable() {
    let result = this.generateExcelData();

    const header = result.data.splice(0, 1);
    const columns = _.map(header[0], function(h, index) {
      return {
        title: h.value,
        render: function(data, type, row, meta) { // using custom render function so it would render html
          return data;
        }
      };
    });
    const data = _.map(result.data, function(d) { return _.map(d, function(row) { return row.value; }); });

    if (this.table && this.table.destroy) {
      this.table.destroy();
      this.table = null;
    }

    this.table = jQuery("#datatable").DataTable({
      data: data,
      columns: columns,
      dom: 'Bt',
      ordering: false,
      paging: false,
      searching: false,
      footer: false,
      info: false,
      buttons: [
        // 'copy', 'pdf',
        {
          extend: 'print',
          text: 'Print',
          className: 'b-light-gray b-raised b-widget b-button',
          customize: function(win)
          {
            jQuery(win.document.body).css('font-size', '12px');
            jQuery(win.document.body).find('table').css('font-size', '12px');
          }
        },
        {
          extend: 'excel',
          text: 'Export to Excel',
          className: 'b-blue b-raised b-widget b-button',
        },
      ]
    });

    jQuery(".dt-button").removeClass("dt-button");

    this.table.buttons().container().appendTo(jQuery('#buttons'));
  }

  generateExcelData() {
    const getEventText = this.getEventText;
    let startDate = this.startDate.clone().startOf('day');

    let result = [
      [
        { value: 'Staff', type: 'string' },
        { value: 'Job', type: 'string' },
        { value: 'PerNo', type: 'string' },
        { value: startDate.format("ddd M/D"), type: 'string' },
        { value: startDate.add(1, 'days').format("ddd M/D"), type: 'string' },
        { value: startDate.add(1, 'days').format("ddd M/D"), type: 'string' },
        { value: startDate.add(1, 'days').format("ddd M/D"), type: 'string' },
        { value: startDate.add(1, 'days').format("ddd M/D"), type: 'string' },
        { value: startDate.add(1, 'days').format("ddd M/D"), type: 'string' },
        { value: startDate.add(1, 'days').format("ddd M/D"), type: 'string' },
      ]
    ];

    startDate = this.startDate.clone().startOf('day');

    _.each(this.scheduler.resources, function(item) {
      var resource = item.data;

      let row = [
        { value: resource.name, type: 'string' },
        { value: resource.job, type: 'string' },
        { value: resource.emp_no + '', type: 'string' }
      ];

      let date = startDate.clone();
      for (let i = 0; i < 7; i++) {
        row.push({ value: getEventText(resource, date.toDate()), type: 'string' });
        date.add(1, 'days');
      }

      result.push(row);
    });

    return { data: result };
  }

  refreshStartDay() {
    this.dateHelper.value = moment(this.scheduler.endDate).subtract(1, 'days').toDate();
    this.dateHelper.picker.refresh();
  }

  // add event button click handled here
  onAddEventClick() {
    //this.scheduler.addEvent();
  }

  // remove event button click handled here
  onRemoveEventClick() {
    this.scheduler.removeEvent();
  }

  // Uncomment the code in this method to start "logging" events
  onSchedulerEvents(event: any) {
    // // catch scheduler events here, for example when dropping an event:
    // if (event.type === 'eventdrop') {
    //     console.log('Drop: ', event);
    // }

    // // or when editing one:
    // if (event.type === 'eventschange') {
    //     console.log('EventStore: ', event);
    // }

    // // or when editing a resource:
    // if (event.type === 'resourceschange') {
    //     console.log('ResourceStore: ', event);
    // }
  }

}
