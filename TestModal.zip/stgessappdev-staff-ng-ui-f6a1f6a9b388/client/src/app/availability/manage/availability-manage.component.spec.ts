import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AvailabilityManageComponent } from './availability-manage.component';

describe('PtoHistoryComponent', () => {
  let component: AvailabilityManageComponent;
  let fixture: ComponentFixture<AvailabilityManageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AvailabilityManageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AvailabilityManageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
