import { Component, OnInit, ViewChild, Input, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { Globals } from '../../shared/common/global/global.provider';
import { HomepageService } from '../../shared/common/services/homepage.service';
import * as moment from 'moment';
import { environment } from '@env/environment';


@Component({
  selector: 'homepage-helpful-links',
  templateUrl: './helpful-links.component.html',
  styleUrls: ['./helpful-links.component.scss'],
  // encapsulation: ViewEncapsulation.None
})

export class HelpfulLinksComponent implements OnInit {

	@Output() openDetails = new EventEmitter();

  links = [];

	ngOnInit() {
    this.homepageService
      .getAccordion(this.globals.proxyUserName || this.globals.user_name)
      .subscribe((res: any) => {
        this.setLinks(res);
      });
  }

  clickLink(link) {
    const details = {
      header: link.header_text,
      source: `${environment.root_url}${link.link_url}`,
      bgClass: 'details'
    }

    this.openDetails.emit(details);
  }
  
  setLinks(res) {
    const paygroup_id = this.globals.proxyUserName ? this.globals.proxyUseProfile.pay_group_id : this.globals.staffProfile.paygroup_id,
      paygroupDetail = this.globals.paygroups.find(row => row.id === paygroup_id);

    this.links = (res || []).map(link => {
      link.header_text = link.link_name;

      // check if there's a date parameter in the link, figure which date needs to be added to the link and name
      if (link.link_url && link.link_url.split("ATT_DATE=").length > 1) {
        let today = moment();
        link.link_url += today.format('YYYYMMDD');
        link.header_text += ' - ' +  today.format('dddd - MMM') + ' ' + today.format('Do');
      }

      return link;
    });
  }

	constructor (
		private globals: Globals,
		private homepageService: HomepageService
	){}
} 
