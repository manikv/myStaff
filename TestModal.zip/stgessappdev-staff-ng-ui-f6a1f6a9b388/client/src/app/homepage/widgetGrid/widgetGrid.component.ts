import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { Globals } from '../../shared/common/global/global.provider';
import { IDatasource } from 'ag-grid-community';
import { HomepageService } from '../../shared/common/services/homepage.service';
import { LinkText } from '../../shared/ag-custom-fields/link-renderer.component';
import * as excelStyles from '../../reporting/common/excelStyles/excelStyles';
import { environment } from '@env/environment';

import * as _ from 'lodash';
import * as moment from 'moment';
declare const document: any;

export class WidgetModel {
	bgClass:any = '';
	heading?;
	type?;
	apiUrl?;
	columnDefs?;
	linkUrl?;
	detailsHeader?;
	headerOptions?;
}
@Component({
	selector: 'homepage-widget-grid',
	templateUrl: './widgetGrid.component.html',
	styleUrls: ['./widgetGrid.component.scss']
})
export class WidgetGridComponent {
	@Input()
	set widgetModelInput(value) {
		if (value !== undefined) {
			this._widgetModelInput.next(value);
		}
	};
	@Input() description: string;
	@Output() changeParameters = new EventEmitter();
	@Output() onCloseGrid = new EventEmitter();
	@Output() openDetails = new EventEmitter();

	private _widgetModelInput = new BehaviorSubject<WidgetModel>(undefined);
	widgetModel = new WidgetModel();
	width = '100%';
	height = 'calc(100vh - 290px)';
	rowData = [];
	rowModelType = "clientSide";
	paginationPageSize = 100;
	gridApi: any;
	overlayLoadingTemplate =`<div class="ag-custom-loading-cell" style="font-size: 30px;">` +
              					`<i class="fa fa-spinner fa-pulse"></i>` +
              				`</div>`;
	context: any;
	frameworkComponents: any;
	pageNumber = 1;
	totalPage = 0;
	totalCount = 0;
	pageSize = 15;
	paginationNumberFormatter = function (params) {
		return "[" + params.value.toLocaleString() + "]";
	};
	xlsStyles = excelStyles.EXCEL_STYLES;
	dataSource: IDatasource;
	gridOptions;

	constructor(
		private globals: Globals,
		private homepageService: HomepageService
	) {
		this._widgetModelInput.subscribe(model => {
			this.widgetModel = model;
		}, err => console.log(err));

		this.frameworkComponents = {
			linkText: LinkText
		}
		this.context = { componentParent: this };

		this.dataSource = {
			getRows: (params: any) => {
				let size = Math.round((params.request.startRow + this.paginationPageSize) / this.paginationPageSize);
				this.homepageService.getWidgetGridData(
					this.widgetModel.apiUrl,
					this.globals.proxyUserName || this.globals.user_name,
					size.toString(),
					this.paginationPageSize.toString(),
					this.globals.proxyUserName?this.globals.proxyUseProfile.id:this.globals.staffProfile.user_id
				)
					.subscribe(res => {
						let length = _.get(res, 'metadata.resultCount', 0);
						params.successCallback(res['data'], length);
					});
			}
		};
		this.gridOptions = {
			defaultColDef: {
				sortable: true,
				resizable: true
			},
			groupDefaultExpanded: -1,
			groupUseEntireRow: true,
			datasource: this.dataSource
		};
	}
	closeGrid() {
		this.onCloseGrid.emit(true);
	}

	onFirstDataRendered(params) {
		params.api.sizeColumnsToFit();
	}

	loadRowData() {
		this.gridApi.showLoadingOverlay();
		let size = 1;
		this.homepageService.getWidgetGridData(
			this.widgetModel.apiUrl,
			this.globals.proxyUserName || this.globals.user_name,
			this.pageNumber.toString(),
			this.pageSize.toString(),
			this.globals.proxyUserName?this.globals.proxyUseProfile.id:this.globals.staffProfile.user_id
		).subscribe((res: any) => {
			this.gridApi.hideOverlay();
			this.rowData = res.data;
			this.totalCount = res.metadata.resultCount;
			this.totalPage = Math.ceil(this.totalCount / this.pageSize);
			setTimeout(() => {
				const text = this.widgetModel.bgClass == 'ut' ? 'Timesheet' : (this.widgetModel.bgClass == 'oc' ? 'Clock' : 'Associate');
				this.setCostumTexForGruping(text);
			}, 200);
		});
	}

	setCostumTexForGruping(text){
		const items = document.getElementsByClassName('ag-group-child-count');
		for (const item of items) {
			let currentText = item.innerText;
			currentText = currentText.slice(0, -1);
			const last = text.slice(-1);
			if(currentText != '(1'){
				if(last != 's'){
					text += 's'
				} 
			}else {
				if(last == 's'){
					text = text.slice(0, -1);
				}
			}
			item.innerText = currentText + ' ' + text + ')';
		}
	}

	linkClicked(data, options: any = false, noCheck=false) {
		const details = {
			detail: data,
			header: options ? options.header : this.widgetModel.detailsHeader ,
			source: `${environment.root_url}${options ? options.url :this.widgetModel.linkUrl}`,
			bgClass: this.widgetModel.bgClass
		}
		const paygroupDetail = this.globals.paygroups.find(row => row.id === this.globals.staffProfile.paygroup_id);
		if(!noCheck){
			switch (this.widgetModel.bgClass) {
				case 'ut':
					_.set(data, 'work_date_formatted', this.formatDate(data.work_date));
					details.source = details.source ? details.source
						.replace('{{emp_id}}', data.emp_id)
						.replace('{{start_date}}', data.work_date_formatted)
						.replace('{{end_date}}', data.work_date_formatted)
						: details.source

					details.header = details.header ? details.header
						.replace('{{date}}', data.work_date)
						.replace('{{user_name}}', data.emp_fullname)
						: details.header;
					break;

				case 'an':
					details.source = details.source ? details.source
						.replace('{{emp_id}}', data.emp_id)
						: details.source

					details.header = details.header ? details.header
						.replace('{{personnel_number}}', data.emp_name)
						.replace('{{user_name}}', data.emp_full_name)
						: details.header;
					break;

				case 'ot':
					let date = this.formatDate(moment(paygroupDetail.start_date).format('YYYY-MM-DD'));
					details.source = details.source ? details.source
						.replace('{{emp_id}}', data.emp_id)
						.replace('{{ww_date}}', date)
						.replace('{{nsd_date}}', date)
						.replace('{{cfd_date}}', date)
						: details.source

					details.header = details.header ? details.header
						.replace('{{personnel_number}}', data.emp_name)
						.replace('{{user_name}}', data.emp_full_name)
						: details.header;
					break;

				case 'mm':
					_.set(data, 'work_date_formatted', this.formatDate(data.work_date));
					details.source = details.source ? details.source
						.replace('{{emp_id}}', data.emp_id)
						.replace('{{start_date}}', data.work_date_formatted)
						.replace('{{end_date}}', data.work_date_formatted)
						: details.source

					details.header = details.header ? details.header
						.replace('{{personnel_number}}', data.emp_name)
						.replace('{{user_name}}', data.emp_full_name)
						: details.header;
					break;
			}
		}
		this.openDetails.emit(details);
	}

	formatDate(date) {
		let formattedDate = date.split('-');

		return `${formattedDate.join('')}%20000000`;
	}

	onGridReady(params) {
		this.gridApi = params.api;
		this.loadRowData();
	}
	onExportExcel() {
		this.homepageService.getWidgetGridData(
			this.widgetModel.apiUrl,
			this.globals.proxyUserName || this.globals.user_name,
			'1',
			this.totalCount.toString(),
			this.globals.proxyUserName?this.globals.proxyUseProfile.id:this.globals.staffProfile.user_id
		).subscribe((res: any) => {
			this.gridApi.hideOverlay();
      res.data.map ((x)=>{
       x.rdr_ip_address = (x.rdr_ip_address ? 'SN: ' + x.rdr_ip_address : x.rdr_ip_address);
       x.last_poll_date = moment(x.last_poll_date).format('MM/DD/YYYY');
      });
			this.gridApi.setRowData(res.data);
			const params = {
				allColumns: false,
				columnGroups: false,
				exportMode: "xlsx",
				fileName: this.widgetModel.headerOptions.docTitle,
				selectAll: true,
				onlySelected: false,
				sheetName: this.widgetModel.headerOptions.docTitle,
				skipFooters: false,
				skipGroups: true,
				skipHeader: false,
				skipPinnedBottom: false,
				skipPinnedTop: false
			};
			this.gridApi.exportDataAsExcel(params);
		});
	}

	getDownloadHelpUrl() {
		this.linkClicked({}, {url: `/cgLaunchpads/getFile?id=MASTER_TROUBLESHOOTING%20GUIDE.PDF`, header: 'Troubleshooting Help'}, true)
		//return `/cgLaunchpads/getFile?id=MASTER_TROUBLESHOOTING%20GUIDE.PDF`;
	}

	getMoreUrl() {
		this.linkClicked({}, {url: this.widgetModel.headerOptions.moreLink, header: 'More'}, true)

		//return `${environment.root_url}${this.widgetModel.headerOptions.moreLink}`;
	}

	onBtFirst() {
		this.pageNumber = 1;
		this.loadRowData();
	}

	onBtLast() {
		this.pageNumber = this.totalPage;
		this.loadRowData();
	}

	onBtNext() {
		this.pageNumber++;
		this.loadRowData();
	}

	onBtPrevious() {
		this.pageNumber--;
		this.loadRowData();
	}
} 
