import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WidgetGridComponent } from './widgetGrid.component';
import { Globals } from '../../shared/common/global/global.provider';
import { HomepageService } from '../../shared/common/services/homepage.service';
import { MockGlobals } from '../../mocks/services/Globals';
import { MockHomepageService } from '../../mocks/services/HomepageService';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AgGridModule } from 'ag-grid-angular';
import { LinkText } from '../../shared/ag-custom-fields/link-renderer.component';

describe('WidgetGridComponent', () => {
  let component: WidgetGridComponent;
  let fixture: ComponentFixture<WidgetGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WidgetGridComponent, LinkText ],
      imports: [
        CommonModule,
        FormsModule,
        AgGridModule.withComponents([LinkText]),
      ],
      providers:[
        { provide: Globals, useClass: MockGlobals},
        { provide: HomepageService, useClass: MockHomepageService},
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WidgetGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
