import * as moment from 'moment';

export const widget_grid_config = {
	'ut': {
		columnDefs: [
			{
				field: 'cost_center',
				rowGroup: true,
				hide: true,
				sort: "asc",
				valueFormatter: function (params) {
					return 'Cost Center: ' + params.value;
				}
			},
			{
				headerName: 'Personnel Number',
				cellRenderer: 'linkText',
				field: 'emp_name'
			},
			{
				headerName: 'Associate Name',
				field: 'emp_fullname',
				sort: "asc"
			},
			{
				headerName: 'Work Date',
				field: 'work_date',
				valueFormatter: function (params) {
					return moment(params.value).format('MM/DD/YYYY');
				}
			},
			{
				headerName: 'Reason',
				field: 'wrks_message'
			}
		],
		apiUrl: 'unauth_timesheet_details',
		linkUrl: '/dailytimesheet/ovrRetrieveIds.jsp?EMP_ID_0={{emp_id}}&START_DATE_0={{start_date}}&END_DATE_0={{end_date}}&DATE_SELECT=7',
		detailsHeader: 'Unauth Timesheet of {{user_name}} on {{date}}',
		headerOptions: {
			showDownloadCSV: false,
			showMore: true,
			showHelp: false,
			moreLink: '/cgReports/cgUnauthTimesheetReport.jsp?mfrm_id=1010509&uiPathLabel=UNAUTH%20TIMESHEET%20REPORT&mfrmUIPathLabel=UNAUTH+TIMESHEET+REPORT&currentID=1010509&parentID=216'
		}
	},
	'an': {
		columnDefs: [
			{
				headerName: "Cost Center",
				field: 'cost_center',
				rowGroup: true,
				hide: true,
				valueFormatter: function (params) {
					return 'Cost Center: ' + params.value;
				}
			},
			{
				headerName: 'Personnel Number',
				cellRenderer: 'linkText',
				field: 'emp_name',
				suppressSizeToFit: true
			},
			{
				headerName: 'Associate Name',
				field: 'emp_full_name'
			},
			{
				headerName: 'Reason',
				field: 'wrk_message'
			}
		],
		apiUrl: 'dashboard_detail/employee_needs_setup',
		linkUrl: '/cgMasterDataEdit/employeeDetails.jsp?EMP_ID_0={{emp_id}}',
		detailsHeader: 'Associate Setup for {{personnel_number}} {{user_name}}',
		headerOptions: {
			showDownloadCSV: false,
			showMore: true,
			showHelp: false,
			moreLink: '/cgReports/cgAssociateNeedSetupReport.jsp?mfrm_id=1010510&uiPathLabel=ASSOCIATE%20NEED%20SETUP%20REPORT&mfrmUIPathLabel=ASSOCIATE+NEED+SETUP+REPORT&currentID=1010510&parentID=216'
		}
	},
	'ot': {
		columnDefs: [
			{
				headerName: 'Cost Center',
				field: 'cost_center',
				rowGroup: true,
				hide: true,
				valueFormatter: function (params) {
					return 'Cost Center: ' + params.value;
				}
			},
			{
				headerName: 'Personnel Number',
				//cellRenderer: 'linkText',
				field: 'emp_name'
			},
			{
				headerName: 'Associate Name',
				field: 'emp_full_name'
			},
			{
				headerName: 'Predicted Hours',
				field: 'predicted_hours_with_today_wrkd'
			}
		],
		apiUrl: 'dashboard_detail/employee_approaching_overtime',
		linkUrl: '/cgScheduling/schedulingSessionDisplay.jsp?EMP_ID={{emp_id}}&TEAM_ID=&WW_DATE={{ww_date}}&NSD_DATE={{nsd_date}}&CFD_DATE={{cfd_date}}',
		detailsHeader: 'Associate schedule of {{personnel_number}} {{user_name}}',
		headerOptions: {
			showDownloadCSV: false,
			showMore: true,
			showHelp: false,
			moreLink: '/cgReports/cgApproachingOTReport.jsp?mfrm_id=1009810&uiPathLabel=Associate%20Approaching%20Overtime%20Report&mfrmUIPathLabel=Associate+Approaching+Overtime+Report&currentID=1009810&parentID=216'
		}
	},
	'mm': {
		columnDefs: [
			{
				headerName: 'Cost Center',
				field: 'costCenter',
				rowGroup: true,
				hide: true,
				valueFormatter: function (params) {
					return 'Cost Center: ' + params.value;
				}
			},
			{
				headerName: 'Personnel Number',
				cellRenderer: 'linkText',
				field: 'emp_name'
			},
			{
				headerName: 'Associate Name',
				field: 'emp_full_name'
			},
			{
				headerName: 'Work Date',
				field: 'work_date',
				valueFormatter: function (params) {
					return moment(params.value).format('MM/DD/YYYY');
				}
			}
		],
		apiUrl: 'dashboard_detail/employee_missed_meals',
		linkUrl: '/dailytimesheet/ovrRetrieveIds.jsp?EMP_ID_0={{emp_id}}&START_DATE_0={{start_date}}&END_DATE_0={{end_date}}&DATE_SELECT=7',
		detailsHeader: 'Timesheet for {{personnel_number}} {{user_name}}',
		headerOptions: {
			showDownloadCSV: false,
			showMore: true,
			showHelp: false,
			moreLink: '/cgReports/cgMissedMealReport.jsp?mfrm_id=1010511&uiPathLabel=MISSED%20MEAL%20REPORT&mfrmUIPathLabel=MISSED+MEAL+REPORT&currentID=1010511&parentID=216'
		}
	},
	'pc': {
		columnDefs: [
			{
				headerName: 'Personnel Number',
				field: 'emp_name'
			},
			{
				headerName: 'Associate Name',
				field: 'emp_full_name'
			},
			{
				headerName: 'Time Clock Punches %',
				field: 'time_clock_punches',
				valueFormatter: params => params.value ? params.value + '%' : ''
			},
			{
				headerName: 'Manual Punches %',
				field: 'manual_punches',
				valueFormatter: params => params.value ? params.value + '%' : ''
			},{
				headerName: 'Cost Center',
				field: 'cost_center'
			}
		],
		apiUrl: 'dashboard_detail/employee_punch_compliance',
		linkUrl: '',
		detailsHeader: '',
		headerOptions: {
			showDownloadCSV: true,
			docTitle: 'Clock Usage',
			showMore: false,
			showHelp: true
		}
	},
	'oc': {
		columnDefs: [
			{
				headerName: 'Cost Center',
				field: 'cost_center',
				rowGroup: true,
				hide: true
			},
			{
				headerName: 'Clock Name',
				field: 'rdr_name'
			},
			{
				headerName: 'Clock Description',
				field: 'rdr_desc'
			},
			{
				headerName: 'Serial Number',
				field: 'rdr_ip_address'
			},
			{
				headerName: 'Offline Since',
				field: 'last_poll_date',
				valueFormatter: function (params) {
					return moment(params.value).format('MM/DD/YYYY');
				}
			},
			{
				headerName: 'Cost Center',
				field: 'cost_center'
			}
		],
		apiUrl: 'dashboard_detail/employee_offline_clocks',
		linkUrl: '',
		detailsHeader: '',
		headerOptions: {
			showDownloadCSV: true,
			docTitle: 'Clocks Offline',
			showMore: false,
			showHelp: true
		}
	},
};
