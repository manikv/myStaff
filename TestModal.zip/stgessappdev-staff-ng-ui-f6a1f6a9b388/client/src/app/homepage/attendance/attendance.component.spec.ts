import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AttendanceComponent } from './attendance.component';
import { TeamMultiTypeaheadModule } from '@staff/sharedModules/team-multi-typehead.module';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ScheduleService } from '../../shared/common/services/schedule.service';
import { MockGlobals } from '../../mocks/services/Globals';
import { MockScheduleService } from '../../mocks/services/ScheduleService';
import { Globals } from '../../shared/common/global/global.provider';
import { HttpClientModule } from '@angular/common/http';
import { EventsService } from 'app/shared/common/events/events.service';

describe('AttendanceComponent', () => {
  let component: AttendanceComponent;
  let fixture: ComponentFixture<AttendanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AttendanceComponent ],
      imports: [
        TeamMultiTypeaheadModule,
        FormsModule,
        CommonModule,
        HttpClientModule
      ],
      providers:[
        { provide: ScheduleService, useClass: MockScheduleService},
        { provide: Globals, useClass: MockGlobals},
        EventsService
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AttendanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create', () => {
    component.getAttendance('test')
    setTimeout(() => {
      expect(component.loading).toBe(false);
    }, 200);
  });
});
