import { Component, EventEmitter, AfterViewInit, Output, ViewChild } from '@angular/core';
import { Globals } from '../../shared/common/global/global.provider';
import { ScheduleService } from '../../shared/common/services/schedule.service';
import * as moment from 'moment';
import { TeamMultiTypeaheadComponent } from '../../shared/team-multi-typeahead/team-multi-typeahead.component';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { DailyViewComponent } from '../../scheduling/daily-view/daily-view.component';
import { ToastrService } from 'ngx-toastr';
// import { BlockUI, NgBlockUI } from 'ng-block-ui';

@Component({
  selector: 'homepage-attendance',
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.scss']
})
export class AttendanceComponent implements AfterViewInit{
  @Output() onItemClick = new EventEmitter();

  // currDateTime = moment('6/29/2020 13:00').format("YYYY-MM-DD HH:mm")
  currDateTime = moment().format("YYYY-MM-DD HH:mm");


  teamComponent: any = {label: "", value: "" };
  scheduledList: Array<any> = [];
  atWorkList : Array<any> = [];
  absentList : Array<any> = [];
  string_format_date: any;
  currListView: Array<any> = [];
  prevSearchTeam: any = '';
  itemStorage = localStorage.getItem('previousSearchedTeam');
  defaultTeamDropDown: any = this.itemStorage ? JSON.parse(this.itemStorage) : null;
  punchList = [];
  selected_team_name: string;
  attendanceNumbers:  any = [
    {
      heading: "Scheduled",
      unitCount: 0,
      class: 'dodgerblue-color',
      borderClass: 'dodgerblue-shadow'
    },
    {
      heading: "At Work",
      unitCount: 0,
      class: 'lightseagreen-color',
      borderClass: 'lightseagreen-shadow'
    },
    {
      heading: "Absent",
      unitCount: 0,
      class: 'darkorange-color',
      borderClass: 'darkorange-shadow'
    }
  ];
  scheduleList=[];
  loading: boolean = false;
  currentView: any;
  isRefreshing: boolean= false;
  @ViewChild('teamdropdown') private teamdropdown: TeamMultiTypeaheadComponent;
  // @BlockUI('this-section') blockUI: NgBlockUI;
  toastrMsg: string = '';
  refreshInterval: number = 30000;  //10000(10secs)=>refreshes for 5min; 30000(30secs)=>refreshes for 15min;
  refreshTimerId: any;

  constructor(
    private scheduleService: ScheduleService,
    private globals: Globals,
    private modalService: NgbModal,
    public activeModal: NgbActiveModal,
    private toastr: ToastrService,

  ){
    const today = new Date();
    this.string_format_date = (today.getMonth() + 1) + '/' + today.getDate()  + '/' + today.getFullYear();

    this.refreshTimerId =  this.globals.setIntervalX(()=> { this.refreshHP() }, this.refreshInterval, 30);
  }

  ngOnInit() {
    this.loading = true;
  }

  ngAfterViewInit(){
    //this.teamdropdown.placeholder = 'Search Team';
    if(this.globals.proxyUserName){
      this.teamdropdown.setValue({label: this.globals.proxyUseProfile.home_team +' - '+ this.globals.proxyUseProfile.team_description, value:{team_name: this.globals.proxyUseProfile.home_team}}, false, false);
    }else{
      //this.teamdropdown.setValue({label: this.globals.staffProfile.home_team, value:{team_name: this.globals.staffProfile.home_team}}, false, false);
      if (this.prevSearchTeam) {
        this.defaultTeamDropDown = this.prevSearchTeam;
        this.teamdropdown.setValue(this.prevSearchTeam, false, true);
      }
    }


  }

  setStorage(value){
    this.prevSearchTeam = value;
    localStorage.setItem('previousSearchedTeam', JSON.stringify(value));
  }

  getAttendance(team_name: string) {
    let attendance = [];
    if(team_name) {
      this.scheduleService.getDailyPunches(team_name, this.string_format_date,).subscribe((p: any) => {
        this.scheduleService.getWeeklySchedules(team_name, this.string_format_date).subscribe((resp: any) => {
          attendance = this.scheduleService.setAttendance(team_name, this.currDateTime, this.attendanceNumbers, resp, p);
          this.setUIData(attendance);
          this.setView(this.attendanceNumbers[0]);
          this.assignCL(0);
          this.loading = false;
        }, err => {
          this.loading = false;
          console.log('error ---> ', err);
        });
      });
    }else{
      this.loading = false;
    }
  }

  getAtWorkStatus(punch){
    return  (punch.punch_type === 'IN' || punch.punch_type === 'MEAL_OUT') ? 'At Work':
      punch.punch_type === 'MEAL_IN'? 'Meal Break':
        punch.punch_type === 'OUT'? 'Work Complete':''
  }

  processPunchChange(data){
    data.punches.sort((a, b) => (a.punch_time > b.punch_time) ? 1 : -1);
    const lastPunch = data.punches[data.punches.length - 1];
    const punchMsg = lastPunch.punch_type=='IN'?'just Clocked In.'
                    :lastPunch.punch_type=='OUT'?'just Clocked Out.'
                    :lastPunch.punch_type=='MEAL_IN'?'just went for a Meal.'
                    :'is back to work.' ;
    this.toastrMsg += data.emp_lastname+', '+data.emp_firstname+' '+punchMsg + "<br/>";
  }

  select($ev){
    if ($ev) {
      this.selected_team_name = $ev.team_name;
      this.getAttendance($ev.team_name);
    }
  }

  setView(view){
    this.currentView = view.heading;
  }

  showWidgetGrid(item){
    item.unitDescription = "Scheduled";
    item.unitCount = "0";
    item.widgetUpdateMessage = "<br/><br/Scheduled";
    item.widgetType = "ut";
    item.widgetWarn = "ok";
    item.applVersion = "201907252119.20190726.102837";
    this.onItemClick.emit(item);
  }

  assignCL(index) {
    this.currListView = [];
    switch (index) {
      case 0: { this.currListView = this.scheduledList; break }
      case 1: { this.currListView = this.atWorkList; break }
      case 2: { this.currListView = this.absentList; break }
    }
  }

  openDetails(){
    this.globals.clearIntervalX(this.refreshTimerId );

    let modalRef = this.modalService.open(DailyViewComponent, { size: 'lg', backdropClass: 'z-1-backdrop', windowClass: 'myCustomModalClass' });
    modalRef.componentInstance.schedule = this.scheduleList;
    modalRef.componentInstance.punches = this.punchList;
    modalRef.componentInstance.selected_team_name = this.selected_team_name;
    modalRef.componentInstance.attendanceNumbers = this.attendanceNumbers;
    modalRef.result.then((result) => {
      this.refreshTimerId =  this.globals.setIntervalX(()=> { this.refreshHP() }, this.refreshInterval, 30);
      if (result==0) {
        //no refresh was made in the modal
        console.log("result:" + result);
      } else {
        let attendance = [];
        attendance = result;
        this.setUIData(attendance);
        this.setView(this.attendanceNumbers[0]);
      }
    });
  }

  refreshHP() {
    //this.scheduleList => ALL associates for the selected team; output of getWeeklySchedules api
    //this.scheduledList => only those who are scheduled for today - used for tab 1

    console.log("Refresh start....id:"+ this.refreshTimerId);
    // this.blockUI.start("Refreshing Data...");

    this.loading = true;
    let attendance = [];
    if(this.selected_team_name) {
      this.scheduleService.getDailyPunches(this.selected_team_name, this.string_format_date,).subscribe((p: any) => {
        p.map(emp => {
          const punchIndex = this.punchList.map(o => o.emp_name).indexOf(emp.emp_name);
          if (punchIndex == -1) {
            this.processPunchChange(emp);
          } else {
            if (emp.punches.length != this.punchList[punchIndex].punches.length) {
              this.processPunchChange(emp);
            }
          }
        });
        attendance = this.scheduleService.setAttendance(this.selected_team_name, this.currDateTime, this.attendanceNumbers, this.scheduleList, p);
        this.setUIData(attendance);
        // this.setView(this.attendanceNumbers[0]);
        if (this.toastrMsg != '') {
          // new Audio("data:audio/wav;base64,//uQRAAAAWMSLwUIYAAsYkXgoQwAEaYLWfkWgAI0wWs/ItAAAGDgYtAgAyN+QWaAAihwMWm4G8QQRDiMcCBcH3Cc+CDv/7xA4Tvh9Rz/y8QADBwMWgQAZG/ILNAARQ4GLTcDeIIIhxGOBAuD7hOfBB3/94gcJ3w+o5/5eIAIAAAVwWgQAVQ2ORaIQwEMAJiDg95G4nQL7mQVWI6GwRcfsZAcsKkJvxgxEjzFUgfHoSQ9Qq7KNwqHwuB13MA4a1q/DmBrHgPcmjiGoh//EwC5nGPEmS4RcfkVKOhJf+WOgoxJclFz3kgn//dBA+ya1GhurNn8zb//9NNutNuhz31f////9vt///z+IdAEAAAK4LQIAKobHItEIYCGAExBwe8jcToF9zIKrEdDYIuP2MgOWFSE34wYiR5iqQPj0JIeoVdlG4VD4XA67mAcNa1fhzA1jwHuTRxDUQ//iYBczjHiTJcIuPyKlHQkv/LHQUYkuSi57yQT//uggfZNajQ3Vmz+Zt//+mm3Wm3Q576v////+32///5/EOgAAADVghQAAAAA//uQZAUAB1WI0PZugAAAAAoQwAAAEk3nRd2qAAAAACiDgAAAAAAABCqEEQRLCgwpBGMlJkIz8jKhGvj4k6jzRnqasNKIeoh5gI7BJaC1A1AoNBjJgbyApVS4IDlZgDU5WUAxEKDNmmALHzZp0Fkz1FMTmGFl1FMEyodIavcCAUHDWrKAIA4aa2oCgILEBupZgHvAhEBcZ6joQBxS76AgccrFlczBvKLC0QI2cBoCFvfTDAo7eoOQInqDPBtvrDEZBNYN5xwNwxQRfw8ZQ5wQVLvO8OYU+mHvFLlDh05Mdg7BT6YrRPpCBznMB2r//xKJjyyOh+cImr2/4doscwD6neZjuZR4AgAABYAAAABy1xcdQtxYBYYZdifkUDgzzXaXn98Z0oi9ILU5mBjFANmRwlVJ3/6jYDAmxaiDG3/6xjQQCCKkRb/6kg/wW+kSJ5//rLobkLSiKmqP/0ikJuDaSaSf/6JiLYLEYnW/+kXg1WRVJL/9EmQ1YZIsv/6Qzwy5qk7/+tEU0nkls3/zIUMPKNX/6yZLf+kFgAfgGyLFAUwY//uQZAUABcd5UiNPVXAAAApAAAAAE0VZQKw9ISAAACgAAAAAVQIygIElVrFkBS+Jhi+EAuu+lKAkYUEIsmEAEoMeDmCETMvfSHTGkF5RWH7kz/ESHWPAq/kcCRhqBtMdokPdM7vil7RG98A2sc7zO6ZvTdM7pmOUAZTnJW+NXxqmd41dqJ6mLTXxrPpnV8avaIf5SvL7pndPvPpndJR9Kuu8fePvuiuhorgWjp7Mf/PRjxcFCPDkW31srioCExivv9lcwKEaHsf/7ow2Fl1T/9RkXgEhYElAoCLFtMArxwivDJJ+bR1HTKJdlEoTELCIqgEwVGSQ+hIm0NbK8WXcTEI0UPoa2NbG4y2K00JEWbZavJXkYaqo9CRHS55FcZTjKEk3NKoCYUnSQ0rWxrZbFKbKIhOKPZe1cJKzZSaQrIyULHDZmV5K4xySsDRKWOruanGtjLJXFEmwaIbDLX0hIPBUQPVFVkQkDoUNfSoDgQGKPekoxeGzA4DUvnn4bxzcZrtJyipKfPNy5w+9lnXwgqsiyHNeSVpemw4bWb9psYeq//uQZBoABQt4yMVxYAIAAAkQoAAAHvYpL5m6AAgAACXDAAAAD59jblTirQe9upFsmZbpMudy7Lz1X1DYsxOOSWpfPqNX2WqktK0DMvuGwlbNj44TleLPQ+Gsfb+GOWOKJoIrWb3cIMeeON6lz2umTqMXV8Mj30yWPpjoSa9ujK8SyeJP5y5mOW1D6hvLepeveEAEDo0mgCRClOEgANv3B9a6fikgUSu/DmAMATrGx7nng5p5iimPNZsfQLYB2sDLIkzRKZOHGAaUyDcpFBSLG9MCQALgAIgQs2YunOszLSAyQYPVC2YdGGeHD2dTdJk1pAHGAWDjnkcLKFymS3RQZTInzySoBwMG0QueC3gMsCEYxUqlrcxK6k1LQQcsmyYeQPdC2YfuGPASCBkcVMQQqpVJshui1tkXQJQV0OXGAZMXSOEEBRirXbVRQW7ugq7IM7rPWSZyDlM3IuNEkxzCOJ0ny2ThNkyRai1b6ev//3dzNGzNb//4uAvHT5sURcZCFcuKLhOFs8mLAAEAt4UWAAIABAAAAAB4qbHo0tIjVkUU//uQZAwABfSFz3ZqQAAAAAngwAAAE1HjMp2qAAAAACZDgAAAD5UkTE1UgZEUExqYynN1qZvqIOREEFmBcJQkwdxiFtw0qEOkGYfRDifBui9MQg4QAHAqWtAWHoCxu1Yf4VfWLPIM2mHDFsbQEVGwyqQoQcwnfHeIkNt9YnkiaS1oizycqJrx4KOQjahZxWbcZgztj2c49nKmkId44S71j0c8eV9yDK6uPRzx5X18eDvjvQ6yKo9ZSS6l//8elePK/Lf//IInrOF/FvDoADYAGBMGb7FtErm5MXMlmPAJQVgWta7Zx2go+8xJ0UiCb8LHHdftWyLJE0QIAIsI+UbXu67dZMjmgDGCGl1H+vpF4NSDckSIkk7Vd+sxEhBQMRU8j/12UIRhzSaUdQ+rQU5kGeFxm+hb1oh6pWWmv3uvmReDl0UnvtapVaIzo1jZbf/pD6ElLqSX+rUmOQNpJFa/r+sa4e/pBlAABoAAAAA3CUgShLdGIxsY7AUABPRrgCABdDuQ5GC7DqPQCgbbJUAoRSUj+NIEig0YfyWUho1VBBBA//uQZB4ABZx5zfMakeAAAAmwAAAAF5F3P0w9GtAAACfAAAAAwLhMDmAYWMgVEG1U0FIGCBgXBXAtfMH10000EEEEEECUBYln03TTTdNBDZopopYvrTTdNa325mImNg3TTPV9q3pmY0xoO6bv3r00y+IDGid/9aaaZTGMuj9mpu9Mpio1dXrr5HERTZSmqU36A3CumzN/9Robv/Xx4v9ijkSRSNLQhAWumap82WRSBUqXStV/YcS+XVLnSS+WLDroqArFkMEsAS+eWmrUzrO0oEmE40RlMZ5+ODIkAyKAGUwZ3mVKmcamcJnMW26MRPgUw6j+LkhyHGVGYjSUUKNpuJUQoOIAyDvEyG8S5yfK6dhZc0Tx1KI/gviKL6qvvFs1+bWtaz58uUNnryq6kt5RzOCkPWlVqVX2a/EEBUdU1KrXLf40GoiiFXK///qpoiDXrOgqDR38JB0bw7SoL+ZB9o1RCkQjQ2CBYZKd/+VJxZRRZlqSkKiws0WFxUyCwsKiMy7hUVFhIaCrNQsKkTIsLivwKKigsj8XYlwt/WKi2N4d//uQRCSAAjURNIHpMZBGYiaQPSYyAAABLAAAAAAAACWAAAAApUF/Mg+0aohSIRobBAsMlO//Kk4soosy1JSFRYWaLC4qZBYWFRGZdwqKiwkNBVmoWFSJkWFxX4FFRQWR+LsS4W/rFRb/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////VEFHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAU291bmRib3kuZGUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMjAwNGh0dHA6Ly93d3cuc291bmRib3kuZGUAAAAAAAAAACU=").play()
          this.toastr.success(this.toastrMsg,
            'Attendance Status', {
              enableHtml: true,
              closeButton: true
            });
          this.setView(this.attendanceNumbers[0]);
        }
        this.toastrMsg = '';
      });
      this.loading = false;
    }else{
      this.loading = false;
    }
  }

  setUIData(attendance: any){
    this.attendanceNumbers = attendance[0].attendanceNumbers;
    this.scheduledList = attendance[0].scheduledList;
    this.atWorkList = attendance[0].atWorkList;
    this.absentList = attendance[0].absentList;
    this.scheduleList = attendance[0].scheduleList;
    this.punchList = attendance[0].punchList;

    this.scheduledList.sort((a, b) => (a.name > b.name) ? 1 : -1);
    this.atWorkList.sort((a, b) => (a.name > b.name) ? 1 : -1);
    this.absentList.sort((a, b) => (a.name > b.name) ? 1 : -1);
    this.scheduleList.sort((a, b) => (a.name > b.name) ? 1 : -1);
    this.punchList.sort((a, b) => (a.name > b.name) ? 1 : -1);
  }



}



