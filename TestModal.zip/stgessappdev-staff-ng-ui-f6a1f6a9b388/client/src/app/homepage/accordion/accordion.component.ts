import { Component, OnInit, ViewChild, Input, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { Globals } from '../../shared/common/global/global.provider';
import { HomepageService } from '../../shared/common/services/homepage.service';
import * as moment from 'moment';
import { environment } from '@env/environment';


@Component({
  selector: 'homepage-accordion',
  templateUrl: './accordion.component.html',
  styleUrls: ['./accordion.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AccordionComponent implements OnInit{

	@Output() openDetails = new EventEmitter();
  activeId = '';
  accordionList = [];
  payPeriod = '';

	ngOnInit(){
    this.homepageService.getAccordion(this.globals.proxyUserName || this.globals.user_name)
    .subscribe((res:any)=>{
      this.setAccordionList(res);
    });
  }

  clickLink(item, name, url){
    const details = {
      header: name + ' - ' + item.weekDay + ' ' + item.date,
      source: `${environment.root_url}${url}`,
      bgClass: 'details'
    }
    this.openDetails.emit(details);
  }
  
  setAccordionList(res){
    const paygroup_id = this.globals.proxyUserName? this.globals.proxyUseProfile.pay_group_id: this.globals.staffProfile.paygroup_id,
          paygroupDetail = this.globals.paygroups.find(row => row.id === this.globals.staffProfile.paygroup_id);
    let start_day = moment(paygroupDetail.start_date);
    for(let i=0;i<7;i++){
      const thisDay = res.find(row => row.day_of_week === start_day.day())
      let itemList = [];
      thisDay.items.map(link=>{
        if(start_day.isAfter(moment(link.link_start_date).subtract(link.avail_for_num_of_weeks_past,'weeks')) && start_day.isBefore(moment(link.link_end_date).add(link.avail_for_num_of_weeks_future,'weeks'))){
          if(link.link_url.split('ATT_DATE=').length>1){
            link.link_url += start_day.format('YYYYMMDD')
          }
          itemList.push(link);
        }
      });
      this.accordionList.push({
        items: itemList,
        weekDay: start_day.format('dddd - MMM'),
        date:  start_day.format('Do')
      });
      if(start_day.format('dd') == moment().format('dd')){
        this.activeId = 'ngb-panel-'+i;
      }
      start_day.add(1,'days');
    }
    this.payPeriod = moment(paygroupDetail.start_date).format('ddd, Do')+' - '+moment(paygroupDetail.end_date).format('ddd, Do')
  }

	constructor(
		private globals: Globals,
		private homepageService: HomepageService
	){}
} 
