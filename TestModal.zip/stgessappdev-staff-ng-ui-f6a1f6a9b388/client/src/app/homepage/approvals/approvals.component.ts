import {Component, OnInit, Output, EventEmitter, Inject, Pipe, PipeTransform} from '@angular/core';
import { Globals } from '../../shared/common/global/global.provider';
import { PtoService } from '../../shared/common/services/pto.service';
import { BurstService } from '../../shared/common/services/burst.service';
import * as moment from 'moment';
import { timeoffDetailsComponent} from "../../pto/pto-details/pto-details.component";
import { NgbActiveModal, NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { DomSanitizer } from "@angular/platform-browser";
import { DOCUMENT } from "@angular/common";
import { BlockUI, NgBlockUI  } from 'ng-block-ui';
import { BookingDetailsComponent } from '../../components/booking-details/booking-details.component';

@Component({
  selector: 'homepage-approvals',
	templateUrl: './approvals.component.html',
	styleUrls: ['./approvals.component.scss']
})
export class ApprovalsComponent implements OnInit{

  @Output() onItemClick = new EventEmitter();
  nobookings: any = '';
  totalApprovals: any = 0;
  teamComponent = { "label": "Team" };
  schedule: any = [];
  timeOffList: Array<any> = [];
  timeOffDetailList: Array<any> = [];
  isloaded = false;
  width = '100%';
  rowSelection = "single";
  height = 'calc(100vh - 200px)';
  timesheetGridOptions: any = {
    defaultColDef: {
      sortable: true,
      resizable: true
    },
    copyHeadersToClipboard: true,
    floatingFilter: true,
  };
  attendanceNumbers= [{
    heading: "Booking Request(s)",
    class: 'yellow-color'
  },
  {
    heading: "Time Off Request(s)",
    class: 'purple-color'
  }];
  loading: boolean = true;
  btnLoadingArray: any = [];
  currentView = this.attendanceNumbers[0].heading;
  btnLoading = false;
  currViewList: Array<any> = [];
  @BlockUI() blockUI: NgBlockUI;
  searchquery: any;
  bookingSearchquery: any;
  gridApi: any;
  gridColumnApi: any;
  columsDef: any = [
    {
      headerName: 'Fulame',
      field: 'emp_fullname',
      resizable: true,
      hide: true,
      rowGroup: true
    },
    {
      headerName: 'Date',
      hide: true,
       width: 125,
       rowGroup: true,
      field: 'dates'
    },
    {
      headerName: 'Requested day',
      field: 'tor_created_date',
       width: 125,
      resizable: true,
    },
    {
      headerName: 'Time requested',
      field: 'reqDaysHrs',
       width: 125,
      resizable: true
    },
    {
      headerName: 'Balance name',
      field: 'balance_name',
       width: 125,
      resizable: true
    }
  ];

  isProxyUser = this.globals.proxyUserName?true:false;
  constructor(
    private ptoService: PtoService,
    private burstService: BurstService,
    private globals: Globals,
    private modalService: NgbModal,
    public activeModal: NgbActiveModal,
    private sanitizer: DomSanitizer,
    @Inject(DOCUMENT) private document: Document
  ){}

  ngOnInit(){
    Promise.all([
      this.getApprovals(),
      this.getTimeoffRequests()
    ]).then(resp => {
      if(resp[0] == 0 && resp[1] > 0){
        this.currentView = this.attendanceNumbers[1].heading;
      }
    })

  }

  onSelectionChanged($event){
    var selectedRows = this.gridApi.getSelectedRows();
    this.timoffDetailsModalOpen(selectedRows)
  }

  getApprovals(){
    return new Promise((resolve, reject) => {
      let week_end_date = moment(new Date()).format('MM/DD/YYYY');
      //let month_end_date = moment(week_end_date).endOf('month').format('MM/DD/YYYY');
      let month_end_date = moment().add(42, 'days').format('MM/DD/YYYY');
      this.totalApprovals = 0;
      this.burstService.getBurstApprovals(this.globals.proxyUserName || this.globals.user_name, month_end_date).subscribe((resp: any) => {
        let approvedList = resp.filter(assignment => assignment.managerResponse === 'Published' && assignment.employeeResponse === 'Accepted' && assignment.burstStatus.toUpperCase() != 'CLOSED');
        approvedList.map(row => {
          this.totalApprovals++;
          let item = this.schedule.find( x => x.scheduleDate == row.scheduleDate );
          if(item) {
            row.shortStartTime = moment(row.startTime).format("h:mm A");
            row.shortEndTime = moment(row.endTime).format("h:mm A");
            item['approvals'].push(row)
          }else {
            row.shortStartTime = moment(row.startTime).format("h:mm A");
            row.shortEndTime = moment(row.endTime).format("h:mm A");
            this.schedule.push({
              scheduleDate: row.scheduleDate,
              approvals: [row]
            })
          }
        });
        this.nobookings = this.schedule.length ? '' : 'No bookings';
        this.loading = false;
        resolve(this.schedule.length);
      }, err => {
        this.nobookings = this.schedule.length ? '' : 'No bookings';
        this.loading = false;
        resolve(0);
        console.log('this.schedule error -->', err);
      });
    })
  }

  getTimeoffRequests() {
    return new Promise((resolve, reject) => {
      this.timeOffDetailList=[];
      this.isloaded = false;
      this.ptoService.getUserTimeoffRequest(this.globals.proxyUserName || this.globals.user_name,'', 'PENDING')
        .subscribe(
          (data:any)  => {
            let filteredData = data.filter( v => v['tor_is_cancel'] === 'N');
              let grpbytorid = filteredData.reduce(function (rv, x) {
                (rv[x['tor_id']] = rv[x['tor_id']] || []).push(x);
                return rv;
              }, {});
              for (let key in grpbytorid) {
                let totDays = 0, totHrs = 0, tor_days=[], valHrs=0, fomattedvalHrs,
                  //req_toff_type = grpbytorid[key][0]['tofftyp_name'].indexOf('DAY') !== -1 ? 'DAY':'HRS';
                  req_toff_type = grpbytorid[key][0]['balance_type'];
                let availDaysHrs = 0;

                grpbytorid[key].map(record => {
                  let diff;
                  if (req_toff_type === 'DAYS') {
                    if (record.tod_day_type === "FD") {
                      totDays += 1;
                      record.requestedDays = 1;
                    } else {
                      totDays += .5;
                      record.requestedDays = .5;
                    }
                    record.toff_type = "Day";
                  } else {
                    let startTime = moment(record.tod_start_time),
                        endTime = moment(record.tod_end_time);
                    diff = moment.duration(endTime.diff(startTime));
                    totHrs =  Math.round((diff.asHours() + totHrs) * 100) / 100;
                    record.tot_type = (totHrs == 1 ? "Hour" : "Hours");
                    record.totHrs = Math.round((diff.asHours()) * 100) / 100;
                  }
                  record.day_formatted = moment(record.tod_date).format("ddd, MMM");
                  record.date_formatted = moment(record.tod_date).format("Do");
                  record.year_formatted = moment(record.tod_date).format("YYYY");
                  tor_days.push(record);
                });
                const startDate =  ( grpbytorid[key].length > 1 ? moment(grpbytorid[key][0]['tod_date']).format("MMM D") : moment(grpbytorid[key][0]['tod_date']).format("MMM D, YYYY") );
                const endDate = ( grpbytorid[key].length > 1 ? ' - ' + moment(grpbytorid[key][grpbytorid[key].length-1]['tod_date']).format("MMM D, YYYY") : '' );
                this.timeOffDetailList.push({
                      wbu_id: grpbytorid[key][0]['wbu_id'],
                      toa_is_approved: grpbytorid[key][0]['toa_is_approved'],
                      toa_comment: grpbytorid[key][0]['toa_comment'],
                      override_id: Number(grpbytorid[key][0]['override_Id']),
                      tod_id: grpbytorid[key][0]['tod_id'],
                      tod_date: grpbytorid[key][0]['tod_date'],
                      tor_start_time: grpbytorid[key][0]['tor_start_time'],
                      tor_end_time: grpbytorid[key][0]['tor_end_time'],
                      tcode_id: Number(grpbytorid[key][0]['tcode_id']),
                      tor_id: grpbytorid[key][0]['tor_id'],
                      tofftyp_id: grpbytorid[key][0]['tofftyp_id'],
                      emp_fullname: grpbytorid[key][0]['emp_fullname'],
                      emp_name: grpbytorid[key][0]['emp_name'],
                      emp_id: grpbytorid[key][0]['emp_id'],
                      toff_start_date: startDate,
                      toff_end_date: endDate,
                      dates:  startDate + endDate,
                      tor_created_date: moment(grpbytorid[key][0]['tor_created_date']).format('MM/DD/YYYY'),
                      balance_name: grpbytorid[key][0]['balance_name'],
                      reqDaysHrs: req_toff_type === 'DAYS' ?totDays.toString(): totHrs,
                      reqDaysHrsType: (req_toff_type === 'DAYS' ? (totDays>1?' Days':' Day') : (totHrs>1 ? ' Hours':' Hour')),
                      availableDays: availDaysHrs,
                      tofftyp_name: grpbytorid[key][0]['balance_name'],
                      tor_comment: grpbytorid[key][0]['tor_comment'],
                      toa_status: grpbytorid[key][0]['toa_status'],
                      tordays: tor_days,
                      team_name: grpbytorid[key][0]['wbt_name'],
                      icon:  this.globals.getIconType(grpbytorid[key][0]['balance_name'])
                  })
              }
              this.isloaded = true;
              resolve(this.timeOffDetailList.length)
          },
          err => {
            this.isloaded = true;
            console.log(err);
            resolve(0);
          },
        );
    })
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }

  formatDateShiftBurstDays(startdate){
    let start = moment(startdate).format('ddd');
    return start;
  }

  formatDateShiftBurstDates(startdate){
    let start = moment(startdate).format('MMM, Do');
    return start;
  }

  setView(view){
    this.currentView = view.heading;
  }

  assignCL(index) {
    this.currViewList = [];
    switch (index) {
      case 0: { this.currViewList = this.schedule; break }
      case 1: { this.currViewList = this.timeOffList; break }
    }
  }

  showDetailsModal(item){
    if(!this.isProxyUser){
      let filteredList = this.timeOffDetailList.filter( detail => detail.tor_id == item.tor_id);
      this.timoffDetailsModalOpen(filteredList);
    }
  }

  cleanArray(item){
    const index = this.btnLoadingArray.indexOf(item);
    if (index != -1) {
      this.btnLoadingArray.splice(index, 1);
    }
  }

  timoffDetailsModalOpen(filteredList) {
    let modalRef = this.modalService.open(timeoffDetailsComponent, { backdrop: "static", size: 'lg' });
    modalRef.componentInstance.timeoffDetail = filteredList;
    modalRef.result.then((result) => {
      if (result) {
        console.log(result);
         if (result == 1) {
           this.getTimeoffRequests().then(success => {
             console.log('success', success)
           });  //reset the list in HomePage
         }
      }
    });
  }

  openModalDetails(details) {
    let modalRef = this.modalService.open(BookingDetailsComponent, { backdrop: "static", size: 'lg' });
    modalRef.componentInstance.item = details;
    modalRef.result.then((result) => {
      if (result) {
        console.log(result);
         if (result) {
          this.schedule.map(item => {
            const index = item.approvals.indexOf(result);
            if(index != -1) {
              item.approvals.splice(index, 1);
              this.totalApprovals--;
              return;
            }
          })
         }
      }
    });
  }


}


@Pipe({
  name: 'ptoFilter'
})
export class PtoFilterPipe implements PipeTransform {
  transform(items: any[], filter: string): any {
    if (!items || !filter) {
      return items;
    }
    return items.filter(item => item.team_name.toUpperCase().indexOf(filter.toUpperCase()) !== -1
        || item.emp_fullname.toUpperCase().indexOf(filter.toUpperCase()) !== -1
        || item.tofftyp_name.toUpperCase().indexOf(filter.toUpperCase()) !== -1
        || item.emp_name.toUpperCase().indexOf(filter.toUpperCase()) !== -1
    );
  }
}


@Pipe({
  name: 'ptoOrderBy'
})
export class PtoOrderByPipe implements PipeTransform{
  transform(array: Array<any>, args?: any) : Array<any> {
    if(!array || array === undefined || array.length === 0) return null;
    array.sort((a: any, b: any) => {
      if (a.tod_date < b.tod_date) {
        return -1;
      } else if (a.tod_date > b.tod_date) {
        return 1;
      } else {
        return 0;
      }
    });
    return array;
  }
}



@Pipe({
  name: 'bookingFilter'
})
export class BookingFilterPipe implements PipeTransform {
  transform(items: any[], filter: string): any {
    if (!items || !filter) {
      return items;
    }
    let retItems = [], tmpApproval = [];
    items.map((item) => {
      tmpApproval = [];
      if (item.approvals.filter((approval) => {
          if(approval.name.toUpperCase().indexOf(filter.toUpperCase()) !== -1
            || approval.burstName.toUpperCase().indexOf(filter.toUpperCase()) !== -1
            || approval.empName.toUpperCase().indexOf(filter.toUpperCase()) !== -1
            || approval.teamName.toUpperCase().indexOf(filter.toUpperCase()) !== -1
          )
            {
              tmpApproval.push(approval);
              return approval;
            }
      }).length>0) {
        retItems.push({
                scheduleDate: item.scheduleDate,
                approvals: tmpApproval
              });
      }
    });
    return retItems;
  }
}
