import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomepageRoutingModule } from './homepage-routing.module';
import { HomepageComponent, UpdatesComponent } from './homepage.component';
import { HomepageService } from '../shared/common/services/homepage.service';
import { PtoService } from '../shared/common/services/pto.service';
import { BurstService } from '../shared/common/services/burst.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import 'ag-grid-community';
import 'ag-grid-enterprise';
import { AgGridModule } from 'ag-grid-angular';
import { LicenseManager } from "ag-grid-enterprise";
LicenseManager.setLicenseKey("SoftwareONE_USA_on_behalf_of_Compass_Group_USA_MultiApp_5Devs_5Deployment_12_August_2020__MTU5NzE4NjgwMDAwMA==de1432ef47c510c631b782c11ab2920d");
import { WidgetGridComponent } from './widgetGrid/widgetGrid.component';
import{ CountUpModule } from '../shared/common/components/count-up/count-up.module';
import { MetricsComponent } from './metrics/metrics.component';
import { AccordionComponent } from './accordion/accordion.component';
import { HelpfulLinksComponent } from './helpful-links/helpful-links.component';
import { AnnouncementComponent } from './announcement/announcement.component';
import { AttendanceComponent } from './attendance/attendance.component';
import { ApprovalsComponent, } from './approvals/approvals.component';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { LinkText } from '../shared/ag-custom-fields/link-renderer.component';
import { BlockUIModule } from 'ng-block-ui';
import { SafeHtmlPipe } from '../shared/pipes/sanitize.pipe';
import { PtoModule } from "../pto/pto.module";
import { TeamMultiTypeaheadModule, OverlayHelpModule  } from '@staff/sharedModules/index';
import { PtoFilterPipe, PtoOrderByPipe, BookingFilterPipe } from './approvals/approvals.component';
import {FormsModule} from "@angular/forms";
import { NotificationService } from '../shared/common/services/notification.service';
import { BookingDetailsModule } from '../components/booking-details/booking-details.module'
import { BookingDetailsComponent } from '../components/booking-details/booking-details.component';
import { SchedulingModule } from '../scheduling/scheduling.module';
import { DailyViewComponent } from '../scheduling/daily-view/daily-view.component';
import { BryntumAngularSharedModule } from "bryntum-angular-shared";

@NgModule({
  entryComponents: [
    UpdatesComponent,
    BookingDetailsComponent,
    LinkText,
    DailyViewComponent
  ],
  declarations: [
    HomepageComponent,
    SafeHtmlPipe,
    UpdatesComponent,
    WidgetGridComponent,
    MetricsComponent,
    AccordionComponent,
    HelpfulLinksComponent,
    AnnouncementComponent,
    AttendanceComponent,
    ApprovalsComponent,
    LinkText,
    PtoFilterPipe,
    PtoOrderByPipe,
    BookingFilterPipe
  ],
  imports: [
    CommonModule,
    HomepageRoutingModule,
    NgbModule,
    BlockUIModule.forRoot(),
    AgGridModule.withComponents([LinkText]),
    CountUpModule,
    TeamMultiTypeaheadModule,
    OverlayHelpModule,
    PtoModule,
    BookingDetailsModule,
    FormsModule,
    SchedulingModule,
    BryntumAngularSharedModule
  ],
  providers: [
    HomepageService,
    PtoService,
    BurstService,
    NgbActiveModal,
    NotificationService
  ]
})
export class HomepageModule { }
