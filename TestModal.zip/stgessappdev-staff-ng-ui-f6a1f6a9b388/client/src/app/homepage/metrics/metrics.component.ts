import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { Globals } from '../../shared/common/global/global.provider';
import { HomepageService } from '../../shared/common/services/homepage.service';

import * as _ from 'lodash';
import { combineLatest } from 'rxjs';

@Component({
  selector: 'homepage-metrics',
  templateUrl: './metrics.component.html',
  styleUrls: ['./metrics.component.scss']
})
export class MetricsComponent implements OnInit {
  @Input() isWidgetGridVisible: boolean;
  @Output() onItemClick = new EventEmitter();
  isLoading: boolean = true;
  isUnauthLoading: boolean = true;
  isError: boolean = false;
  isUnauthError: boolean = false;
  selectedMetric: any;
  metrics: any = [
    {
      'unitDescription': 'Unauthorized<br/>Timesheets',
      'unitCount': 0,
      'widgetUpdateMessage': 'Current data updates in real time<br/>Five weeks or older update hourly',
      'metricType': 'unauth_timesheets',
      'widgetType': 'ut',
      'gridHeading':  'Unauthorized Timesheets'
    },
    {
      'unitDescription': 'Associates</br>Needing Setup',
      'unitCount': 0,
      'widgetUpdateMessage': '<br/>Updates every four hours',
      'metricType': 'assoc_needing_setup',
      'widgetType': 'an',
      'gridHeading':  'Associates Needing Setup'
    },
    {
      'unitDescription': 'Overtime Warning',
      'unitCount': 0,
      'widgetUpdateMessage': '<br/><br/>Updates every 30 minutes',
      'metricType': 'approaching_ot',
      'widgetType': 'ot',
      'gridHeading':  'Associates Approaching Overtime'
    },
    {
      'unitDescription': 'Clock Usage',
      'unitCount': 0,
      'widgetUpdateMessage': '<br/><br/>Updates daily at 4 AM ET',
      'metricType': 'punch_compliance',
      'widgetType': 'pc',
      'gridHeading':  'Punch Compliance'
    },
    {
      'unitDescription': 'Missed Meal',
      'unitCount': 0,
      'widgetUpdateMessage': '<br/><br/>Updates daily at 4 AM ET',
      'metricType': 'missed_meal',
      'widgetType': 'mm',
      'gridHeading':  'Missed Meal'
    },
    {
      'unitDescription': 'Clocks Offline',
      'unitCount': 0,
      'widgetUpdateMessage': '<br/><br/>Updates every one hours',
      'metricType': 'offline_clocks',
      'widgetType': 'oc',
      'gridHeading':  'Clocks Offline'
    }
  ];

  constructor(
    private globals: Globals,
    private homepageService: HomepageService
  ) { }

  ngOnInit() {
    this.getunauth();
    this.homepageService.getDashboard(this.globals.proxyUserName || this.globals.user_name)
    .subscribe((data) => {
        this.metrics.forEach(metric => {
          if(metric.widgetType != 'ut'){
            metric.unitCount = _.get(data[0], metric.metricType);
          }
        });
        this.isLoading = false;
      },
      error=>{
        this.isLoading = false;
        this.isError = true;
      }
    );
  }

  getunauth(){    
    this.isUnauthLoading = true;
    this.homepageService.getDashboardUnauth(this.globals.proxyUserName || this.globals.user_name, this.globals.proxyUserName?this.globals.proxyUseProfile.id:this.globals.staffProfile.user_id)
    .subscribe((data: any) => {
        this.metrics[0].unitCount = data[0].unauth_timesheets;
        this.isUnauthLoading = false;
      },
      error=>{
        this.isUnauthLoading = false;
        this.isUnauthError = true;
      }
    );
  }

  checkUnauthStatus(emp_id, work_date){
    return this.homepageService.checkDashboardUnauthStatus(this.globals.proxyUserName || this.globals.user_name, emp_id, work_date.split('-')[1]+'/'+work_date.split('-')[2]+'/'+work_date.split('-')[0]);
  }

  showWidgetGrid(item) {
      this.selectedMetric = item;
      this.onItemClick.emit(item);
  }

  getClass(item) {
    let styleClass = item.widgetType;

    if (_.get(this.selectedMetric, 'metricType') == item.metricType && this.isWidgetGridVisible) {
      styleClass = styleClass + ' bottom-arrow';
    }
    return styleClass;
  }
} 
