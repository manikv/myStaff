import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MetricsComponent } from './metrics.component';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CountUpModule } from '../../shared/common/components/count-up/count-up.module';
import { Globals } from '../../shared/common/global/global.provider';
import { HomepageService } from '../../shared/common/services/homepage.service';
import { MockGlobals } from '../../mocks/services/Globals';
import { MockHomepageService } from '../../mocks/services/HomepageService';
import { SafeHtmlPipe } from '../../shared/pipes/sanitize.pipe';

describe('MetricsComponent', () => {
  let component: MetricsComponent;
  let fixture: ComponentFixture<MetricsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MetricsComponent, SafeHtmlPipe ],
      imports:[
        CommonModule,
        FormsModule,
        CountUpModule
      ],
      providers: [
        { provide: Globals, useClass: MockGlobals},
        { provide: HomepageService, useClass: MockHomepageService},
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MetricsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('test showWidgetGrid', () => {
    const item={
      title: 'test'
    }

    component.showWidgetGrid(item);
    expect(component.selectedMetric).toEqual(item);
  });
});
