import { Component, ViewEncapsulation, Input, OnInit, ViewChild, Inject, HostListener } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { DomSanitizer} from '@angular/platform-browser';
import { WidgetModel } from './widgetGrid/widgetGrid.component';
import * as widgetGridConfig from './widgetGrid/widgetGrid.config';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { BlockUI, NgBlockUI  } from 'ng-block-ui';
import { MetricsComponent } from './metrics/metrics.component';
import { WidgetGridComponent } from './widgetGrid/widgetGrid.component';
@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class HomepageComponent {
  activeId = '';
  widgetModel = new WidgetModel();
  widgetGrid_isVisible: boolean = false;
  editMode: boolean = false;
  closeResult: string;
  showDetail: boolean;
  details: any;
  showNewFeatureOnLoadCount = 0;
  intialLoad: boolean = true;
  @ViewChild('metericscomponent') private metericscomponent: MetricsComponent;
  @ViewChild('widgetgrid') private widgetgrid: WidgetGridComponent;
  @BlockUI() blockUI: NgBlockUI;
  @HostListener('document:keydown.escape', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    if (this.showDetail) {
      this.closeDetails();
    }
    if(this.widgetGrid_isVisible){
      this.closeGrid();
    }
  }
  constructor(
    private modalService: NgbModal,
    public activeModal: NgbActiveModal,
    private sanitizer: DomSanitizer,
    @Inject(DOCUMENT) private document: Document,
  ) {
    this.showNewFeatureOnLoadCount = Number(localStorage.getItem('showNewFeatureOnLoad'))||0;
    if(this.showNewFeatureOnLoadCount === 0){
      this.showNewFeature();
    }
    localStorage.setItem('showNewFeatureOnLoad', (this.showNewFeatureOnLoadCount+1).toString());
  }

  showNewFeature(){
    this.updatesModalOpen();
    let _my = this;
    setTimeout(function () { _my.activeModal.dismiss() }, 1000);
  }

  updatesModalOpen() {
    let modalRef = this.modalService.open(UpdatesComponent, { backdrop: 'static', size: 'lg' });
    modalRef.componentInstance.imgUrl = './assets/images/_workbrain_appdata_upload_HOME-PAGE-UPDATES.gif';
  }

  showWidgetGrid(item) {
    let _my = this;
    this.widgetGrid_isVisible = false;
    this.widgetModel.bgClass = item.widgetType;
    this.widgetModel.heading = item.gridHeading; // item.unitDescription.split('</br>').join(' ').split('<br/>').join(' ');
    this.widgetModel.linkUrl = widgetGridConfig.widget_grid_config[item.widgetType].linkUrl;
    this.widgetModel.detailsHeader = widgetGridConfig.widget_grid_config[item.widgetType].detailsHeader;
    this.widgetModel.headerOptions = widgetGridConfig.widget_grid_config[item.widgetType].headerOptions;
    this.widgetModel.columnDefs = widgetGridConfig.widget_grid_config[item.widgetType].columnDefs;
    this.widgetModel.apiUrl = widgetGridConfig.widget_grid_config[item.widgetType].apiUrl;
    setTimeout(function () { _my.widgetGrid_isVisible = true }, 100);
  }

  closeGrid() {
    this.blockUI.stop();
    this.widgetGrid_isVisible = false;
  }

  openDetails(event) {
    this.details = event;
    this.details.source = this.sanitizer.bypassSecurityTrustResourceUrl(this.details.source);
    this.showDetail = true;
    this.document.body.classList.add('modal-open');
    this.blockUI.start('');
  }

  closeDetails() {
    this.showDetail = false;
    this.document.body.classList.remove('modal-open');
    if(this.details.bgClass === "ut"){
      this.metericscomponent.checkUnauthStatus(this.details.detail.emp_id, this.details.detail.work_date).subscribe(
        res=>{
          this.metericscomponent.getunauth();
          this.widgetgrid.loadRowData();        
      });
    }
  }

  openHelpModal(){
    var winWidth = 750,
      winHeight = 550,
      posX,
      posY,
      newWindowOptions;
    if (window.screen) {
        posX 	= (screen.availWidth - (winWidth/2))/4;
        posY 	= (screen.availHeight - (winHeight/2))/4;
    } else {
        posX	= 220;
        posY	= 200;
    }
    newWindowOptions = "width=" + winWidth + ",height=" + winHeight + ",innerWidth=" + winWidth + ",innerHeight=" + winHeight + ",resizable=1,screenX="+posX+",screenY="+posY+",left="+posX+",top="+posY;
	  window.open('/help/cg/MySTAFF_UserReferenceGuide.pdf', "Help", newWindowOptions).focus();
  }
}

@Component({
  template: `
    <div class="modal-header">
      <h4 class="modal-title text-primary" id="modal-basic-title">New Features</h4>
      <button type="button" class="close" aria-label="Close" (click)="activeModal.dismiss()"><span aria-hidden="true">&times;</span></button>
    </div>
    <div class="modal-body text-center">
      <img [src]="imgUrl" class="img-responsive announcement-image"/>
    </div>`
})
export class UpdatesComponent implements OnInit {
 
  @Input() imgUrl;

  constructor(public activeModal: NgbActiveModal) { }

  ngOnInit(): void {
    this.imgUrl = this.imgUrl + '?v1=' + new Date().getTime();
  }
}
