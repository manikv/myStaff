import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { HomepageRoutingModule } from './homepage-routing.module';
import { HomepageComponent, UpdatesComponent } from './homepage.component';
import { NgbModule, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { BlockUIModule } from 'ng-block-ui';
import { AgGridModule } from 'ag-grid-angular';
import { CountUpModule } from '../shared/common/components/count-up/count-up.module';

import { PtoModule } from '../pto/pto.module';
import { FormsModule } from '@angular/forms';
import { LinkText } from '../shared/ag-custom-fields/link-renderer.component';
import { TeamMultiTypeaheadModule } from '@staff/sharedModules/team-multi-typehead.module';
import { OverlayHelpModule } from '@staff/sharedModules/overlay-help.module';
import { SafeHtmlPipe } from '../shared/pipes/sanitize.pipe';
import { WidgetGridComponent } from './widgetGrid/widgetGrid.component';
import { MetricsComponent } from './metrics/metrics.component';
import { PtoOrderByPipe, PtoFilterPipe, ApprovalsComponent } from './approvals/approvals.component';
import { AccordionComponent } from './accordion/accordion.component';
import { AnnouncementComponent } from './announcement/announcement.component';
import { AttendanceComponent } from './attendance/attendance.component';
import { HomepageService } from '../shared/common/services/homepage.service';
import { PtoService } from '../shared/common/services/pto.service';
import { BurstService } from '../shared/common/services/burst.service';
import { NotificationService } from '../shared/common/services/notification.service';
import { HttpClientModule } from '@angular/common/http';
import { Globals } from '../shared/common/global/global.provider';
import { EventsService } from '../shared/common/events/events.service';
import { MockPtoService } from '../mocks/services/PtoService';
import { MockBurstService } from '../mocks/services/BurstService';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { MockHomepageService } from '../mocks/services/HomepageService';
import { MockGlobals } from '../mocks/services/Globals';

describe('HomepageComponent', () => {
  let component: HomepageComponent;
  let fixture: ComponentFixture<HomepageComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        HomepageComponent,
        SafeHtmlPipe,
        UpdatesComponent,
        WidgetGridComponent,
        MetricsComponent,
        AccordionComponent,
        AnnouncementComponent,
        AttendanceComponent,
        ApprovalsComponent,
        LinkText,
        PtoFilterPipe,
        PtoOrderByPipe
      ],
      imports: [
        CommonModule,
        HomepageRoutingModule,
        HttpClientModule,
        NgbModule,
        BlockUIModule.forRoot(),
        AgGridModule.withComponents([LinkText]),
        CountUpModule,
        TeamMultiTypeaheadModule,
        OverlayHelpModule,
        PtoModule,
        FormsModule
      ],
      providers: [
        { provide: Globals, useClass: MockGlobals },
        { provide: HomepageService, useClass: MockHomepageService },
        { provide: PtoService, useClass: MockPtoService },
        { provide: BurstService, useClass: MockBurstService },
        NgbActiveModal,
        NotificationService,
        EventsService
      ]
    });
    TestBed.overrideModule(BrowserDynamicTestingModule, {
      set: {
        entryComponents: [UpdatesComponent, LinkText,]
      }
    })
      .compileComponents();
    fixture = TestBed.createComponent(HomepageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
      console.log('fixture ---->', fixture)
      console.log('component ---->', component)
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Test showWidgetGrid function', () => {
    const item = {
      unitDescription: "Clocks Offline",
      unitCount: 3511,
      widgetUpdateMessage: "<br/><br/>Updates every one hours",
      metricType: "offline_clocks",
      widgetType: "oc",
      gridHeading: "Test"
    }
    component.showWidgetGrid(item);
    expect(component.widgetModel.heading).toEqual(item.gridHeading);
  });

  it('Test closeGrid function', () => {
    component.closeGrid();
    expect(component.widgetGrid_isVisible).toBe(false);
  });

  it('Test openDetails and closeDetail function', () => {
    component.openDetails({
      source: '',
      bgClass: 'test'
    });
    expect(component.showDetail).toBe(true);
    component.closeDetails();
    expect(component.showDetail).toBe(false);
  });

  it('Test openHelpModal function', () => {
    let spy = spyOn(window, 'open').and.callThrough()
    component.openHelpModal();
    expect(spy).toHaveBeenCalled();
  });
});
