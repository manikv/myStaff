import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { Globals } from '../../shared/common/global/global.provider';
import { HomepageService } from '../../shared/common/services/homepage.service';

@Component({
  selector: 'homepage-announcement',
  templateUrl: './announcement.component.html',
  styleUrls: ['./announcement.component.scss']  
})
export class AnnouncementComponent implements OnInit{
  dashboardAnnouncement = [];

	ngOnInit(){
    this.homepageService.getDashboardAnnouncement(this.globals.proxyUserName || this.globals.user_name)
    .subscribe((res:any)=>{
      for (const item of res) {
        this.dashboardAnnouncement.push({
          dashboard_announcement: item.dashboard_announcement.replace(/<br><br>/g, '')
        })
      }
    });
  }

	constructor(
		private globals: Globals,
		private homepageService: HomepageService
	){}
} 
