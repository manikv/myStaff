import { Component, OnInit,ElementRef, ViewEncapsulation } from '@angular/core';
import { ParametersModel, ParametersComponent } from '../common//parameters/parameters.component';
import { ReportingService } from '../common/reporting.service';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { Globals } from '../../shared/common/global/global.provider';
import * as excelStyles from '../common/excelStyles/excelStyles';

@Component({
  selector: 'app-report-dashboard',
  templateUrl: './dashboard.component.html'
})
export class ReportDashboardComponent{
  associatereports = [
    {
      link: "/reporting/common/balanceReport",
      title: "Associate Balance Report"
    }
  ];
  teamreports = [
    {
      link: "/reporting/common/teamWeeklyReport",
      title: "Team Weekly Report"
    },
    {
      link: "/reporting/team-work-summary",
      title: "Levy Reports"
    }
  ];
  audittrailreports = [
    {
      link: "/reporting/common/auditTrail",
      title: "Audit Trail Report"
    }
  ]
}
