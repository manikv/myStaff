import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';
import { ReportingService } from '../../common/reporting.service';
import * as excelStyles from '../../common/excelStyles/excelStyles';
import { ReportingCommonService } from '../../common/reporting.common.service';

@Component({
  selector: 'app-trial-balance-report',
  templateUrl: './trial-balance.component.html'
})
export class TrialBalanceReportComponent implements OnInit{
  reportId;
  columnDefs = [];
  width='98%';
  height='calc(100vh - 160px)';
  trialBalanceViewSummary = 'details';
  gridOptions = {
    defaultColDef: {
      sortable: true,
      resizable: true
    },
    autoGroupColumnDef: {
      width: 250,
      headerName: 'Name',
      cellRenderer:'agGroupCellRenderer',
      cellClass: "noBorderCell",
      cellRendererParams: {
        suppressCount: true
      }
    },
    rowBuffer: 14999,
    suppressMaxRenderedRowRestriction:true,
    suppressColumnVirtualisation:true,
    groupDefaultExpanded: -1,
    suppressAggFuncInHeader: true,
    childrenAfterGroup: true,
    excelStyles: excelStyles.EXCEL_STYLES
  };
  gridApi;
  gridLoaded: boolean = false;
  showSummary: boolean = false;

  @Input() data: Object[];
  @Output() onBlockui = new EventEmitter();
  @Input() selectedTeam: any;
  @Input() associateGrouping: any;
  @Input() trialBalanceColumnDefsData: any;
  @Input() trialBalanceColumnDefsTeams: any;
  @Input() trialBalanceColumnDefsTcodes: any;

  constructor(
    private reportingService: ReportingService,
    private reportingCommonService: ReportingCommonService
  ) {}

  onGridReady(params) {
    this.gridApi = params.api;
  }

  

  ngOnInit(){
    this.reportId = 'trialBalance';
    this.reportingService.getReportColumnDefs(this.reportId, '')
    .subscribe(res=>{
      res.map((col:any)=>{
        if(col.valFormatter){
          col.valueFormatter = this.reportingCommonService[col.valFormatter]
        }
      })
      this.columnDefs = res;
      this.gridLoaded = true;
    });
  }

  expandAllTrail(){
    this.showSummary  =false;
    this.gridOptions['api'].expandAll();
  }

  collapseAllTrail(type){
    this.showSummary  =false;
    this.onBlockui.emit(true);
    let checkType = type === 'jobs' ? "job_name_with_desc" : type === 'associates' ? "fullName_and_id" : "tcode_group";
    this.gridOptions['api'].forEachNode( function(rowNode) {
      if(rowNode.field === checkType){
        rowNode.setExpanded(false);
      }else{
        rowNode.setExpanded(true);
      }
    });
    this.onBlockui.emit(false);
  }

  getElementTrialBalance(team, tcode_group, type){
    let item = this.trialBalanceColumnDefsData.find((data: any) =>  data.tcode_group == tcode_group && data.team == team );
    if(type==='time'){
      return item ? this.limitDecimals(item.time) : '0.00';
    }else{
      return item ? this.limitDecimals(item.amount) : '0.00';
    }
  }

  limitDecimals(value){
    return Number(Math.floor(value *100)/100).toFixed(2);
  }
}
