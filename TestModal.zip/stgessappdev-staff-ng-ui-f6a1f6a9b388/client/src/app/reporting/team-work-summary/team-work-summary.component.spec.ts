import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TeamWorkSummaryComponent } from './team-work-summary.component';

describe('TeamWorkSummaryComponent', () => {
  let component: TeamWorkSummaryComponent;
  let fixture: ComponentFixture<TeamWorkSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TeamWorkSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TeamWorkSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
