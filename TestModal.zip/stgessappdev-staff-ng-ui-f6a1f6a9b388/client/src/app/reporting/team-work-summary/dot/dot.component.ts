import { Component, OnInit, EventEmitter, Input, ViewEncapsulation } from '@angular/core';
import { ReportingService } from '../../common/reporting.service';
import * as excelStyles from '../../common/excelStyles/excelStyles';
import { ReportingCommonService } from '../../common/reporting.common.service';

@Component({
  selector: 'app-dot-report',
  templateUrl: './dot.component.html',
   encapsulation: ViewEncapsulation.None
})
export class DOTReportComponent implements OnInit{
  reportId;
  columnDefs = [];
  width='98%';
  height='calc(100vh - 160px)';
  viewSummary = false;
  gridOptions: any = {
    defaultColDef: {
      resizable: true
    },
    columnDefs: this.columnDefs,
    rowData: null,
    suppressMaxRenderedRowRestriction:true,
    suppressColumnVirtualisation:true,
    groupDefaultExpanded: -1,
    suppressAggFuncInHeader: true,
    excelStyles: excelStyles.EXCEL_STYLES,
    autoGroupColumnDef: {
      width: 250,
      headerName: 'Team',
      cellClass: "allCell",
      cellRenderer:'agGroupCellRenderer',
      pinned: "left",
      field: 'team_name',
      cellRendererParams: {
        suppressCount: true
      }
    },
    rowBuffer: 9999,
    groupIncludeFooter : false,
    groupIncludeTotalFooter : false//,
    //pivotRowTotals : 'before',
    //pivotColumnGroupTotals: 'before'
  };
  gridApi;
  gridColumnApi;
  gridLoaded: boolean = false;

  @Input() data: Object[];
  @Input() onBlockui = new EventEmitter();

  constructor(
    private reportingService: ReportingService,
    private reportingCommonService: ReportingCommonService
  ) {}

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridColumnApi.setPivotMode(true);    
  }

  ngOnInit(){
    this.reportId = 'dot';
    this.reportingService.getReportColumnDefs(this.reportId, '')
    .subscribe(res=>{
      res.map((col:any)=>{
        if(col.valFormatter){
          col.valueFormatter = this.reportingCommonService[col.valFormatter]
        }
      })
      this.columnDefs = res;
      this.gridLoaded = true;
    });
  }

  customHeader(params) {
    var html = 'some text';
    return html;
  }

  expandAlll(){
    this.gridOptions.api.expandAll();
  }

  collapseAll(){
    this.gridOptions.api.collapseAll();
  }
}
