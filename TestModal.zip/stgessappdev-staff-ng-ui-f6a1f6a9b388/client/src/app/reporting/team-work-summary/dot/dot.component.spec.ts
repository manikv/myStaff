import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DOTReportComponent } from './dot.component';

describe('DOTReportComponent', () => {
  let component: DOTReportComponent;
  let fixture: ComponentFixture<DOTReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DOTReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DOTReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
