import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TimeDetailReportComponent } from './time-detail.component';

describe('TimeDetailReportComponent', () => {
  let component: TimeDetailReportComponent;
  let fixture: ComponentFixture<TimeDetailReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TimeDetailReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TimeDetailReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
