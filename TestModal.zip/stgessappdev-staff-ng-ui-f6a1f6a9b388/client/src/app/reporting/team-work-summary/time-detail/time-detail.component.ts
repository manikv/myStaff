import { Component, OnInit, ElementRef, Input, EventEmitter, Output } from '@angular/core';
import { ReportingService } from '../../common/reporting.service';
import * as excelStyles from '../../common/excelStyles/excelStyles';
import { ReportingCommonService } from '../../common/reporting.common.service';

@Component({
  selector: 'app-time-detail-report',
  templateUrl: './time-detail.component.html'
})
export class TimeDetailReportComponent implements OnInit{
  reportId;
  columnDefs = [];
  width='98%';
  height='calc(100vh - 160px)';
  timeDetailViewSummary = false;
  gridOptions = {
    defaultColDef: {
      sortable: true,
      resizable: true
    },
    autoGroupColumnDef: {
      width: 250,
      headerName: 'Name',
      cellRenderer:'agGroupCellRenderer',
      field: 'tcode_group',
      cellClass: "allCell",
      pinned: "left",
      cellRendererParams: {
        suppressCount: true
      }
    },
    rowBuffer: 14999,
    groupDefaultExpanded: -1,
    suppressAggFuncInHeader: true,
    excelStyles: excelStyles.EXCEL_STYLES
  };
  gridApi;
  gridLoaded: boolean = false;

  @Input() data: Object[];
  @Output() onBlockui = new EventEmitter();

  constructor(
    private reportingService: ReportingService,
    private reportingCommonService: ReportingCommonService
  ) {}

  onGridReady(params) {
    this.gridApi = params.api;
  }

  ngOnInit(){
    this.reportId = 'timeDetail';
    this.reportingService.getReportColumnDefs(this.reportId, '')
    .subscribe(res=>{
      res.map((col:any)=>{
        if(col.valFormatter){
          col.valueFormatter = this.reportingCommonService[col.valFormatter]
        }
      })
      this.columnDefs = res;
      this.gridLoaded = true;
    });
  }

  expandAllTimedetail(){
    this.gridOptions['api'].expandAll();
  }

  collapseAllTimedetail(){
    this.onBlockui.emit(true);
    this.gridOptions['api'].forEachNode( function(rowNode) {
      if(rowNode.field === "job_desc"){
        rowNode.setExpanded(false);
      }
    });
    this.onBlockui.emit(false);
  }
}
