import { Component, ViewChild, ViewEncapsulation } from '@angular/core';
import { ParametersModel } from '../common//parameters/parameters.component';
import { ReportingService } from '../common/reporting.service';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { format } from 'date-fns';
import { Globals } from '../../shared/common/global/global.provider';
import * as excelStyles from '../common/excelStyles/excelStyles';
import { BlockUI, NgBlockUI  } from 'ng-block-ui';
import { ValueFormatterService } from 'ag-grid-community';
import { TimeDetailReportComponent } from './time-detail/time-detail.component';
import { DOTReportComponent } from './dot/dot.component';
import { TrialBalanceReportComponent } from './trial-balance/trial-balance.component';
import { ExceptionsReportComponent } from './exceptions/exceptions.component';
import { ReportingCommonService } from '../common/reporting.common.service';


@Component({
  selector: 'app-team-work-summary-report',
  templateUrl: './team-work-summary.component.html',
  encapsulation: ViewEncapsulation.None,
  styles: [`.ag-row-level-0{background-color: #fff !important;}.ag-row-level-1{background-color: #ddd !important;}.ag-row-level-2{background-color: #eee !important;}`]

})
export class TeamWorkSummaryComponent {

  @BlockUI() blockUI: NgBlockUI;
  @ViewChild("timedetail") timedetail:TimeDetailReportComponent;
  @ViewChild("dot") dot:DOTReportComponent;
  @ViewChild("trialbalance") trialbalance:TimeDetailReportComponent;
  @ViewChild("exceptions") exceptions:ExceptionsReportComponent;
  constructor(
    private reportingService: ReportingService,
    private globals: Globals,
    private reportingCommonService: ReportingCommonService
	) {
    this.groupDefaultExpanded = 5;
    this.pivotColumnGroupTotals = "before";
    this.pivotRowTotals = "before";
		this.parametersModel.components = [
      {"label":"Team","type":"team_name","required": true,"nullify":"associate","isSingleSelection": true},
      {"label":"Preset Dates","type":"preset_date"},
			{"label":"Start Date","type":"start_date","required": true},
      {"label":"End Date","type":"end_date","required": true},
      { "label": "Include Sub Teams", "type": "sub_teams", "model": true}
		];
		this.parametersModel.heading = this.heading;
	}
	private gridApi;
	private trialGridApi;
  private exceptionGridApi;
  private dotGridApi;
  private gridColumnApi;
  private trialgridColumnApi;
  private dotgridColumnApi;
  private exceptiongridColumnApi;
  rowData: any = [];
  parametersModel = new ParametersModel();
  private rowModelType = "clientSide";
  private rowGroupPanelShow;
  private sideBar;
  private groupDefaultExpanded;
  private pivotColumnGroupTotals;
  private pivotRowTotals;
  tabSelected: any = 'Time Detail';
  autoGroupTrailColumnDef = {
    headerName: "Name",
    field: "fullName_and_id",
    width: 200,
    cellRenderer: "agGroupCellRenderer"
  };
  selected_team = '';
  timeDetailViewSummary = false;
  trialBalanceViewSummary = 'details';
  reportId;
  reportUrl =         "/api/shared/reports/teams/{team_name}/worksummary_details?sub_teams={sub_teams}&trial_data=false&home_team=false&start_date={start_date}&end_date={end_date}";
  reportDefaultUrl =  "/api/shared/reports/teams/{team_name}/worksummary_details?sub_teams={sub_teams}&trial_data=false&home_team=false&start_date={start_date}&end_date={end_date}";
  reportMainUrl =     "/api/shared/reports/teams/{team_name}/worksummary_details?sub_teams={sub_teams}&trial_data=false&home_team=false&start_date={start_date}&end_date={end_date}";
  heading = "Work Summary Report";
  isServerData: boolean = false;
  width='98%';
  height='calc(100vh - 160px)';
  viewType = "grid";
  view: any = "";
  xList: any;
	yList: Array<any> = [];
	paginationPageSize = 20;
  xlsStyles = excelStyles.EXCEL_STYLES;
  dataLoaded: boolean = false;
  exceptionsData: any;
  dotData: any;
  trialRowData: any;
  trialData: any;
  timeDetailData: any;


  trialBalancetotalAmount = 0;
  trialBalancetotalHours = 0;
  teamNameGrpuping = [];
  private timeDetailColumnDefsTeams = [];
  private timeDetailColumnDefJobs = [];
  private timeDetailColumnDefsData = [];
  private trialBalanceColumnDefsSumary = [];
  private trialBalanceColumnDefsData = [];

   associateGrouping = [
    {field: 'checks', value: 0, message: 'Total # of employees receiving checks'},
    {field: '$_1500_and_2000', value: 0, message: 'Total # of employees earning between $1500 and $2000'},
    {field: '$_2000_and_2500', value: 0, message: 'Total # of employees earning between $2000 and $2500'},
    {field: 'up_2500', value: 0, message: 'Total # of employees earning over $2500'},
  ];
  // end trial grid
  


  limitDecimals(value){
    return Number(Math.floor(value *100)/100).toFixed(2);
  }

  processDotSecondaryColDef(colDef) {
    colDef.headerName = colDef.headerName.toUpperCase();
    colDef.cellStyle =  { 'text-align': 'right'  };
    //colDef.valueFormatter(currencyFormatter);
  }

  changeParameters(parameters){
    this.reportDefaultUrl = this.reportMainUrl;
    parameters.map(comp=>{
      switch(comp.type) {
        case 'team_name': {
          if(comp.model.team_name){
            this.reportDefaultUrl = this.reportDefaultUrl.replace('{team_name}', comp.model.team_name);
            this.selected_team = comp.model.team_name +'-'+ comp.model.team_desc
          }else{
            let teamList = [];
            comp.model.map(t=>{teamList.push(t.team_name)});
            this.reportDefaultUrl = this.reportDefaultUrl.replace('{team_name}', teamList.join(','));
          }
          break;
        }
        case 'home-team': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{home_team}', comp.model.join(','));
          break;
        }
        case 'end_date': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{end_date}', comp.model.month+'/'+comp.model.day+'/'+comp.model.year);
          break;
        }
        case 'start_date': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{start_date}', comp.model.month+'/'+comp.model.day+'/'+comp.model.year);
          break;
        }
        case 'sub_teams': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{sub_teams}', comp.model);
          break;
        }
        case 'end-date': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{end_date}', comp.model.month+'/'+comp.model.day+'/'+comp.model.year);
          break;
        }
      }
    });
		this.xList = undefined;
		this.yList = [];
    this.setUpGrid();
    this.loadRowData();
  }

  currencyFormatter(params) {
    if(params.value){
      return "\x24" + (params.value && params.value>0?params.value.toFixed(2):'0.00');
    } else
      return "\x24 0.00";
  }

  roundFormatter(params) {
    return (params.value && params.value>0?Number(params.value).toFixed(2):'0.00');
  }

  dateFormatter(params) {
    return params.value ? format(new Date(params.value), 'ddd MM/DD/YYYY') : '';
  }

  timeFormatter(params) {
    return params.value ?format(new Date(params.value), 'hh:mm A'): '';
  }

  valFormater(params) {
    if (params.node.key === '$'){
      if(params.value != null) {
        //return "\x24" + params.value ;
        return params.value.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
       }
    else
        return "\x24 0.00";
    } else if (params.node.key === 'H') {
      if (params.value != null) {
        return params.value.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
      } else
        return "0.00";
    }else if(params.value){
      if(params.value != null)
        //return '0.00';
        return params.value.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
      else
        return '0.00'; //params.value;
    }
  }

  setUpGrid(){
    // this.columnDefs.map(column=>{
		// 	if(column['children']){
		// 		column['children'].map(col=>{            
		// 			if (col.xChartLine) { this.xList = col };
		// 			if (col.yChartLine) { this.yList.push(col) };
		// 		});
		// 	}else{
		// 		if (column['xChartLine']) { this.xList = column };
		// 		if (column['yChartLine']) { this.yList.push(column) };
		// 	}        
		// });
    this.sideBar = {
      toolPanels: [
        {
          id: "columns",
          labelDefault: "Columns",
          labelKey: "columns",
          iconKey: "columns",
          toolPanel: "agColumnsToolPanel",
          toolPanelParams: {
            suppressPivots: true,
            suppressPivotMode: true,
            suppressValues: true,
            enableRowGroup: true
          }
        }
      ]
		};
		this.dataLoaded = true;
  }


  clearFilters() {
    this.gridApi.setFilterModel(null);
    this.gridApi.onFilterChanged();
  }

  onBtExportPdf() {
    const doc = new jsPDF('l', 'pt');
    let head =[],headToBody=[],body=[];
    // this.columnDefs.map(column=>{
    //   if(column['children']){
    //     column['children'].map(col=>{
    //       head.push(col.headerName);
    //       headToBody.push(col.field);
    //     });
    //   }else{
    //     head.push(column.headerName);
    //     headToBody.push(column.field);
    //   }
    // });
    const data = this.exportPDFData(this.tabSelected);
    doc.autoTable(data);
    doc.save(this.heading+'.pdf');
  }

  logTabChange(event) {
    this.tabSelected = event;
  }

  onBtExport() {
    var params = {
      allColumns: false,
      columnGroups: true,
      exportMode: "xlsx",
      fileName: this.tabSelected  + ' Report',
      selectAll: true,
      onlySelected: false,
      sheetName: this.tabSelected  + ' Report',
      skipFooters: false,
      skipHeader: false,
      skipPinnedBottom: false,
      skipPinnedTop: false,
      shouldRowBeSkipped:function (params:any) {
        console.log(params)
      },
      processCellCallback : this.reportingCommonService.getExcelFormatting,
      customHeader: this.generateCustomHeader()
    }
    this.exportExcelData(this.tabSelected, params);
  }
  generateCustomHeader(){
    let initHeader = [
      [],
      [
        {
          styleId: "staffHeader",
          data: {
            type: "String",
            value: "MY STAFF REPORTS"
          }
        },
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: "Run by "+ this.globals.rbacProfile.user_name
          },
          mergeAcross: 2
        }
      ],
      [
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: this.tabSelected
          }
        },
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: "Run at " + format(new Date(), 'MM/DD/YYYY HH:mm a')
          },
          mergeAcross: 2
        }
      ],
      [
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: this.selected_team
          }
        }
      ],
      []
    ] 
    if (this.tabSelected == 'Time Detail'){
      this.buildDataToTimeDetailExcel(initHeader);
    }

    return initHeader;
  }

  buildDataToTimeDetailExcel(initHeader){
    let headers: any = [{
      styleId: "blueHeader",
      data: {
        type: "String",
        value:  'Rev Center Summary	'
      },
      mergeAcross: 1
    }]
    this.timeDetailColumnDefsTeams.map((team: any) => {
      headers.push({
        styleId: "blueHeader",
        data: {
          type: "String",
          value: team
        }
      })
    })
    initHeader.push(headers);
    this.timeDetailColumnDefJobs.map(job => {
      let row = [{
        styleId: "blueHeader",
        data: {
          type: "String",
          value:  job+'\n'
        }
      }];
      row.push({
        styleId: "pageHeader",
        data: {
          type: "String",
          value: '$\nHours'
        }
      });
      this.timeDetailColumnDefsTeams.map(team => {
        const item = this.getElementTiemDetail(team, job);
        row.push({
          styleId: "pageHeader",
          data: {
            type: "String",
            value: '$'+this.limitDecimals(item.amount) + '\n' + this.limitDecimals(item.time)
          }
        });
      })
      initHeader.push(row);
    });
    initHeader.push([]);
  }

  generateTableByTeams(customHeader){
      if (this.teamNameGrpuping.length) {
        customHeader.push([
          {
            styleId: "blueHeader",
            data: {
              type: "String",
              value: 'Team Name'
            },
          },
          {
            styleId: "header",
            data: {
              type: "String",
              value: '$Amount'
            },
          },
          {
            styleId: "header",
            data: {
              type: "String",
              value: 'Hours'
            }
          }
        ])
      }
      this.teamNameGrpuping.map((item: any) => {
        customHeader.push([
          {
            styleId: "allCell",
            data: {
              type: "String",
              value: item.team
            },
          },
          {
            styleId: "numberCell",
            data: {
              type: "String",
              value: this.reportingCommonService.currencyFormatter({value: item.amount_total})
            },
          },
          {
            styleId: "numberCell",
            data: {
              type: "String",
              value: this.reportingCommonService.roundFormatter({value: item.hours_total})
            }
          }
        ])
      });
  }

  getCostumTotalsHeader(){
      return  [
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: ""
          },
        },
        {
          styleId: "header",
          data: {
            type: "String",
            value: "$ Amount"
          },
        },
        {
          styleId: "header",
          data: {
            type: "String",
            value: "Hours"
          }
        }
      ];
  }

  getSummaryTotalsHeader(customHeader){
    this.associateGrouping.map((item: any) => {
      customHeader.push([
        {
          styleId: "allCell",
          data: {
            type: "String",
            value: item.message
          },
          mergeAcross: 1
        },
        {
          styleId: "allCell",
          data: {
            type: "Number",
            value: item.value
          },
        }
      ])
    });
    customHeader.push([]);
}

  getCostumTotalsData(): Array<any>{
      return [
        {
          styleId: "blueHeader",
          data: {
            type: "String",
            value: "TOTAL:"
          },
        },
        {
          styleId: "numberCell",
          data: {
            type: "String",
            value: this.reportingCommonService.currencyFormatter({value: this.trialBalancetotalAmount})
          },
        },
        {
          styleId: "numberCell",
          data: {
            type: "String",
            value: this.reportingCommonService.roundFormatter({value:this.trialBalancetotalHours})
          }
        }
      ];
  }

  exportExcelData(index, params) {
    switch (index) {
      case 'Time Detail':
        this.timedetail.gridApi.exportDataAsExcel(params);
        break;
      case 'Exceptions':
        this.exceptions.gridApi.exportDataAsExcel(params);
        break;
      case 'DOT':
        this.dot.gridApi.exportDataAsExcel(params);
        break;
      default:
        break;
    }
  }
  exportPDFData(index) {
    let body:any = [];
    // switch (index) {
    //   case '':
    //     let headToBody = []; 
    //     this.rowData.map(row=>{
    //       let dummyRow= [];
    //       headToBody.map(attr=>{
    //         dummyRow.push(row[attr]);
    //       });
    //       body.push(dummyRow);
    //     });
    //     return {head: [], body}
    //   case 'Trial Balance':
    //     let head = [['Name','ID','JobName','Paycode',"$ Amount",'Hours','Rate','Billed Location']];
    //     this.trialRowData.map(item => {
    //       const { emp_firstname, emp_name, job_name, tcode_group, worked_amount, worked_minutes, worked_rate, display_value } = item;
    //       body.push([emp_firstname, emp_name, job_name, tcode_group, worked_amount, worked_minutes, worked_rate, display_value]);
    //     })
    //     return {body, head};
    //   case 'Exception':
    //     this.exceptionsRowData.map(row=>{
    //       let dummyRow= [];
    //       headToBody.map(attr=>{
    //         dummyRow.push(row[attr]);
    //       });
    //       body.push(dummyRow);
    //     });
    //     return {head: [], body}
    //   default:
    //     break;
    // }
  }



  onBtPrint() {
    var gridApi = this.gridApi;
    this.setPrinterFriendly();
    setTimeout(function() {
      print();
      this.setNormal();
    }, 2000);
  }

  setPrinterFriendly() {
    this.gridApi.setDomLayout("print");
    this.width = '';
    this.height = '';
	}
	
  setNormal() {
    this.width='100%';
    this.height='calc(100vh - 110px)';
    this.gridApi.setDomLayout(null);
  }

  showChart(view){
    this.viewType = view;
    setTimeout(() => {
      const width = document.getElementById("ngxChartId").offsetWidth;
      this.view = [width - ((5 * width) /100), width - ((60 * width) /100)];
    }, 100);
  }


  onExceptionGridReady(params) {
    this.exceptionGridApi = params.api;
    this.exceptiongridColumnApi = params.columnApi;
    //this.exceptiongridColumnApi.setPivotMode(false);
    //this.exceptiongridColumnApi.setPivotColumns(["exception_name","display_flag"]);
    //this.exceptiongridColumnApi.setRowGroupColumns(["home_team","job_name","emp_fullname"]);
  }

  changeBlockui($ev){
    if($ev){
      this.blockUI.start('Loading...');
    }else{
      this.blockUI.stop();
    }
  }
  loadRowData() {
      this.blockUI.start('Loading...');
      this.trialBalancetotalAmount = 0;
      this.trialBalancetotalHours = 0;
      this.timeDetailColumnDefsTeams= [];
      this.timeDetailColumnDefJobs= [];
      this.timeDetailColumnDefsData = [];
      this.trialBalanceColumnDefsSumary = [];
      this.trialBalanceColumnDefsData = [];
      this.reportUrl = this.reportDefaultUrl.replace('{limit}', this.paginationPageSize.toString());
      this.reportingService.getReportData(this.reportUrl)
      .subscribe((res: {data:any, metadata:{resultCount:number}})=> {
        this.timeDetailData = res.data.timeDetail;
        this.dotData = res.data.dot;
        this.exceptionsData = res.data.exceptions;
        this.timeDetailColumnDefsTeams = res.data.timeDetailTotalTable.teams;
        this.timeDetailColumnDefJobs = res.data.timeDetailTotalTable.jobs;
        this.timeDetailColumnDefsData = res.data.timeDetailTotalTable.data;
        this.blockUI.stop(); 
      });
  }

  getElementTiemDetail(team, job){
    return this.timeDetailColumnDefsData.find((data: any) =>  data.job == job && data.team == team ) || { amount: '0', time: '0'};
  }
}