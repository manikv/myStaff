import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExceptionsReportComponent } from './exceptions.component';

describe('ExceptionsReportComponent', () => {
  let component: ExceptionsReportComponent;
  let fixture: ComponentFixture<ExceptionsReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExceptionsReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExceptionsReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
