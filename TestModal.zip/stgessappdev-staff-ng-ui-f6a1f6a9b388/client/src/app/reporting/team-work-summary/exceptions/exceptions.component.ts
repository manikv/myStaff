import { Component, OnInit, EventEmitter, Input } from '@angular/core';
import { ReportingService } from '../../common/reporting.service';
import * as excelStyles from '../../common/excelStyles/excelStyles';
import { ReportingCommonService } from '../../common/reporting.common.service';

@Component({
  selector: 'app-exceptions-report',
  templateUrl: './exceptions.component.html'
})
export class ExceptionsReportComponent implements OnInit{
  reportId;
  columnDefs = [];
  width='98%';
  height='calc(100vh - 160px)';
  viewSummary = false;
  gridOptions = {    
    defaultColDef: {
      sortable: true,
      resizable: true
    },
    suppressMaxRenderedRowRestriction: true,
    suppressColumnVirtualisation: true,
    groupDefaultExpanded: 2,
    autoGroupColumnDef: {
      pinned: "left",
      width: 250,
      headerName: 'Name',
      cellRenderer: 'agGroupCellRenderer',
      cellClass: "allCell",
      cellRendererParams: {
        suppressCount: true
      }
    },
    rowBuffer: 9999,
    suppressAggFuncInHeader: true,
    groupHideOpenParents: false,
    groupMultiAutoColumn: false,
    excelStyles: excelStyles.EXCEL_STYLES
  };
  gridApi;
  gridColumnApi;
  gridLoaded: boolean = false;

  @Input() data: Object[];
  @Input() onBlockui = new EventEmitter();

  constructor(
    private reportingService: ReportingService,
    private reportingCommonService: ReportingCommonService
  ) {}

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridColumnApi.setPivotMode(true);
  }

  ngOnInit(){
    this.reportId = 'exceptions';
    this.reportingService.getReportColumnDefs(this.reportId, '')
    .subscribe(res=>{
      res.map((col:any)=>{
        if(col.children){
          col.children.map((column:any)=>{
            if(column.valFormatter){
              column.valueFormatter = this.reportingCommonService[column.valFormatter]
            }
          });
        }else{
          if(col.valFormatter){
            col.valueFormatter = this.reportingCommonService[col.valFormatter]
          }
        }
      })
      this.columnDefs = res;
      this.gridLoaded = true;
    });
  }

  expandAlll(){
    this.gridOptions['api'].expandAll();
  }

  collapseAll(){
    this.gridOptions['api'].collapseAll();
  }
}
