import { Component, ViewChild } from '@angular/core';
import { ParametersModel } from '../common//parameters/parameters.component';
import { ReportingService } from '../common/reporting.service';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { format } from 'date-fns';
import { Globals } from '../../shared/common/global/global.provider';
import * as excelStyles from '../common/excelStyles/excelStyles';
import { BlockUI, NgBlockUI  } from 'ng-block-ui';
import { ValueFormatterService } from 'ag-grid-community';
import { TrialBalanceReportComponent } from './trial-balance/trial-balance.component';
import { ReportingCommonService } from '../common/reporting.common.service';


@Component({
  selector: 'app-trial-balance-summary-report',
  templateUrl: './trial-balance.component.html',
  styles: [`.ag-row-level-0{background-color: #fff !important;}.ag-row-level-1{background-color: #ddd !important;}.ag-row-level-2{background-color: #eee !important;}`]
})
export class TrialBalanceComponent {

  @BlockUI() blockUI: NgBlockUI;
  @ViewChild("trialbalance") trialbalance:TrialBalanceReportComponent;
  constructor(
    private reportingService: ReportingService,
    private globals: Globals,
    private reportingCommonService: ReportingCommonService
	) {
		this.parametersModel.components = [
      {"label":"Team","type":"team_name","required": true,"nullify":"associate","isSingleSelection": true},
      {"label":"Preset Dates","type":"preset_date"},
			{"label":"Start Date","type":"start_date","required": true},
      {"label":"End Date","type":"end_date","required": true},
      { "label": "Include Sub Teams", "type": "sub_teams", "model": true}
		];
		this.parametersModel.heading = this.heading;
	}
  parametersModel = new ParametersModel();
  private rowModelType = "clientSide";
  reportId;
  reportUrl =         "/api/shared/reports/teams/{team_name}/worksummary_details?sub_teams={sub_teams}&trial_data=true&home_team=true&start_date={start_date}&end_date={end_date}";
  reportDefaultUrl =  "/api/shared/reports/teams/{team_name}/worksummary_details?sub_teams={sub_teams}&trial_data=true&home_team=true&start_date={start_date}&end_date={end_date}";
  reportMainUrl =     "/api/shared/reports/teams/{team_name}/worksummary_details?sub_teams={sub_teams}&trial_data=true&home_team=true&start_date={start_date}&end_date={end_date}";
  heading = "Trial Balance Report";
  isServerData: boolean = false;
  width='98%';
  height='calc(100vh - 160px)';
  selected_team = '';
  viewType = "grid";
  view: any = "";
  xList: any;
	yList: Array<any> = [];
	paginationPageSize = 20;
  xlsStyles = excelStyles.EXCEL_STYLES;
  dataLoaded: boolean = false;
  trialData: any;
  trialBalancetotalAmount = 0;
  trialBalancetotalHours = 0;
  teamNameGrpuping = [];
  private trialBalanceColumnDefsTeams = [];
  private trialBalanceColumnDefsTcodes = [];
  private trialBalanceColumnDefsData = [];
  associateGrouping = [];
  selectedParameter: any;
  
  changeParameters(parameters){
    this.reportDefaultUrl = this.reportMainUrl;
    parameters.map(comp=>{
      switch(comp.type) {
        case 'team_name': {
          if(comp.model.team_name){
            this.reportDefaultUrl = this.reportDefaultUrl.replace('{team_name}', comp.model.team_name);
            this.selected_team = comp.model.team_name +'-'+ comp.model.team_desc
          }else{
            let teamList = [];
            comp.model.map(t=>{teamList.push(t.team_name)});
            this.reportDefaultUrl = this.reportDefaultUrl.replace('{team_name}', teamList.join(','));
          }
          break;
        }
        case 'home-team': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{home_team}', comp.model.join(','));
          break;
        }
        case 'end_date': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{end_date}', comp.model.month+'/'+comp.model.day+'/'+comp.model.year);
          comp.value= comp.model.month+'/'+comp.model.day+'/'+comp.model.year;
          break;
        }
        case 'start_date': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{start_date}', comp.model.month+'/'+comp.model.day+'/'+comp.model.year);
          comp.value= comp.model.month+'/'+comp.model.day+'/'+comp.model.year;
          break;
        }
        case 'sub_teams': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{sub_teams}', comp.model);
          break;
        }
        case 'end-date': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{end_date}', comp.model.month+'/'+comp.model.day+'/'+comp.model.year);
          break;
        }
      }
    });
		this.xList = undefined;
		this.yList = [];
    this.setUpGrid();
    this.loadRowData();
    this.selectedParameter = parameters;
  }

  
  setUpGrid(){
  	this.dataLoaded = true;
  }


  onBtExportPdf() {
    
  }


  onBtExport() {
    var params = {
      allColumns: false,
      columnGroups: true,
      exportMode: "xlsx",
      fileName: 'Trial Balance Report',
      selectAll: true,
      onlySelected: false,
      sheetName: 'Trial Balance Report',
      skipFooters: false,
      skipHeader: false,
      skipPinnedBottom: false,
      skipPinnedTop: false,
      shouldRowBeSkipped:function (params:any) {
        console.log(params)
      },
      processCellCallback : this.reportingCommonService.getExcelFormatting,
      customHeader: this.generateCustomHeader()
    }
    this.trialbalance.gridApi.exportDataAsExcel(params);
  }
  generateCustomHeader(){
    let initHeader = [
      [],
      [
        {
          styleId: "staffHeader",
          data: {
            type: "String",
            value: "MY STAFF REPORTS"
          }
        },
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: "Run by "+ this.globals.rbacProfile.user_name
          },
          mergeAcross: 2
        }
      ],
      [
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: 'Trial Balance Report'
          }
        },
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: "Run at " + format(new Date(), 'MM/DD/YYYY HH:mm a')
          },
          mergeAcross: 2
        }
      ],
      [
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: this.selected_team
          }
        }
      ]
    ];
    this.buildParamterDataExcel(initHeader);
    this.getSummaryTotalsHeader(initHeader);
    this.buildDataToTrialBalanceSummaryExcel(initHeader);
    this.buildDataToTrialBalanceExcel(initHeader);
    return initHeader;
  }

  buildParamterDataExcel(initHeader){
    let headers: any = [];
    this.selectedParameter.map((para: any) => {
      if(para.value){
        headers.push({
          styleId: "pageHeader",
          data: {
            type: "String",
            value: para.label+' - '+para.value
          }
        });
      }
    })
    initHeader.push(headers);
    initHeader.push([]);
  }


  buildDataToTrialBalanceSummaryExcel(initHeader){
    let headers: any = [{
      styleId: "blueHeader",
      data: {
        type: "String",
        value:  'Rev Center Summary	'
      },
      mergeAcross: 1
    }]
    this.trialBalanceColumnDefsTcodes.map((data: any) => {
      headers.push({
        styleId: "blueHeader",
        data: {
          type: "String",
          value: data
        }
      })
    })
    initHeader.push(headers);
    let row = [{
      styleId: "blueHeader",
      data: {
        type: "String",
        value:  this.selected_team+'\n'
      }
    }];
    row.push({
      styleId: "pageHeader",
      data: {
        type: "String",
        value: '$\nHours'
      }
    });
    this.trialBalanceColumnDefsTcodes.map(data => {
      row.push({
        styleId: "pageHeader",
        data: {
          type: "String",
          value: '$'+this.trialbalance.getElementTrialBalance('Total', data,'amount') + '\n' +this.trialbalance.getElementTrialBalance('Total', data,'time')
        }
      });
    })
    initHeader.push(row);
    initHeader.push([]);
  }

  buildDataToTrialBalanceExcel(initHeader){
    let headers: any = [{
      styleId: "blueHeader",
      data: {
        type: "String",
        value:  'Rev Center Summary	'
      },
      mergeAcross: 1
    }]
    this.trialBalanceColumnDefsTcodes.map((data: any) => {
      headers.push({
        styleId: "blueHeader",
        data: {
          type: "String",
          value: data
        }
      })
    })
    initHeader.push(headers);
    this.trialBalanceColumnDefsTeams.map(header => {
      let row = [{
        styleId: "blueHeader",
        data: {
          type: "String",
          value:  header+'\n'
        }
      }];
      row.push({
        styleId: "pageHeader",
        data: {
          type: "String",
          value: '$\nHours'
        }
      });
      this.trialBalanceColumnDefsTcodes.map(data => {
        row.push({
          styleId: "pageHeader",
          data: {
            type: "String",
            value: '$'+this.trialbalance.getElementTrialBalance(header, data,'amount') + '\n' +this.trialbalance.getElementTrialBalance(header, data,'time')
          }
        });
      })
      initHeader.push(row);
    });
    initHeader.push([]);
  }

  generateTableByTeams(customHeader){
      if (this.teamNameGrpuping.length) {
        customHeader.push([
          {
            styleId: "blueHeader",
            data: {
              type: "String",
              value: 'Team Name'
            },
          },
          {
            styleId: "header",
            data: {
              type: "String",
              value: '$Amount'
            },
          },
          {
            styleId: "header",
            data: {
              type: "String",
              value: 'Hours'
            }
          }
        ])
      }
      this.teamNameGrpuping.map((item: any) => {
        customHeader.push([
          {
            styleId: "allCell",
            data: {
              type: "String",
              value: item.team
            },
          },
          {
            styleId: "numberCell",
            data: {
              type: "String",
              value: this.reportingCommonService.currencyFormatter({value: item.amount_total})
            },
          },
          {
            styleId: "numberCell",
            data: {
              type: "String",
              value: this.reportingCommonService.roundFormatter({value: item.hours_total})
            }
          }
        ])
      });
  }

  getCostumTotalsHeader(){
      return  [
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: ""
          },
        },
        {
          styleId: "header",
          data: {
            type: "String",
            value: "$ Amount"
          },
        },
        {
          styleId: "header",
          data: {
            type: "String",
            value: "Hours"
          }
        }
      ];
  }

  getSummaryTotalsHeader(customHeader){
    this.associateGrouping.map((item: any) => {
      customHeader.push([
        {
          styleId: "allCell",
          data: {
            type: "String",
            value: item.message
          },
          mergeAcross: 1
        },
        {
          styleId: "allCell",
          data: {
            type: "Number",
            value: item.value
          },
        }
      ])
    });
    customHeader.push([]);
}

  getCostumTotalsData(): Array<any>{
      return [
        {
          styleId: "blueHeader",
          data: {
            type: "String",
            value: "TOTAL:"
          },
        },
        {
          styleId: "numberCell",
          data: {
            type: "String",
            value: this.reportingCommonService.currencyFormatter({value: this.trialBalancetotalAmount})
          },
        },
        {
          styleId: "numberCell",
          data: {
            type: "String",
            value: this.reportingCommonService.roundFormatter({value:this.trialBalancetotalHours})
          }
        }
      ];
  }

  exportPDFData(index) {
    let body:any = [];
    // switch (index) {
    //   case '':
    //     let headToBody = []; 
    //     this.rowData.map(row=>{
    //       let dummyRow= [];
    //       headToBody.map(attr=>{
    //         dummyRow.push(row[attr]);
    //       });
    //       body.push(dummyRow);
    //     });
    //     return {head: [], body}
    //   case 'Trial Balance':
    //     let head = [['Name','ID','JobName','Paycode',"$ Amount",'Hours','Rate','Billed Location']];
    //     this.trialRowData.map(item => {
    //       const { emp_firstname, emp_name, job_name, tcode_group, worked_amount, worked_minutes, worked_rate, display_value } = item;
    //       body.push([emp_firstname, emp_name, job_name, tcode_group, worked_amount, worked_minutes, worked_rate, display_value]);
    //     })
    //     return {body, head};
    //   case 'Exception':
    //     this.exceptionsRowData.map(row=>{
    //       let dummyRow= [];
    //       headToBody.map(attr=>{
    //         dummyRow.push(row[attr]);
    //       });
    //       body.push(dummyRow);
    //     });
    //     return {head: [], body}
    //   default:
    //     break;
    // }
  }
	

  showChart(view){
    this.viewType = view;
    setTimeout(() => {
      const width = document.getElementById("ngxChartId").offsetWidth;
      this.view = [width - ((5 * width) /100), width - ((60 * width) /100)];
    }, 100);
  }

  loadRowData() {
      this.blockUI.start('Loading...');
      this.trialBalancetotalAmount = 0;
      this.trialBalancetotalHours = 0;
      this.trialBalanceColumnDefsTeams = [];
      this.trialBalanceColumnDefsTcodes = [];
      this.trialBalanceColumnDefsData = [];
      this.reportUrl = this.reportDefaultUrl.replace('{limit}', this.paginationPageSize.toString());
      this.reportingService.getReportData(this.reportUrl)
      .subscribe((res: {data:any, metadata:{resultCount:number}})=> {
        this.trialData = res.data.trialBalance;
        this.associateGrouping = res.data.associateGrid;
        this.trialBalancetotalAmount = res.data.trialBalanceTotal.trialBalancetotalHours;
        this.trialBalancetotalHours = res.data.trialBalanceTotal.trialBalancetotalAmount;
        this.trialBalanceColumnDefsTcodes = res.data.trialBalanceTotalTable.tcodes;
        this.trialBalanceColumnDefsTeams = res.data.trialBalanceTotalTable.teams;
        this.trialBalanceColumnDefsData = res.data.trialBalanceTotalTable.data;
        this.blockUI.stop(); 
      });
  }
}
