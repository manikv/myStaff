import { Component, Input, Output, EventEmitter, ElementRef, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';

@Component({
  selector: 'reporting-chart-manager',
  templateUrl: './chart-manager.component.html',
  styleUrls: ['./chart-manager.component.scss']
})
export class ReportingChartManagerComponent implements OnInit{
  // options
  showXAxis = true;
  showYAxis = true;
  gradient = false;
  showLegend = false;
  showXAxisLabel = true;
  xAxisLabel = 'Team';
  showYAxisLabel = true;
  yAxisLabel = 'Value';
  @Input() view:any = '';

  // pie
  showLabels = true;
  explodeSlices = false;
  doughnut = false;

  colorScheme = {
    domain: ['#5AA454', '#A10A28', '#C7B42C', '#AAAAAA', '#000']
  };

  tempData: any = [];
  dataNgxBarChart: any= [];
  dataNgxLineChart: Array<any> = [];
  dataNgxMultiBarChart: Array<any> = [];
  dataNgxPieChart: Array<any> = [];

  private chartContainer: ElementRef;
  margin = {top: 20, right: 20, bottom: 30, left: 40};

  @Input() showBarChart: boolean;
  @Input() showLineChart: boolean;
  @Input() showPieChart: boolean;
  @Input() xList: any;
  @Input() yList: Array<any> = [];
  @Input()
  set chartDataModelInput(value) {
    if (value !== undefined) {
      this._chartDataModelInput.next(value);
    }
  };
  private _chartDataModelInput = new BehaviorSubject<[object]>(undefined);
  chartDataModel = [];

  ngOnInit(){
    this._chartDataModelInput.subscribe(model => {
      if(model){
        this.chartDataModel = model;
        this.tempData = model;
        this.buildStructureToCharts(this.chartDataModel);
      }
    }, err => console.log(err));
  }

  setPieDatadata(data){
    this.dataNgxPieChart =  data;
  }

  buildStructureToCharts(data, flag: any = false){
    if ( this.xList  && this.yList.length) {
      this.dataNgxLineChart = [];
      this.dataNgxBarChart = [];
      const headerData: any = flag ? this.yList.filter((item: any) => item.headerName === flag) : this.yList;
      if (!flag) {
        this.dataNgxMultiBarChart = data.map((item: any) => {
          return {
            name: item.wbtDesc,
            series: headerData.map((row: any) => {
              return { name: row.headerName, value: item[row.field]  }
            })
          };
        });
      };

      headerData.map((col: any) => {
        const chartData = this.dataNgxLineChart.find((row: any) => row.name === col.headerName);
        const chart = {
          name: col.headerName,
          series: data.map((item: any) => {
            return { name: item[this.xList.field] , value: item[col.field] === 'NA' ? "0.00" : item[col.field] }
          })
        };
        if ( chartData ) {
          const index = this.dataNgxLineChart.indexOf(chartData);
          this.dataNgxLineChart[index] =  chart;
          this.dataNgxBarChart = chart.series;
        } else {
          this.dataNgxLineChart.push(chart);
          this.dataNgxBarChart = chart.series;
        }
      });
      this.dataNgxPieChart = this.dataNgxMultiBarChart[0] ? this.dataNgxMultiBarChart[0].series : [];
    }
  }
} 
