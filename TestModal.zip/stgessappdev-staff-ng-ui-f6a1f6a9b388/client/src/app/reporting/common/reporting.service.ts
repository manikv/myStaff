import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { ReportingModule } from '../reporting.module';

@Injectable()
export class ReportingService {

  constructor(private http: HttpClient) { }

  private handleError(error) {
    return throwError(error);
  }

  getReportDetails(report_id: string){
    return  this.http.get(`${environment.api_url}`+ environment.urls.getReportDetails.replace('{report_id}', report_id)).pipe(map((response: {data:Array<object>}) => response.data));
  }

  getReportColumnDefs(report_id: string, dynamic){
    let params = {};
    if(dynamic.length > 0){
      params['dynamic'] = JSON.stringify(dynamic);
    }
    return  this.http.get(`${environment.api_url}`+ environment.urls.getReportColumnDefs.replace('{report_id}', report_id),{"params": params}).pipe(map((response: {data:Array<object>}) => response.data));
  }

  getReportData(report_url: string){
    return  this.http.get(`${environment.api_url}`+ '/ui' + report_url);
  }
}
