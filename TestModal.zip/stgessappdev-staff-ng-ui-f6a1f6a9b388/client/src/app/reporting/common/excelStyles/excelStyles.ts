export const EXCEL_STYLES = [
	{
		id: "allCell",
		borders: {
			borderBottom: 1,
			borderLeft: 1,
			borderTop: 1,
			borderRight: 1
		},
		font:{
			size: 9
		},
		alignment:{
			horizontal: "Left"
		},
	},
	{
		id: "allCellBold",
		borders: {
			borderBottom: 1,
			borderLeft: 1,
			borderTop: 1,
			borderRight: 1
		},
		font:{
			bold: true,
			size: 9
		},
		alignment:{
			horizontal: "Left"
		},
	},
	{
		id: "noBorderCell",
		font:{
			size: 9
		},
		alignment:{
			horizontal: "Left"
		},
	},
	{
		id: "noBorderCellBold",
		borders: {
			borderTop: 2
		},
		font:{
			bold: true,
			size: 9
		},
		alignment:{
			horizontal: "Left"
		},
	},
	{
		id: "numberCell",
		borders: {
			borderBottom: 1,
			borderLeft: 1,
			borderTop: 1,
			borderRight: 1
		},
		font:{
			size: 9
		},
		alignment:{
			horizontal: "Right"
		},
	},
	{
		id: "pageHeader",
		font:{
			bold: true,
			size: 10
		},
		alignment:{
			horizontal: "Center",
			wrapText: true
		},
		borders: {
			borderBottom: 1,
			borderLeft: 1,
			borderTop: 1,
			borderRight: 1
		}
	},
	{
		id: "staffHeader",
		font:{
			size: 10,
			bold: true,
			color: '#80C44B'
		},
		alignment:{
			horizontal: "Center",
			wrapText: true
		},
		borders: {
			borderBottom: 1,
			borderLeft: 1,
			borderTop: 1,
			borderRight: 1
		}
	},
	{
		id: "blueHeader",
		font:{
			size: 10,
			bold: true,
			color: '#FFFFFF'
		},
		alignment:{
			horizontal: "Center",
			wrapText: true
		},
		borders: {
			borderBottom: 1,
			borderLeft: 1,
			borderTop: 1,
			borderRight: 1
		},
		interior: {
			color: "#5A97D3",
			pattern: 'Solid'
		}
	},
	{
		id: 'headerReports',
		font:{
			size: 10,
			color: '#000'
		},
		alignment:{
			horizontal: "Center"
		},
		interior: {
			color: "#888888",
			pattern: "Solid"
		}
	},
	{
		id: "header",
		interior: {
			color: "#5A97D3",
			pattern: 'Solid'
		},
		font:{
			size: 12,
			bold: true,
			color: '#FFFFFF'
		},
		alignment:{
			horizontal: "Center"
		},
		borders: {
			borderBottom: 1,
			borderLeft: 1,
			borderTop: 1,
			borderRight: 1
		}
	},
	{
    id: "dothdr",
    interior: {
      color: "#CCCCCC",
      pattern: "Solid"
		}
	},
  {
    id: "dothdr",
    interior: {
      color: "#CCCCCC",
      pattern: "Solid"
    },
    font:{
      size: 12,
      bold: true
    },
    alignment:{
      horizontal: "right"
    },
    borders: {
      borderBottom: {
        color: "#5687f5",
        lineStyle: "Continuous",
        weight: 1
      },
      borderLeft: {
        color: "#5687f5",
        lineStyle: "Continuous",
        weight: 1
      },
      borderRight: {
        color: "#5687f5",
        lineStyle: "Continuous",
        weight: 1
      },
      borderTop: {
        color: "#5687f5",
        lineStyle: "Continuous",
        weight: 1
      }
    }
  },
  {
    id: "greenBackground",
    alignment: {
      horizontal: 'Right'
    },
    font: { color: "#e0ffc1"},
    interior: {
      color: "#008000", pattern: 'Solid'
    }
	},
	{
		id: "currencyFormatBold",
		borders: {
			borderBottom: 1,
			borderLeft: 1,
			borderTop: 1,
			borderRight: 1
		},
		font:{
			size: 9,
      bold: true
		},
		alignment:{
			horizontal: "Right"
		}
	},
  {
		id: "currencyFormat",
		borders: {
			borderBottom: 1,
			borderLeft: 1,
			borderTop: 1,
			borderRight: 1
		},
		font:{
			size: 9
		},
		alignment:{
			horizontal: "Right"
		},
    numberFormat: { format: "$#,##0.00" }
	},
	{
		id: "noBorderCurrencyFormat",
		font:{
			size: 9
		},
		alignment:{
			horizontal: "Right"
		},
    numberFormat: { format: "$#,##0.00" }
	},
	{
		id: "noBorderCurrencyFormatBold",
		borders: {
			borderTop: 2
		},
		font:{
			bold: true,
			size: 9
		},
		alignment:{
			horizontal: "Right"
		},
    numberFormat: { format: "$#,##0.00" }
	},
  {
		id: "numberFormat",
		borders: {
			borderBottom: 1,
			borderLeft: 1,
			borderTop: 1,
			borderRight: 1
		},
		font:{
			size: 9
		},
		alignment:{
			horizontal: "Right"
		},
    numberFormat: { format: "#,##0.00" }
	},
	{
		id: "numberFormatBold",
		borders: {
			borderBottom: 1,
			borderLeft: 1,
			borderTop: 1,
			borderRight: 1
		},
		font:{
			size: 9,
      bold: true
		},
		alignment:{
			horizontal: "Right"
		},
    numberFormat: { format: "#,##0.00" }
	},
	{
		id: "noBorderNumberFormat",
		font:{
			size: 9
		},
		alignment:{
			horizontal: "Right"
		},
    numberFormat: { format: "#,##0.00" }
	},
	{
		id: "noBorderNumberFormatBold",
		borders: {
			borderTop: 2
		},
		font:{
			size: 9,
      bold: true
		},
		alignment:{
			horizontal: "Right"
		},
    numberFormat: { format: "#,##0.00" }
	},
	{
		id: "negativeNumberFormat",
		borders: {
			borderBottom: 1,
			borderLeft: 1,
			borderTop: 1,
			borderRight: 1
		},
		font:{
			size: 9,
			color: '#990000'
		},
		alignment:{
			horizontal: "Right"
		},
    numberFormat: { format: "(#,##0.00)" }
	},
	{
		id: "negativeNumberFormatBold",
		borders: {
			borderBottom: 1,
			borderLeft: 1,
			borderTop: 1,
			borderRight: 1
		},
		font:{
			size: 9,
			color: '#990000',
      bold: true
		},
		alignment:{
			horizontal: "Right"
		},
    numberFormat: { format: "(#,##0.00)" }
	},
	{
		id: "negativecurrencyFormat",
		borders: {
			borderBottom: 1,
			borderLeft: 1,
			borderTop: 1,
			borderRight: 1
		},
		font:{
			size: 9,
			color: '#990000'
		},
		alignment:{
			horizontal: "Right"
		},
    numberFormat: { format: "($#,##0.00)" }
	},
	{
		id: "negativecurrencyFormatBold",
		borders: {
			borderBottom: 1,
			borderLeft: 1,
			borderTop: 1,
			borderRight: 1
		},
		font:{
			size: 9,
			color: '#990000',
      bold: true
		},
		alignment:{
			horizontal: "Right"
		},
    numberFormat: { format: "($#,##0.00)" }
  }
];
