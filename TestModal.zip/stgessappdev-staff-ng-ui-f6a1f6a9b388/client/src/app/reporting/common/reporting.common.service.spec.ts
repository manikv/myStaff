import { TestBed } from '@angular/core/testing';

import { ReportingCommonService } from './reporting.common.service';

describe('ReportingCommonService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ReportingCommonService = TestBed.get(ReportingCommonService);
    expect(service).toBeTruthy();
  });
});
