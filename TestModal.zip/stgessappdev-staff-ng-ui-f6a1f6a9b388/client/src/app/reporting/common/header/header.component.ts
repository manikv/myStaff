import { Component, Input, Output, EventEmitter } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'reporting-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class ReportingHeaderCompnent{
  @Input() heading: string;
  @Output() onBtnExportPdf = new EventEmitter();
  @Output() onBtnExportXslx = new EventEmitter();
  @Output() onBtnPrint = new EventEmitter();
  @Output() onBtnGrid = new EventEmitter();
  @Output() onBtnBarChart = new EventEmitter();
  @Output() onBtnPieChart = new EventEmitter();
  @Output() onBtnLineChart = new EventEmitter();
  @Output() onSchedule = new EventEmitter();
  closeResult: string;

  btnExportPdf($ev){
    this.onBtnExportPdf.emit($ev)
  }

  btnExportXslx($ev){
    this.onBtnExportXslx.emit($ev)
  }

  btnPrint($ev){
    this.onBtnPrint.emit($ev)
  }

  btnGird($ev){
    this.onBtnGrid.emit($ev)
  }

  btnBarChart($ev){
    this.onBtnBarChart.emit($ev)
  }

  btnPieChart($ev){
    this.onBtnPieChart.emit($ev)
  }

  btnLineChart($ev){
    this.onBtnLineChart.emit($ev)
  }

  schedule($ev){
    this.onSchedule.emit($ev)
  }

  openScheduleModal(content) {
    this.modalService.open(content).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

  constructor(private modalService: NgbModal){ }
} 
