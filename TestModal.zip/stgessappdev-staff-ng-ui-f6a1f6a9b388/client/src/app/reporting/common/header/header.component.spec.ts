import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportingHeaderCompnent } from './header.component';

describe('ReportingHeaderCompnent', () => {
  let component: ReportingHeaderCompnent;
  let fixture: ComponentFixture<ReportingHeaderCompnent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportingHeaderCompnent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportingHeaderCompnent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
