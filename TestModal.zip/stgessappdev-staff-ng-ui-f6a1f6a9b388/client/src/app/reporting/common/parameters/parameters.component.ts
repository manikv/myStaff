import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { trigger, state, style, animate, transition, query } from '@angular/animations';
import { Globals } from '../../../shared/common/global/global.provider';
import { DatepickerComponent, DatePickerModel } from '../../../shared/common/components/datepicker/datepicker.component';
import { CalendarPresetComponent } from '../../../shared/calendar-preset/calendar-preset.component';
import { CommonService } from '../../../shared/common/services/common.service';

export class ParametersModel {
  heading?;
  components?;
  urlQueryParams?;
}

@Component({
  selector: 'reporting-parameters',
  templateUrl: './parameters.component.html',
  styleUrls: ['./parameters.component.scss'],
  animations: [
  trigger('smoothCollapse', [
    state('initial', style({
      height:'0',
      opacity:'0',
      overflow: 'hidden',
      padding: '5px'
    })),
    state('final', style({
      opacity:'1'
    })),
    transition('initial=>final', animate('150ms')),
    transition('final=>initial', animate('150ms'))
  ])]
})
export class ParametersComponent implements OnInit {
  heading: string;
  private _parametersModelInput = new BehaviorSubject<ParametersModel>(undefined);
  parametersModel = new ParametersModel();
  submitted = false;
  availabilityToChangeDate = true;
  isCollapsed: boolean = false;
  startDateModel: DatePickerModel = {id:'ATC-start-date',required:true,validFormat:true, maxDate: null, errorText: 'start date'};
  endDateModel: DatePickerModel = {id:'ATC-end-date',required:true,validFormat:true, minDate: null, errorText: 'end date'};
  @Input() description: string;
  @Output() changeParameters = new EventEmitter();

  @Input()
  set parametersModelInput(value) {
    if (value !== undefined) {
      this._parametersModelInput.next(value);
    }
  };
  @ViewChild("startdate") startdate: DatepickerComponent;
  @ViewChild("enddate") enddate: DatepickerComponent;
  @ViewChild("presetdate") presetdate: CalendarPresetComponent;

  constructor(private globals: Globals, private commonService: CommonService){}

  ngOnInit() {
    this._parametersModelInput.subscribe(model => {
      this.parametersModel = model;
      if(this.parametersModel.urlQueryParams){
        this.setFormValue();
      }
    }, err => console.log(err));
  }

  isFormValidate(){
    if(this.parametersModel.components){
      let validated = 0, required = 0;
      this.parametersModel.components.map(component=>{
        if(component.required){
          required++;
          if(component.model){
            switch(component.type) {
              case 'start_date': {
                if(this.commonService.validateDateFormat(component.model) && this.startdate.isValidFormat){
                  validated++;
                }
                break;
              }
              case 'end_date': {
                if(this.commonService.validateDateFormat(component.model) && this.enddate.isValidFormat){
                  validated++;
                }
                break;
              }
              default:
                validated++;
                break;
            }            
          }
        }
      });
      if(validated >= required){
        return false;
      }
    }
    return true;
  }

  setFormValue(){
    this.parametersModel.components.map(component=>{
      for(var key in this.parametersModel.urlQueryParams) {
        if(this.parametersModel.urlQueryParams.hasOwnProperty(key)) {
          if(key === component.type){
            switch(key) {
              case 'team_name': {
                component.model = {team_name: this.parametersModel.urlQueryParams[key]};
                break;
              }
              case 'emp_name': {
                component.model = {emp_name: this.parametersModel.urlQueryParams[key]};
                break;
              }
              case 'balance_type': {
                component.model = {balance_type: this.parametersModel.urlQueryParams[key]};
                break;
              }
              case 'paygroup': {
                component.model = {paygroup: this.parametersModel.urlQueryParams[key]};
                break;
              }
              case 'start_date': {
                this.startdate.setValue(this.parametersModel.urlQueryParams[key]); this.startdate.setValue(this.parametersModel.urlQueryParams[key]);
                break;
              }
              case 'end_date': {
                this.startdate.setValue(this.parametersModel.urlQueryParams[key]);
                break;
              }
              case 'ovr_ids': {
                component.model = {ovr_ids: this.parametersModel.urlQueryParams[key]};
                break;
              }
            }
          }
        }
      }
    });    
  }

  select($ev, component, isDateChange = false){
    component.model = $ev;
    if(component.nullify){
      let nullifyList = component.nullify.split(',');
      nullifyList.map(item=>{
        this.parametersModel.components.map(comp=>{
          if(comp.type === item){
            comp.model = [];
          }
        });
      });      
    }
    if(this.commonService.validateDateFormat($ev)){
      if(component.type === 'start_date' || component.type === 'end_date'){
        this.setMinDate(component.type, $ev);
        this.parametersModel.components.map(comp=>{
          if(comp.type === 'preset_date'){
            comp.model = this.availabilityToChangeDate && isDateChange ? 'CUSTOMDATE' : comp.model;
            this.presetdate.checkCustomValue(component.type, component.model);
          }
        });
      }
    }
    if(component.type === 'team_name'){
      this.parametersModel.components.map(comp=>{
        // if(comp.type === 'preset_date'){
        //   this.presetdate.checkCustomValue(component.type, component.model);
        // }
      });
    }
  }

  setMinDate(type, value){
    if(type == 'start_date'){
      this.endDateModel.minDate = value;
    }else if(type == 'end_date'){
      this.startDateModel.maxDate = value;
    }
  }

  selectPaygroup($ev, type){
    this.parametersModel.components.map(component=>{
      if(type === component.type){
        component.model = $ev;
      }
    });
  }

  apply(){
    this.isCollapsed = !this.isCollapsed;
    this.changeParameters.emit(this.parametersModel.components);
  }

  changePreset($ev, component){
    this.availabilityToChangeDate = false;
    component.model = $ev;
    if($ev !== 'CUSTOMDATE'){
      this.parametersModel.components.map(comp=>{
        if(comp.type === 'start_date'){
          this.startdate.setValue($ev.start_date);
        }else if(comp.type === 'end_date'){
          this.enddate.setValue($ev.end_date);
        }
      });
    }
    this.availabilityToChangeDate = true;
  }
} 
