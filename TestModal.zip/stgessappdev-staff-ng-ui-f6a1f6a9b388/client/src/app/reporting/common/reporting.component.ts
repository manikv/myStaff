import { Component, ViewChild, OnInit,ElementRef, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CurrencyPipe } from '@angular/common';
import { IDatasource, IGetRowsParams } from 'ag-grid-community';
import { ParametersModel, ParametersComponent } from './parameters/parameters.component';
import { ReportingService } from './reporting.service';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { format } from 'date-fns'
import { Globals } from '../../shared/common/global/global.provider';
import * as excelStyles from './excelStyles/excelStyles';
import { ReportingCommonService } from '../common/reporting.common.service';
import { BlockUI, NgBlockUI  } from 'ng-block-ui';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-reporting',
  templateUrl: './reporting.component.html',
  styleUrls: ['./reporting.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ReportingComponent implements OnInit{
  private gridApi;
  private gridColumnApi;
  rowData: any = [];
  reportsConfigState = '';
  parametersModel = new ParametersModel();
  chartDataModel = [];
  columnDefs = [];
  private rowModelType;
  private rowGroupPanelShow;
  private sideBar;
  @ViewChild('parametercomponent', { static: true }) private parametercomponent: ParametersComponent;
  reportId;
  reportUrl;
  reportDefaultUrl;
  reportMainUrl;
  heading;
  description;
  parameterText = "Edit";
  isServerData: boolean = false;
  width='100%';
  height='calc(100vh - 110px)';
  viewType = "grid";
  dataLoaded: boolean = false;
  selectedParameter: any;
  // view: any[] = [900, 600];
  view: any = "";
  xList: any;
  yList: Array<any> = [];
  xlsStyles = excelStyles.EXCEL_STYLES;
  isPivot = false;
  @BlockUI() blockUI: NgBlockUI;
  constructor(
    private route: ActivatedRoute,
    private reportingService: ReportingService,
    private currencyPipe: CurrencyPipe,
    private globals: Globals,
    private reportingCommonService: ReportingCommonService,
    private modalService: NgbModal
  ) {}

  ngOnInit() {
    this.reportId = this.route.snapshot.paramMap.get('reportid');
    this.reportingService.getReportDetails(this.reportId)
    .subscribe((res:any)=>{
      this.parametersModel.components = res.parameters;
      this.parametersModel.heading = res.heading;
      this.heading = res.heading;
      this.description = res.description;
      this.reportDefaultUrl =  res.reportUrl;
      this.reportMainUrl =  res.reportUrl;
      this.isServerData =  res.serverdata;
      if(this.isServerData){
        this.rowModelType = "infinite";
      }else{
        this.rowModelType = "clientSide";
      }
      this.isServerData =  res.serverdata;
      this.gridOptions = res.gridOptions;
      this.parametersModel.urlQueryParams = this.route.snapshot.queryParamMap['params'];
      this.isPivot = res.pivotTable;
      this.reportsConfigState = 'config';
    }, error=>{
      this.reportsConfigState = 'error';
    });
  }

  changeParameters(parameters){
    this.reportsConfigState = 'config';
    let dynamic = [];
    this.reportDefaultUrl = this.reportMainUrl;
    parameters.map(comp=>{
      if(comp.dynamic){
        let dummyDynamic = {type: comp.dynamic, values: comp.model}
        dynamic.push(dummyDynamic);
      }
      switch(comp.type) {
        case 'team_name': {
          if(comp.model.team_name){
            this.reportDefaultUrl = this.reportDefaultUrl.replace('{team_name}', comp.model.team_name);
            comp.value=comp.model.team_name;
          }else{
            let teamList = [];
            comp.model.map(t=>{teamList.push(t.team_name)});
            this.reportDefaultUrl = this.reportDefaultUrl.replace('{team_name}', teamList.join(','));
            comp.value=teamList.join(',');
          }
          break;
        }
        case 'emp_name': {
          let empList = [];
          comp.model.map(e=>{empList.push(e.emp_name)});
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{emp_name}', empList.join(','));
          comp.value= empList.join(',');
          break;
        }
        case 'balance_type': {
          let balList = [], balNameList = [];
          comp.model.map(t=>{balList.push(t.id);balNameList.push(t.name)});
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{balance_type}', balList.join(','));
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{balance_name_type}', balNameList.join(','));
          comp.value= balNameList.join(',');
          break;
        }
        case 'start_date': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{start_date}', comp.model.month+'/'+comp.model.day+'/'+comp.model.year);
          comp.value= comp.model.month+'/'+comp.model.day+'/'+comp.model.year;
          break;
        }
        case 'end_date': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{end_date}', comp.model.month+'/'+comp.model.day+'/'+comp.model.year);
          comp.value= comp.model.month+'/'+comp.model.day+'/'+comp.model.year;
          break;
        }
        case 'sub_teams': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{sub_teams}', comp.model);
          break;
        }
        case 'emp_id': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{emp_id}', this.globals.staffProfile.user_id);
          break;
        }
        case 'paygroup_id': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{paygroup_id}', comp.model);
          break;
        }
        case 'ovr_ids': {
          let ovrrideList = [];
          if(comp.model){
            comp.model.map(t=>{ovrrideList.push(t.ovr_typ_id)})
          }
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{ovr_ids}', ovrrideList.join(','));
          break;
        }
        case 'pay_grp_id': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{pay_grp_id}', comp.model.id);
          break;
        }
        case 'odd_even_team': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{odd_even_team}', comp.model);
          break;
        }
      }
    });
    this.reportingService.getReportColumnDefs(this.reportId, dynamic)
    .subscribe(res=>{
      this.xList = undefined;
      this.yList = [];
      res.map((column:any)=>{
        if(column.children){
          column.children.map((col:any)=>{
            if(col.valFormatter){
              col.valueFormatter = this.reportingCommonService[col.valFormatter]
            }            
            if (col.xChartLine) { this.xList = col };
            if (col.yChartLine) { this.yList.push(col)};
            if(col.valFilter === "dateFilter"){
              col.filterParams = {
                browserDatePicker:false
              };
            }
          });
        }else{
          if(column.valFormatter){
            column.valueFormatter = this.reportingCommonService[column.valFormatter]
          }
          if (column['xChartLine']) { this.xList = column };
          if (column['yChartLine']) { this.yList.push(column)};
          if(column.valFilter === "dateFilter"){
            column.filterParams = {
              browserDatePicker:false
            };
          }
        }        
      });
      this.columnDefs = res;
      this.setUpGrid();
      this.reportsConfigState = 'loaded';
    });
    this.selectedParameter = parameters;
  }

  getDataPath = function(data) {
    return data.orgHierarchy;
  };

  setUpGrid(){
    // this.autoGroupColumnDef = { width: 150 };
    // this.rowGroupPanelShow = "never";
    this.sideBar = {
      toolPanels: [
        {
          id: "columns",
          labelDefault: "Columns",
          labelKey: "columns",
          iconKey: "columns",
          toolPanel: "agColumnsToolPanel",
          toolPanelParams: {
            suppressPivots: true,
            suppressPivotMode: true,
            suppressValues: true,
            enableRowGroup: true
          }
        }
      ]
    };
  }

  getReportLink(){
    let locationUrl = window.location.href.split('?'), reportParams = this.reportDefaultUrl.split('?')[1];
    return encodeURIComponent(locationUrl.length === 1 ? locationUrl[0]+'?'+reportParams : locationUrl[0]+'?'+locationUrl[1]+'&'+reportParams);
  }

  copyLink(ev){
    const el = document.createElement('textarea');
    el.value = this.getReportLink();
    el.setAttribute('readonly', '');
    el.style.position = 'absolute';
    el.style.left = '-9999px';
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
  }

  email(ev){
    const el = document.createElement('a');
    el.href = "mailto:?subject="+this.heading+"&body="+this.getReportLink();
    el.style.position = 'absolute';
    el.style.left = '-9999px';
    document.body.appendChild(el);
    el.click();
    document.body.removeChild(el);
  }

  paginationPageSize = 20;
  paginationNumberFormatter = function(params) {
    return "[" + params.value.toLocaleString() + "]";
  };

  gridOptions = {
    defaultColDef: {
      sortable: true,
      resizable: true
    },
    columnDefs: this.columnDefs,
    rowData: null,
    floatingFilter: true,
    rowBuffer: 29999,
    cacheBlockSize: this.paginationPageSize,
    groupDefaultExpanded: -1
  };

  clearFilters() {
    this.gridApi.setFilterModel(null);
    this.gridApi.onFilterChanged();
  }

  onBtExportPdf() {
    const doc = new jsPDF('l', 'pt');
    let head =[],headToBody=[],body=[],headToBodyFormatting=[];
    this.columnDefs.map(column=>{
      if(column.children){
        column.children.map(col=>{
          head.push(col.headerName);
          headToBody.push(col.field);
          headToBodyFormatting.push(col.valueFormatter ? col.valueFormatter : null);
        });
      }else{
        head.push(column.headerName);
        headToBody.push(column.field);
        headToBodyFormatting.push(column.valueFormatter ? column.valueFormatter : null);
      }
    });
    this.rowData.map(row=>{
      let dummyRow= [];
      headToBody.map((attr,i)=>{
        if(headToBodyFormatting[i] != null){
          dummyRow.push(headToBodyFormatting[i]({value: row[attr]}));
        }else{
          dummyRow.push(row[attr]);
        }
      });
      body.push(dummyRow);
    });
    doc.autoTable({
      head: [head],
      body: body
    });
    doc.save(this.heading+'.pdf');
  }

  onBtExport() {
    var params: any = {        
      fileName: this.heading,
      exportMode: "pdf"
    };
    
    params = {
      allColumns: false,
      columnGroups: true,
      exportMode: "xlsx",
      fileName: this.heading,
      selectAll: true,
      onlySelected: false,
      sheetName: this.heading,
      skipFooters: false,
      skipGroups: false,
      skipHeader: false,
      skipPinnedBottom: false,
      skipPinnedTop: false,
      processCellCallback : this.reportingCommonService.getExcelFormatting,
      customHeader: this.generateCustomHeader()
    }
    this.onPageSizeChanged(this.gridApi.paginationGetTotalPages()*this.gridApi.paginationGetRowCount());
    this.gridApi.exportDataAsExcel(params);
    this.onPageSizeChanged(this.paginationPageSize);
  }

  generateCustomHeader(){
    let initHeader = [
      [],
      [
        {
          styleId: "staffHeader",
          data: {
            type: "String",
            value: "MY STAFF REPORTS"
          },
          mergeAcross: 2
        },
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: "Run by "+ this.globals.rbacProfile.user_name
          }
        }
      ],
      [
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: this.heading
          },
          mergeAcross: 2
        },
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: "Run at " +format(new Date(), 'MM/DD/YYYY HH:mm a')
          }
        }
      ],
      []
    ];
    this.buildParamterDataExcel(initHeader);
    return initHeader;
  }

  buildParamterDataExcel(initHeader){
    let headers: any = [];
    this.selectedParameter.map((para: any) => {
      if(para.value){
        headers.push({
          styleId: "pageHeader",
          data: {
            type: "String",
            value: para.label ? para.label+' - '+para.value : para.value
          }
        });
      }
    })
    initHeader.push(headers);
    initHeader.push([]);
  }

  onBtPrint() {
    var gridApi = this.gridApi;
    this.setPrinterFriendly();
    setTimeout(function() {
      print();
      this.setNormal();
    }, 2000);
  }

  setPrinterFriendly() {
    this.gridApi.setDomLayout("print");
    this.width = '';
    this.height = '';
  }
  setNormal() {
    this.width='100%';
    this.height='calc(100vh - 110px)';
    this.gridApi.setDomLayout(null);
  }

  dataSource:  IDatasource   = {
    getRows: (params: IGetRowsParams ) => {
      this.blockUI.start('Loading...');
        // this.gridParams = params.request;
      let page = params.endRow/this.paginationPageSize;
        //let sort = params.request.sortModel ? this.buildSort(params.request.sortModel) : [];
      // let filter = params.request.filterModel ? this.buildFilter(params.request.filterModel) : [];
      this.reportUrl = this.reportDefaultUrl
        .replace('{limit}', this.paginationPageSize);
        this.reportingService.getReportData(this.reportUrl)
          .subscribe((res: any)=>{
            params.successCallback(res.data, res.metadata.resultCount);            
            this.rowData = res.data;
            this.blockUI.stop();
          });
    }
  };

  showChart(view){
    this.viewType = view;
    setTimeout(() => {
      const width = document.getElementById("ngxChartId").offsetWidth;
      this.view = [width - ((5 * width) /100), width - ((60 * width) /100)];
    }, 100);
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    if(this.isServerData){
      params.api.setDatasource(this.dataSource);
    }else{
      this.loadRowData()
    }
    if(this.isPivot){
      this.gridColumnApi.setPivotMode(true); 
    }
  }

  loadRowData(){
    this.blockUI.start('Loading...');
    this.reportUrl = this.reportDefaultUrl
     .replace('{limit}', this.paginationPageSize);
    this.reportingService.getReportData(this.reportUrl)
      .subscribe((res: {data:Array<object>, metadata:{resultCount:number}})=>{
        this.rowData = res.data;
        this.blockUI.stop();
      },
      error=>{
        this.modalService.open(AlertComponent);
        this.blockUI.stop();
      }
    );
  }

  onPageSizeChanged(newPageSize) {
    this.gridApi.paginationSetPageSize(Number(newPageSize));
  }
}
@Component({
  template: '<div class="modal-header"><h4 class="modal-title" id="modal-basic-title">Something went wrong!</h4></div><div class="modal-body"><p>Please check back later!</p></div><div class="modal-footer"><button type="button" class="btn btn-outline-dark" (click)="activeModal.dismiss()">ok</button></div>'
})
export class AlertComponent {
  constructor(public activeModal: NgbActiveModal) {}
}
