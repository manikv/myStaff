import { Injectable } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ReportingModule } from '../reporting.module';
import { format } from 'date-fns';

@Injectable()
export class ReportingCommonService {
  currencyFormatter(params) {
    if(params.value != undefined){
      if (Number(params.value)>0){
        return Number(params.value).toLocaleString('en-US', { style: 'currency', currency: 'USD' });
      }else if (Number(params.value) === 0) {
        return '$0.00';
      }else {
        return '('+Number(params.value*-1).toLocaleString('en-US', { style: 'currency', currency: 'USD' })+')';
      }
    }else{
      return '';
    }
  }

  roundFormatter(params) {
    if(params.value != undefined){
      if (Number(params.value)>0){
        return Number(params.value).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
      }else if (Number(params.value) === 0) {
        return '0.00';
      }else {
        return '('+(Number(params.value) * -1).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')+')';
      }
    }else{
      return '';
    }
  }

  dateFormatter(params) {
    let response = '';
    if(params.value){
      response = format(new Date(params.value), 'MM/DD/YYYY')
      if(response === 'Invalid Date'){
        let dateObj = {year:0,month:0,day:0,hr:0,min:0},
        splittedValue = params.value.split(' ');
        if(splittedValue.length === 2){
          dateObj.year = Number(splittedValue[0].split('-')[0]);
          dateObj.month = Number(splittedValue[0].split('-')[1]) -1;
          dateObj.day = Number(splittedValue[0].split('-')[2]);
          dateObj.hr = Number(splittedValue[1].split(':')[0]);
          dateObj.min = Number(splittedValue[1].split(':')[1]);
        }
        response = format(new Date(dateObj.year,dateObj.month, dateObj.day), 'MM/DD/YYYY')
      }
    }
    return response;
  }

  dayDateFormatter(params) {
    let response = '';
    if(params.value){
      response = format(new Date(params.value), 'ddd MM/DD/YYYY')
      if(response === 'Invalid Date'){
        let dateObj = {year:0,month:0,day:0,hr:0,min:0},
        splittedValue = params.value.split(' ');
        if(splittedValue.length === 2){
          dateObj.year = Number(splittedValue[0].split('-')[0]);
          dateObj.month = Number(splittedValue[0].split('-')[1]) -1;
          dateObj.day = Number(splittedValue[0].split('-')[2]);
          dateObj.hr = Number(splittedValue[1].split(':')[0]);
          dateObj.min = Number(splittedValue[1].split(':')[1]);
        }
        response = format(new Date(dateObj.year,dateObj.month, dateObj.day, dateObj.hr,dateObj.min), 'ddd MM/DD/YYYY')
      }
    }
    return response;
  }

  timeFormatter(params) {
    let response = '';
    if(params.value){
      response = format(new Date(params.value), 'hh:mm A')
      if(response === 'Invalid Date'){
        let dateObj = {year:0,month:0,day:0,hr:0,min:0},
        splittedValue = params.value.split(' ');
        if(splittedValue.length === 2){
          dateObj.year = Number(splittedValue[0].split('-')[0]);
          dateObj.month = Number(splittedValue[0].split('-')[1]) -1;
          dateObj.day = Number(splittedValue[0].split('-')[2]);
          dateObj.hr = Number(splittedValue[1].split(':')[0]);
          dateObj.min = Number(splittedValue[1].split(':')[1]);
        }
        response = format(new Date(dateObj.year,dateObj.month, dateObj.day, dateObj.hr,dateObj.min), 'hh:mm A')
      }
    }
    return response;
  }

   dotValFormater(params){
    if (params.column.originalParent != null && params.column.originalParent.colGroupDef.headerName === '$'){
      if(params.value != null)
        return params.value.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
      else
        return "\x24 0.00";
    }else if (params.column.originalParent != null && params.column.originalParent.colGroupDef.headerName === 'H') {
      if (params.value != null)
        return params.value.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
      //return params.value.toLocaleString('en-US');
      else
        return "0.00";
    }else{
      return params.value;
    }
  }

  colIdFormatter(params) {
   if (params.node.colId === 'totalshifts' || params.node.colId === 'unscheduled') {
      if (params.value != null)
        return params.value.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
      else
        return "0.00";
    }else{
      return '';
    }
  }

  getExcelFormatting(params){
    if (params.node.group){
      if(params.node.uiLevel != 2 && (params.column.colDef.cellClass == 'noBorderCell' || params.column.colDef.cellClass == 'noBorderCellBold')){
        params.column.colDef.cellClass = 'noBorderCellBold'
      }else if(params.node.uiLevel == 2 && (params.column.colDef.cellClass == 'noBorderCell' || params.column.colDef.cellClass == 'noBorderCellBold')){
        params.column.colDef.cellClass = 'noBorderCell'
      }
    }
    if (params.column.getColId() === 'ag-Grid-AutoColumn') {    //team_name'){
      if (params.value) {
        let dummy_team_name = params.value.split('->');
        if (dummy_team_name.length > 1) {
          let dummyResponse;
          if(dummy_team_name.length === 2){
            dummyResponse = '';
          }else{
            dummyResponse = '-';
            for(let i=0; i<(dummy_team_name.length-1);i++){
              dummyResponse += '    ';
            }
          }
          dummyResponse += dummy_team_name[dummy_team_name.length-1];
          return dummyResponse;
        } else if (dummy_team_name.length === 0) {
          return params.value.replace(/-> /g, '');
        } else {
          if(params.node.level > 0){
            let dummyResponse = '-';
            for(let i=0; i<(params.node.level);i++){
              dummyResponse += '    ';
            }
            return dummyResponse + params.value;
          }else{
            return params.value;
          }
        }
      }
    }    
    if(params.node.group && params.value && !params.column.aggFunc && typeof(params.value) !== 'number') {
      let dummy_value = params.value.split('->');
      return dummy_value[dummy_value.length - 1];
    }

    if (params.column.colDef.valFormatter === 'dateFormatter' && params.value){
      let response = '';
      if(params.value){
        response = format(new Date(params.value), 'MM/DD/YYYY')
        if(response === 'Invalid Date'){
          let dateObj = {year:0,month:0,day:0,hr:0,min:0},
          splittedValue = params.value.split(' ');
          if(splittedValue.length === 2){
            dateObj.year = Number(splittedValue[0].split('-')[0]);
            dateObj.month = Number(splittedValue[0].split('-')[1]) -1;
            dateObj.day = Number(splittedValue[0].split('-')[2]);
            dateObj.hr = Number(splittedValue[1].split(':')[0]);
            dateObj.min = Number(splittedValue[1].split(':')[1]);
          }
          response = format(new Date(dateObj.year,dateObj.month, dateObj.day), 'MM/DD/YYYY')
        }
      }
      return response;
    }else if (params.column.colDef.valFormatter === 'dayDateFormatter' && params.value){
      let response = '';
      if(params.value){
        response = format(new Date(params.value), 'ddd MM/DD/YYYY')
        if(response === 'Invalid Date'){
          let dateObj = {year:0,month:0,day:0,hr:0,min:0},
          splittedValue = params.value.split(' ');
          if(splittedValue.length === 2){
            dateObj.year = Number(splittedValue[0].split('-')[0]);
            dateObj.month = Number(splittedValue[0].split('-')[1]) -1;
            dateObj.day = Number(splittedValue[0].split('-')[2]);
            dateObj.hr = Number(splittedValue[1].split(':')[0]);
            dateObj.min = Number(splittedValue[1].split(':')[1]);
          }
          response = format(new Date(dateObj.year,dateObj.month, dateObj.day, dateObj.hr,dateObj.min), 'ddd MM/DD/YYYY')
        }
      }
      return response;
    }else if (params.column.colDef.valFormatter === 'timeFormatter' && params.value){
      let response = '';
      if(params.value){
        response = format(new Date(params.value), 'hh:mm A')
        if(response === 'Invalid Date'){
          let dateObj = {year:0,month:0,day:0,hr:0,min:0},
          splittedValue = params.value.split(' ');
          if(splittedValue.length === 2){
            dateObj.year = Number(splittedValue[0].split('-')[0]);
            dateObj.month = Number(splittedValue[0].split('-')[1]) -1;
            dateObj.day = Number(splittedValue[0].split('-')[2]);
            dateObj.hr = Number(splittedValue[1].split(':')[0]);
            dateObj.min = Number(splittedValue[1].split(':')[1]);
          }
          response = format(new Date(dateObj.year,dateObj.month, dateObj.day, dateObj.hr,dateObj.min), 'hh:mm A')
        }
      }
      return response;
    }else if (params.column.colDef.valFormatter === 'roundFormatter'){
       if (params.node.group){
        if(params.node.uiLevel != 2 && (params.column.colDef.cellClass == 'noBorderNumberFormat' || params.column.colDef.cellClass == 'noBorderNumberFormatBold')){
          params.column.colDef.cellClass = 'noBorderNumberFormatBold'
        }else if(params.node.uiLevel == 2 && (params.column.colDef.cellClass == 'noBorderNumberFormat' || params.column.colDef.cellClass == 'noBorderNumberFormatBold')){
          params.column.colDef.cellClass = 'noBorderNumberFormat'
        }
      }else if(params.column.colDef.cellClass != 'noBorderNumberFormat' && params.column.colDef.cellClass != 'noBorderNumberFormatBold'){
        if (Number(params.value)>=0){
          params.column.colDef.cellClass = 'numberFormat';
        }else {
          params.column.colDef.cellClass = 'negativeNumberFormat';
        }
      }
      if(params.value != undefined){       
        if (Number(params.value)>0){
          return params.value;
        }else if (Number(params.value) === 0) {
          return 0;
        }else {
          return (Number(params.value) * -1);
        }
      }else{
        return '';
      }
    }else if (params.column.colDef.valFormatter === 'currencyFormatter'){
      if (params.node.group){
        if(params.node.uiLevel != 2 && (params.column.colDef.cellClass == 'noBorderCurrencyFormat' || params.column.colDef.cellClass == 'noBorderCurrencyFormatBold')){
          params.column.colDef.cellClass = 'noBorderCurrencyFormatBold'
        }else if(params.node.uiLevel == 2 && (params.column.colDef.cellClass == 'noBorderCurrencyFormat' || params.column.colDef.cellClass == 'noBorderCurrencyFormatBold')){
          params.column.colDef.cellClass = 'noBorderCurrencyFormat'
        }
      }else if(params.column.colDef.cellClass != 'noBorderCurrencyFormat' && params.column.colDef.cellClass != 'noBorderCurrencyFormatBold'){
        if (Number(params.value)>=0){
          params.column.colDef.cellClass = 'currencyFormat';
        }else {
          params.column.colDef.cellClass = 'negativecurrencyFormat';
        }
      }
      if(params.value != undefined){       
        if (Number(params.value)>0){
          if(params.column.colDef.cellClass === 'noBorderCurrencyFormatBold' || params.column.colDef.cellClass === 'noBorderCurrencyFormat'){
            return params.value.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
          }else{
            return params.value;
          }
        }else if (Number(params.value) === 0) {
          return 0;
        }else {
          return (Number(params.value) * -1);
        }
      }else{
        return '';
      }
    } else if (params.column.colDef.valFormatter === 'dotValFormater'){
        if (params.column.originalParent.colGroupDef.headerName === '$'){
          if(params.value != null)
            return params.value.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
          else
            return "\x24 0.00";
        }else if (params.column.originalParent.colGroupDef.headerName === 'H') {
          if (params.value != null)
            return params.value.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
          //return params.value.toLocaleString('en-US');
          else
            return "0.00";
        }else{
          return params.value;
        }
      } else{
      return params.value
    }
  }
}
