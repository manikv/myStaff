import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ScheduleDotComponent } from './schedule-dot.component';

describe('ScheduleDotComponent', () => {
  let component: ScheduleDotComponent;
  let fixture: ComponentFixture<ScheduleDotComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ScheduleDotComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScheduleDotComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
