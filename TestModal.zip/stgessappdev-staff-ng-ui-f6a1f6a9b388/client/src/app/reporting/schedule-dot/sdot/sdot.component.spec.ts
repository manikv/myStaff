import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SDOTReportComponent } from './sdot.component';

describe('SDOTReportComponent', () => {
  let component: SDOTReportComponent;
  let fixture: ComponentFixture<SDOTReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SDOTReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SDOTReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
