import { Component, ViewChild, ViewEncapsulation } from '@angular/core';
import { ParametersModel } from '../common//parameters/parameters.component';
import { ReportingService } from '../common/reporting.service';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { format } from 'date-fns';
import { Globals } from '../../shared/common/global/global.provider';
import * as excelStyles from '../common/excelStyles/excelStyles';
import { BlockUI, NgBlockUI  } from 'ng-block-ui';
import { ValueFormatterService } from 'ag-grid-community';
import { SDOTReportComponent } from './sdot/sdot.component';
import { ReportingCommonService } from '../common/reporting.common.service';


@Component({
  templateUrl: './schedule-dot.component.html',
  encapsulation: ViewEncapsulation.None,
  styles: [`.ag-row-level-0{background-color: #fff !important;}.ag-row-level-1{background-color: #ddd !important;}.ag-row-level-2{background-color: #eee !important;}`]

})
export class ScheduleDotComponent {

  @BlockUI() blockUI: NgBlockUI;
  @ViewChild("dot") dot:SDOTReportComponent;
  constructor(
    private reportingService: ReportingService,
    private globals: Globals,
    private reportingCommonService: ReportingCommonService
	) {
    this.groupDefaultExpanded = 5;
    this.pivotColumnGroupTotals = "before";
    this.pivotRowTotals = "before";
		this.parametersModel.components = [
      { "label": "Team", "type": "team_name", "required": true, "isSingleSelection": true },
      { "label": "Preset Dates", "type": "preset_date" },
      { "label": "Start Date", "type": "start_date", "required": true },
      { "label": "End Date", "type": "end_date", "required": true },
      { "label": "Include Sub Teams", "type": "sub_teams", "model": true}
    ];
		this.parametersModel.heading = this.heading;
	}
	private gridApi;
	private trialGridApi;
  private exceptionGridApi;
  private dotGridApi;
  private gridColumnApi;
  private trialgridColumnApi;
  private dotgridColumnApi;
  private exceptiongridColumnApi;
  rowData: any = [];
  parametersModel = new ParametersModel();
  private rowModelType = "clientSide";
  private rowGroupPanelShow;
  private sideBar;
  private groupDefaultExpanded;
  private pivotColumnGroupTotals;
  private pivotRowTotals;
  tabSelected: any;
  autoGroupTrailColumnDef = {
    headerName: "Name",
    field: "fullName_and_id",
    width: 200,
    cellRenderer: "agGroupCellRenderer"
  };
  selected_team = '';
  timeDetailViewSummary = false;
  trialBalanceViewSummary = 'details';
  reportId;
  reportUrl = "/api/shared/reports/teams/{team_name}/schedule_details?subteam_flag={sub_teams}&start_work_day={start_date}&end_work_day={end_date}";
  reportDefaultUrl = "/api/shared/reports/teams/{team_name}/schedule_details?subteam_flag={sub_teams}&start_work_day={start_date}&end_work_day={end_date}";
  reportMainUrl = "/api/shared/reports/teams/{team_name}/schedule_details?subteam_flag={sub_teams}&start_work_day={start_date}&end_work_day={end_date}";
  heading = "Schedule DOT";
  isServerData: boolean = false;
  width='98%';
  height='calc(100vh - 160px)';
  viewType = "grid";
  view: any = "";
  xList: any;
	yList: Array<any> = [];
	paginationPageSize = 20;
  xlsStyles = excelStyles.EXCEL_STYLES;
  dataLoaded: boolean = false;
  dotData: any;
  selectedParameter: any;

  changeParameters(parameters){
    this.reportDefaultUrl = this.reportMainUrl;
    parameters.map(comp=>{
      switch(comp.type) {
        case 'team_name': {
          if(comp.model.team_name){
            this.reportDefaultUrl = this.reportDefaultUrl.replace('{team_name}', comp.model.team_name);
            this.selected_team = comp.model.team_name +'-'+ comp.model.team_desc;
          }else{
            let teamList = [];
            comp.model.map(t=>{teamList.push(t.team_name)});
            this.reportDefaultUrl = this.reportDefaultUrl.replace('{team_name}', teamList.join(','));
          }
          break;
        }
        case 'home-team': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{home_team}', comp.model.join(','));
          break;
        }
        case 'end_date': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{end_date}', comp.model.month+'/'+comp.model.day+'/'+comp.model.year);
          comp.value= comp.model.month+'/'+comp.model.day+'/'+comp.model.year;
          break;
        }
        case 'start_date': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{start_date}', comp.model.month+'/'+comp.model.day+'/'+comp.model.year);
          comp.value= comp.model.month+'/'+comp.model.day+'/'+comp.model.year;
          break;
        }
        case 'sub_teams': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{sub_teams}', comp.model);
          break;
        }
        case 'end-date': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{end_date}', comp.model.month+'/'+comp.model.day+'/'+comp.model.year);
          break;
        }
      }
    });
		this.xList = undefined;
		this.yList = [];
    this.setUpGrid();
    this.loadRowData();
    this.selectedParameter = parameters;
  }

  setUpGrid(){
    this.tabSelected = this.selected_team;
		this.dataLoaded = true;
  }


  onBtExport() {
    var params = {
      allColumns: false,
      columnGroups: true,
      exportMode: "xlsx",
      fileName: this.tabSelected  + ' Report',
      selectAll: true,
      onlySelected: false,
      sheetName: this.tabSelected  + ' Report',
      skipFooters: false,
      skipHeader: false,
      skipPinnedBottom: false,
      skipPinnedTop: false,
      shouldRowBeSkipped:function (params:any) {
        console.log(params)
      },
      processCellCallback : this.reportingCommonService.getExcelFormatting,
      customHeader: this.generateCustomHeader()
    }
    this.exportExcelData(this.tabSelected, params);
  }
  generateCustomHeader(){
    let initHeader = [
      [],
      [
        {
          styleId: "staffHeader",
          data: {
            type: "String",
            value: "MY STAFF REPORTS"
          }
        },
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: "Run by "+ this.globals.rbacProfile.user_name
          },
          mergeAcross: 2
        }
      ],
      [
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: this.tabSelected
          }
        },
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: "Run at " + format(new Date(), 'MM/DD/YYYY HH:mm a')
          },
          mergeAcross: 2
        }
      ]
    ];
    this.buildParamterDataExcel(initHeader);
    return initHeader;
  }

  buildParamterDataExcel(initHeader){
    let headers: any = [];
    this.selectedParameter.map((para: any) => {
      if(para.value){
        headers.push({
          styleId: "pageHeader",
          data: {
            type: "String",
            value: para.label+' - '+para.value
          }
        });
      }
    })
    initHeader.push(headers);
    initHeader.push([]);
  }

  exportExcelData(index, params) {
    this.dot.gridApi.exportDataAsExcel(params);
  }
  
  loadRowData() {
      this.blockUI.start('Loading...');
      this.reportUrl = this.reportDefaultUrl;
      this.reportingService.getReportData(this.reportUrl)
      .subscribe((res: {data:any, metadata:{resultCount:number}})=> {
        this.dotData = res.data;
        this.blockUI.stop(); 
      });
  }
}