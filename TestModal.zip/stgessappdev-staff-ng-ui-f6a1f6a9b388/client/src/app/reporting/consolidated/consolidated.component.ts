import { Component, ViewEncapsulation } from '@angular/core';
import { ParametersModel } from '../common/parameters/parameters.component';
import { ReportingService } from '../common/reporting.service';
import 'jspdf-autotable';
import { format, isThursday } from 'date-fns';
import { Globals } from '../../shared/common/global/global.provider';
import * as excelStyles from '../common/excelStyles/excelStyles';
import { BlockUI, NgBlockUI  } from 'ng-block-ui';
import { ReportingCommonService } from '../common/reporting.common.service';


@Component({
  templateUrl: './consolidated.component.html',
  encapsulation: ViewEncapsulation.None,
  styles: [`.ag-row-level-0{background-color: #fff !important;}.ag-row-level-1{background-color: #ddd !important;}.ag-row-level-2{background-color: #eee !important;}`]

})
export class ConsolidatedReportComponent {

  @BlockUI() blockUI: NgBlockUI;
  constructor(
    private reportingService: ReportingService,
    private globals: Globals,
    private reportingCommonService: ReportingCommonService
	) {
		this.parametersModel.components = [
      { "label": "ODD / EVEN Location(s)", "type": "odd_even_team" },
      { "label": "Time Period", "type": "preset_date", "showOnlyCurrentPayweek": true }
    ];
		this.parametersModel.heading = this.heading;
	}
	private gridApi;
  rowData: any = [];
  parametersModel = new ParametersModel();
  private rowModelType = "clientSide";
  tabSelected: any;
  autoGroupTrailColumnDef = {
    headerName: "Name",
    field: "fullName_and_id",
    width: 200,
    cellRenderer: "agGroupCellRenderer"
  };
  selected_team = '';
  timeDetailViewSummary = false;
  trialBalanceViewSummary = 'details';
  reportId;
  columnDefs = [];
  reportUrl = "/api/shared/report/consolidated_pay?pay_area={odd_even_team}";
  reportDefaultUrl = "/api/shared/report/consolidated_pay?pay_area={odd_even_team}";
  reportMainUrl = "/api/shared/report/consolidated_pay?pay_area={odd_even_team}";
  heading = "Consolidated Report";
  isServerData: boolean = false;
  width='98%';
  height='calc(100vh - 160px)';
  viewType = "grid";
  view: any = "";
	paginationPageSize = 20;
  xlsStyles = excelStyles.EXCEL_STYLES;
  dataLoaded: boolean = false;
  data: any;
  selectedParameter: any;
  summaryData: any;
  summaryWageTypeData: any;

  changeParameters(parameters){
    this.reportDefaultUrl = this.reportMainUrl;
    parameters.map(comp=>{
      switch(comp.type) {
        case 'team_name': {
          if(comp.model.team_name){
            this.reportDefaultUrl = this.reportDefaultUrl.replace('{team_name}', comp.model.team_name);
            this.selected_team = comp.model.team_name +'-'+ comp.model.team_desc;
          }else{
            let teamList = [];
            comp.model.map(t=>{teamList.push(t.team_name)});
            this.reportDefaultUrl = this.reportDefaultUrl.replace('{team_name}', teamList.join(','));
          }
          break;
        }
        case 'home-team': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{home_team}', comp.model.join(','));
          break;
        }
        case 'end_date': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{end_date}', comp.model.month+'/'+comp.model.day+'/'+comp.model.year);
          comp.value= comp.model.month+'/'+comp.model.day+'/'+comp.model.year;
          break;
        }
        case 'start_date': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{start_date}', comp.model.month+'/'+comp.model.day+'/'+comp.model.year);
          comp.value= comp.model.month+'/'+comp.model.day+'/'+comp.model.year;
          break;
        }
        case 'sub_teams': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{sub_teams}', comp.model);
          break;
        }
        case 'end-date': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{end_date}', comp.model.month+'/'+comp.model.day+'/'+comp.model.year);
          break;
        }
        case 'odd_even_team': {
          this.reportDefaultUrl = this.reportDefaultUrl.replace('{odd_even_team}', comp.model);
          break;
        }
      }
    });
    this.setUpGrid();
    this.loadRowData();
    this.selectedParameter = parameters;
  }

  setUpGrid(){
    this.tabSelected = this.selected_team;
		this.dataLoaded = true;
  }


  onBtExport() {
    var params = {
      allColumns: false,
      columnGroups: true,
      exportMode: "xlsx",
      fileName: 'Consolidated Report',
      selectAll: true,
      onlySelected: false,
      sheetName: 'Consolidated Report',
      skipFooters: false,
      skipHeader: false,
      skipPinnedBottom: false,
      skipPinnedTop: false,
      shouldRowBeSkipped:function (params:any) {
      },
      processCellCallback : this.reportingCommonService.getExcelFormatting,
      customHeader: this.generateCustomHeader()
    }
    this.exportExcelData(params);
  }
  generateCustomHeader(){
    let initHeader = [
      [],
      [
        {
          styleId: "staffHeader",
          data: {
            type: "String",
            value: "MY STAFF REPORTS"
          },
          mergeAcross: 2
        },
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: "Run by "+ this.globals.rbacProfile.user_name
          }
        }
      ],
      [
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: this.heading
          },
          mergeAcross: 2
        },
        {
          styleId: "pageHeader",
          data: {
            type: "String",
            value: "Run at " +format(new Date(), 'MM/DD/YYYY HH:mm a')
          }
        }
      ],
      []
    ];
    this.buildSummary(initHeader);
    return initHeader;
  }

  buildSummary(initHeader){
    let headers: any = [{
        styleId: "blueHeader",
        data: {
          type: "String",
          value:  'Rev Center Summary'
        }
      },
      {
        styleId: 'blueHeader',
        data: {
          type: "String",
          value:  'Weekend Date'
        },
        mergeAcross: 1
      }
    ];

    this.summaryData[0].data.map((dat: any) => {
      headers.push({
        styleId: "blueHeader",
        data: {
          type: "String",
          value: dat.hour_wage_type
        }
      })
    })
    initHeader.push(headers);
    this.summaryData.map(header => {
      let row = [{
        styleId: "blueHeader",
        data: {
          type: "String",
          value:  header.team+'\n'
        }
      }];
      row.push({
        styleId: "pageHeader",
        data: {
          type: "String",
          value: header.weekend_date
        }
      });
      row.push({
        styleId: "pageHeader",
        data: {
          type: "String",
          value: '$\nHours'
        }
      });
      header.data.map(dat => {
        row.push({
          styleId: "pageHeader",
          data: {
            type: "String",
            value: '$'+this.limitDecimals(dat.hour_wage_amt) + '\n' +this.limitDecimals(dat.hour_wage_hrs)
          }
        });
      })
      initHeader.push(row);
    });
    initHeader.push([]);
  }

  onGridReady(params) {
    this.gridApi = params.api;
  }

  exportExcelData(params) {
    this.gridApi.exportDataAsExcel(params);
  }

  loadRowData() {
    this.blockUI.start('Loading...');
    this.reportUrl = this.reportDefaultUrl;
    // let tmpData =
    //   [{"employee_id":421967,"work_id":508862246,"employee_name":"1193924","employee_first_name":"JUANA","employee_last_name":"GARZA","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583211600000,"team_name":"42917","team_desc":"GRB ADMIN","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"306075","job_desc":"WAITER/WAITRESS","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"PRODUCTIVE","worked_minutes":1,"work_rate":12.86,"home_team":"42917","home_team_desc":"GRB ADMIN","work_amount":0.21,"work_start_time":1583274300000,"work_end_time":1583274360000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"REG","tcode_name":"WRK","total_reg_mts":331,"total_reg_amt":75.61999999999998,"hour_wage_hrs":594.1666666666666,"hour_wage_amt":30778.759999999995,"hour_wage_type":"REG","team":"TOTAL"},{"employee_id":421301,"work_id":508862577,"employee_name":"1250545","employee_first_name":"STARR","employee_last_name":"VAUGHAN","shift_name":"OFF","cal_grp_name":"LEVY_SALARY_NEX","pay_grp_name":"SAT-FRI HOURLY","work_date":1581742800000,"team_name":"36219","team_desc":"NIGHT ADMIN","hourly_type_name":"OT-BASE-D","hourly_type_udf2":"OT","job_name":"046100","job_desc":"BARTENDER","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"OVERTIME","worked_minutes":30,"work_rate":8,"home_team":"36219","home_team_desc":"NIGHT ADMIN","work_amount":4,"work_start_time":1581798600000,"work_end_time":1581800400000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-02-21","tcode_grp":"OVERTIME","tcode_name":"WRK","total_ot_mts":30,"total_ot_amt":4,"hour_wage_hrs":0.5333333333333333,"hour_wage_amt":4,"hour_wage_type":"OVERTIME","team":"TOTAL"},{"employee_id":421829,"work_id":508864073,"employee_name":"1372617","employee_first_name":"JANET","employee_last_name":"BADONI","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583384400000,"team_name":"33101","team_desc":"BANK1 ADMIN","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"506150","job_desc":"TRAINING","job_grp":null,"exception_flag":"NA","project_name":"NULL","work_udf1":"PRODUCTIVE","worked_minutes":30,"work_rate":33,"home_team":"33101","home_team_desc":"BANK1 ADMIN","work_amount":16.5,"work_start_time":1583424000000,"work_end_time":1583425800000,"schedule":"Y","shift_one":"Y","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"MEAL","tcode_name":"MEAL","hour_wage_type":"MEAL","hour_wage_amt":405.59000000000003,"hour_wage_mts":1141,"hour_wage_hrs":19.016666666666666,"team":"TOTAL"},{"employee_id":421312,"work_id":508861374,"employee_name":"1252731","employee_first_name":"KEVIN","employee_last_name":"HARRIS","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583211600000,"team_name":"33101","team_desc":"BANK1 ADMIN","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"386030","job_desc":"ATTENDANT, WAREHOUSE","job_grp":"BOH","exception_flag":"NA","project_name":"NULL","work_udf1":"PRODUCTIVE","worked_minutes":4,"work_rate":11.5,"home_team":"33101","home_team_desc":"BANK1 ADMIN","work_amount":0.76,"work_start_time":1583272440000,"work_end_time":1583272680000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"BREAK","tcode_name":"BREAK","hour_wage_type":"BREAK","hour_wage_amt":394.88000000000034,"hour_wage_mts":2496,"hour_wage_hrs":41.6,"team":"TOTAL"},{"employee_id":422498,"work_id":508864053,"employee_name":"909537","employee_first_name":"GEORGE","employee_last_name":"ALLEN","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583470800000,"team_name":"33101","team_desc":"BANK1 ADMIN","hourly_type_name":"OT-PREM-W","hourly_type_udf2":"OT-Prem","job_name":"336055","job_desc":"LEAD, CONCESSION","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"OVERTIME","worked_minutes":0,"work_rate":226.59,"home_team":"33301","home_team_desc":"DYNMO ADMIN","work_amount":1521.92,"work_start_time":-2208970800000,"work_end_time":-2208970800000,"schedule":"Y","shift_one":"Y","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"FLSA-WEEK","tcode_name":"FLSA-WEEK","hour_wage_type":"FLSA-WEEK","hour_wage_amt":1521.92,"hour_wage_mts":0,"hour_wage_hrs":0,"team":"TOTAL"},{"employee_id":422489,"work_id":508862475,"employee_name":"872190","employee_first_name":"MAXIMO","employee_last_name":"AYALA","shift_name":"OFF","cal_grp_name":"LEVY_COMMISSION_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583211600000,"team_name":"33301","team_desc":"DYNMO ADMIN","hourly_type_name":"OT-PREM-D1","hourly_type_udf2":"OT-Prem","job_name":"386030","job_desc":"ATTENDANT, WAREHOUSE","job_grp":"BOH","exception_flag":"NA","project_name":"NULL","work_udf1":"OVERTIME","worked_minutes":0,"work_rate":0,"home_team":"33301","home_team_desc":"DYNMO ADMIN","work_amount":0,"work_start_time":-2208970800000,"work_end_time":-2208970800000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"FLSA-DAY","tcode_name":"FLSA-DAY","hour_wage_type":"FLSA-DAY","hour_wage_amt":3.25,"hour_wage_mts":0,"hour_wage_hrs":0,"team":"TOTAL"},{"employee_id":14917,"work_id":508859260,"employee_name":"347986","employee_first_name":"JUAN P","employee_last_name":"LOPEZ","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583470800000,"team_name":"33750","team_desc":"RKTLQ ADMIN","hourly_type_name":"PREM-AMNT","hourly_type_udf2":"Other$","job_name":"096020","job_desc":"COOK","job_grp":"BOH","exception_flag":"NA","project_name":"NULL","work_udf1":"MISC","worked_minutes":0,"work_rate":30,"home_team":"33750","home_team_desc":"RKTLQ ADMIN","work_amount":30,"work_start_time":-2208970800000,"work_end_time":-2208970800000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"SERVICE-CHARGE","tcode_name":"SERVICE-CHARGE","hour_wage_type":"SERVICE-CHARGE","hour_wage_amt":30,"hour_wage_mts":0,"hour_wage_hrs":0,"team":"TOTAL"},{"employee_id":421302,"work_id":508853545,"employee_name":"1250585","employee_first_name":"MICHAEL","employee_last_name":"MURPHY","shift_name":"OFF","cal_grp_name":"LEVY_SALARY_NEX","pay_grp_name":"SAT-FRI HOURLY","work_date":1581742800000,"team_name":"36219","team_desc":"NIGHT ADMIN","hourly_type_name":"PREM-AMNT","hourly_type_udf2":"Other$","job_name":"046100","job_desc":"BARTENDER","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"MISC","worked_minutes":0,"work_rate":10,"home_team":"36219","home_team_desc":"NIGHT ADMIN","work_amount":10,"work_start_time":-2208970800000,"work_end_time":-2208970800000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-02-21","tcode_grp":"LEAD","tcode_name":"LEAD","hour_wage_type":"LEAD","hour_wage_amt":10,"hour_wage_mts":0,"hour_wage_hrs":0,"team":"TOTAL"},{"employee_id":421302,"work_id":508853543,"employee_name":"1250585","employee_first_name":"MICHAEL","employee_last_name":"MURPHY","shift_name":"OFF","cal_grp_name":"LEVY_SALARY_NEX","pay_grp_name":"SAT-FRI HOURLY","work_date":1582088400000,"team_name":"36219","team_desc":"NIGHT ADMIN","hourly_type_name":"0.5X","hourly_type_udf2":"Prem-Adj","job_name":"046100","job_desc":"BARTENDER","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"HOLIDAY","worked_minutes":0,"work_rate":4,"home_team":"36219","home_team_desc":"NIGHT ADMIN","work_amount":32,"work_start_time":-2208970800000,"work_end_time":-2208970800000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-02-21","tcode_grp":"HOL-0.5","tcode_name":"HOL-0.5","hour_wage_type":"HOL-0.5","hour_wage_amt":32,"hour_wage_mts":0,"hour_wage_hrs":0,"team":"TOTAL"},{"employee_id":421302,"work_id":508853542,"employee_name":"1250585","employee_first_name":"MICHAEL","employee_last_name":"MURPHY","shift_name":"OFF","cal_grp_name":"LEVY_SALARY_NEX","pay_grp_name":"SAT-FRI HOURLY","work_date":1582088400000,"team_name":"36219","team_desc":"NIGHT ADMIN","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"046100","job_desc":"BARTENDER","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"HOLIDAY","worked_minutes":0,"work_rate":8,"home_team":"36219","home_team_desc":"NIGHT ADMIN","work_amount":64,"work_start_time":-2208970800000,"work_end_time":-2208970800000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-02-21","tcode_grp":"HOL","tcode_name":"HOL","hour_wage_type":"HOL","hour_wage_amt":64,"hour_wage_mts":0,"hour_wage_hrs":0,"team":"TOTAL"},{"employee_id":423114,"work_id":508856232,"employee_name":"1307768","employee_first_name":"NEWHIRE","employee_last_name":"TEST","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1582606800000,"team_name":"36273","team_desc":"DYNMO CLUB 1","hourly_type_name":"UNPAID-HOUR","hourly_type_udf2":"Unpaid","job_name":"106020","job_desc":"COOK, GRILL","job_grp":"BOH","exception_flag":"EO","project_name":"LevySchedulingTest","work_udf1":null,"worked_minutes":60,"work_rate":0,"home_team":"36273","home_team_desc":"DYNMO CLUB 1","work_amount":0,"work_start_time":1582664400000,"work_end_time":1582668000000,"schedule":"Y","shift_one":"Y","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-02-28","tcode_grp":"LE-AUTH","tcode_name":"LE-AUTH","hour_wage_type":"LE-AUTH","hour_wage_amt":0,"hour_wage_mts":60,"hour_wage_hrs":1,"team":"TOTAL"},{"employee_id":422498,"work_id":508855035,"employee_name":"909537","employee_first_name":"GEORGE","employee_last_name":"ALLEN","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583470800000,"team_name":"33101","team_desc":"BANK1 ADMIN","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"506150","job_desc":"TRAINING","job_grp":null,"exception_flag":"NA","project_name":"Test1","work_udf1":"PRODUCTIVE","worked_minutes":317,"work_rate":9,"home_team":"33301","home_team_desc":"DYNMO ADMIN","work_amount":47.55,"work_start_time":1583470800000,"work_end_time":1583489820000,"schedule":"Y","shift_one":"Y","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"REG","tcode_name":"TRN","total_reg_mts":8426,"total_reg_amt":2858.1,"team":"33301 - DYNMO ADMIN","hour_wage_hrs":140.43333333333334,"hour_wage_amt":2858.1,"hour_wage_type":"REG"},{"employee_id":421829,"work_id":508864073,"employee_name":"1372617","employee_first_name":"JANET","employee_last_name":"BADONI","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583384400000,"team_name":"33101","team_desc":"BANK1 ADMIN","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"506150","job_desc":"TRAINING","job_grp":null,"exception_flag":"NA","project_name":"NULL","work_udf1":"PRODUCTIVE","worked_minutes":30,"work_rate":33,"home_team":"33101","home_team_desc":"BANK1 ADMIN","work_amount":16.5,"work_start_time":1583424000000,"work_end_time":1583425800000,"schedule":"Y","shift_one":"Y","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"MEAL","tcode_name":"MEAL","hour_wage_type":"MEAL","hour_wage_amt":43.75,"hour_wage_mts":165,"team":"33101 - BANK1 ADMIN","hour_wage_hrs":2.75},{"employee_id":421312,"work_id":508861374,"employee_name":"1252731","employee_first_name":"KEVIN","employee_last_name":"HARRIS","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583211600000,"team_name":"33101","team_desc":"BANK1 ADMIN","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"386030","job_desc":"ATTENDANT, WAREHOUSE","job_grp":"BOH","exception_flag":"NA","project_name":"NULL","work_udf1":"PRODUCTIVE","worked_minutes":4,"work_rate":11.5,"home_team":"33101","home_team_desc":"BANK1 ADMIN","work_amount":0.76,"work_start_time":1583272440000,"work_end_time":1583272680000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"BREAK","tcode_name":"BREAK","hour_wage_type":"BREAK","hour_wage_amt":2.0999999999999996,"hour_wage_mts":11,"team":"33101 - BANK1 ADMIN","hour_wage_hrs":0.18333333333333332},{"employee_id":422498,"work_id":508864053,"employee_name":"909537","employee_first_name":"GEORGE","employee_last_name":"ALLEN","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583470800000,"team_name":"33101","team_desc":"BANK1 ADMIN","hourly_type_name":"OT-PREM-W","hourly_type_udf2":"OT-Prem","job_name":"336055","job_desc":"LEAD, CONCESSION","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"OVERTIME","worked_minutes":0,"work_rate":226.59,"home_team":"33301","home_team_desc":"DYNMO ADMIN","work_amount":1521.92,"work_start_time":-2208970800000,"work_end_time":-2208970800000,"schedule":"Y","shift_one":"Y","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"FLSA-WEEK","tcode_name":"FLSA-WEEK","hour_wage_type":"FLSA-WEEK","hour_wage_amt":1521.92,"hour_wage_mts":0,"team":"33301 - DYNMO ADMIN","hour_wage_hrs":0},{"employee_id":422542,"work_id":508862467,"employee_name":"1257941","employee_first_name":"JAMES R","employee_last_name":"FLETCHER JR.","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583211600000,"team_name":"33301","team_desc":"DYNMO ADMIN","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"506150","job_desc":"TRAINING","job_grp":null,"exception_flag":"NA","project_name":"NULL","work_udf1":"PRODUCTIVE","worked_minutes":330,"work_rate":30,"home_team":"33301","home_team_desc":"DYNMO ADMIN","work_amount":165,"work_start_time":1583253000000,"work_end_time":1583272800000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"REG","tcode_name":"TRN","total_reg_mts":14645,"total_reg_amt":25127.98,"team":"33301 - DYNMO ADMIN","hour_wage_hrs":244.08333333333334,"hour_wage_amt":25127.98,"hour_wage_type":"REG"},{"employee_id":422489,"work_id":508862481,"employee_name":"872190","employee_first_name":"MAXIMO","employee_last_name":"AYALA","shift_name":"OFF","cal_grp_name":"LEVY_COMMISSION_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583211600000,"team_name":"33301","team_desc":"DYNMO ADMIN","hourly_type_name":"OT-BASE-D-2","hourly_type_udf2":"DT","job_name":"386030","job_desc":"ATTENDANT, WAREHOUSE","job_grp":"BOH","exception_flag":"NA","project_name":"NULL","work_udf1":"OVERTIME","worked_minutes":2,"work_rate":0,"home_team":"33301","home_team_desc":"DYNMO ADMIN","work_amount":0,"work_start_time":1583272980000,"work_end_time":1583273100000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"OVERTIME","tcode_name":"WRK","total_ot_mts":2,"total_ot_amt":0,"team":"33301 - DYNMO ADMIN","hour_wage_hrs":0.03333333333333333,"hour_wage_amt":0,"hour_wage_type":"OVERTIME"},{"employee_id":422485,"work_id":508861226,"employee_name":"861573","employee_first_name":"RAYMOND","employee_last_name":"ALEXANDER","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583298000000,"team_name":"33301","team_desc":"DYNMO ADMIN","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"146055","job_desc":"HAWKER","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"PRODUCTIVE","worked_minutes":30,"work_rate":0,"home_team":"33301","home_team_desc":"DYNMO ADMIN","work_amount":0,"work_start_time":1583362800000,"work_end_time":1583364600000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"MEAL","tcode_name":"MEAL","hour_wage_type":"MEAL","hour_wage_amt":268.18,"hour_wage_mts":501,"team":"33301 - DYNMO ADMIN","hour_wage_hrs":8.35},{"employee_id":422485,"work_id":508861572,"employee_name":"861573","employee_first_name":"RAYMOND","employee_last_name":"ALEXANDER","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583211600000,"team_name":"33301","team_desc":"DYNMO ADMIN","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"146055","job_desc":"HAWKER","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"PRODUCTIVE","worked_minutes":16,"work_rate":0,"home_team":"33301","home_team_desc":"DYNMO ADMIN","work_amount":0,"work_start_time":1583273100000,"work_end_time":1583274060000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"BREAK","tcode_name":"BREAK","hour_wage_type":"BREAK","hour_wage_amt":60.42,"hour_wage_mts":564,"team":"33301 - DYNMO ADMIN","hour_wage_hrs":9.4},{"employee_id":422489,"work_id":508862475,"employee_name":"872190","employee_first_name":"MAXIMO","employee_last_name":"AYALA","shift_name":"OFF","cal_grp_name":"LEVY_COMMISSION_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583211600000,"team_name":"33301","team_desc":"DYNMO ADMIN","hourly_type_name":"OT-PREM-D1","hourly_type_udf2":"OT-Prem","job_name":"386030","job_desc":"ATTENDANT, WAREHOUSE","job_grp":"BOH","exception_flag":"NA","project_name":"NULL","work_udf1":"OVERTIME","worked_minutes":0,"work_rate":0,"home_team":"33301","home_team_desc":"DYNMO ADMIN","work_amount":0,"work_start_time":-2208970800000,"work_end_time":-2208970800000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"FLSA-DAY","tcode_name":"FLSA-DAY","hour_wage_type":"FLSA-DAY","hour_wage_amt":0,"hour_wage_mts":0,"team":"33301 - DYNMO ADMIN","hour_wage_hrs":0},{"employee_id":421362,"work_id":508863383,"employee_name":"1261397","employee_first_name":"SAMUEL L","employee_last_name":"ANDERSON","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583298000000,"team_name":"33375","team_desc":"INDY ADMIN","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"066055","job_desc":"CASHIER","job_grp":"FOH","exception_flag":"NA","project_name":"Game 5:00 PM","work_udf1":"PRODUCTIVE","worked_minutes":60,"work_rate":13,"home_team":"33101","home_team_desc":"BANK1 ADMIN","work_amount":13,"work_start_time":1583359200000,"work_end_time":1583362800000,"schedule":"Y","shift_one":"Y","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"REG","tcode_name":"TRN","total_reg_mts":60,"total_reg_amt":13,"team":"33101 - BANK1 ADMIN","hour_wage_hrs":1,"hour_wage_amt":13,"hour_wage_type":"REG"},{"employee_id":422576,"work_id":508862327,"employee_name":"1063484","employee_first_name":"ASHELY","employee_last_name":"PAUL","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583211600000,"team_name":"33750","team_desc":"RKTLQ ADMIN","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"646055","job_desc":"SUPV, CONCESSIONS LEAD","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"PRODUCTIVE","worked_minutes":5,"work_rate":9,"home_team":"33750","home_team_desc":"RKTLQ ADMIN","work_amount":0.75,"work_start_time":1583274420000,"work_end_time":1583274720000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"REG","tcode_name":"WRK","total_reg_mts":8798,"total_reg_amt":2219.059999999997,"team":"33750 - RKTLQ ADMIN","hour_wage_hrs":146.63333333333333,"hour_wage_amt":2219.059999999997,"hour_wage_type":"REG"},{"employee_id":422370,"work_id":508862326,"employee_name":"1219981","employee_first_name":"SUZANNE","employee_last_name":"GUZMAN","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583211600000,"team_name":"33750","team_desc":"RKTLQ ADMIN","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"046100","job_desc":"BARTENDER","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"PRODUCTIVE","worked_minutes":5,"work_rate":10,"home_team":"33750","home_team_desc":"RKTLQ ADMIN","work_amount":0.83,"work_start_time":1583274420000,"work_end_time":1583274720000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"BREAK","tcode_name":"BREAK","hour_wage_type":"BREAK","hour_wage_amt":240.4900000000004,"hour_wage_mts":1516,"team":"33750 - RKTLQ ADMIN","hour_wage_hrs":25.266666666666666},{"employee_id":422401,"work_id":508863274,"employee_name":"1237594","employee_first_name":"MOISES M","employee_last_name":"ALENS - TARIO","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583298000000,"team_name":"33750","team_desc":"RKTLQ ADMIN","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"506150","job_desc":"TRAINING","job_grp":null,"exception_flag":"NA","project_name":"NULL","work_udf1":"PRODUCTIVE","worked_minutes":25,"work_rate":10,"home_team":"33750","home_team_desc":"RKTLQ ADMIN","work_amount":4.16,"work_start_time":1583337900000,"work_end_time":1583339400000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"MEAL","tcode_name":"MEAL_LT_30MIN","hour_wage_type":"MEAL","hour_wage_amt":65.66,"hour_wage_mts":265,"team":"33750 - RKTLQ ADMIN","hour_wage_hrs":4.416666666666667},{"employee_id":14917,"work_id":508859260,"employee_name":"347986","employee_first_name":"JUAN P","employee_last_name":"LOPEZ","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583470800000,"team_name":"33750","team_desc":"RKTLQ ADMIN","hourly_type_name":"PREM-AMNT","hourly_type_udf2":"Other$","job_name":"096020","job_desc":"COOK","job_grp":"BOH","exception_flag":"NA","project_name":"NULL","work_udf1":"MISC","worked_minutes":0,"work_rate":30,"home_team":"33750","home_team_desc":"RKTLQ ADMIN","work_amount":30,"work_start_time":-2208970800000,"work_end_time":-2208970800000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"SERVICE-CHARGE","tcode_name":"SERVICE-CHARGE","hour_wage_type":"SERVICE-CHARGE","hour_wage_amt":30,"hour_wage_mts":0,"team":"33750 - RKTLQ ADMIN","hour_wage_hrs":0},{"employee_id":421302,"work_id":508853538,"employee_name":"1250585","employee_first_name":"MICHAEL","employee_last_name":"MURPHY","shift_name":"OFF","cal_grp_name":"LEVY_SALARY_NEX","pay_grp_name":"SAT-FRI HOURLY","work_date":1581915600000,"team_name":"36219","team_desc":"NIGHT ADMIN","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"046100","job_desc":"BARTENDER","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"PRODUCTIVE","worked_minutes":300,"work_rate":8,"home_team":"36219","home_team_desc":"NIGHT ADMIN","work_amount":40,"work_start_time":1581937200000,"work_end_time":1581955200000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-02-21","tcode_grp":"REG","tcode_name":"WRK","total_reg_mts":2895,"total_reg_amt":386,"team":"36219 - NIGHT ADMIN","hour_wage_hrs":48.25,"hour_wage_amt":386,"hour_wage_type":"REG"},{"employee_id":421301,"work_id":508862577,"employee_name":"1250545","employee_first_name":"STARR","employee_last_name":"VAUGHAN","shift_name":"OFF","cal_grp_name":"LEVY_SALARY_NEX","pay_grp_name":"SAT-FRI HOURLY","work_date":1581742800000,"team_name":"36219","team_desc":"NIGHT ADMIN","hourly_type_name":"OT-BASE-D","hourly_type_udf2":"OT","job_name":"046100","job_desc":"BARTENDER","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"OVERTIME","worked_minutes":30,"work_rate":8,"home_team":"36219","home_team_desc":"NIGHT ADMIN","work_amount":4,"work_start_time":1581798600000,"work_end_time":1581800400000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-02-21","tcode_grp":"OVERTIME","tcode_name":"WRK","total_ot_mts":30,"total_ot_amt":4,"team":"36219 - NIGHT ADMIN","hour_wage_hrs":0.5,"hour_wage_amt":4,"hour_wage_type":"OVERTIME"},{"employee_id":421302,"work_id":508853535,"employee_name":"1250585","employee_first_name":"MICHAEL","employee_last_name":"MURPHY","shift_name":"OFF","cal_grp_name":"LEVY_SALARY_NEX","pay_grp_name":"SAT-FRI HOURLY","work_date":1581829200000,"team_name":"36219","team_desc":"NIGHT ADMIN","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"046100","job_desc":"BARTENDER","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"PRODUCTIVE","worked_minutes":30,"work_rate":8,"home_team":"36219","home_team_desc":"NIGHT ADMIN","work_amount":4,"work_start_time":1581868800000,"work_end_time":1581870600000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-02-21","tcode_grp":"MEAL","tcode_name":"MEAL_GT_35MIN","hour_wage_type":"MEAL","hour_wage_amt":28,"hour_wage_mts":210,"team":"36219 - NIGHT ADMIN","hour_wage_hrs":3.5},{"employee_id":421302,"work_id":508853545,"employee_name":"1250585","employee_first_name":"MICHAEL","employee_last_name":"MURPHY","shift_name":"OFF","cal_grp_name":"LEVY_SALARY_NEX","pay_grp_name":"SAT-FRI HOURLY","work_date":1581742800000,"team_name":"36219","team_desc":"NIGHT ADMIN","hourly_type_name":"PREM-AMNT","hourly_type_udf2":"Other$","job_name":"046100","job_desc":"BARTENDER","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"MISC","worked_minutes":0,"work_rate":10,"home_team":"36219","home_team_desc":"NIGHT ADMIN","work_amount":10,"work_start_time":-2208970800000,"work_end_time":-2208970800000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-02-21","tcode_grp":"LEAD","tcode_name":"LEAD","hour_wage_type":"LEAD","hour_wage_amt":10,"hour_wage_mts":0,"team":"36219 - NIGHT ADMIN","hour_wage_hrs":0},{"employee_id":421301,"work_id":508862576,"employee_name":"1250545","employee_first_name":"STARR","employee_last_name":"VAUGHAN","shift_name":"OFF","cal_grp_name":"LEVY_SALARY_NEX","pay_grp_name":"SAT-FRI HOURLY","work_date":1581742800000,"team_name":"36219","team_desc":"NIGHT ADMIN","hourly_type_name":"OT-PREM-D1","hourly_type_udf2":"OT-Prem","job_name":"046100","job_desc":"BARTENDER","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"OVERTIME","worked_minutes":0,"work_rate":6.5,"home_team":"36219","home_team_desc":"NIGHT ADMIN","work_amount":3.25,"work_start_time":-2208970800000,"work_end_time":-2208970800000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-02-21","tcode_grp":"FLSA-DAY","tcode_name":"FLSA-DAY","hour_wage_type":"FLSA-DAY","hour_wage_amt":3.25,"hour_wage_mts":0,"team":"36219 - NIGHT ADMIN","hour_wage_hrs":0},{"employee_id":421302,"work_id":508853543,"employee_name":"1250585","employee_first_name":"MICHAEL","employee_last_name":"MURPHY","shift_name":"OFF","cal_grp_name":"LEVY_SALARY_NEX","pay_grp_name":"SAT-FRI HOURLY","work_date":1582088400000,"team_name":"36219","team_desc":"NIGHT ADMIN","hourly_type_name":"0.5X","hourly_type_udf2":"Prem-Adj","job_name":"046100","job_desc":"BARTENDER","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"HOLIDAY","worked_minutes":0,"work_rate":4,"home_team":"36219","home_team_desc":"NIGHT ADMIN","work_amount":32,"work_start_time":-2208970800000,"work_end_time":-2208970800000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-02-21","tcode_grp":"HOL-0.5","tcode_name":"HOL-0.5","hour_wage_type":"HOL-0.5","hour_wage_amt":32,"hour_wage_mts":0,"team":"36219 - NIGHT ADMIN","hour_wage_hrs":0},{"employee_id":421302,"work_id":508853542,"employee_name":"1250585","employee_first_name":"MICHAEL","employee_last_name":"MURPHY","shift_name":"OFF","cal_grp_name":"LEVY_SALARY_NEX","pay_grp_name":"SAT-FRI HOURLY","work_date":1582088400000,"team_name":"36219","team_desc":"NIGHT ADMIN","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"046100","job_desc":"BARTENDER","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"HOLIDAY","worked_minutes":0,"work_rate":8,"home_team":"36219","home_team_desc":"NIGHT ADMIN","work_amount":64,"work_start_time":-2208970800000,"work_end_time":-2208970800000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-02-21","tcode_grp":"HOL","tcode_name":"HOL","hour_wage_type":"HOL","hour_wage_amt":64,"hour_wage_mts":0,"team":"36219 - NIGHT ADMIN","hour_wage_hrs":0},{"employee_id":421305,"work_id":508861599,"employee_name":"1250632","employee_first_name":"SAMUEL","employee_last_name":"HARLEY","shift_name":"OFF","cal_grp_name":"LEVY_SALARY_NEX","pay_grp_name":"SAT-FRI HOURLY","work_date":1583211600000,"team_name":"36219","team_desc":"NIGHT ADMIN","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"046100","job_desc":"BARTENDER","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"PRODUCTIVE","worked_minutes":34,"work_rate":8,"home_team":"36219","home_team_desc":"NIGHT ADMIN","work_amount":4.53,"work_start_time":1583272620000,"work_end_time":1583274660000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"BREAK","tcode_name":"BREAK","hour_wage_type":"BREAK","hour_wage_amt":4.53,"hour_wage_mts":34,"team":"36219 - NIGHT ADMIN","hour_wage_hrs":0.5666666666666667},{"employee_id":423114,"work_id":508856227,"employee_name":"1307768","employee_first_name":"NEWHIRE","employee_last_name":"TEST","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1582606800000,"team_name":"36273","team_desc":"DYNMO CLUB 1","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"106020","job_desc":"COOK, GRILL","job_grp":"BOH","exception_flag":"NA","project_name":"LevySchedulingTest","work_udf1":"PRODUCTIVE","worked_minutes":480,"work_rate":12,"home_team":"36273","home_team_desc":"DYNMO CLUB 1","work_amount":96,"work_start_time":1582635600000,"work_end_time":1582664400000,"schedule":"Y","shift_one":"Y","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-02-28","tcode_grp":"REG","tcode_name":"WRK","total_reg_mts":495,"total_reg_amt":99,"team":"36273 - DYNMO CLUB 1","hour_wage_hrs":8.25,"hour_wage_amt":99,"hour_wage_type":"REG"},{"employee_id":423113,"work_id":508862058,"employee_name":"1307769","employee_first_name":"LEVYSUBSITE","employee_last_name":"TEST","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583211600000,"team_name":"36273","team_desc":"DYNMO CLUB 1","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"100","job_desc":"BAKER","job_grp":null,"exception_flag":"NA","project_name":"NULL","work_udf1":"PRODUCTIVE","worked_minutes":5,"work_rate":12,"home_team":"36273","home_team_desc":"DYNMO CLUB 1","work_amount":1,"work_start_time":1583274180000,"work_end_time":1583274480000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"BREAK","tcode_name":"BREAK","hour_wage_type":"BREAK","hour_wage_amt":7.6000000000000005,"hour_wage_mts":38,"team":"36273 - DYNMO CLUB 1","hour_wage_hrs":0.6333333333333333},{"employee_id":423114,"work_id":508856232,"employee_name":"1307768","employee_first_name":"NEWHIRE","employee_last_name":"TEST","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1582606800000,"team_name":"36273","team_desc":"DYNMO CLUB 1","hourly_type_name":"UNPAID-HOUR","hourly_type_udf2":"Unpaid","job_name":"106020","job_desc":"COOK, GRILL","job_grp":"BOH","exception_flag":"EO","project_name":"LevySchedulingTest","work_udf1":null,"worked_minutes":60,"work_rate":0,"home_team":"36273","home_team_desc":"DYNMO CLUB 1","work_amount":0,"work_start_time":1582664400000,"work_end_time":1582668000000,"schedule":"Y","shift_one":"Y","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-02-28","tcode_grp":"LE-AUTH","tcode_name":"LE-AUTH","hour_wage_type":"LE-AUTH","hour_wage_amt":0,"hour_wage_mts":60,"team":"36273 - DYNMO CLUB 1","hour_wage_hrs":1},{"employee_id":421967,"work_id":508862246,"employee_name":"1193924","employee_first_name":"JUANA","employee_last_name":"GARZA","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583211600000,"team_name":"42917","team_desc":"GRB ADMIN","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"306075","job_desc":"WAITER/WAITRESS","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"PRODUCTIVE","worked_minutes":1,"work_rate":12.86,"home_team":"42917","home_team_desc":"GRB ADMIN","work_amount":0.21,"work_start_time":1583274300000,"work_end_time":1583274360000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"REG","tcode_name":"WRK","total_reg_mts":331,"total_reg_amt":75.61999999999998,"team":"42917 - GRB ADMIN","hour_wage_hrs":5.516666666666667,"hour_wage_amt":75.61999999999998,"hour_wage_type":"REG"},{"employee_id":422025,"work_id":508862315,"employee_name":"1235120","employee_first_name":"ALEIDA","employee_last_name":"PONCE","shift_name":"OFF","cal_grp_name":"LEVY_HOURLY","pay_grp_name":"SAT-FRI HOURLY","work_date":1583211600000,"team_name":"42917","team_desc":"GRB ADMIN","hourly_type_name":"REG","hourly_type_udf2":"Reg","job_name":"306075","job_desc":"WAITER/WAITRESS","job_grp":"FOH","exception_flag":"NA","project_name":"NULL","work_udf1":"PRODUCTIVE","worked_minutes":5,"work_rate":13,"home_team":"42917","home_team_desc":"GRB ADMIN","work_amount":1.08,"work_start_time":1583274420000,"work_end_time":1583274720000,"schedule":"N","shift_one":"N","shift_two":"N","shift_three":"N","pay_dist":"ODD","weekend_date":"2020-03-06","tcode_grp":"BREAK","tcode_name":"BREAK","hour_wage_type":"BREAK","hour_wage_amt":79.73999999999992,"hour_wage_mts":333,"team":"42917 - GRB ADMIN","hour_wage_hrs":5.55}];
    // this.data = tmpData;
    // this.createSummaryData();
    // this.blockUI.stop();
    this.reportingService.getReportData(this.reportUrl)
        .subscribe((res: {data:any, metadata:{resultCount:number}})=> {
          this.data = res.data;
          this.createSummaryData();
          this.blockUI.stop();
      });
  }

  createSummaryData(){
    this.summaryData = [];
    let totalData = {
        team: 'TOTAL',
        weekend_date: '',
        data: [{
          hour_wage_type: "TOTAL",
          hour_wage_amt: 0,
          hour_wage_hrs: 0
        }]
    },
    colVal=[{
      hour_wage_type: "TOTAL",
      hour_wage_amt: 0,
      hour_wage_hrs: 0
    }];
    this.data.map(val=>{
      if(val.team == 'TOTAL'){
        totalData.data.push(val);
        totalData.data[0].hour_wage_amt += val.hour_wage_amt;
        totalData.data[0].hour_wage_hrs += val.hour_wage_hrs;
        colVal.push({hour_wage_type: val.hour_wage_type,hour_wage_amt: 0,hour_wage_hrs: 0})
      }
    });
    this.summaryData.push(totalData);
    this.data.map(val=>{
      if(val.team != 'TOTAL'){
        let sumData = {
          team: val.team,
          weekend_date: val.weekend_date,
          data: JSON.parse(JSON.stringify(colVal))
        };
        const index = this.summaryData.map(o => o.team).indexOf(val.team);
        if(index == -1){
          sumData.data.map(col=>{
            if(col.hour_wage_type == val.hour_wage_type){
              col.hour_wage_amt = val.hour_wage_amt;
              col.hour_wage_hrs = val.hour_wage_hrs;
              sumData.data[0].hour_wage_amt = val.hour_wage_amt;
              sumData.data[0].hour_wage_hrs = val.hour_wage_hrs;
            }
          });
          this.summaryData.push(sumData);
        }else{
          this.summaryData[index].data[0].hour_wage_amt += val.hour_wage_amt;
          this.summaryData[index].data[0].hour_wage_hrs += val.hour_wage_hrs;
          this.summaryData[index].data.map(col=>{
            if(col.hour_wage_type == val.hour_wage_type){
              col.hour_wage_amt = val.hour_wage_amt;
              col.hour_wage_hrs = val.hour_wage_hrs;
            }
          });
        }
      }
    });
  }

  limitDecimals(value){
    return Number(Math.floor(value *100)/100).toFixed(2);
  }
}
