import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AlertComponent, ReportingComponent } from './common/reporting.component';
import { ParametersComponent } from './common/parameters/parameters.component';
import { ReportingHeaderCompnent } from './common/header/header.component';
import { ReportingChartManagerComponent } from './common/chart-manager/chart-manager.component';
import { ReportingRoutingModule } from './reporting-routing.module';
import 'ag-grid-community';
import 'ag-grid-enterprise';
import { AgGridModule } from 'ag-grid-angular';
import { DatepickerModule } from '../shared/common/components/datepicker/datepicker.module';
import { DropdownModule } from '../shared/common/components/dropdown/dropdown.module';
import { ReportingService } from './common/reporting.service';
import { CurrencyPipe } from '@angular/common';
// import { LineChartComponent } from './common/charts/line_chart/line-chart.component';
// import { BarChartComponent } from './common/charts/bar_chart/bar-chart.component';
// import { PieChartComponent } from './common/charts/pie_chart/pie-chart.component';
import { LicenseManager } from "ag-grid-enterprise";
LicenseManager.setLicenseKey("SoftwareONE_USA_on_behalf_of_Compass_Group_USA_MultiApp_5Devs_5Deployment_12_August_2020__MTU5NzE4NjgwMDAwMA==de1432ef47c510c631b782c11ab2920d");
// ngx-charts modules
import { DOTReportComponent } from './team-work-summary/dot/dot.component';
import { TeamWorkSummaryComponent } from './team-work-summary/team-work-summary.component';
import { TrialBalanceComponent } from './team-work-summary/trial-balance.component';
import { TimeDetailReportComponent } from './team-work-summary/time-detail/time-detail.component';
import { TrialBalanceReportComponent } from './team-work-summary/trial-balance/trial-balance.component';
import { ExceptionsReportComponent } from './team-work-summary/exceptions/exceptions.component';
import { ScheduleDotComponent } from './schedule-dot/schedule-dot.component';
import { SDOTReportComponent } from './schedule-dot/sdot/sdot.component';
import { ReportDashboardComponent } from './dashboard/dashboard.component';
import { BlockUIModule } from 'ng-block-ui';
import { ReportingCommonService } from './common/reporting.common.service';
import { PaygroupCalendarModule } from '@staff/sharedModules/index';
import { ConsolidatedReportComponent } from './consolidated/consolidated.component';
import { TeamMultiTypeaheadModule, AssociateMultiTypeheadModule, BalancesDropdownModule, CalendarPresetModule, OverrideNamesDropdownModule, PaygroupDropdownModule, OddEvenTeamModule } from '@staff/sharedModules/index';

@NgModule({
  entryComponents: [
    AlertComponent
  ],
  declarations: [
    ReportingComponent,
    AlertComponent,
    ParametersComponent,
    ReportingChartManagerComponent,
    ReportingHeaderCompnent,
    TimeDetailReportComponent,
    TrialBalanceReportComponent,
    ExceptionsReportComponent,
    DOTReportComponent,
    TeamWorkSummaryComponent,
    TrialBalanceComponent,
    ReportDashboardComponent,
    ScheduleDotComponent,
    SDOTReportComponent,
    ConsolidatedReportComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReportingRoutingModule,
    NgbModule,
    AgGridModule.withComponents([]),
    PaygroupCalendarModule,
    DatepickerModule,
    DropdownModule,
    CalendarPresetModule,
    TeamMultiTypeaheadModule,
    BalancesDropdownModule,
    AssociateMultiTypeheadModule,
    BlockUIModule.forRoot(),
    OverrideNamesDropdownModule,
    PaygroupDropdownModule,
    OddEvenTeamModule
  ],
  providers: [
    ReportingService,
    ReportingCommonService,
    CurrencyPipe
  ]
})
export class ReportingModule { }
