import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReportingComponent } from './common/reporting.component';
import { TeamWorkSummaryComponent } from './team-work-summary/team-work-summary.component';
import { TrialBalanceComponent } from './team-work-summary/trial-balance.component';
import { ReportDashboardComponent } from './dashboard/dashboard.component';
import { ScheduleDotComponent } from './schedule-dot/schedule-dot.component';
import { ConsolidatedReportComponent } from './consolidated/consolidated.component';

const routes: Routes = [
  {
    path: 'common/:reportid',
    component: ReportingComponent
  },
  {
    path: 'team-work-summary',
    component: TeamWorkSummaryComponent
  },
  {
    path: 'trial-balance',
    component: TrialBalanceComponent
  },
  {
    path: 'schedule-dot',
    component: ScheduleDotComponent
  },
  {
    path: 'dashboard',
    component: ReportDashboardComponent
  },
  {
    path: 'consolidated',
    component: ConsolidatedReportComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportingRoutingModule { }
